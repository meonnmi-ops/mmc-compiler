#!/usr/bin/env python3
"""
mmc_packer.py - prototype packer: GGUF v3  -> .mmc (prototype)

Usage:
    python mmc_packer.py input.gguf output.mmc

Notes:
- This is a prototype. It reads a GGUF v3 file (basic types and tensor index),
  extracts metadata and tensor blobs, writes a compact .mmc format (see MMC_SPEC.md).
- For safety and simplicity the packer fully reads GGUF metadata (could be large).
- The packer stores metadata in JSON (utf-8). Tensor blob bytes are copied unchanged.
"""

import struct
import json
import sys
from functools import reduce
from operator import mul

MAGIC_GGUF = 0x46554747  # "GGUF" little-endian
MMC_MAGIC = b"MMCF"
MMC_VERSION = 1
HEADER_SIZE = 64
ALIGN = 64

# GGUF value types (subset)
GGUF_TYPE_UINT8 = 0
GGUF_TYPE_INT8 = 1
GGUF_TYPE_UINT16 = 2
GGUF_TYPE_INT16 = 3
GGUF_TYPE_UINT32 = 4
GGUF_TYPE_INT32 = 5
GGUF_TYPE_FLOAT32 = 6
GGUF_TYPE_BOOL = 7
GGUF_TYPE_STRING = 8
GGUF_TYPE_ARRAY = 9
GGUF_TYPE_UINT64 = 10
GGUF_TYPE_INT64 = 11
GGUF_TYPE_FLOAT64 = 12

# GGML tensor types (subset mapped into .mmc elem types)
GGML_TYPE_F32 = 0
GGML_TYPE_F16 = 1
GGML_TYPE_BF16 = 2
GGML_TYPE_Q8_0 = 3
GGML_TYPE_Q4_0 = 4
GGML_TYPE_Q4_1 = 5
GGML_TYPE_RAW_UINT8 = 6

def align_up(x, a=ALIGN):
    return ((x + a - 1) // a) * a

def read_gguf_header(f):
    magic = struct.unpack("<I", f.read(4))[0]
    if magic != MAGIC_GGUF:
        raise ValueError("Not a GGUF v3 file (bad magic)")
    version = struct.unpack("<I", f.read(4))[0]
    n_tensors = struct.unpack("<Q", f.read(8))[0]
    n_kv = struct.unpack("<Q", f.read(8))[0]
    return version, n_tensors, n_kv

def read_value(f, dtype):
    if dtype == GGUF_TYPE_UINT8:
        return struct.unpack("<B", f.read(1))[0]
    elif dtype == GGUF_TYPE_INT8:
        return struct.unpack("<b", f.read(1))[0]
    elif dtype == GGUF_TYPE_UINT16:
        return struct.unpack("<H", f.read(2))[0]
    elif dtype == GGUF_TYPE_INT16:
        return struct.unpack("<h", f.read(2))[0]
    elif dtype == GGUF_TYPE_UINT32:
        return struct.unpack("<I", f.read(4))[0]
    elif dtype == GGUF_TYPE_INT32:
        return struct.unpack("<i", f.read(4))[0]
    elif dtype == GGUF_TYPE_UINT64:
        return struct.unpack("<Q", f.read(8))[0]
    elif dtype == GGUF_TYPE_INT64:
        return struct.unpack("<q", f.read(8))[0]
    elif dtype == GGUF_TYPE_FLOAT32:
        return struct.unpack("<f", f.read(4))[0]
    elif dtype == GGUF_TYPE_FLOAT64:
        return struct.unpack("<d", f.read(8))[0]
    elif dtype == GGUF_TYPE_BOOL:
        return struct.unpack("<?", f.read(1))[0]
    elif dtype == GGUF_TYPE_STRING:
        length = struct.unpack("<Q", f.read(8))[0]
        return f.read(length).decode("utf-8", errors="replace")
    elif dtype == GGUF_TYPE_ARRAY:
        elem_type = struct.unpack("<I", f.read(4))[0]
        count = struct.unpack("<Q", f.read(8))[0]
        res = []
        for _ in range(count):
            res.append(read_value(f, elem_type))
        return res
    else:
        raise ValueError("Unknown GGUF value type: %s" % dtype)

def parse_metadata(f, n_kv):
    km = {}
    for _ in range(n_kv):
        key_len_bytes = f.read(8)
        if not key_len_bytes:
            break
        key_len = struct.unpack("<Q", key_len_bytes)[0]
        key = f.read(key_len).decode("utf-8", errors="replace")

        val_type = struct.unpack("<I", f.read(4))[0]
        if val_type == GGUF_TYPE_ARRAY:
            elem_type = struct.unpack("<I", f.read(4))[0]
            count = struct.unpack("<Q", f.read(8))[0]
            # Read array contents (naive)
            arr = []
            for _ in range(count):
                arr.append(read_value(f, elem_type))
            km[key] = arr
        else:
            km[key] = read_value(f, val_type)
    # align 32 bytes (GGUF) before tensor infos
    pos = f.tell()
    aligned = ((pos + 31) // 32) * 32
    if aligned > pos:
        f.seek(aligned)
    return km

def parse_tensor_infos(f, n_tensors):
    infos = []
    for _ in range(n_tensors):
        name_len = struct.unpack("<Q", f.read(8))[0]
        if name_len > 10000:
            raise ValueError("Suspicious tensor name length")
        name = f.read(name_len).decode("utf-8", errors="replace")

        n_dims = struct.unpack("<I", f.read(4))[0]
        dims = []
        for _ in range(n_dims):
            dims.append(struct.unpack("<Q", f.read(8))[0])

        tensor_type = struct.unpack("<I", f.read(4))[0]
        offset = struct.unpack("<Q", f.read(8))[0]
        infos.append({
            "name": name,
            "n_dims": n_dims,
            "dims": dims,
            "type": tensor_type,
            "offset": offset
        })
    # align 32 bytes
    pos = f.tell()
    aligned = ((pos + 31) // 32) * 32
    if aligned > pos:
        f.seek(aligned)
    data_start = f.tell()
    return infos, data_start

def gguf_type_size(elem_type, dims):
    # dims: list -> product
    n_total = 1 if len(dims) == 0 else reduce(mul, dims, 1)
    if elem_type == GGML_TYPE_F32:
        return n_total * 4
    elif elem_type == GGML_TYPE_F16 or elem_type == GGML_TYPE_BF16:
        return n_total * 2
    elif elem_type == GGML_TYPE_Q8_0:
        QK = 32
        block_size = 2 + QK
        n_blocks = (n_total + QK - 1) // QK
        return n_blocks * block_size
    elif elem_type == GGML_TYPE_Q4_0:
        QK = 32
        block_size = 2 + QK // 2
        n_blocks = (n_total + QK - 1) // QK
        return n_blocks * block_size
    elif elem_type == GGML_TYPE_Q4_1:
        QK = 32
        block_size = 2 + 2 + QK // 2
        n_blocks = (n_total + QK - 1) // QK
        return n_blocks * block_size
    else:
        # fallback: unknown format can't be sized; raise
        raise NotImplementedError("Type size not implemented for elem_type %d" % elem_type)

def convert_gguf_to_mmc(gguf_path, mmc_path):
    with open(gguf_path, "rb") as f:
        version, n_tensors, n_kv = read_gguf_header(f)
        print("GGUF version", version, "tensors", n_tensors, "kv", n_kv)
        metadata = parse_metadata(f, n_kv)
        tensor_infos, data_start = parse_tensor_infos(f, n_tensors)

        # read tensor blobs (from data_start + offset)
        for ti in tensor_infos:
            elem_type = ti["type"]
            dims = ti["dims"]
            size = gguf_type_size(elem_type, dims)
            f.seek(data_start + ti["offset"])
            blob = f.read(size)
            ti["byte_size"] = len(blob)
            ti["_blob"] = blob

    # Prepare .mmc metadata JSON
    mmc_metadata = {
        "source": "gguf",
        "gguf_version": version,
        "gguf_metadata": metadata,
        "n_tensors": len(tensor_infos)
    }
    metadata_bytes = json.dumps(mmc_metadata, ensure_ascii=False).encode("utf-8")
    metadata_size = len(metadata_bytes)

    # compute index and offsets
    index_entries = []
    # we will write header (64), metadata (aligned), then index, then tensor blobs
    metadata_offset = HEADER_SIZE
    metadata_pad = align_up(metadata_size) - metadata_size
    index_offset = metadata_offset + metadata_size + metadata_pad

    # compute where blobs will start: index size depends on names/dims; generate index entries first with placeholders
    # We'll build index in memory, compute its size, then fix data offsets
    index_bytes = bytearray()
    for ti in tensor_infos:
        name_b = ti["name"].encode("utf-8")
        index_bytes += struct.pack("<I", len(name_b))
        index_bytes += name_b
        index_bytes += struct.pack("<I", ti["n_dims"])
        for d in ti["dims"]:
            index_bytes += struct.pack("<Q", d)
        # map gguf tensor type to mmc elem_type (we reuse the GGML type numeric values)
        index_bytes += struct.pack("<I", ti["type"])
        # placeholders for offset and size (will fill later)
        index_bytes += struct.pack("<Q", 0)  # data_offset placeholder
        index_bytes += struct.pack("<Q", ti["byte_size"])
    index_size = len(index_bytes)
    index_pad = 0  # we don't require extra pad for the index itself; data start will be aligned
    data_start = index_offset + index_size + index_pad
    data_start = align_up(data_start)

    # fill data offsets
    cur = data_start
    final_blobs = []
    idx_cursor = 0
    out_index = bytearray()
    for ti in tensor_infos:
        name_b = ti["name"].encode("utf-8")
        out_index += struct.pack("<I", len(name_b))
        out_index += name_b
        out_index += struct.pack("<I", ti["n_dims"])
        for d in ti["dims"]:
            out_index += struct.pack("<Q", d)
        out_index += struct.pack("<I", ti["type"])
        out_index += struct.pack("<Q", cur)
        out_index += struct.pack("<Q", ti["byte_size"])
        final_blobs.append(ti["_blob"])
        cur += ti["byte_size"]
        # align each blob start to 64 bytes for performance
        cur = align_up(cur)

    # Write .mmc
    with open(mmc_path, "wb") as out:
        # header
        header = bytearray(HEADER_SIZE)
        header[0:4] = MMC_MAGIC
        header[4:8] = struct.pack("<I", MMC_VERSION)
        header[8:16] = struct.pack("<Q", metadata_size)
        header[16:20] = struct.pack("<I", len(tensor_infos))
        header[20:28] = struct.pack("<Q", index_offset)
        # rest reserved / zero
        out.write(header)

        # metadata
        out.write(metadata_bytes)
        if metadata_pad:
            out.write(b"\x00" * metadata_pad)

        # index
        out.write(out_index)
        # pad up to aligned data_start
        cur_pos = out.tell()
        if cur_pos < data_start:
            out.write(b"\x00" * (data_start - cur_pos))

        # tensor blobs
        for blob in final_blobs:
            out.write(blob)
            # pad to 64-byte for next blob
            pos = out.tell()
            pad = align_up(pos) - pos
            if pad:
                out.write(b"\x00" * pad)

    print("Wrote .mmc:", mmc_path, "metadata_size:", metadata_size, "n_tensors:", len(tensor_infos))


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python mmc_packer.py input.gguf output.mmc")
        sys.exit(1)
    convert_gguf_to_mmc(sys.argv[1], sys.argv[2])