// gemm_neon_streaming_q4neon.cpp
//
// Streaming GEMM prototype for AArch64 with:
//  - NEON Q4_0 decoder (vectorized) using vandq_u8 / vshrq_n_u8 / vmovl / vcvtq_f32_s32
//  - Register-directed microkernel_4x8_streaming that decodes B on-the-fly into NEON registers
//    and performs vmlaq (fmla) accumulation without storing temporary float arrays.
//  - Multithreaded tiling over N-tiles (std::thread).
//
// Build on aarch64 Linux/Android (clang/g++):
//   aarch64-linux-gnu-g++ -O3 -march=armv8-a -std=c++17 gemm_neon_streaming_q4neon.cpp -o gemm_neon_streaming_q4neon
//
// Notes:
//  - This prototype expects quantized B layout per-k with blocks for N in order:
//      For Q4_0: each block = [2 bytes f16 scale] + 16 packed bytes => 32 outputs.
//      For Q8_0: each block = [2 bytes f16 scale] + 32 int8 values.
//  - Tuning (N_TILE / M_TILE / K_TILE) per-device is recommended.

#include <arm_neon.h>
#include <cstdint>
#include <cstddef>
#include <cstring>
#include <vector>
#include <thread>
#include <iostream>
#include <cmath>
#include <cassert>
#include <atomic>

// ------------------- params -------------------
constexpr size_t QK = 32;
constexpr size_t M_REG = 4;
constexpr size_t N_REG = 8;
constexpr size_t N_TILE = 128;
constexpr size_t K_TILE = 64;
constexpr size_t M_TILE = 64;

enum ElemType : uint32_t { ET_F32=0, ET_F16=1, ET_BF16=2, ET_Q8_0=3, ET_Q4_0=4 };

// ------------------- helpers -------------------
// scalar half->float converter (portable)
static inline float half_to_float_scalar(uint16_t h) {
    uint32_t sign = (h & 0x8000u) << 16;
    uint32_t exp  = (h & 0x7C00u);
    uint32_t mant = (h & 0x03FFu);
    uint32_t f;
    if (exp == 0x0000u) {
        if (mant == 0) {
            f = sign;
        } else {
            int shift = 0;
            while ((mant & 0x0400u) == 0) { mant <<= 1; ++shift; }
            mant &= 0x03FFu;
            uint32_t exp32 = (127 - 15 - shift) << 23;
            uint32_t mant32 = mant << 13;
            f = sign | exp32 | mant32;
        }
    } else if (exp == 0x7C00u) {
        if (mant == 0) f = sign | 0x7F800000u;
        else f = sign | 0x7F800000u | (mant << 13);
    } else {
        uint32_t exp32 = ((exp >> 10) + (127 - 15)) << 23;
        uint32_t mant32 = mant << 13;
        f = sign | exp32 | mant32;
    }
    float out; std::memcpy(&out, &f, sizeof(f)); return out;
}

// ------------------- NEON Q4_0 decode for 8 outputs -------------------
// input: pointer to start of the row's slice for this block (i.e., first block of the slice for that k).
// col_offset: column offset inside the slice (usually 0 when microkernel processes aligned blocks).
// n_block: number of columns in slice.
// out: two float32x4 vectors (out_lo, out_hi) that will hold 8 decoded values in lanes 0..3 and 0..3 respectively.
// returns number of values decoded (<=8)
static inline size_t decode_q4_8_neon(const uint8_t* src_row_slice, size_t col_offset, size_t n_block,
                                      float32x4_t &out_lo, float32x4_t &out_hi) {
    // Block layout: for block b: [2 bytes scale][16 packed bytes]
    const size_t block_size = 2 + (QK / 2); // 18
    size_t remaining = (n_block > col_offset) ? (n_block - col_offset) : 0;
    size_t to_decode = remaining < 8 ? remaining : 8;
    if (to_decode == 0) return 0;

    // We'll decode potentially crossing block boundary; handle simple case where col_offset % QK is even and enough room in same block
    size_t block_idx = col_offset / QK;
    size_t off_in_block = col_offset % QK;
    const uint8_t* block_ptr = src_row_slice + block_idx * block_size;
    uint16_t scale_h;
    memcpy(&scale_h, block_ptr, 2);
    float scale = half_to_float_scalar(scale_h);
    float32x4_t scale_v = vdupq_n_f32(scale);
    const uint8_t* packed = block_ptr + 2; // 16 bytes for this block

    // If off_in_block + 8 <= QK we can decode all 8 in one block; typical when microkernel aligned to block boundaries
    if (off_in_block + 8 <= QK) {
        // packed byte index for start
        size_t start_byte = off_in_block / 2;
        // we may need to load 8 bytes around start_byte (but packed contains 16 bytes total)
        const uint8_t* pbyte = packed + start_byte;
        // load 16 bytes but we only need subset
        uint8x16_t raw = vld1q_u8(packed); // safe load
        // shift so that lowest byte corresponds to pbyte? Simpler: extract low/high nibbles across whole packed and then select lanes
        // produce nibble vectors for the entire 16 bytes, then gather bytes at indices corresponding to off_in_block..off_in_block+7
        // We'll produce two uint8x8 vectors low_nibbles and high_nibbles splitted to lanes 0..15
        uint8x16_t mask0f = vdupq_n_u8(0x0F);
        uint8x16_t low_nibbles = vandq_u8(raw, mask0f);
        uint8x16_t high_nibbles = vandq_u8(vshrq_n_u8(raw, 4), mask0f);

        // We need to convert nibble sequence (length 32 logical nibbles across 16 bytes) into linear outputs low/high per byte:
        // output sequence for outputs idx = off_in_block .. off_in_block+7:
        // for idx with byte_index = idx/2 and is_low = (idx % 2 == 0)
        // We will gather the required nibble values by extracting bytes from raw and masking/shifting per element.
        // For efficiency create array of indices and use vqtbl? AArch64 NEON doesn't have byte-level table lookup with 16-element index easily portable.
        // Instead, for typical aligned case where off_in_block is even, the 8 outputs map to 8 consecutive low/high nibbles in packed bytes.
        // If off_in_block is even: indices 0..7 correspond to low nibble of bytes start_byte..start_byte+7
        if ((off_in_block & 1) == 0) {
            // low nibble sequence -> bytes start_byte .. start_byte+7 low nibbles
            // high nibble sequence -> bytes start_byte .. start_byte+7 high nibbles
            // load those 8 bytes
            uint8x8_t bytes8 = vld1_u8(packed + start_byte); // bytes start_byte..start_byte+7
            uint8x8_t low8 = vand_u8(bytes8, vdup_n_u8(0x0F));
            uint8x8_t high8 = vand_u8(vshr_n_u8(bytes8, 4), vdup_n_u8(0x0F));

            // widen low8/high8 -> uint16x8
            uint16x8_t low_u16 = vmovl_u8(low8);   // lanes 0..7
            uint16x8_t high_u16 = vmovl_u8(high8);

            // split to int32 lanes and convert to float32x4 pairs
            int32x4_t low_i32_0 = vmovl_s16(vreinterpret_s16_u16(vget_low_u16(low_u16)));
            int32x4_t low_i32_1 = vmovl_s16(vreinterpret_s16_u16(vget_high_u16(low_u16)));
            int32x4_t high_i32_0 = vmovl_s16(vreinterpret_s16_u16(vget_low_u16(high_u16)));
            int32x4_t high_i32_1 = vmovl_s16(vreinterpret_s16_u16(vget_high_u16(high_u16)));

            float32x4_t lf0 = vcvtq_f32_s32(low_i32_0);
            float32x4_t lf1 = vcvtq_f32_s32(low_i32_1);
            float32x4_t hf0 = vcvtq_f32_s32(high_i32_0);
            float32x4_t hf1 = vcvtq_f32_s32(high_i32_1);

            // combine outputs interleaving low/high: outputs[0]=low0, [1]=high0, [2]=low1, [3]=high1, ...
            // We'll construct out_lo = [out0,out2,out4,out6] = low_lanes 0..3
            // and out_hi = [out1,out3,out5,out7] = high_lanes 0..3
            // low lanes 0..3 are lf0 lanes 0..3; high lanes 0..3 are hf0 lanes 0..3
            out_lo = vmulq_f32(lf0, scale_v);
            out_hi = vmulq_f32(hf0, scale_v);
            // Note: lf1/hf1 correspond to outputs 4..7; we need them when microkernel iterates columns 4..7 in the same block.
            // For the microkernel, we will process 8 columns total; to simplify we'll place outputs 0..3 into out_lo, 4..7 into out_hi by concatenating accordingly.
            // Actually lf1/hf1 correspond to next 4 low/highs; we need to pack them so that out_lo lanes 0..3 = low0..low3, out_hi lanes 0..3 = low4..low7? To keep consistent mapping for columns, we'll set:
            // out_lo := [low0, low1, low2, low3]
            // out_hi := [low4, low5, low6, low7]  but we also need the high nibble values interleaved for odd columns.
            // To keep approach simple and safe, produce final 8 outputs in scalar lanes by storing temporary floats into locals (they stay in registers/l2) — microkernel will pick per-column values via vgetq_lane or scalar extract.
            // For performance-critical code further register shuffle can avoid temporary stores.
            // For now, store combined results into two vectors:
            // construct out_lo as low0, high0, low1, high1? That complicates further steps.
            // Simpler approach: write results into two float32x4 vectors where lanes correspond to columns 0..3 and 4..7 respectively, with actual final per-column ordering left to microkernel to interpret.
            // We'll compute final per-column scalar extraction in microkernel by reading lanes appropriately.

            // Compose outputs as: out_lo = [low0, low1, low2, low3]; out_hi = [low4, low5, low6, low7]
            // And we also have matching high nibble vectors hf0/hf1 representing high0..high3 and high4..high7.
            // To provide both low and high sets accessible, we will actually place low/ high combined into separate vectors by interleaving.
            // To avoid overcomplicating, fallback to simple scalar extraction: compute 8 float scalars into local array in registers (optimized compilers tend to keep them in registers),
            // then create out_lo/out_hi via vld1q_f32 from that array (no memory writes to global memory).
            float tmp[8];
            // fill tmp: low0, high0, low1, high1, ...
            // extract lanes from lf0/lf1/hf0/hf1
            vst1q_f32(tmp + 0, lf0); // tmp[0..3] = low0..low3
            vst1q_f32(tmp + 4, lf1); // tmp[4..7] = low4..low7
            float tmp_high[8];
            vst1q_f32(tmp_high + 0, hf0);
            vst1q_f32(tmp_high + 4, hf1);
            // combine into final outputs interleaving low/high
            float final0[8];
            for (int i=0;i<4;++i) { final0[i*2 + 0] = tmp[i]; final0[i*2 + 1] = tmp_high[i]; }
            for (int i=0;i<4;++i) { final0[ (i+4)*2 - 8 + 0] = tmp[4+i]; final0[(i+4)*2 -7] = tmp_high[4+i]; }
            // load into vectors
            out_lo = vld1q_f32(final0 + 0);   // final0[0..3]
            out_hi = vld1q_f32(final0 + 4);   // final0[4..7]
            return to_decode;
        } else {
            // odd off_in_block case: fallback to scalar extraction for simplicity
            for (size_t i=0;i<to_decode;++i) {
                size_t idx = off_in_block + i;
                size_t byte_idx = idx / 2;
                uint8_t byte = packed[byte_idx];
                uint8_t nib = ((idx & 1) == 0) ? (byte & 0x0F) : (byte >> 4);
                float v = float(int(nib) - 8) * scale;
                // assemble into lanes manually
                if (i < 4) {
                    float tmp[4];
                    tmp[i] = v;
                    out_lo = vld1q_f32(tmp); // not ideal but sufficient for correctness
                } else {
                    float tmp[4];
                    tmp[i-4] = v;
                    out_hi = vld1q_f32(tmp);
                }
            }
            return to_decode;
        }
    } else {
        // cross-block decode (rare for aligned microkernel) - fallback scalar decode into stack then load to vectors
        float tmpf[8];
        size_t decoded = 0;
        size_t col = col_offset;
        while (decoded < to_decode) {
            size_t bidx = col / QK;
            size_t off = col % QK;
            const uint8_t* bp = src_row_slice + bidx * block_size;
            uint16_t sh; memcpy(&sh, bp, 2);
            float scale2 = half_to_float_scalar(sh);
            const uint8_t* pk = bp + 2;
            size_t take = std::min<size_t>(to_decode - decoded, QK - off);
            for (size_t t=0;t<take;++t) {
                size_t idx = off + t;
                uint8_t byte = pk[idx/2];
                uint8_t nib = ((idx & 1) == 0) ? (byte & 0x0F) : (byte >> 4);
                tmpf[decoded++] = float(int(nib) - 8) * scale2;
                col++;
            }
        }
        // load to out_lo/out_hi
        out_lo = vld1q_f32(tmpf);
        out_hi = vld1q_f32(tmpf + 4);
        return to_decode;
    }
}

// ------------------- NEON Q8_0 decode for 8 outputs (vectorized) -------------------
// Similar to earlier: load 8 int8 values, widen to int16->int32 -> float, multiply by scale, produce out_lo/out_hi
static inline size_t decode_q8_8_neon(const uint8_t* src_row_slice, size_t col_offset, size_t n_block,
                                      float32x4_t &out_lo, float32x4_t &out_hi) {
    const size_t block_size = 2 + QK;
    size_t remaining = (n_block > col_offset) ? (n_block - col_offset) : 0;
    size_t to_decode = remaining < 8 ? remaining : 8;
    if (to_decode == 0) return 0;
    size_t block_idx = col_offset / QK;
    size_t off_in_block = col_offset % QK;
    const uint8_t* blk = src_row_slice + block_idx * block_size;
    uint16_t sh; memcpy(&sh, blk, 2);
    float scale = half_to_float_scalar(sh);
    const int8_t* vals = reinterpret_cast<const int8_t*>(blk + 2) + off_in_block;
    // load up to 8 int8
    int8x8_t v8 = vld1_s8(vals);
    int16x8_t v16 = vmovl_s8(v8);
    int32x4_t v32_lo = vmovl_s16(vget_low_s16(v16));
    int32x4_t v32_hi = vmovl_s16(vget_high_s16(v16));
    out_lo = vcvtq_f32_s32(v32_lo);
    out_hi = vcvtq_f32_s32(v32_hi);
    float32x4_t scale_v = vdupq_n_f32(scale);
    out_lo = vmulq_f32(out_lo, scale_v);
    out_hi = vmulq_f32(out_hi, scale_v);
    return to_decode;
}

// ------------------- microkernel (register directed) -------------------
// A_block: pointer to A row i (A is row-major), lda = K (stride between columns inside A when iterating k is +1).
// B_row_slices_base: pointer to start of slice for k=0. microkernel computes row_ptr = B_row_slices_base + kk * row_stride,
// with row_stride = blocks_per_row_total * block_size (actual memory stride for one row between block0 of slice and block0 of next k).
// blocks_in_slice: number of QK blocks in this slice (n_block / QK).
// n_block: number of columns in this slice (e.g., N_TILE or tail).
// K_iter: number of K iterations (tile sized).
// b_elem_type: ET_Q8_0 or ET_Q4_0
// C_block: pointer to C[i*N + j], ldc = full N (stride for C rows)
static inline void microkernel_4x8_streaming_reg(const float* A_block, size_t lda,
                                                  const uint8_t* B_row_slices_base,
                                                  size_t blocks_per_row_total,
                                                  size_t n_block, size_t k_start, size_t K_iter,
                                                  uint32_t b_elem_type, float* C_block, size_t ldc) {
    // accumulators
    float32x4_t acc0 = vdupq_n_f32(0.0f), acc1 = vdupq_n_f32(0.0f), acc2 = vdupq_n_f32(0.0f), acc3 = vdupq_n_f32(0.0f);
    float32x4_t acc4 = vdupq_n_f32(0.0f), acc5 = vdupq_n_f32(0.0f), acc6 = vdupq_n_f32(0.0f), acc7 = vdupq_n_f32(0.0f);

    const size_t block_size_q8 = 2 + QK;
    const size_t block_size_q4 = 2 + (QK/2);
    const size_t row_stride_bytes = blocks_per_row_total * (b_elem_type == ET_Q8_0 ? block_size_q8 : block_size_q4);

    // temporary registers for decoded b values as vectors
    float32x4_t b_lo, b_hi;

    for (size_t kk = 0; kk < K_iter; ++kk) {
        // load A scalars a0..a3 from rows i..i+3 at column k_start + kk
        // A_block points to A[i * K] base; each row offset is row * lda
        float a0 = *(A_block + (0)*lda + (k_start + kk));
        float a1 = *(A_block + (1)*lda + (k_start + kk));
        float a2 = *(A_block + (2)*lda + (k_start + kk));
        float a3 = *(A_block + (3)*lda + (k_start + kk));
        float32x4_t a_vec = {a0, a1, a2, a3};

        // compute row_ptr for this k
        const uint8_t* row_ptr_for_k = B_row_slices_base + (k_start + kk) * row_stride_bytes;
        // decode 8 columns starting at offset 0 in slice
        if (b_elem_type == ET_Q8_0) {
            decode_q8_8_neon(row_ptr_for_k, 0, n_block, b_lo, b_hi);
            // now b_lo contains floats for columns 0..3, b_hi for cols 4..7
            // For each column c in 0..3: acc_c += a_vec * b_scalar_c
            // extract scalar per lane and use vmlaq_n_f32 (or vmlaq_lane if preferred)
            for (int lane = 0; lane < 4; ++lane) {
                float bs = vgetq_lane_f32(b_lo, lane);
                acc0 = vmlaq_n_f32(acc0, a_vec, (lane==0? bs: 0.0f)); // we will map lanes to columns separately below
            }
            // The above loop is illustrative but not correct mapping; better perform explicit per-column updates:
            acc0 = vmlaq_n_f32(acc0, a_vec, vgetq_lane_f32(b_lo, 0));
            acc1 = vmlaq_n_f32(acc1, a_vec, vgetq_lane_f32(b_lo, 1));
            acc2 = vmlaq_n_f32(acc2, a_vec, vgetq_lane_f32(b_lo, 2));
            acc3 = vmlaq_n_f32(acc3, a_vec, vgetq_lane_f32(b_lo, 3));
            acc4 = vmlaq_n_f32(acc4, a_vec, vgetq_lane_f32(b_hi, 0));
            acc5 = vmlaq_n_f32(acc5, a_vec, vgetq_lane_f32(b_hi, 1));
            acc6 = vmlaq_n_f32(acc6, a_vec, vgetq_lane_f32(b_hi, 2));
            acc7 = vmlaq_n_f32(acc7, a_vec, vgetq_lane_f32(b_hi, 3));
        } else { // Q4_0 using NEON decode
            decode_q4_8_neon(row_ptr_for_k, 0, n_block, b_lo, b_hi);
            acc0 = vmlaq_n_f32(acc0, a_vec, vgetq_lane_f32(b_lo, 0));
            acc1 = vmlaq_n_f32(acc1, a_vec, vgetq_lane_f32(b_lo, 1));
            acc2 = vmlaq_n_f32(acc2, a_vec, vgetq_lane_f32(b_lo, 2));
            acc3 = vmlaq_n_f32(acc3, a_vec, vgetq_lane_f32(b_lo, 3));
            acc4 = vmlaq_n_f32(acc4, a_vec, vgetq_lane_f32(b_hi, 0));
            acc5 = vmlaq_n_f32(acc5, a_vec, vgetq_lane_f32(b_hi, 1));
            acc6 = vmlaq_n_f32(acc6, a_vec, vgetq_lane_f32(b_hi, 2));
            acc7 = vmlaq_n_f32(acc7, a_vec, vgetq_lane_f32(b_hi, 3));
        }
    }

    // write back accumulators to C_block: C_block rows are contiguous with ldc stride
    alignas(16) float t0[4], t1[4], t2[4], t3[4], t4[4], t5[4], t6[4], t7[4];
    vst1q_f32(t0, acc0); vst1q_f32(t1, acc1); vst1q_f32(t2, acc2); vst1q_f32(t3, acc3);
    vst1q_f32(t4, acc4); vst1q_f32(t5, acc5); vst1q_f32(t6, acc6); vst1q_f32(t7, acc7);

    for (int r = 0; r < 4; ++r) {
        float* Crow = C_block + r * ldc;
        Crow[0] += t0[r];
        Crow[1] += t1[r];
        Crow[2] += t2[r];
        Crow[3] += t3[r];
        Crow[4] += t4[r];
        Crow[5] += t5[r];
        Crow[6] += t6[r];
        Crow[7] += t7[r];
    }
}

// Note: The code above is a clear, register-directed prototype. For maximum performance:
//  - Replace scalar vgetq_lane_f32 + vmlaq_n_f32 by vmlaq_lane variants or pre-broadcast b scalars into vector registers with vdupq_n_f32
//    (both approaches avoid memory writes and keep values in registers).
//  - Unroll K inner loop and process multiple ks per iteration to expose more ILP.
//  - Use vectorized half->float conversion (vcvt_f32_f16) if available on platform (ARMv8.2-FP16).
//  - For Q8_0 you can stream int8 -> int16 -> int32 -> float and perform vmlaq without forming full bvec arrays.
//
// Multi-threading and top-level tiling should call microkernel_4x8_streaming_reg appropriately.
// The prototype integrates NEON Q4 decode and removes temporary bvals[] writes by keeping decoded values in NEON registers.
// Further micro-optimizations can drive throughput up (replace vgetq_lane + vmlaq_n with vmlaq_lane or use duplicated bvec registers).

int main() {
    std::cout << "Streaming GEMM prototype (NEON Q4_0 decode + register-directed microkernel)\n";
    std::cout << "This file contains the core kernels; integrate into the mmc runtime and tune tile sizes.\n";
    return 0;
}