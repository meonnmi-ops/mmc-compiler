// Simple mmc_reader prototype (POSIX) - memory-maps .mmc and lists header, metadata, and tensors.
// Build (Linux/macOS): g++ -std=c++17 mmc_reader.cpp -O2 -o mmc_reader
// Run: ./mmc_reader model.mmc

#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

#include <cstdint>
#include <cstring>
#include <iostream>
#include <string>
#include <vector>
#include <stdexcept>

struct MmcHeader {
    char magic[4];   // "MMCF"
    uint32_t version;
    uint64_t metadata_size;
    uint32_t n_tensors;
    uint64_t index_offset;
    // total header = 64 bytes; rest is reserved
};

static inline size_t align_up(size_t x, size_t a=64) {
    return ((x + a - 1) / a) * a;
}

int main(int argc, char** argv) {
    if (argc != 2) {
        std::cerr << "Usage: " << argv[0] << " model.mmc\n";
        return 1;
    }
    const char* path = argv[1];

    int fd = open(path, O_RDONLY);
    if (fd < 0) {
        perror("open");
        return 1;
    }

    struct stat st;
    if (fstat(fd, &st) != 0) {
        perror("fstat");
        close(fd);
        return 1;
    }
    size_t size = st.st_size;
    if (size < sizeof(MmcHeader)) {
        std::cerr << "File too small\n";
        close(fd);
        return 1;
    }

    void* p = mmap(nullptr, size, PROT_READ, MAP_PRIVATE, fd, 0);
    if (p == MAP_FAILED) {
        perror("mmap");
        close(fd);
        return 1;
    }

    uint8_t* base = reinterpret_cast<uint8_t*>(p);

    MmcHeader header;
    memcpy(&header, base, sizeof(MmcHeader));
    if (std::memcmp(header.magic, "MMCF", 4) != 0) {
        std::cerr << "Bad MMC magic\n";
        munmap(p, size);
        close(fd);
        return 1;
    }
    std::cout << "MMC version " << header.version << ", metadata_size="
              << header.metadata_size << ", n_tensors=" << header.n_tensors
              << ", index_offset=" << header.index_offset << "\n";

    // read metadata JSON blob (not parsing JSON here)
    if (header.metadata_size > 0) {
        size_t meta_off = sizeof(MmcHeader);
        if (meta_off + header.metadata_size > size) {
            std::cerr << "Metadata out of range\n";
            munmap(p, size);
            close(fd);
            return 1;
        }
        std::string meta((char*)(base + meta_off), header.metadata_size);
        std::cout << "Metadata (first 512 chars):\n";
        std::cout << meta.substr(0, 512) << (meta.size() > 512 ? "...\n" : "\n");
    }

    // walk the index
    size_t idx = header.index_offset;
    for (uint32_t ti = 0; ti < header.n_tensors; ++ti) {
        if (idx + 4 > size) { std::cerr << "Index truncated\n"; break; }
        uint32_t name_len = *reinterpret_cast<uint32_t*>(base + idx);
        idx += 4;
        if (idx + name_len > size) { std::cerr << "Index name truncated\n"; break; }
        std::string name((char*)(base + idx), name_len);
        idx += name_len;
        if (idx + 4 > size) { std::cerr << "Index truncated (n_dims)\n"; break; }
        uint32_t n_dims = *reinterpret_cast<uint32_t*>(base + idx);
        idx += 4;
        std::vector<uint64_t> dims;
        dims.reserve(n_dims);
        for (uint32_t d = 0; d < n_dims; ++d) {
            if (idx + 8 > size) { std::cerr << "Index dims truncated\n"; break; }
            uint64_t dv = *reinterpret_cast<uint64_t*>(base + idx);
            idx += 8;
            dims.push_back(dv);
        }
        if (idx + 4 + 8 + 8 > size) { std::cerr << "Index entry truncated\n"; break; }
        uint32_t elem_type = *reinterpret_cast<uint32_t*>(base + idx);
        idx += 4;
        uint64_t data_offset = *reinterpret_cast<uint64_t*>(base + idx);
        idx += 8;
        uint64_t data_size = *reinterpret_cast<uint64_t*>(base + idx);
        idx += 8;

        std::cout << "Tensor[" << ti << "]: name='" << name << "' type=" << elem_type
                  << " dims=[";
        for (size_t i=0;i<dims.size();++i){ if (i) std::cout << ","; std::cout << dims[i]; }
        std::cout << "] data_offset=" << data_offset << " data_size=" << data_size << "\n";

        // Example: create pointer to tensor bytes inside mmap (no copy)
        if (data_offset + data_size <= size) {
            const uint8_t* tptr = base + data_offset;
            // For debugging, e.g., print first bytes
            size_t show = std::min<size_t>(16, data_size);
            std::cout << "  data[0.." << show << "]:";
            for (size_t b = 0; b < show; ++b) {
                printf(" %02x", tptr[b]);
            }
            std::cout << "\n";
        } else {
            std::cout << "  -> data out of file bounds\n";
        }
    }

    munmap(p, size);
    close(fd);
    return 0;
}