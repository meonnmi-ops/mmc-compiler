name=dequant_avx2_q8_q4.cpp
```cpp
// dequant_avx2_q8_q4.cpp
//
// AVX2 implementations (with scalar fallbacks) for GGUF-style Q8_0 and Q4_0 blocks.
//
// Build: g++ -O3 -mavx2 -mf16c -msse4.1 dequant_avx2_q8_q4.cpp -o dequant_test
//
// Notes:
//  - Assumes little-endian layout: each block begins with 2-byte float16 (IEEE 754 half) scale,
//    followed by 32 int8 values (Q8_0) OR 16 packed bytes (Q4_0).
//  - Input `src` points to contiguous blocks (no header). Functions accept n_elements (total
//    number of output elements) to handle trailing partial blocks.
//  - Functions write n_elements floats into dst[] (caller allocated).
//  - Requires AVX2 & SSE4.1 for the optimized path; scalar fallback used if not enabled.

#include <immintrin.h>
#include <cstdint>
#include <cstddef>
#include <cstring>
#include <cassert>
#include <cmath>

// ---------- helper: half -> float (portable scalar) ----------
// Convert IEEE-754 binary16 (uint16_t) to float (32-bit).
// This implementation is branchless and reasonably fast for scalar conversion.
// Reference idea: convert to float32 by reconstructing exponent/mantissa.
static inline float half_to_float(uint16_t h) {
    // Based on well-known bit-twiddling conversion.
    uint32_t sign = (h & 0x8000u) << 16;
    uint32_t exp  = (h & 0x7C00u);
    uint32_t mant = (h & 0x03FFu);

    uint32_t f;
    if (exp == 0x0000u) {
        if (mant == 0) {
            // zero
            f = sign;
        } else {
            // subnormal -> normalize
            // shift mantissa until leading 1
            int shift = 0;
            while ((mant & 0x0400u) == 0) {
                mant <<= 1;
                shift++;
            }
            mant &= 0x03FFu; // remove leading 1
            uint32_t exp32 = (127 - 15 - shift) << 23;
            uint32_t mant32 = mant << 13;
            f = sign | exp32 | mant32;
        }
    } else if (exp == 0x7C00u) {
        // inf or NaN
        if (mant == 0) {
            f = sign | 0x7F800000u; // inf
        } else {
            f = sign | 0x7F800000u | (mant << 13); // NaN (propagate mantissa)
        }
    } else {
        // normalized
        uint32_t exp32 = ((exp >> 10) + (127 - 15)) << 23;
        uint32_t mant32 = mant << 13;
        f = sign | exp32 | mant32;
    }
    float out;
    std::memcpy(&out, &f, sizeof(f));
    return out;
}

// ---------- Q8_0 dequant (AVX2) ----------
// Q8_0 block: [2 bytes f16 scale][32 bytes int8 values] = 34 bytes per block.
// src must point to the first byte of first block. dst must have space for n_elements floats.
void dequant_q8_0_avx2(const uint8_t* src, size_t n_elements, float* dst) {
    const size_t QK = 32;
    const size_t block_size = 2 + QK;
    size_t n_blocks = (n_elements + QK - 1) / QK;
    size_t produced = 0;

#if defined(__AVX2__) && defined(__SSE4_1__)
    for (size_t b = 0; b < n_blocks; ++b) {
        const uint8_t* block = src + b * block_size;
        uint16_t scale_h;
        std::memcpy(&scale_h, block, sizeof(uint16_t)); // little-endian
        float scale = half_to_float(scale_h); // scalar conversion; small cost

        const uint8_t* vals = block + 2;
        // process first 16 int8
        __m128i v8_0 = _mm_loadu_si128((const __m128i*)(vals));       // bytes 0..15
        __m128i v8_1 = _mm_loadu_si128((const __m128i*)(vals + 16));  // bytes 16..31

        // sign-extend 8-bit -> 16-bit (SSE4.1)
        __m256i v16_lo = _mm256_cvtepi8_epi16(v8_0); // 16 x int16 in 256-bit lane
        __m256i v16_hi = _mm256_cvtepi8_epi16(v8_1);

        // split into two 128-bit halves of 16-bit, then to 32-bit and convert to float
        __m128i v16_lo_lo = _mm256_castsi256_si128(v16_lo);
        __m128i v16_lo_hi = _mm256_extracti128_si256(v16_lo, 1);
        __m128i v16_hi_lo = _mm256_castsi256_si128(v16_hi);
        __m128i v16_hi_hi = _mm256_extracti128_si256(v16_hi, 1);

        __m256i v32_0 = _mm256_cvtepi16_epi32(v16_lo_lo); // 8 x int32
        __m256i v32_1 = _mm256_cvtepi16_epi32(v16_lo_hi);
        __m256i v32_2 = _mm256_cvtepi16_epi32(v16_hi_lo);
        __m256i v32_3 = _mm256_cvtepi16_epi32(v16_hi_hi);

        __m256 f0 = _mm256_cvtepi32_ps(v32_0);
        __m256 f1 = _mm256_cvtepi32_ps(v32_1);
        __m256 f2 = _mm256_cvtepi32_ps(v32_2);
        __m256 f3 = _mm256_cvtepi32_ps(v32_3);

        __m256 scale_ps = _mm256_set1_ps(scale);

        // multiply and store (we must avoid writing past n_elements)
        size_t remain = n_elements - produced;
        // store f0..f3 in order to dst+produced
        if (remain >= 8) {
            _mm256_storeu_ps(dst + produced, _mm256_mul_ps(f0, scale_ps)); produced += 8; remain -= 8;
        } else {
            alignas(32) float tmp[8];
            _mm256_storeu_ps(tmp, _mm256_mul_ps(f0, scale_ps));
            for (size_t i=0;i<remain;i++) dst[produced+i] = tmp[i];
            produced += remain;
            continue;
        }
        if (remain >= 8) {
            _mm256_storeu_ps(dst + produced, _mm256_mul_ps(f1, scale_ps)); produced += 8; remain -= 8;
        } else {
            alignas(32) float tmp[8];
            _mm256_storeu_ps(tmp, _mm256_mul_ps(f1, scale_ps));
            for (size_t i=0;i<remain;i++) dst[produced+i] = tmp[i];
            produced += remain;
            continue;
        }
        if (remain >= 8) {
            _mm256_storeu_ps(dst + produced, _mm256_mul_ps(f2, scale_ps)); produced += 8; remain -= 8;
        } else {
            alignas(32) float tmp[8];
            _mm256_storeu_ps(tmp, _mm256_mul_ps(f2, scale_ps));
            for (size_t i=0;i<remain;i++) dst[produced+i] = tmp[i];
            produced += remain;
            continue;
        }
        if (remain >= 8) {
            _mm256_storeu_ps(dst + produced, _mm256_mul_ps(f3, scale_ps)); produced += 8; remain -= 8;
        } else {
            alignas(32) float tmp[8];
            _mm256_storeu_ps(tmp, _mm256_mul_ps(f3, scale_ps));
            for (size_t i=0;i<remain;i++) dst[produced+i] = tmp[i];
            produced += remain;
            continue;
        }
    }
#else
    // scalar fallback
    for (size_t b = 0; b < n_blocks; ++b) {
        const uint8_t* block = src + b * block_size;
        uint16_t scale_h;
        std::memcpy(&scale_h, block, sizeof(uint16_t));
        float scale = half_to_float(scale_h);
        const int8_t* vals = (const int8_t*)(block + 2);
        for (size_t j = 0; j < QK && produced < n_elements; ++j, ++produced) {
            dst[produced] = float(vals[j]) * scale;
        }
    }
#endif
}

// ---------- Q4_0 dequant (AVX2) ----------
// Q4_0 block: [2 bytes f16 scale][16 bytes packed] -> 32 outputs per block.
// Each packed byte: low nibble (bits 0..3), high nibble (bits 4..7).
// Values are signed in range -8..7 via (nibble - 8).
void dequant_q4_0_avx2(const uint8_t* src, size_t n_elements, float* dst) {
    const size_t QK = 32;
    const size_t block_size = 2 + QK/2; // 18 bytes
    size_t n_blocks = (n_elements + QK - 1) / QK;
    size_t produced = 0;

#if defined(__AVX2__) && defined(__SSE4_1__)
    const __m128i mask0f = _mm_set1_epi8((char)0x0F);
    const __m256  minus8_ps = _mm256_set1_ps(8.0f);

    for (size_t b = 0; b < n_blocks; ++b) {
        const uint8_t* block = src + b * block_size;
        uint16_t scale_h;
        std::memcpy(&scale_h, block, sizeof(uint16_t));
        float scale = half_to_float(scale_h);
        const uint8_t* packed = block + 2; // 16 bytes

        // load 16 packed bytes
        __m128i p = _mm_loadu_si128((const __m128i*)packed); // bytes 0..15

        // low nibbles
        __m128i low = _mm_and_si128(p, mask0f);
        // high nibbles = (p >> 4) & 0x0F
        __m128i high = _mm_and_si128(_mm_srli_epi16(p, 4), mask0f);

        // process lower 8 bytes and upper 8 bytes separately for each of low/high
        __m128i low_lo = _mm_cvtepu8_epi16(low);                          // expands bytes 0..7 -> 8x16-bit
        __m128i low_hi = _mm_cvtepu8_epi16(_mm_srli_si128(low, 8));       // bytes 8..15
        __m128i high_lo = _mm_cvtepu8_epi16(high);
        __m128i high_hi = _mm_cvtepu8_epi16(_mm_srli_si128(high, 8));

        // convert to int32 vectors and then to float
        __m256i low32_0 = _mm256_cvtepi16_epi32(low_lo);
        __m256i low32_1 = _mm256_cvtepi16_epi32(low_hi);
        __m256i high32_0 = _mm256_cvtepi16_epi32(high_lo);
        __m256i high32_1 = _mm256_cvtepi16_epi32(high_hi);

        __m256 lowf0 = _mm256_cvtepi32_ps(low32_0);
        __m256 lowf1 = _mm256_cvtepi32_ps(low32_1);
        __m256 highf0 = _mm256_cvtepi32_ps(high32_0);
        __m256 highf1 = _mm256_cvtepi32_ps(high32_1);

        // convert nibble (0..15) to signed by subtracting 8.0f
        lowf0 = _mm256_sub_ps(lowf0, minus8_ps);
        lowf1 = _mm256_sub_ps(lowf1, minus8_ps);
        highf0 = _mm256_sub_ps(highf0, minus8_ps);
        highf1 = _mm256_sub_ps(highf1, minus8_ps);

        // multiply by scale
        __m256 scale_ps = _mm256_set1_ps(scale);
        lowf0  = _mm256_mul_ps(lowf0, scale_ps);
        lowf1  = _mm256_mul_ps(lowf1, scale_ps);
        highf0 = _mm256_mul_ps(highf0, scale_ps);
        highf1 = _mm256_mul_ps(highf1, scale_ps);

        // Now we need to interleave low/high for each byte:
        // for byte i: dst[idx + 2*i] = low[i]; dst[idx + 2*i + 1] = high[i]
        // We produced low[0..7], low[8..15], high[0..7], high[8..15].
        // For simplicity and clarity we store to a temporary float buffer then interleave.
        alignas(32) float tmp_low[16];
        alignas(32) float tmp_high[16];
        _mm256_storeu_ps(tmp_low + 0, lowf0);
        _mm256_storeu_ps(tmp_low + 8, lowf1);
        _mm256_storeu_ps(tmp_high + 0, highf0);
        _mm256_storeu_ps(tmp_high + 8, highf1);

        // interleave into dst
        size_t base = produced;
        for (int i = 0; i < 16 && produced < n_elements; ++i) {
            // low
            dst[produced++] = tmp_low[i];
            if (produced >= n_elements) break;
            // high
            dst[produced++] = tmp_high[i];
        }
    }
#else
    // scalar fallback
    for (size_t b = 0; b < n_blocks; ++b) {
        const uint8_t* block = src + b * block_size;
        uint16_t scale_h;
        std::memcpy(&scale_h, block, sizeof(uint16_t));
        float scale = half_to_float(scale_h);
        const uint8_t* packed = block + 2;
        for (size_t j = 0; j < 16 && produced < n_elements; ++j) {
            uint8_t byte = packed[j];
            int low = (byte & 0x0F) - 8;
            int high = (byte >> 4) - 8;
            dst[produced++] = float(low) * scale;
            if (produced < n_elements)
                dst[produced++] = float(high) * scale;
        }
    }
#endif
}

// --------------- Example usage (pseudo) ----------------
// Suppose `blob` points to packed blocks and `n_elems` is total outputs:
// float* out = (float*)malloc(n_elems * sizeof(float));
// dequant_q8_0_avx2(blob, n_elems, out);
// dequant_q4_0_avx2(blob, n_elems, out);
// free(out);

// --------------------------------------------------------