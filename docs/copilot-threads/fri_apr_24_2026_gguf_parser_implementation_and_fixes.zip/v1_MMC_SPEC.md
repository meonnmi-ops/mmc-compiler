# MMC Format (prototype) — .mmc

Version: 0.1 (prototype)
Endianness: little-endian

High-level goals:
- Single-file, memory-map-friendly binary for fast native runtime loading.
- Simple header, JSON metadata blob, tensor index, then contiguous tensor blobs.
- Alignment friendly (64-byte alignment for header/sections) for CPU caches.

Layout (file byte offsets, all offsets are from file start):

0x00: Header (fixed 64 bytes)
  - magic: 4 bytes ASCII "MMCF" (0x4D 0x4D 0x43 0x46)
  - version: u32 (little-endian) -> currently 1
  - metadata_size: u64 -> size in bytes of the metadata JSON blob
  - n_tensors: u32 -> number of tensors in index
  - index_offset: u64 -> offset (from file start) to the beginning of the tensor index
  - reserved/padding: remaining bytes up to 64 bytes total

After header:
  - metadata_blob (JSON utf-8) length = metadata_size bytes
    - The JSON contains model-level metadata (tokenizer type, vocab size, model name, optional original GGUF metadata keys).
    - The runtime can parse JSON to obtain tokenizer config, special tokens, other info.
  - metadata padded to 64-byte boundary

At index_offset:
  - tensor_index (variable length): sequential entries; entries themselves are unaligned but entire index begins at index_offset which is aligned.
  - Each tensor index entry:
      - name_len: u32
      - name: name_len bytes (utf-8)
      - n_dims: u32
      - dims: n_dims × u64 (each dim as u64 little-endian)
      - elem_type: u32 (see Element types below)
      - data_offset: u64 (offset from file start to tensor blob)
      - data_size: u64 (byte size of tensor blob)
  - There are n_tensors entries.

After index:
  - tensor blobs — raw bytes for each tensor (in order). The runtime uses elem_type and data_size to interpret.

Element types (elem_type values)
  - 0 = F32 (float32)
  - 1 = F16 (IEEE 754 float16)
  - 2 = BF16 (bfloat16, stored as 16-bit)
  - 3 = Q8_0 (block quantized; store raw bytes as in GGUF Q8_0 layout)
  - 4 = Q4_0
  - 5 = Q4_1
  - 6 = RAW_UINT8 (for vocab arrays, etc.)
  - (Extend as needed; for complex formats store raw blob and implement dequant in runtime)

Notes / Guarantees
  - All multi-byte integers and floats are little-endian.
  - The metadata blob is JSON for easy extensibility.
  - Tensors are packed as contiguous blobs so runtime can mmap and point into the mapped area.
  - data_offset should be aligned to 64 bytes for improved performance.
  - data_size is exact number of bytes for that tensor blob.
  - The tensor index should fit into memory; for extremely large numbers of small tensors you may chunk or compress the index.

Rationale & usage
  - The runtime mmc_reader will mmap file, read header & metadata JSON, then read tensor index and map pointers into the mmap region for each tensor (no copying).
  - For quantized tensors (Q4/Q8/Q5), keep the raw packed representation in the blob and implement dequant kernels that operate on the packed bytes to avoid expanding them unnecessarily.

Example minimal header values (pseudo):
  magic = b"MMCF"
  version = 1
  metadata_size = 1024
  n_tensors = 42
  index_offset = 64 + pad_to_64(metadata_size)

Design note: This prototype format trades simplicity for features. If you need backward compatibility with GGUF, packers can store the original GGUF metadata as a JSON field and place raw tensor contents as blobs (extracted from GGUF) so the .mmc remains a simple container optimized for native loading.