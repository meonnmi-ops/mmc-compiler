import numpy as np

def _dequantize_q8_0(self, n_elements):
    """Vectorized-ish Q8_0 dequantize (QK=32)."""
    QK = 32
    block_size = 2 + QK
    n_blocks = (n_elements + QK - 1) // QK
    raw = self.file.read(n_blocks * block_size)
    if len(raw) != n_blocks * block_size:
        raise EOFError("Unexpected EOF in Q8_0 data")

    # parse into blocks of bytes
    blocks = np.frombuffer(raw, dtype=np.uint8).reshape(n_blocks, block_size)

    # scales: first 2 bytes of each block interpreted as float16
    # Be explicit about endianness if needed, e.g. dtype='<f2' for little-endian float16
    scales = blocks[:, :2].view(np.float16).astype(np.float32)  # shape (n_blocks,)

    # values: next QK bytes as int8
    vals = blocks[:, 2:2 + QK].astype(np.int8).astype(np.float32)  # shape (n_blocks, QK)

    result = (vals * scales[:, None]).ravel()[:n_elements].astype(np.float32)
    return result

def _dequantize_q4_0(self, n_elements):
    """Vectorized Q4_0: packed nibbles with offset (-8)."""
    QK = 32
    block_size = 2 + QK // 2
    n_blocks = (n_elements + QK - 1) // QK
    raw = self.file.read(n_blocks * block_size)
    if len(raw) != n_blocks * block_size:
        raise EOFError("Unexpected EOF in Q4_0 data")

    blocks = np.frombuffer(raw, dtype=np.uint8).reshape(n_blocks, block_size)

    scales = blocks[:, :2].view(np.float16).astype(np.float32)

    packed = blocks[:, 2:2 + (QK // 2)].astype(np.uint8)  # shape (n_blocks, 16)
    low = (packed & 0x0F).astype(np.int8) - 8
    high = (packed >> 4).astype(np.int8) - 8

    vals = np.empty((n_blocks, QK), dtype=np.float32)
    vals[:, 0::2] = low.astype(np.float32)
    vals[:, 1::2] = high.astype(np.float32)

    result = (vals * scales[:, None]).ravel()[:n_elements].astype(np.float32)
    return result

def _dequantize_q4_1(self, n_elements):
    """Vectorized Q4_1: scale(f16) + min(f16) + packed 16 bytes."""
    QK = 32
    block_size = 2 + 2 + QK // 2
    n_blocks = (n_elements + QK - 1) // QK
    raw = self.file.read(n_blocks * block_size)
    if len(raw) != n_blocks * block_size:
        raise EOFError("Unexpected EOF in Q4_1 data")

    blocks = np.frombuffer(raw, dtype=np.uint8).reshape(n_blocks, block_size)

    scales = blocks[:, :2].view(np.float16).astype(np.float32)
    mins = blocks[:, 2:4].view(np.float16).astype(np.float32)

    packed = blocks[:, 4:4 + (QK // 2)].astype(np.uint8)
    low = (packed & 0x0F).astype(np.float32)
    high = (packed >> 4).astype(np.float32)

    vals = np.empty((n_blocks, QK), dtype=np.float32)
    vals[:, 0::2] = low
    vals[:, 1::2] = high

    result = (mins[:, None] + vals * scales[:, None]).ravel()[:n_elements].astype(np.float32)
    return result