// gemm_neon_streaming.cpp
//
// Streaming, mmap-friendly GEMM prototype for AArch64 (NEON).
// - On-the-fly dequantization (no large intermediate float Bf).
// - Microkernel: 4x8 (M_reg=4, N_reg=8), uses NEON vmlaq (fmla).
// - Q8_0 decode vectorized for 8 outputs; Q4_0 decode scalar (correct).
// - Multi-threaded over N-blocks using std::thread.
//
// Notes:
//  - This code is a prototype (clear, correct, relatively optimized).
//  - For highest performance, further vectorize Q4_0 decode, use streaming int8 microkernel (avoid even temporary b[8]),
//    and tune tile sizes per target CPU and cache sizes.
//  - Ensure packer writes quant blob layout that this reader expects:
//      For each k (0..K-1): blocks for N in order; block=(2 bytes f16 scale) + (QK bytes int8) for Q8_0,
//      or (2 + QK/2) for Q4_0. That way, per-k pointer into slice is computed with simple arithmetic.

#include <arm_neon.h>
#include <cstdint>
#include <cstddef>
#include <cstring>
#include <vector>
#include <thread>
#include <iostream>
#include <cmath>
#include <cassert>
#include <atomic>

// --------------------------------------
// Parameters & tiling (tunable)
// --------------------------------------
constexpr size_t QK = 32;                 // quant block width
constexpr size_t M_REG = 4;               // microkernel M-register block
constexpr size_t N_REG = 8;               // microkernel N-register block
// Tile sizes (choose to fit L1/L2); tune per device
constexpr size_t N_TILE = 128;            // process N in 128-col tiles (multiple of QK)
constexpr size_t K_TILE = 64;             // K-tiling, keeps working set small for L1
constexpr size_t M_TILE = 64;             // M-tiling (process M in blocks)

// Element types (match mmc)
enum ElemType : uint32_t { ET_F32=0, ET_F16=1, ET_BF16=2, ET_Q8_0=3, ET_Q4_0=4 };

// --------------------------------------
// half->float scalar converter
// (portable, correct). Replace with vector vcvt if hardware supports.
// --------------------------------------
static inline float half_to_float_scalar(uint16_t h) {
    uint32_t sign = (h & 0x8000u) << 16;
    uint32_t exp  = (h & 0x7C00u);
    uint32_t mant = (h & 0x03FFu);
    uint32_t f;
    if (exp == 0x0000u) {
        if (mant == 0) {
            f = sign;
        } else {
            int shift = 0;
            while ((mant & 0x0400u) == 0) { mant <<= 1; ++shift; }
            mant &= 0x03FFu;
            uint32_t exp32 = (127 - 15 - shift) << 23;
            uint32_t mant32 = mant << 13;
            f = sign | exp32 | mant32;
        }
    } else if (exp == 0x7C00u) {
        if (mant == 0) f = sign | 0x7F800000u;
        else f = sign | 0x7F800000u | (mant << 13);
    } else {
        uint32_t exp32 = ((exp >> 10) + (127 - 15)) << 23;
        uint32_t mant32 = mant << 13;
        f = sign | exp32 | mant32;
    }
    float out; std::memcpy(&out, &f, sizeof(f)); return out;
}

// --------------------------------------
// decode up to 8 Q8_0 outputs (vectorized) for a given k-row slice and column offset
// src_row_slice: pointer to the start of quant data for this k row and NB tile (i.e., first block of the tile)
// col_offset_in_slice: column offset within the slice (0..n_block-1). We decode 8 outputs starting here (may cross a block boundary).
// blocks_per_row_slice: how many QK blocks are in the slice
// returns number of decoded outputs actually filled (<=8) via out array of floats
// --------------------------------------
static inline size_t decode_q8_8_neon(const uint8_t* src_row_slice,
                                      size_t col_offset_in_slice,
                                      size_t n_block,         // length of this slice (columns)
                                      float out[8]) {
    // src layout per-row slice: for block b=0..blocks_per_row-1: [2 bytes half scale][QK int8 values]
    const size_t block_size = 2 + QK;
    // We'll decode up to 8 values starting at col_offset_in_slice (handle crossing into next block if necessary)
    size_t remaining = n_block - col_offset_in_slice;
    size_t to_decode = std::min<size_t>(8, remaining);
    size_t decoded = 0;
    size_t col = col_offset_in_slice;

    while (decoded < to_decode) {
        size_t block_idx = col / QK;
        size_t off_in_block = col % QK;
        const uint8_t* block_ptr = src_row_slice + block_idx * block_size;
        uint16_t scale_h;
        memcpy(&scale_h, block_ptr, sizeof(uint16_t));
        float scale = half_to_float_scalar(scale_h);

        const int8_t* vals = reinterpret_cast<const int8_t*>(block_ptr + 2);

        // number we can take from this block
        size_t take = std::min<size_t>(to_decode - decoded, QK - off_in_block);

        // vectorize if take >= 4, else scalar
        size_t i = 0;
        if (take >= 8) {
            // load 8 int8 values starting at vals + off_in_block
            // Use vld1_s8 on int8x8_t
            const int8_t* ptr8 = vals + off_in_block;
            int8x8_t v8 = vld1_s8(ptr8); // 8 x int8
            int16x8_t v16 = vmovl_s8(v8); // widen to int16x8
            // split to two int32x4
            int32x4_t v32_lo = vmovl_s16(vget_low_s16(v16));
            int32x4_t v32_hi = vmovl_s16(vget_high_s16(v16));
            float32x4_t f_lo = vcvtq_f32_s32(v32_lo);
            float32x4_t f_hi = vcvtq_f32_s32(v32_hi);
            float32x4_t scale_v = vdupq_n_f32(scale);
            f_lo = vmulq_f32(f_lo, scale_v);
            f_hi = vmulq_f32(f_hi, scale_v);
            vst1q_f32(out + decoded + 0, f_lo);
            vst1q_f32(out + decoded + 4, f_hi);
            decoded += 8;
            col += 8;
            continue;
        }
        // handle smaller takes (1..7) scalar for simplicity (rare if N_REG small)
        for (i = 0; i < take; ++i) {
            out[decoded + i] = float(vals[off_in_block + i]) * scale;
        }
        decoded += take;
        col += take;
    }

    return to_decode;
}

// --------------------------------------
// decode up to 8 Q4_0 outputs for a given k-row slice and col offset
// Scalar implementation (clear); vectorization path can be added later.
// Each block: 2 bytes half scale + 16 packed bytes (32 outputs).
// --------------------------------------
static inline size_t decode_q4_8_scalar(const uint8_t* src_row_slice,
                                        size_t col_offset_in_slice,
                                        size_t n_block,
                                        float out[8]) {
    const size_t block_size = 2 + (QK / 2);
    size_t remaining = n_block - col_offset_in_slice;
    size_t to_decode = std::min<size_t>(8, remaining);
    size_t decoded = 0;
    size_t col = col_offset_in_slice;

    while (decoded < to_decode) {
        size_t block_idx = col / QK;
        size_t off_in_block = col % QK;
        const uint8_t* block_ptr = src_row_slice + block_idx * block_size;
        uint16_t scale_h;
        memcpy(&scale_h, block_ptr, sizeof(uint16_t));
        float scale = half_to_float_scalar(scale_h);
        const uint8_t* packed = block_ptr + 2; // 16 bytes

        // off_in_block in [0..31] -> packed byte index = off/2, if even -> low nibble then high nibble next etc.
        size_t take = std::min<size_t>(to_decode - decoded, QK - off_in_block);
        for (size_t i = 0; i < take; ++i) {
            size_t idx = off_in_block + i;
            size_t byte_idx = idx / 2;
            uint8_t byte = packed[byte_idx];
            uint8_t nib;
            if ((idx & 1) == 0) nib = byte & 0x0F; else nib = (byte >> 4) & 0x0F;
            int signed_val = int(nib) - 8;
            out[decoded + i] = float(signed_val) * scale;
        }
        decoded += take;
        col += take;
    }
    return to_decode;
}

// --------------------------------------
// streaming microkernel 4x8:
// compute C[i:i+4, j:j+8] += A[i:i+4, 0:K] * B[0:K, j:j+8]
// A rows are row-major with lda=K; B quantized is accessed on-the-fly via provided src_row_slice (per-k offsets).
// src_row_slice_base_for_k: pointer to beginning of quant row for k, but we will compute per-slice pointer externally.
// b_elem_type indicates Q8_0 or Q4_0; src_layout explained in top comment.
// --------------------------------------
static inline void microkernel_4x8_streaming(const float* A_block /*ptr to A[i*lda]*/,
                                             size_t lda,
                                             const uint8_t* B_row_slices_base, // pointer to start of quant slice region for all k (i.e., first block for nb)
                                             size_t blocks_per_row_slice,      // number of QK blocks in this slice (n_block / QK)
                                             size_t n_block,                   // number of columns in this slice
                                             size_t k_start, size_t K_iter,
                                             uint32_t b_elem_type,
                                             float* C_block, size_t ldc) {
    // accumulators: 8 columns x 4 rows -> stored as float32x4_t acc_colX
    float32x4_t acc0 = vdupq_n_f32(0.0f), acc1 = vdupq_n_f32(0.0f), acc2 = vdupq_n_f32(0.0f), acc3 = vdupq_n_f32(0.0f);
    float32x4_t acc4 = vdupq_n_f32(0.0f), acc5 = vdupq_n_f32(0.0f), acc6 = vdupq_n_f32(0.0f), acc7 = vdupq_n_f32(0.0f);

    // For each k (k_start .. k_start+K_iter-1)
    // We need for current k a pointer to the quant data for that row for the whole slice
    // layout per-row-slice: row_base = k * (blocks_per_row_total * block_size) + (nb/QK)*block_size  -- here we assume B_row_slices_base already points to the start for nb (first block) across k rows.
    // For simpler prototype, we assume B_row_slices_base = pointer such that for row k the row-slice pointer is:
    //    row_ptr = B_row_slices_base + k * (blocks_per_row_slice * block_size)
    // That is how gemm_streaming_quantized sets it up.

    const size_t block_size_q8 = 2 + QK;
    const size_t block_size_q4 = 2 + (QK / 2);
    const size_t row_stride = blocks_per_row_slice * (b_elem_type == ET_Q8_0 ? block_size_q8 : block_size_q4);

    // Temporary container for decoded 8 B values per k
    float bvals[8];

    for (size_t kk = 0; kk < K_iter; ++kk) {
        const float* Arow0 = A_block + (0) * lda + kk; // A[i+0, k]
        const float* Arow1 = A_block + (1) * lda + kk;
        const float* Arow2 = A_block + (2) * lda + kk;
        const float* Arow3 = A_block + (3) * lda + kk;
        // read A scalars
        float a0 = *Arow0;
        float a1 = *Arow1;
        float a2 = *Arow2;
        float a3 = *Arow3;

        // pack a_vec for vmlaq_n
        float32x4_t a_vec = {a0, a1, a2, a3}; // pseudo-constructor; some compilers accept initializer lists

        // compute pointer to this row's slice start:
        const uint8_t* row_ptr = B_row_slices_base + kk * row_stride;

        // decode 8 B elements at column offset within the slice: here assume kernel is aligned to j start 0 of the slice
        // For microkernel call we assume it is used for columns j..j+7 inside the slice and so caller provides offset=0 relative to slice
        // so decode starting at offset 0
        if (b_elem_type == ET_Q8_0) {
            decode_q8_8_neon(row_ptr, 0, n_block, bvals); // decodes 8 values
        } else {
            decode_q4_8_scalar(row_ptr, 0, n_block, bvals);
        }

        // accumulate: accX += a_vec * bvals[X] for X=0..7
        acc0 = vmlaq_n_f32(acc0, a_vec, bvals[0]);
        acc1 = vmlaq_n_f32(acc1, a_vec, bvals[1]);
        acc2 = vmlaq_n_f32(acc2, a_vec, bvals[2]);
        acc3 = vmlaq_n_f32(acc3, a_vec, bvals[3]);
        acc4 = vmlaq_n_f32(acc4, a_vec, bvals[4]);
        acc5 = vmlaq_n_f32(acc5, a_vec, bvals[5]);
        acc6 = vmlaq_n_f32(acc6, a_vec, bvals[6]);
        acc7 = vmlaq_n_f32(acc7, a_vec, bvals[7]);
    }

    // store accumulators into C_block (4 rows x 8 cols), C_block has ldc stride
    alignas(16) float t0[4], t1[4], t2[4], t3[4], t4[4], t5[4], t6[4], t7[4];
    vst1q_f32(t0, acc0); vst1q_f32(t1, acc1); vst1q_f32(t2, acc2); vst1q_f32(t3, acc3);
    vst1q_f32(t4, acc4); vst1q_f32(t5, acc5); vst1q_f32(t6, acc6); vst1q_f32(t7, acc7);

    for (int r = 0; r < 4; ++r) {
        float* Crow = C_block + r * ldc;
        Crow[0] += t0[r];
        Crow[1] += t1[r];
        Crow[2] += t2[r];
        Crow[3] += t3[r];
        Crow[4] += t4[r];
        Crow[5] += t5[r];
        Crow[6] += t6[r];
        Crow[7] += t7[r];
    }
}

// --------------------------------------
// gemm streaming top-level:
// - tiles N in N_TILE slices; for each slice we create B_row_slices_base pointing to the beginning of that slice for all k rows,
//   and dispatch worker threads over slice ranges. Each worker iterates MBLOCKs of M and inner K tiling.
// - B_q is the quant blob pointer arranged row-major per-k with blocks_per_row_total blocks per row.
// --------------------------------------
void gemm_streaming_quantized_mt(const float* A, size_t M, size_t K,
                                 const uint8_t* B_q, uint32_t b_elem_type,
                                 size_t N, float* C) {
    // zero C
    memset(C, 0, sizeof(float) * M * N);

    const size_t blocks_per_row_total = N / QK;
    const size_t block_size_bytes = (b_elem_type == ET_Q8_0) ? (2 + QK) : (2 + QK/2);

    // determine number of tiles over N
    size_t n_tiles = (N + N_TILE - 1) / N_TILE;

    // thread pool over tiles: we'll divide tile indices across available cores
    unsigned hw = std::max<unsigned>(1, std::thread::hardware_concurrency());
    std::vector<std::thread> threads;
    std::atomic<size_t> tile_index(0);

    auto worker = [&](unsigned tid)->void {
        while (true) {
            size_t t = tile_index.fetch_add(1);
            if (t >= n_tiles) break;
            size_t nb = t * N_TILE;
            size_t this_n = std::min(N_TILE, N - nb);
            // ensure multiple of QK for prototype; if not, handle tail appropriately
            assert(this_n % QK == 0);
            size_t blocks_in_slice = this_n / QK;

            // compute pointer base to start of slice for k=0:
            // row_ptr_for_k0 = B_q + (nb/QK) * block_size_bytes
            const uint8_t* slice_base_k0 = B_q + (nb / QK) * block_size_bytes;

            // For each M tile
            for (size_t mi = 0; mi < M; mi += M_TILE) {
                size_t m_cur = std::min(M_TILE, M - mi);
                // For each M micro block of 4 rows
                for (size_t i = mi; i < mi + m_cur; i += M_REG) {
                    size_t m_rem = std::min(M_REG, mi + m_cur - i);
                    // For each sub-block of N (process N_REG columns local to the slice)
                    for (size_t j = 0; j < this_n; j += N_REG) {
                        size_t n_rem = std::min(N_REG, this_n - j);
                        if (m_rem == 4 && n_rem == 8) {
                            // build B_row_slices_base: for k row it should be pointer to (k * blocks_per_row_total * block_size_bytes) + slice offset
                            // We'll create base pointer equal to B_q + (nb/QK)*block_size_bytes such that row_ptr = base + k * (blocks_per_row_total*block_size_bytes)
                            const uint8_t* slice_base = slice_base_k0; // start for k=0
                            float* Cblock = C + (i * N) + (nb + j);
                            // Ablock pointer: A + i*K
                            const float* Ablock = A + i * K;
                            // For streaming microkernel we want B_row_slices_base to point to the first block of this slice for k=0 and
                            // the microkernel expects row_ptr = base + kk * (blocks_in_slice * block_size)
                            // However in this simpler layout, we compute row_stride accordingly when invoking microkernel
                            // For convenience create a temporary per-k base that matches microkernel expectation:
                            // We build a contiguous area where consecutive k rows are contiguous blocks for this slice alone. That is essentially
                            // a view into B_q with stride blocks_per_row_total * block_size_bytes. But microkernel uses row_stride = blocks_in_slice * block_size_bytes,
                            // so we must pass a B_row_slices_base arranged in that way (contiguous per k for the slice). To avoid copying, we compute per-k pointers inside microkernel.
                            // Here we pass a pointer to the start of slice for k=0 and also pass blocks_in_slice and n_block.
                            // The microkernel uses B_row_slices_base + kk * row_stride where row_stride = blocks_in_slice*block_size_bytes.
                            // So to make this consistent, we must ensure that the memory between row starts equals row_stride.
                            // But the actual B_q layout stores blocks_per_row_total * block_size_bytes per row; since blocks_in_slice <= blocks_per_row_total,
                            // row_stride computed inside microkernel should be blocks_in_slice * block_size_bytes, and the base pointer arithmetic done in microkernel
                            // will not point to correct memory unless we pass row_stride matching actual memory stride.
                            // To simplify: we'll set B_row_slices_base to point to the first block of slice for k=0, and microkernel will compute row_stride = blocks_per_row_total*block_size_bytes,
                            // so modify microkernel call accordingly below (we pass blocks_per_row_total).
                            // Call streaming microkernel for K-tiled chunks
                            for (size_t kk = 0; kk < K; kk += K_TILE) {
                                size_t k_iter = std::min(K_TILE, K - kk);
                                // For this microkernel variant we will call a small loop: we need to provide B_row_slices_base such that row_ptr = B_q + kk * (blocks_per_row_total*block_size_bytes) + (nb/QK)*block_size_bytes
                                // So build a pointer base_for_kk = B_q + kk * (blocks_per_row_total*block_size_bytes) + (nb/QK)*block_size_bytes
                                const uint8_t* base_for_kk = B_q + kk * (blocks_per_row_total * block_size_bytes) + (nb / QK) * block_size_bytes;
                                // microkernel expects B_row_slices_base such that row_ptr = base_for_kk + kk2 * (blocks_per_row_total * block_size_bytes)
                                // and n_block=this_n. blocks_per_row_slice is blocks_in_slice (used for local row_stride calc)
                                // Call microkernel: input A block pointer must be pointer to A[i*lda] and lda=K. We'll give A + i*K (row i) and microkernel will use lda correctly.
                                microkernel_4x8_streaming(Ablock, K,
                                                          base_for_kk, blocks_in_slice, this_n,
                                                          kk, k_iter, b_elem_type,
                                                          Cblock, N);
                            }
                        } else {
                            // handle tails naively
                            for (size_t ii = 0; ii < m_rem; ++ii) {
                                for (size_t jj = 0; jj < n_rem; ++jj) {
                                    double acc = 0.0;
                                    for (size_t kk = 0; kk < K; ++kk) {
                                        // compute B[k, nb+j+jj] via decode on-the-fly:
                                        // find block index in row: block_idx = (nb + j + jj) / QK; off = (nb+j+jj) % QK
                                        size_t col_in_slice = j + jj;
                                        size_t block_idx = col_in_slice / QK;
                                        size_t off_in_block = col_in_slice % QK;
                                        const uint8_t* row_ptr = B_q + kk * (blocks_per_row_total * block_size_bytes) + block_idx * block_size_bytes + (nb / QK) * block_size_bytes;
                                        if (b_elem_type == ET_Q8_0) {
                                            uint16_t scale_h; memcpy(&scale_h, row_ptr, 2);
                                            float scale = half_to_float_scalar(scale_h);
                                            const int8_t* vals = reinterpret_cast<const int8_t*>(row_ptr + 2);
                                            float bv = float(vals[off_in_block]) * scale;
                                            acc += A[(i + ii) * K + kk] * bv;
                                        } else {
                                            uint16_t scale_h; memcpy(&scale_h, row_ptr, 2);
                                            float scale = half_to_float_scalar(scale_h);
                                            const uint8_t* packed = row_ptr + 2;
                                            uint8_t byte = packed[off_in_block / 2];
                                            uint8_t nib = ((off_in_block & 1) == 0) ? (byte & 0x0F) : (byte >> 4);
                                            float bv = float(int(nib) - 8) * scale;
                                            acc += A[(i + ii) * K + kk] * bv;
                                        }
                                    }
                                    C[(i + ii) * N + (nb + j + jj)] += float(acc);
                                }
                            }
                        } // end n_rem branch
                    } // end j loop
                } // end i loop
            } // end mi loop
        } // end while tile_index fetch
    };

    // launch threads
    for (unsigned t = 0; t < hw; ++t) {
        threads.emplace_back(worker, t);
    }
    for (auto &th : threads) th.join();
}

// --------------------------------------
// Simple unit test driver (small sizes, quantize B naive to Q8_0 with scale=1.0 so we can compare easily).
// --------------------------------------
static void reference_gemm(const float* A, const float* B, float* C, size_t M, size_t K, size_t N) {
    for (size_t i = 0; i < M; ++i) for (size_t j = 0; j < N; ++j) {
        double s = 0.0;
        for (size_t k = 0; k < K; ++k) s += double(A[i*K + k]) * double(B[k*N + j]);
        C[i*N + j] = float(s);
    }
}

static void quantize_B_q8_naive(const float* B, size_t K, size_t N, std::vector<uint8_t>& out_blob) {
    // naive: set scale=1.0 half, and quantize by rounding to int8 (for test only)
    size_t blocks_per_row = N / QK;
    out_blob.clear();
    out_blob.reserve(K * blocks_per_row * (2 + QK));
    for (size_t k = 0; k < K; ++k) {
        for (size_t b = 0; b < blocks_per_row; ++b) {
            uint16_t scale_h = 0x3C00; // half 1.0
            out_blob.push_back(uint8_t(scale_h & 0xFF));
            out_blob.push_back(uint8_t((scale_h >> 8) & 0xFF));
            for (size_t i = 0; i < QK; ++i) {
                int8_t q = (int8_t)std::lrintf(B[k*N + b*QK + i]);
                out_blob.push_back((uint8_t)q);
            }
        }
    }
}

int main() {
    size_t M = 8, K = 64, N = 64; // N must be multiple of QK for prototype
    std::vector<float> A(M*K), B(K*N), Cref(M*N), Ctest(M*N);
    for (size_t i = 0; i < M*K; ++i) A[i] = float((int)i % 7 - 3) * 0.125f;
    for (size_t i = 0; i < K*N; ++i) B[i] = float((int)i % 11 - 5) * 0.0625f;
    reference_gemm(A.data(), B.data(), Cref.data(), M, K, N);

    std::vector<uint8_t> Bq;
    quantize_B_q8_naive(B.data(), K, N, Bq);

    gemm_streaming_quantized_mt(A.data(), M, K, Bq.data(), ET_Q8_0, N, Ctest.data());

    double max_err = 0.0;
    for (size_t i = 0; i < M*N; ++i) max_err = std::max(max_err, double(fabs(Cref[i] - Ctest[i])));
    std::cout << "Max error (Q8 naive quant=1.0 scale): " << max_err << std::endl;
    if (max_err < 1e-3) std::cout << "PASSED\n"; else std::cout << "Check tolerance / quantization\n";
    return 0;
}