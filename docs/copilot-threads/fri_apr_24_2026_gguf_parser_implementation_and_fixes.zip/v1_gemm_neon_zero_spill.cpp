// Optimized NEON Q4_0: "Zero-spill, Pure-register Pipeline" microkernel + decoder.
// Assumes blocks aligned to 8 columns for kernel; no use of float stack temp at any point.
// Build: aarch64-linux-gnu-g++ -O3 -march=armv8-a+fp16 -std=c++17 gemm_neon_zero_spill.cpp -o gemm_neon_zero_spill

#include <arm_neon.h>
#include <cstdint>
#include <cstring>
#include <iostream>

// --- Scalar half->float (portable, may replace with vcvt_f32_f16 for ARMv8.2+FP16) ---
inline float half_to_float(uint16_t h) {
    uint32_t sign = ((h & 0x8000u) << 16);
    uint32_t exp  = (h & 0x7C00u);
    uint32_t mant = (h & 0x03FFu);
    uint32_t res;
    if (exp == 0) {
        if (mant==0) res=sign;
        else {
            mant <<= 1; while((mant&0x400)==0){mant<<=1;}
            mant&=0x3FF; exp=0x1C000;
            res = sign | exp | (mant << 13);
        }
    } else if (exp==0x7C00u) res = sign | 0x7F800000u | (mant<<13);
    else res=sign | (((exp>>10)+112)<<23) | (mant<<13);
    float f; std::memcpy(&f,&res,4); return f;
}

// --- Q4_0 block NEON zero-spill decoder: produces out0, out1 as f32x4 (low/high), pure in-register ---
inline void decode_q4_8_neon_f32x4(const uint8_t* packed, uint16_t scale_h, float32x4_t& out0, float32x4_t& out1) {
    // packed = pointer to 8 bytes (each has [hi|lo] nibbles, covering cols 0-7)
    float scale = half_to_float(scale_h);
    // Load 8 bytes containing 8 "low" and 8 "high" nibbles
    uint8x8_t bytes = vld1_u8(packed);
    // Get lo/hi nibbles; yields 8x8bits per
    uint8x8_t lo_nib = vand_u8(bytes, vdup_n_u8(0x0F));
    uint8x8_t hi_nib = vshr_n_u8(bytes, 4);
    // Convert lo/hi nibbles to int32_t (for signedness, subtract 8 after widening):
    int16x8_t lo16  = vreinterpretq_s16_u16(vsubl_u8(lo_nib, vdup_n_u8(8)));
    int16x8_t hi16  = vreinterpretq_s16_u16(vsubl_u8(hi_nib, vdup_n_u8(8)));
    int32x4_t lo32a = vmovl_s16(vget_low_s16(lo16)), hi32a = vmovl_s16(vget_low_s16(hi16));
    int32x4_t lo32b = vmovl_s16(vget_high_s16(lo16)), hi32b = vmovl_s16(vget_high_s16(hi16));
    // Convert to float:
    float32x4_t floa = vmulq_n_f32(vcvtq_f32_s32(lo32a), scale);
    float32x4_t fhi  = vmulq_n_f32(vcvtq_f32_s32(hi32a), scale);
    float32x4_t flob = vmulq_n_f32(vcvtq_f32_s32(lo32b), scale);
    float32x4_t fhib = vmulq_n_f32(vcvtq_f32_s32(hi32b), scale);

    // Now interleave: target output = [low0,high0,low1,high1,low2,high2,low3,high3] (first f32x4)
    // and [low4,high4,low5,high5,low6,high6,low7,high7] (second f32x4)
    // Use vzip for 4-wide block interleaving
    float32x4x2_t z0 = vzipq_f32(floa, fhi);   // out0: lane0=low0, lane1=high0, lane2=low1, lane3=high1
    float32x4x2_t z1 = vzipq_f32(flob, fhib);  // out1: lane0=low2, lane1=high2, lane2=low3, lane3=high3
    // (You can vzip2 for crossing 4-8, but to get all 8 in correct order do vcombine.)

    // Final arrangement (8-float group as 2x4): merge z0.val, z1.val as two f32x4 (pure registers)
    out0 = z0.val[0]; // [low0,high0,low1,high1]
    out1 = z0.val[1]; // [low2,high2,low3,high3]
    // (if you need all 8 in a single vector, you may use vcombine_f32, but 4+4 approach is microkernel friendly)
}

// --- Microkernel: 4x8 (no temp memory, vmlaq_lane_f32 pure-register) ---
// A_block: [4 x lda] float
// packed:  pointer to Q4 block for the 8 columns
// scale_h: block scale (f16)
// C_block: [4 x ldc] float accumulation output
void microkernel_4x8_q4zero(const float* A_block, size_t lda, const uint8_t* packed, uint16_t scale_h, float* C_block, size_t ldc) {
    // Register setup
    float32x4_t acc0 = vdupq_n_f32(0); float32x4_t acc1 = vdupq_n_f32(0); float32x4_t acc2 = vdupq_n_f32(0); float32x4_t acc3 = vdupq_n_f32(0); float32x4_t acc4 = vdupq_n_f32(0); float32x4_t acc5 = vdupq_n_f32(0); float32x4_t acc6 = vdupq_n_f32(0); float32x4_t acc7 = vdupq_n_f32(0);

    // For illustration: process K=1 only, making extension to K_TILE inside outer K loop straightforward.
    // For k=0..K-1 (unroll for K_TILE)
    // Load 4 A scalars (maybe unroll this for A[i:(i+4),k])
    float32x4_t Avec = {A_block[0*lda],A_block[1*lda],A_block[2*lda],A_block[3*lda]};

    // Q4_0 decode, pure register: packed, scale_h -> two f32x4 (low0...low3, high0...high3,...)
    float32x4_t qlo, qhi; decode_q4_8_neon_f32x4(packed, scale_h, qlo, qhi);

    // Use vmlaq_lane_f32: accumulate "per-lane register" to each output
    // accX = vmlaq_lane_f32(accX, Avec, qlo/qhi, lane)
    acc0 = vmlaq_lane_f32(acc0, Avec, vget_low_f32(qlo), 0); // for col 0
    acc1 = vmlaq_lane_f32(acc1, Avec, vget_low_f32(qlo), 1); // for col 1
    acc2 = vmlaq_lane_f32(acc2, Avec, vget_low_f32(qlo), 2); // for col 2
    acc3 = vmlaq_lane_f32(acc3, Avec, vget_low_f32(qlo), 3); // for col 3
    acc4 = vmlaq_lane_f32(acc4, Avec, vget_low_f32(qhi), 0); // for col 4
    acc5 = vmlaq_lane_f32(acc5, Avec, vget_low_f32(qhi), 1); // for col 5
    acc6 = vmlaq_lane_f32(acc6, Avec, vget_low_f32(qhi), 2); // for col 6
    acc7 = vmlaq_lane_f32(acc7, Avec, vget_low_f32(qhi), 3); // for col 7

    // Store accumulators (C_block, row-major, stride ldc)
    vst1q_f32(C_block + 0*ldc, acc0);
    vst1q_f32(C_block + 1*ldc, acc1);
    vst1q_f32(C_block + 2*ldc, acc2);
    vst1q_f32(C_block + 3*ldc, acc3);
    vst1q_f32(C_block + 4*ldc, acc4);
    vst1q_f32(C_block + 5*ldc, acc5);
    vst1q_f32(C_block + 6*ldc, acc6);
    vst1q_f32(C_block + 7*ldc, acc7);
}

// Example main (not a functional runner, but code is ready for integration)
// Move this inside the corresponding gemm_streaming_quantized_mt() tiling logic from previous answers.
// Then launch threads over N-tiles, call this kernel per (M,N) tile pair.

int main() {
    std::cout << "Zero-spill Q4_0 NEON streaming kernel demonstration (pure-register interleave/vmlaq_lane)\n";
    // See comments above for integration points. Unit tests and full GEMM reference provided in previous code.
}