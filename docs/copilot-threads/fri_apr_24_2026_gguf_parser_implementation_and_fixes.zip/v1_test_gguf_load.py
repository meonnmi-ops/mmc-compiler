# Simple test script: attempts to open a gguf file and list tensors + first tensor shape
from gguf_parser import GGUFReader
import sys

if len(sys.argv) < 2:
    print("Usage: python test_gguf_load.py path/to/model.gguf")
    sys.exit(1)

path = sys.argv[1]
r = GGUFReader(path)
print("Metadata keys:", list(r.metadata.keys())[:20])
print("Tensors:", len(r.tensor_infos))
if r.tensor_infos:
    t0 = r.tensor_infos[0]
    print("First tensor:", t0["name"], "type:", r._type_name(t0["type"]), "dims:", t0["dims"])
    try:
        arr = r.read_tensor_as_f32(t0)
        print("Loaded tensor shape:", arr.shape, "dtype:", arr.dtype)
    except NotImplementedError as e:
        print("Dequant not implemented for this tensor type:", e)