# Tiling & Streaming Strategy (for embedded/Android AArch64)

Goal
- Minimize memory traffic and working-set size.
- Maximize register use and L1/L2 reuse.
- Avoid expanding entire quantized B into floats; decode on-the-fly per small microkernel.
- Parallelize across N-blocks (output columns) to avoid synchronization.

Key ideas & parameters
- Microkernel: M_reg × N_reg = 4 × 8
  - Keeps per-column accumulators in 4-lane NEON registers.
  - Inner loop iterates over K and uses vmlaq_n_f32 (broadcast scalar b) to update 4-row accumulators — this maps well to A being in L1 (small) and B streaming.

- Tiles:
  - N_TILE (128) — number of output columns processed per tile. Must be multiple of QK (32).
  - K_TILE (64) — process K in small chunks to fit A tile slices in L1/L2 and to avoid re-loading the same A data often.
  - M_TILE (64) — block of rows for improved cache reuse and for dividing work across threads.

- B quant layout (required for streaming):
  - For each k (row of B), store blocks for N in order:
    - Q8_0 block = [2 bytes f16 scale] + [32 int8 values]
    - Q4_0 block = [2 bytes f16 scale] + [16 packed bytes => 32 nibbles]
  - This layout allows fast computation of pointer to the required block for any (k, nb_start).

- Streaming algorithm
  - For each N-tile (nb .. nb + N_TILE):
    - For each M-tile:
      - For j in 0..N_TILE step N_REG:
        - For kk in 0..K step K_TILE:
          - For k in kk..kk+K_TILE:
            - Load A scalars for 4 rows
            - Decode B[k, j..j+7] on-the-fly (decode small number of columns only)
            - vmlaq_n_f32(acc_colX, a_vec, bvalX) for X=0..7
  - After finishing k loop, store accumulators to C.

- Threading
  - Partition across N-tiles: each thread processes a subset of N-tiles and writes directly to its C columns (no atomics).
  - Use std::thread or pthread; choose number of threads = hardware_concurrency or tuned count.
  - Ensure each thread works on disjoint C columns to avoid false sharing (pad per-thread working buffers if needed).
  - For large M, consider also partitioning M across threads (two-dimensional partitioning), but start with N partition for simplicity.

Tuning recommendations
- Measure L1/L2 sizes of target device and choose K_TILE so that A[M_reg..M_reg+M_TILE] * K_TILE fits L1 (plus register spills).
- On big cores choose larger tile sizes (e.g., N_TILE=256, K_TILE=128). On little cores reduce to smaller tiles.
- Use vectorized half->float conversion (vcvt) when hardware supports IEEE FP16 instructions to speed scale extraction.
- Replace scalar Q4_0 decode with NEON-nibble extraction + widening to reduce decode overhead.
- Consider streaming int8 multiply directly into accumulators without expanding to float arrays (perform vmovl+vcvt in inner loop).
- Use prefetch (prfm) on B quant blobs if necessary on large models.

Correctness & validation
- Build unit tests that:
  - Quantize a small float B with known scale behavior (or use scale=1) and compare streaming result vs reference float GEMM.
  - Use random seeds and small M/K/N to validate numerical correctness & tail handling.

Memory mapping (.mmc)
- Use mmap to map the .mmc file into memory (read-only) and pass pointer to quant blob (B_q) to gemm_streaming_quantized_mt().
- Because we stream small blocks of B per-k, OS will page in only required pages; avoid copying large tensors into RAM.

Safety notes
- This code is prototype-level: ensure careful pointer arithmetic and bounds checks before production use.
- For Android, compile with NDK and test across different ARM microarchitectures (Cortex-A53 vs A76 vs X1) to pick best tile parameters.
