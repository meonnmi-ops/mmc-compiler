#!/usr/bin/env python3
"""
MyanOS Universal Backend v4.2.1
=================================
100% FREE — Zero paid API keys!

Universal Backend that runs on ANY device:
  - Phone (Termux / Android) — ARM64
  - Laptop (antiX Linux / Ubuntu / any Linux) — x86_64
  - Desktop (Windows / macOS) — via Python

Architecture:
  Primary:   Ollama (Local AI — Burmese Coder 4B + Qwen2.5-7B)
  Fallback:  HuggingFace Free Inference API (cloud — zero cost)

Features:
  - Auto-detect Termux vs Linux vs Windows vs macOS
  - Real terminal access (shell commands via subprocess)
  - Ollama API connector (auto-discover)
  - Multi-Agent AI Pipeline (Manager -> Worker -> Review)
  - User Authentication (Login / Register / Guest)
  - CORS enabled (any origin)
  - Serves MyanOS Desktop frontend
  - System stats, memory, file operations

Usage:
  python main.py                    # Auto-detect, port 5000
  python main.py --port 8080        # Custom port
  python main.py --host 0.0.0.0     # All interfaces (for phone hotspot)
  python main.py --host 0.0.0.0 --port 5000   # Termux default
  python main.py --port 5000        # Laptop default

Boss: Meonn Mi (meonnmi-ops)
"""

import os
import sys
import json
import time
import re
import threading
import traceback
import urllib.request
import urllib.error
import platform
import subprocess
import hashlib
import secrets
import argparse
from datetime import datetime
from pathlib import Path

# ── Flask imports (with fallback) ──
try:
    from flask import Flask, request, jsonify, send_from_directory, Response
    from flask_cors import CORS
except ImportError:
    print("=" * 60)
    print("  Flask not found! Installing dependencies...")
    print("  Run: pip install flask flask-cors requests")
    print("=" * 60)
    import subprocess as _sp
    _sp.run([sys.executable, "-m", "pip", "install", "flask", "flask-cors", "requests"],
            check=False)
    from flask import Flask, request, jsonify, send_from_directory, Response
    from flask_cors import CORS

# ═══════════════════════════════════════════════════════════════════
#  ENVIRONMENT DETECTION
# ═══════════════════════════════════════════════════════════════════

def detect_environment():
    """Auto-detect where we're running: Termux, Linux, Windows, macOS."""
    env = {
        "system": platform.system(),
        "machine": platform.machine(),
        "python": platform.python_version(),
        "hostname": platform.node(),
        "is_termux": False,
        "is_android": False,
        "is_linux": False,
        "is_windows": False,
        "is_macos": False,
        "home": str(Path.home()),
    }

    # Detect Termux (Android)
    termux = os.environ.get("TERMUX_VERSION") or os.environ.get("TERMUX__APK_VERSION") or ""
    prefix = os.environ.get("PREFIX", "")
    if "com.termux" in prefix or termux or os.path.exists("/data/data/com.termux"):
        env["is_termux"] = True
        env["is_android"] = True
        env["system"] = "Android (Termux)"

    # Detect OS
    if platform.system() == "Linux" and not env["is_termux"]:
        env["is_linux"] = True
    elif platform.system() == "Windows":
        env["is_windows"] = True
    elif platform.system() == "Darwin":
        env["is_macos"] = True

    return env


ENV = detect_environment()

# ═══════════════════════════════════════════════════════════════════
#  CONFIGURATION
# ═══════════════════════════════════════════════════════════════════

VERSION = "4.2.1"
PORT = int(os.environ.get("PORT", 5000))
HF_TOKEN = os.environ.get("HF_TOKEN", "")

# Desktop frontend directory (same folder as main.py)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DESKTOP_DIR = os.path.join(BASE_DIR, "desktop")
DATA_DIR = os.path.join(BASE_DIR, "data")
USERS_FILE = os.path.join(DATA_DIR, "users.json")

# Ollama
OLLAMA_HOST = os.environ.get("OLLAMA_HOST", "http://127.0.0.1:11434")
OLLAMA_CHAT = f"{OLLAMA_HOST}/api/chat"
OLLAMA_TAGS = f"{OLLAMA_HOST}/api/tags"

# Ollama Models
WORKER_MODEL = "hf.co/WYNN747/burmese-coder-4b:BF16"   # Burmese Coder 4B
MANAGER_MODEL = "qwen2.5:7b"                              # Qwen2.5-7B

# HF Free Fallback Models
HF_MODELS = [
    "Qwen/Qwen2.5-7B-Instruct",
    "mistralai/Mistral-7B-Instruct-v0.3",
    "HuggingFaceH4/zephyr-7b-beta",
    "google/gemma-2-2b-it",
    "microsoft/Phi-3-mini-4k-instruct",
]

# Shell config (safe commands allowed)
SAFE_COMMANDS = {
    "ls", "pwd", "cd", "cat", "head", "tail", "echo", "date", "whoami",
    "uname", "hostname", "df", "du", "free", "top", "ps", "uptime",
    "clear", "history", "which", "whereis", "type", "env", "export",
    "python", "python3", "pip", "pip3", "git", "curl", "wget",
    "mkdir", "rmdir", "touch", "cp", "mv", "rm", "chmod", "chown",
    "grep", "find", "sort", "uniq", "wc", "cut", "awk", "sed",
    "ollama", "node", "npm", "npx", "sh", "bash", "zsh",
    "termux-setup-storage", "termux-info", "termux-reload-settings",
    "ip", "ifconfig", "ping", "nslookup", "netstat", "ss",
    "tar", "zip", "unzip", "gzip", "gunzip", "bzip2",
    "ffmpeg", "ffplay", "ffprobe",
    "vim", "nano", "less", "more",
    "myanos", "myanpm", "myan",
    # apt package manager
    "apt", "apt-get", "apt-cache", "apt-mark", "apt-add-repository", "add-apt-repository",
    "dpkg", "aptitude",
    # Termux package manager
    "pkg", "pkg install", "pkg search", "pkg list-installed",
    # sudo commands
    "sudo", "su",
    # System services
    "systemctl", "service", "journalctl",
    # Build tools
    "make", "cmake", "gcc", "g++", "cc",
    # Network tools
    "ssh", "scp", "rsync", "nc", "nmap",
    # Disk tools
    "fdisk", "mkfs", "mount", "umount", "lsblk",
    # Process tools
    "kill", "killall", "pkill", "nohup", "screen", "tmux",
    # Dev tools
    "cargo", "rustc", "go", "java", "javac",
    # Text/code tools
    "code", "htop", "btop",
}

START_TIME = time.time()

# Task Management
agent_tasks = {}
task_counter = 0
task_lock = threading.Lock()
agent_logs = {}

# ═══════════════════════════════════════════════════════════════════
#  FLASK APP
# ═══════════════════════════════════════════════════════════════════

app = Flask(__name__)
CORS(app, resources={r"/*": {"origins": "*"}})

# ═══════════════════════════════════════════════════════════════════
#  USER AUTHENTICATION (File-based, works everywhere)
# ═══════════════════════════════════════════════════════════════════

def _ensure_data_dir():
    """Create data directory and default admin user."""
    os.makedirs(DATA_DIR, exist_ok=True)
    if not os.path.exists(USERS_FILE):
        # Create default admin account
        admin_pass = hashlib.sha256("admin".encode()).hexdigest()
        default_users = {
            "admin": {
                "username": "admin",
                "display_name": "Admin (Owner)",
                "password_hash": admin_pass,
                "role": "admin",
                "created": datetime.now().isoformat(),
                "last_login": None,
            }
        }
        with open(USERS_FILE, "w") as f:
            json.dump(default_users, f, indent=2, ensure_ascii=False)
        print("[AUTH] Created default admin account: admin / admin")
        print("[AUTH] IMPORTANT: Change the password after first login!")
    return USERS_FILE


def _load_users():
    """Load users from JSON file."""
    _ensure_data_dir()
    try:
        with open(USERS_FILE, "r") as f:
            return json.load(f)
    except Exception:
        return {}


def _save_users(users):
    """Save users to JSON file."""
    os.makedirs(DATA_DIR, exist_ok=True)
    with open(USERS_FILE, "w") as f:
        json.dump(users, f, indent=2, ensure_ascii=False)


def _hash_password(password):
    """Hash password with SHA-256 + salt."""
    salt = secrets.token_hex(16)
    hashed = hashlib.sha256((salt + password).encode()).hexdigest()
    return f"{salt}:${hashed}"


def _verify_password(password, stored_hash):
    """Verify password against stored hash."""
    if ":" not in stored_hash:
        # Legacy plain SHA-256
        return hashlib.sha256(password.encode()).hexdigest() == stored_hash
    salt, hashed = stored_hash.split(":", 1)
    return hashlib.sha256((salt + password).encode()).hexdigest() == hashed


# ═══════════════════════════════════════════════════════════════════
#  OLLAMA INTEGRATION
# ═══════════════════════════════════════════════════════════════════

def _ollama_up():
    """Is Ollama running?"""
    try:
        req = urllib.request.Request(OLLAMA_TAGS, method="GET")
        urllib.request.urlopen(req, timeout=5)
        return True
    except Exception:
        return False


def _ollama_models():
    """List Ollama models."""
    try:
        req = urllib.request.Request(OLLAMA_TAGS, method="GET")
        resp = urllib.request.urlopen(req, timeout=5)
        data = json.loads(resp.read().decode("utf-8"))
        return [m.get("name", "") for m in data.get("models", [])]
    except Exception:
        return []


def _model_ready(name):
    """Check if specific model is loaded in Ollama."""
    for m in _ollama_models():
        short = name.split("/")[-1]
        if short in m or name in m:
            return True
    return False


def _ollama_chat(model, messages, timeout=300):
    """Chat with Ollama. Returns (text, model) or (None, error)."""
    payload = json.dumps({
        "model": model,
        "messages": messages,
        "stream": False,
        "options": {
            "temperature": 0.7,
            "top_p": 0.9,
            "num_predict": 4096,
        }
    }).encode("utf-8")

    req = urllib.request.Request(
        OLLAMA_CHAT,
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST"
    )
    try:
        resp = urllib.request.urlopen(req, timeout=timeout)
        result = json.loads(resp.read().decode("utf-8"))
        text = result.get("message", {}).get("content", "")
        return text, model
    except Exception as e:
        return None, e


# ═══════════════════════════════════════════════════════════════════
#  MYANMAR LANGUAGE DETECTION
# ═══════════════════════════════════════════════════════════════════

_MYANMAR_RE = re.compile(r'[\u1000-\u109F\uAA60-\uAA7F]')

_CODE_KW = [
    "code", "program", "python", "javascript", "html", "css",
    "function", "class", "debug", "error", "bug", "compile", "run",
    "build", "create", "generate", "web", "app", "dashboard", "tool",
    "install", "setup", "api", "server", "database", "sort",
    "algorithm", "calculate", "math", "translate", "fix", "execute",
    "window", "button", "input", "output", "form", "table", "list",
    # Myanmar keywords
    "ပြုပြင်", "ချင်း", "ထုတ်", "ရေး", "စားရေး", "ဖြစ်စဉ်",
    "ကုဒ်", "ဖွင့်", "ထည့်", "ပြောင်း", "ဖော်ပြ",
    "ဘုတ်", "လမ်းညွှန်", "စီမံ", "အတွေ့အကြုံ",
]


def _is_myanmar(text):
    return bool(_MYANMAR_RE.search(text))


def _is_code(text):
    return any(k in text.lower() for k in _CODE_KW)


# ═══════════════════════════════════════════════════════════════════
#  TASK MANAGEMENT
# ═══════════════════════════════════════════════════════════════════

def _new_task(agent, message, task_type="single"):
    global task_counter
    with task_lock:
        task_counter += 1
        tid = f"task_{task_counter:05d}"
    agent_tasks[tid] = {
        "task_id": tid,
        "status": "pending",
        "progress": 0,
        "phase": "init",
        "agent": agent,
        "message": message[:200],
        "started": time.time(),
        "finished": None,
        "result": None,
        "error": None,
        "task_type": task_type,
        "backend": "unknown",
        "model": "",
    }
    agent_logs[tid] = []
    return tid


def _set_task(tid, **kw):
    if tid not in agent_tasks:
        return
    for k, v in kw.items():
        if k in agent_tasks[tid] and v is not None:
            agent_tasks[tid][k] = v


def _log(tid, agent, event, content):
    if tid in agent_logs:
        agent_logs[tid].append({
            "agent": agent, "event": event,
            "content": content[:500],
            "time": datetime.now().isoformat(),
        })
        if tid in agent_tasks:
            agent_tasks[tid]["agent_logs"] = agent_logs[tid][-50:]


def _done(tid, result, backend="ollama", model=""):
    _set_task(tid, status="completed", progress=100, phase="done",
              finished=time.time(), result=(result or "")[:500],
              backend=backend, model=model)


def _fail(tid, error):
    _set_task(tid, status="failed", finished=time.time(), error=str(error)[:500])


# ═══════════════════════════════════════════════════════════════════
#  HF FREE INFERENCE API (Fallback — ZERO COST)
# ═══════════════════════════════════════════════════════════════════

def _hf_chat(messages, model, timeout=120):
    """Call HF Free Inference API — no API key needed for free models."""
    prompt = ""
    for msg in messages:
        r = msg.get("role", "user")
        c = msg.get("content", "")
        prompt += f"<{r}> {c}\n"
    prompt += "<assistant>\n"

    payload = json.dumps({
        "inputs": prompt,
        "parameters": {
            "max_new_tokens": 4096,
            "temperature": 0.7,
            "top_p": 0.95,
            "return_full_text": False,
        },
        "options": {"wait_for_model": True},
    }).encode("utf-8")

    url = f"https://api-inference.huggingface.co/models/{model}"
    headers = {"Content-Type": "application/json"}
    if HF_TOKEN:
        headers["Authorization"] = f"Bearer {HF_TOKEN}"

    req = urllib.request.Request(url, data=payload, headers=headers)
    resp = urllib.request.urlopen(req, timeout=timeout)
    result = json.loads(resp.read().decode("utf-8"))
    if isinstance(result, list) and result:
        return result[0].get("generated_text", "")
    return str(result)


def _hf_fallback(messages, tid=None, agent="manager"):
    """Try HF models as fallback, return (text, model, backend)."""
    last_err = None
    for i, model in enumerate(HF_MODELS):
        try:
            if tid:
                pct = 10 + int((i / len(HF_MODELS)) * 60)
                _set_task(tid, progress=pct, phase="fallback",
                          message=f"HF fallback: {model.split('/')[-1]}")
                _log(tid, agent, "info", f"Fallback -> {model.split('/')[-1]}")
            reply = _hf_chat(messages, model)
            return reply, model, "hf-free"
        except Exception as e:
            last_err = e
            continue
    return None, last_err, "hf-free"


# ═══════════════════════════════════════════════════════════════════
#  SMART ROUTING ENGINE
# ═══════════════════════════════════════════════════════════════════

def _smart_chat(messages, agent_role, tid=None):
    """
    Route: Ollama (primary) -> HF Free (fallback)
    agent_role: 'worker' | 'manager'
    Returns: (text, model_name, backend_name)
    """
    if agent_role == "worker":
        ollama_model = WORKER_MODEL
    else:
        ollama_model = MANAGER_MODEL

    # Try Ollama
    if _ollama_up() and _model_ready(ollama_model):
        short = ollama_model.split("/")[-1]
        if tid:
            _set_task(tid, backend="ollama", model=short)
            _log(tid, agent_role, "info", f"Using Ollama: {short}")

        text, err = _ollama_chat(ollama_model, messages)
        if text:
            return text, ollama_model, "ollama"

        if tid:
            _log(tid, agent_role, "error",
                 f"Ollama failed: {str(err)[:100]}, switching to HF Free")
    else:
        if tid:
            reason = "not running" if not _ollama_up() else "model not loaded"
            _log(tid, agent_role, "info", f"Ollama {reason}, using HF Free")

    # HF Free fallback
    reply, model, backend = _hf_fallback(messages, tid, agent_role)
    if reply:
        return reply, model, backend

    return None, "All AI backends failed", "none"


# ═══════════════════════════════════════════════════════════════════
#  FRONTEND (Serve Desktop UI)
# ═══════════════════════════════════════════════════════════════════

@app.route("/")
def serve_desktop():
    """Serve MyanOS Desktop frontend."""
    return send_from_directory(DESKTOP_DIR, "index.html")


@app.route("/<path:path>")
def serve_static(path):
    """Serve static files from desktop/ directory."""
    file_path = os.path.join(DESKTOP_DIR, path)
    if os.path.isfile(file_path):
        return send_from_directory(DESKTOP_DIR, path)
    return jsonify({"error": "Not found"}), 404


# ═══════════════════════════════════════════════════════════════════
#  AUTHENTICATION API
# ═══════════════════════════════════════════════════════════════════

@app.route("/api/auth/login", methods=["POST"])
def auth_login():
    """User login with username + password."""
    data = request.get_json(force=True, silent=True) or {}
    username = data.get("username", "").strip().lower()
    password = data.get("password", "")

    if not username or not password:
        return jsonify({"success": False, "error": "Username and password required"}), 400

    users = _load_users()
    user = users.get(username)

    if not user:
        return jsonify({"success": False, "error": "User not found"}), 401

    if not _verify_password(password, user["password_hash"]):
        return jsonify({"success": False, "error": "Wrong password"}), 401

    # Update last login
    user["last_login"] = datetime.now().isoformat()
    users[username] = user
    _save_users(users)

    # Generate session token
    token = secrets.token_hex(32)
    return jsonify({
        "success": True,
        "token": token,
        "user": {
            "username": user["username"],
            "display_name": user.get("display_name", user["username"]),
            "role": user.get("role", "user"),
        },
    })


@app.route("/api/auth/register", methods=["POST"])
def auth_register():
    """Register a new user."""
    data = request.get_json(force=True, silent=True) or {}
    username = data.get("username", "").strip().lower()
    password = data.get("password", "")
    display_name = data.get("display_name", username)

    if not username or not password:
        return jsonify({"success": False, "error": "Username and password required"}), 400

    if len(username) < 3:
        return jsonify({"success": False, "error": "Username must be at least 3 characters"}), 400

    if len(password) < 4:
        return jsonify({"success": False, "error": "Password must be at least 4 characters"}), 400

    users = _load_users()

    if username in users:
        return jsonify({"success": False, "error": "Username already exists"}), 409

    # Create user
    password_hash = _hash_password(password)
    users[username] = {
        "username": username,
        "display_name": display_name,
        "password_hash": password_hash,
        "role": "user",
        "created": datetime.now().isoformat(),
        "last_login": None,
    }
    _save_users(users)

    token = secrets.token_hex(32)
    return jsonify({
        "success": True,
        "token": token,
        "user": {
            "username": username,
            "display_name": display_name,
            "role": "user",
        },
    })


@app.route("/api/auth/guest", methods=["POST"])
def auth_guest():
    """Continue as guest (no account needed)."""
    token = secrets.token_hex(32)
    return jsonify({
        "success": True,
        "token": token,
        "user": {
            "username": "guest",
            "display_name": "Guest",
            "role": "guest",
        },
    })


@app.route("/api/auth/change-password", methods=["POST"])
def auth_change_password():
    """Change user password."""
    data = request.get_json(force=True, silent=True) or {}
    username = data.get("username", "").strip().lower()
    old_password = data.get("old_password", "")
    new_password = data.get("new_password", "")

    if not username or not old_password or not new_password:
        return jsonify({"success": False, "error": "All fields required"}), 400

    if len(new_password) < 4:
        return jsonify({"success": False, "error": "New password must be at least 4 characters"}), 400

    users = _load_users()
    user = users.get(username)
    if not user:
        return jsonify({"success": False, "error": "User not found"}), 404

    if not _verify_password(old_password, user["password_hash"]):
        return jsonify({"success": False, "error": "Current password is wrong"}), 401

    user["password_hash"] = _hash_password(new_password)
    users[username] = user
    _save_users(users)

    return jsonify({"success": True, "message": "Password changed successfully"})


@app.route("/api/auth/users", methods=["GET"])
def auth_list_users():
    """List all registered users (admin only)."""
    users = _load_users()
    safe_users = {}
    for u, data in users.items():
        safe_users[u] = {
            "username": data["username"],
            "display_name": data.get("display_name", u),
            "role": data.get("role", "user"),
            "created": data.get("created", ""),
            "last_login": data.get("last_login", ""),
        }
    return jsonify({"users": safe_users, "count": len(safe_users)})


# ═══════════════════════════════════════════════════════════════════
#  TERMINAL / SHELL ACCESS (Real subprocess)
# ═══════════════════════════════════════════════════════════════════

def _get_shell():
    """Get the appropriate shell for the current environment."""
    if ENV["is_termux"]:
        return "/data/data/com.termux/files/usr/bin/bash"
    elif ENV["is_linux"]:
        return "/bin/bash"
    elif ENV["is_macos"]:
        return "/bin/zsh"
    elif ENV["is_windows"]:
        return "cmd.exe"
    return "/bin/sh"


def _run_shell_command(cmd, timeout=30):
    """Execute a shell command and return output."""
    shell = _get_shell()
    try:
        # Detect if it's a Python one-liner
        if cmd.strip().startswith(("python ", "python3 ", "!python ", "!python3 ")):
            code = cmd.strip()
            for prefix in ["!python ", "!python3 ", "python ", "python3 "]:
                code = code.replace(prefix, "", 1)
            result = subprocess.run(
                [sys.executable, "-c", code],
                capture_output=True, text=True, timeout=120,
                shell=False
            )
            output = result.stdout
            if result.stderr:
                output += "\n" + result.stderr
            return output, result.returncode

        # Real shell command
        result = subprocess.run(
            cmd,
            capture_output=True, text=True, timeout=timeout,
            shell=True,
            executable=shell,
            cwd=BASE_DIR,
        )
        output = result.stdout
        if result.stderr:
            output += "\n" + result.stderr
        return output, result.returncode

    except subprocess.TimeoutExpired:
        return f"[TIMEOUT] Command exceeded {timeout}s limit", 1
    except Exception as e:
        return f"[ERROR] {e}", 1


@app.route("/api/exec", methods=["POST"])
def exec_cmd():
    """Execute shell command or Python code. Supports apt, sudo, etc."""
    data = request.get_json(force=True, silent=True) or {}
    cmd = data.get("cmd", "").strip()

    if not cmd:
        return jsonify({"output": "", "status": 0})

    # Handle sudo — strip it, run directly (MyanOS runs as user, no real sudo needed)
    # In Termux there's no sudo; on Linux the server already has user permissions
    sudo_strip = cmd
    if sudo_strip.startswith("sudo "):
        sudo_strip = sudo_strip[5:].strip()

    # Handle apt-get commands with -y flag auto-injection
    if sudo_strip.startswith(("apt ", "apt-get ")):
        parts = sudo_strip.split()
        action = parts[1] if len(parts) > 1 else ""
        if action in ("install", "remove", "purge", "update", "upgrade", "dist-upgrade", "autoremove"):
            if "-y" not in parts:
                parts.insert(2, "-y")
            sudo_strip = " ".join(parts)

    # Handle Termux pkg commands
    if sudo_strip.startswith("pkg "):
        parts = sudo_strip.split()
        action = parts[1] if len(parts) > 1 else ""
        if action in ("install", "remove", "search", "list-installed"):
            if action == "install" and "-y" not in parts:
                parts.insert(2, "-y")
            sudo_strip = " ".join(parts)

    # Handle systemctl (check if running on a system with systemd)
    if sudo_strip.startswith("systemctl ") and ENV.get("is_termux"):
        return jsonify({"output": "[INFO] systemctl is not available in Termux. Use 'sv' or 'termux-service' instead.", "status": 1})

    output, status = _run_shell_command(sudo_strip, timeout=120)
    return jsonify({"output": output, "status": status})


@app.route("/api/shell", methods=["POST"])
def shell_exec():
    """Execute shell command (real terminal access)."""
    data = request.get_json(force=True, silent=True) or {}
    cmd = data.get("cmd", "").strip()

    if not cmd:
        return jsonify({"output": "", "status": 0, "cwd": BASE_DIR})

    # Get optional working directory
    cwd = data.get("cwd", BASE_DIR)
    if not os.path.isdir(cwd):
        cwd = BASE_DIR

    shell = _get_shell()
    try:
        result = subprocess.run(
            cmd,
            capture_output=True, text=True, timeout=60,
            shell=True,
            executable=shell,
            cwd=cwd,
            env={**os.environ},
        )
        output = result.stdout
        if result.stderr:
            output += "\n" + result.stderr
        return jsonify({
            "output": output,
            "status": result.returncode,
            "cwd": cwd,
            "shell": shell,
        })
    except subprocess.TimeoutExpired:
        return jsonify({"output": "[TIMEOUT] 60s exceeded", "status": 1, "cwd": cwd})
    except Exception as e:
        return jsonify({"output": f"[ERROR] {e}", "status": 1, "cwd": cwd})


# ═══════════════════════════════════════════════════════════════════
#  OLLAMA MANAGEMENT
# ═══════════════════════════════════════════════════════════════════

@app.route("/api/ollama-status")
def ollama_status():
    """Check Ollama status and loaded models."""
    ollama = _ollama_up()
    models = []
    if ollama:
        try:
            req = urllib.request.Request(OLLAMA_TAGS, method="GET")
            resp = urllib.request.urlopen(req, timeout=5)
            data = json.loads(resp.read().decode("utf-8"))
            for m in data.get("models", []):
                models.append({
                    "name": m.get("name", ""),
                    "size_gb": round(m.get("size", 0) / (1024**3), 2),
                    "modified": m.get("modified_at", ""),
                })
        except Exception:
            pass

    return jsonify({
        "available": ollama,
        "host": OLLAMA_HOST,
        "models": models,
        "worker": {
            "model": WORKER_MODEL,
            "loaded": any("burmese-coder" in m.get("name", "") for m in models),
        },
        "manager": {
            "model": MANAGER_MODEL,
            "loaded": any("qwen" in m.get("name", "") for m in models),
        },
    })


@app.route("/api/ollama-pull", methods=["POST"])
def ollama_pull():
    """Pull a model from Ollama library."""
    data = request.get_json(force=True, silent=True) or {}
    model = data.get("model", WORKER_MODEL)

    if not _ollama_up():
        return jsonify({"success": False, "error": "Ollama is not running"}), 503

    def _pull():
        tid = _new_task("system", f"Pull model: {model}", "ollama")
        _set_task(tid, status="running", progress=5, phase="pulling")
        try:
            payload = json.dumps({"name": model, "stream": False}).encode("utf-8")
            req = urllib.request.Request(
                f"{OLLAMA_HOST}/api/pull",
                data=payload,
                headers={"Content-Type": "application/json"},
                method="POST"
            )
            resp = urllib.request.urlopen(req, timeout=1800)
            _done(tid, f"Pulled: {model}", "ollama", model)
        except Exception as e:
            _fail(tid, e)

    thread = threading.Thread(target=_pull, daemon=True)
    thread.start()

    return jsonify({
        "success": True,
        "message": f"Pulling {model}... (this may take a while)",
        "model": model,
    })


# ═══════════════════════════════════════════════════════════════════
#  AI CHAT — Smart Routing
# ═══════════════════════════════════════════════════════════════════

@app.route("/api/ai-chat", methods=["POST"])
def ai_chat():
    """
    Smart AI Chat with auto-routing:
    - Myanmar + coding -> Worker (Burmese Coder 4B)
    - General question -> Manager (Qwen2.5-7B)
    - Worker error -> Manager reviews
    """
    data = request.get_json(force=True, silent=True) or {}
    messages = data.get("messages", [])

    if not messages:
        return jsonify({"success": False, "error": "messages required"}), 400

    # Get last user message
    user_msg = ""
    for msg in reversed(messages):
        if msg.get("role") == "user":
            user_msg = msg.get("content", "")
            break

    # Route based on language + intent
    has_mm = _is_myanmar(user_msg)
    is_code = _is_code(user_msg)

    if has_mm and is_code:
        role = "worker"
        display = "Lead Developer (Burmese Coder 4B)"
    elif is_code:
        role = "worker"
        display = "Lead Developer (Burmese Coder 4B)"
    else:
        role = "manager"
        display = "Project Manager (Qwen2.5-7B)"

    tid = _new_task(role, user_msg[:200], "single")
    _set_task(tid, status="running", progress=5, phase="analyzing")
    _log(tid, "system", "info", f"Routing: {display}")

    text, model, backend = _smart_chat(messages, role, tid)

    if text:
        short_model = model.split("/")[-1] if model else ""
        _done(tid, text[:200], backend, short_model)

        return jsonify({
            "success": True,
            "response": text,
            "backend": backend,
            "agent": role,
            "agent_display": display,
            "model": model,
            "task_id": tid,
            "cost": 0,
        })

    _fail(tid, model)
    return jsonify({
        "success": False,
        "error": f"All AI backends failed: {model}",
        "task_id": tid,
    }), 503


@app.route("/api/multi-agent", methods=["POST"])
def multi_agent():
    """
    Full 3-phase pipeline:
    1. Manager: Analyze + Plan
    2. Worker: Generate code
    3. Manager: Review + Fix errors
    """
    data = request.get_json(force=True, silent=True) or {}
    task_desc = data.get("task", "")
    context = data.get("context", "")
    language = data.get("language", "myanmar")

    if not task_desc:
        return jsonify({"success": False, "error": "task required"}), 400

    tid = _new_task("manager", task_desc, "pipeline")
    _set_task(tid, status="running", progress=5, phase="analyzing")
    _log(tid, "system", "info", f"Multi-Agent pipeline: {task_desc[:100]}")

    def _run():
        try:
            # Phase 1: Manager (Planning)
            _set_task(tid, progress=10, phase="planning",
                      message="Manager: Analyzing task...")
            _log(tid, "manager", "thinking", "Analyzing requirements...")

            mgr_msgs = [
                {"role": "system", "content": f"""You are the Project Manager AI in a multi-agent system.
Your job:
1. Analyze the user's task thoroughly
2. Break it into clear implementation steps
3. Specify technologies (HTML/CSS/JS for web, Python for tools)
4. Give specific instructions for the Lead Developer

## Response Format:
### Task Analysis
[Your detailed analysis]

### Implementation Plan
1. [Step 1]
2. [Step 2]
3. [Step 3]

### For Lead Developer
[Specific code instructions - be very detailed]

### Expected Output
[What the final result should look like]

Language preference: {language}. Use Myanmar if user writes in Myanmar."""},
                {"role": "user", "content": f"Context: {context}\n\nTask: {task_desc}"}
            ]

            plan, _, _ = _smart_chat(mgr_msgs, "manager", tid)
            if not plan:
                _fail(tid, "Manager failed to analyze task")
                return

            _log(tid, "manager", "response", plan[:500])
            _set_task(tid, progress=30, phase="generating",
                      message="Manager: Plan done -> Worker")

            # Phase 2: Worker (Code Generation)
            _log(tid, "worker", "thinking", "Generating code...")

            wrk_msgs = [
                {"role": "system", "content": f"""You are the Lead Developer AI. Write clean, working code.
Rules:
- Web apps: Complete single HTML file with embedded CSS + JavaScript
- Dark theme (Tokyo Night: #1a1b2e, #24283b, #7aa2f7, #c0caf5)
- Myanmar font: font-family: 'Noto Sans Myanmar', sans-serif
- Beautiful, responsive, functional, modern UI
- All interactive elements must work
- Include helpful code comments

CRITICAL: Output ONLY the code. No markdown, no explanations.
If HTML: start with <!DOCTYPE html>
If Python: start with #!/usr/bin/env python3"""},
                {"role": "user", "content": f"## Manager's Plan:\n{plan}\n\n## Build this:\n{task_desc}"}
            ]

            _set_task(tid, progress=40, message="Worker: Writing code...")
            code, _, _ = _smart_chat(wrk_msgs, "worker", tid)

            if not code:
                _log(tid, "worker", "error", "Worker failed. Manager stepping in...")
                _set_task(tid, progress=50, message="Manager: Taking over coding...")
                backup = [
                    {"role": "system", "content": """You are generating code. Write complete working code.
Output ONLY the code. No markdown wrapping.
Web apps: complete HTML file with CSS and JavaScript.
Tools: complete Python script."""},
                    {"role": "user", "content": f"Write code for: {task_desc}\n\nPlan:\n{plan[:500]}"}
                ]
                code, _, _ = _smart_chat(backup, "manager", tid)
                if not code:
                    _fail(tid, "Both Worker and Manager failed")
                    return

            _log(tid, "worker", "response", code[:500])
            _set_task(tid, progress=70, phase="reviewing",
                      message="Worker: Code done -> Manager review")

            # Phase 3: Manager (Code Review)
            _log(tid, "manager", "thinking", "Reviewing code quality...")

            rev_msgs = [
                {"role": "system", "content": """You are a Code Reviewer. Check for:
1. Bugs and logic errors
2. Missing features or incomplete functionality
3. Security issues (XSS, injection, etc.)
4. Code quality and best practices
5. UI/UX improvements

## Response Format:
### Review Summary
[Overall assessment - 2-3 sentences]

### Issues Found
- [Issue 1 and how to fix it]

### Rating: X/10

### Corrected Code
[If corrections needed: complete corrected code]
[If no corrections: "No changes needed"]"""},
                {"role": "user", "content": f"Task: {task_desc}\n\nCode to review:\n{code}\n\nReview and fix if needed."}
            ]

            _set_task(tid, progress=80, message="Manager: Reviewing...")
            review, _, _ = _smart_chat(rev_msgs, "manager", tid)

            final_code = code
            if review:
                _log(tid, "manager", "response", review[:500])
                if "### Corrected Code" in review:
                    corrected = review.split("### Corrected Code")[-1].strip()
                    if len(corrected) > 100:
                        final_code = corrected
                        _log(tid, "manager", "info", "Corrections applied from review")

            if tid in agent_tasks:
                agent_tasks[tid]["pipeline"] = {
                    "manager_plan": plan,
                    "worker_code": code,
                    "manager_review": review or "Skipped",
                    "final_code": final_code,
                }

            _done(tid, "Pipeline complete", "multi-agent", "pipeline")

        except Exception as e:
            _log(tid, "system", "error", f"Pipeline error: {str(e)}")
            _fail(tid, e)

    thread = threading.Thread(target=_run, daemon=True)
    thread.start()

    return jsonify({
        "success": True,
        "task_id": tid,
        "message": "Multi-agent pipeline started",
        "poll_url": f"/api/task-status?task_id={tid}",
        "logs_url": f"/api/task-logs?task_id={tid}",
        "agents": ["manager", "worker", "manager (reviewer)"],
    })


# ═══════════════════════════════════════════════════════════════════
#  AI DEV ENVIRONMENT
# ═══════════════════════════════════════════════════════════════════

@app.route("/api/ai-dev", methods=["POST"])
def ai_dev():
    """Generate web apps/tools using AI."""
    data = request.get_json(force=True, silent=True) or {}
    task = data.get("task", "")
    dev_type = data.get("type", "web")

    if not task:
        return jsonify({"success": False, "error": "task required"}), 400

    tid = _new_task("worker", task, "ai-dev")
    _set_task(tid, status="running", progress=10, phase="generating")

    prompts = {
        "web": """Expert web developer for Myanmar language apps.
Create complete single-file HTML application.
- Dark theme (Tokyo Night: #1a1b2e, #24283b, #7aa2f7, #c0caf5)
- Myanmar text with proper Unicode fonts
- Beautiful, responsive, functional
- All elements must work
Output ONLY the HTML code. No markdown.""",

        "dashboard": """Data dashboard expert. Create analytics dashboard.
- Dark theme with KPI cards, progress bars, charts, tables
- CSS/SVG charts (no external libraries)
- Myanmar language labels
- Responsive grid layout
Output ONLY HTML code.""",

        "tool": """Utility tool developer. Create a web-based tool.
- Dark theme, functional, beautiful design
- Myanmar language interface
- Fully working logic
Output ONLY HTML code.""",
    }

    messages = [
        {"role": "system", "content": prompts.get(dev_type, prompts["web"])},
        {"role": "user", "content": f"Build this: {task}"}
    ]

    reply, model, backend = _smart_chat(messages, "worker", tid)

    if reply:
        code = reply.strip()
        for prefix in ["```html", "```python", "```"]:
            if code.startswith(prefix):
                code = code[len(prefix):].strip()
                break
        if code.endswith("```"):
            code = code[:-3].strip()

        _done(tid, f"Generated {dev_type} ({len(code)} chars)", backend, model)
        return jsonify({
            "success": True,
            "code": code,
            "task_id": tid,
            "type": dev_type,
            "size": len(code),
            "backend": backend,
        })

    _fail(tid, model)
    return jsonify({"success": False, "error": f"Failed: {model}", "task_id": tid}), 503


# ═══════════════════════════════════════════════════════════════════
#  MEMORY (Personal AI Assistant)
# ═══════════════════════════════════════════════════════════════════

@app.route("/api/memory", methods=["GET", "POST"])
def memory():
    if request.method == "GET":
        return jsonify({"status": "ok", "note": "Client stores in IndexedDB. POST to process with AI."})

    data = request.get_json(force=True, silent=True) or {}
    action = data.get("action", "query")
    memories = data.get("memories", [])
    query = data.get("query", "")

    if action == "query" and query and memories:
        ctx = "\n".join([f"- {m.get('content', '')}" for m in memories[-20:]])
        messages = [
            {"role": "system", "content": f"""Personal AI assistant with memory.
Answer using stored memories as context. Be helpful and specific.
Use Myanmar if user writes Myanmar.

User's memories:
{ctx}"""},
            {"role": "user", "content": query}
        ]
        tid = _new_task("manager", query[:100], "memory")
        reply, model, backend = _smart_chat(messages, "manager", tid)
        if reply:
            _done(tid, reply[:200], backend, model)
            return jsonify({"success": True, "response": reply, "task_id": tid})
        _fail(tid, model)
        return jsonify({"success": False, "error": str(model)}), 503

    return jsonify({"success": True, "message": "Memory ready", "action": action})


# ═══════════════════════════════════════════════════════════════════
#  TASK STATUS & LOGS
# ═══════════════════════════════════════════════════════════════════

@app.route("/api/task-status")
def task_status():
    tid = request.args.get("task_id", "")
    if tid and tid in agent_tasks:
        return jsonify(agent_tasks[tid])

    tasks = {}
    for tid, t in sorted(agent_tasks.items(),
                         key=lambda x: x[1].get("started", 0),
                         reverse=True)[:20]:
        tasks[tid] = t
    return jsonify({"tasks": tasks, "total": len(agent_tasks)})


@app.route("/api/task-logs")
def task_logs():
    tid = request.args.get("task_id", "")
    if not tid:
        return jsonify({"error": "task_id required"}), 400
    logs = agent_logs.get(tid, [])
    return jsonify({"task_id": tid, "logs": logs, "count": len(logs)})


# ═══════════════════════════════════════════════════════════════════
#  SYSTEM INFO & HEALTH
# ═══════════════════════════════════════════════════════════════════

@app.route("/api/health")
def health():
    ollama = _ollama_up()
    models = _ollama_models() if ollama else []
    cpu = 0
    mem_gb = 0
    try:
        import psutil
        cpu = psutil.cpu_percent(interval=0.3)
        mem_gb = round(psutil.virtual_memory().available / (1024**3), 2)
    except ImportError:
        pass

    worker_ready = any("burmese-coder" in m for m in models)
    manager_ready = any("qwen" in m for m in models)

    return jsonify({
        "status": "healthy",
        "version": VERSION,
        "environment": ENV,
        "ollama": {"available": ollama, "models": models},
        "cpu_percent": cpu,
        "memory_available_gb": mem_gb,
        "ai_backend": "ollama" if (ollama and worker_ready) else "hf-free",
        "agents": {
            "manager": {
                "model": MANAGER_MODEL,
                "status": "ready" if manager_ready else ("loading" if ollama else "offline"),
            },
            "worker": {
                "model": WORKER_MODEL,
                "status": "ready" if worker_ready else ("loading" if ollama else "offline"),
            },
        },
        "active_tasks": sum(1 for t in agent_tasks.values() if t["status"] == "running"),
        "uptime_seconds": int(time.time() - START_TIME),
        "timestamp": datetime.now().isoformat(),
    })


@app.route("/api/heartbeat")
def heartbeat():
    ollama = _ollama_up()
    models = _ollama_models() if ollama else []
    worker_ready = any("burmese-coder" in m for m in models)
    manager_ready = any("qwen" in m for m in models)

    active = []
    for tid, t in sorted(agent_tasks.items(),
                         key=lambda x: x[1].get("started", 0),
                         reverse=True):
        if t["status"] == "running":
            active.append({
                "task_id": t["task_id"],
                "status": t["status"],
                "progress": t["progress"],
                "phase": t["phase"],
                "agent": t["agent"],
                "backend": t["backend"],
                "message": t["message"],
            })
        if len(active) >= 5:
            break

    return jsonify({
        "beat": "alive",
        "timestamp": datetime.now().isoformat(),
        "uptime": int(time.time() - START_TIME),
        "system": {
            "ollama": ollama,
            "models_loaded": len(models),
            "lead_dev_ready": worker_ready,
            "manager_ready": manager_ready,
            "environment": ENV["system"],
        },
        "agents": {
            "manager": {
                "model": MANAGER_MODEL,
                "status": "ready" if manager_ready else ("loading" if ollama else "offline"),
            },
            "worker": {
                "model": WORKER_MODEL,
                "status": "ready" if worker_ready else ("loading" if ollama else "offline"),
            },
        },
        "active_tasks": active,
    })


@app.route("/api/system")
def system_info():
    return jsonify({
        "os": f"MyanOS Web OS v{VERSION}",
        "platform": f"{platform.system()} {platform.machine()}",
        "python": platform.python_version(),
        "version": VERSION,
        "environment": ENV,
        "ai_backend": "Ollama + HF Free",
        "hostname": platform.node(),
    })


@app.route("/api/system-stats")
def system_stats():
    stats = {
        "cpu": {"percent": 0, "cores_logical": 0},
        "memory": {"total_gb": 0, "used_gb": 0, "percent": 0},
        "disk": {"total_gb": 0, "used_gb": 0, "free_gb": 0, "percent": 0},
        "os_info": {"system": platform.system(), "myanos_version": VERSION, "environment": ENV},
        "uptime_seconds": int(time.time() - START_TIME),
        "timestamp": datetime.now().isoformat(),
    }
    try:
        import psutil
        stats["cpu"]["percent"] = psutil.cpu_percent(interval=0.3)
        stats["cpu"]["cores_logical"] = psutil.cpu_count(logical=True) or 0
        mem = psutil.virtual_memory()
        stats["memory"] = {
            "total_gb": round(mem.total / 1e9, 1),
            "used_gb": round(mem.used / 1e9, 1),
            "percent": mem.percent,
        }
        disk = psutil.disk_usage("/")
        stats["disk"] = {
            "total_gb": round(disk.total / 1e9, 1),
            "used_gb": round(disk.used / 1e9, 1),
            "free_gb": round(disk.free / 1e9, 1),
            "percent": disk.percent,
        }
    except ImportError:
        pass
    return jsonify(stats)


@app.route("/api/agent-status")
def agent_status():
    ollama = _ollama_up()
    models = _ollama_models() if ollama else []
    completed = sum(1 for t in agent_tasks.values() if t["status"] == "completed")
    failed = sum(1 for t in agent_tasks.values() if t["status"] == "failed")

    return jsonify({
        "version": VERSION,
        "architecture": "Ollama Multi-Agent (2 Agents + HF Free Fallback)",
        "worker": {
            "model": WORKER_MODEL,
            "role": "Myanmar Code Generation (Lead Developer)",
            "status": "online" if any("burmese-coder" in m for m in models)
                       else ("loading" if ollama else "offline"),
        },
        "manager": {
            "model": MANAGER_MODEL,
            "role": "Planning, Routing, Code Review (Project Manager)",
            "status": "online" if any("qwen" in m for m in models)
                       else ("loading" if ollama else "offline"),
        },
        "stats": {"total_tasks": len(agent_tasks), "completed": completed, "failed": failed},
        "environment": ENV,
    })


@app.route("/api/training", methods=["GET", "POST"])
def training():
    """AI Training Center — execute Python code cells, manage sessions."""
    if request.method == "GET":
        return jsonify({
            "status": "ok",
            "python": platform.python_version(),
            "ai_backend": "Ollama + HF Free",
            "system": ENV["system"],
            "machine": ENV["machine"],
            "home": ENV["home"],
            "packages_available": _check_training_packages(),
        })
    data = request.get_json(force=True, silent=True) or {}
    action = data.get("action", "")

    if action == "execute_cell":
        code = data.get("code", "").strip()
        if not code:
            return jsonify({"output": "[ERROR] No code provided", "status": 1})

        # Route to Python subprocess for code execution
        # Auto-detect if it's Python code or shell command
        is_python = any(kw in code for kw in [
            "import ", "def ", "class ", "print(", "from ",
            "for ", "while ", "if ", "return ", "lambda ",
            "try:", "except ", "with ", "async ", "await ",
            "True", "False", "None", "range(", "len(", "list(",
            "dict(", "input(", "int(", "float(", "str(",
        ])

        if is_python:
            # Run as Python code with full stdlib access
            try:
                result = subprocess.run(
                    [sys.executable, "-c", code],
                    capture_output=True, text=True, timeout=180,
                    cwd=BASE_DIR, env={**os.environ},
                )
                output = result.stdout
                if result.stderr:
                    output += ("\n" if output else "") + result.stderr
                return jsonify({"output": output, "status": result.returncode})
            except subprocess.TimeoutExpired:
                return jsonify({"output": "[TIMEOUT] Code execution exceeded 180s limit", "status": 1})
            except Exception as e:
                return jsonify({"output": f"[ERROR] {e}", "status": 1})
        else:
            # Run as shell command
            output, status = _run_shell_command(code, timeout=120)
            return jsonify({"output": output, "status": status})

    elif action == "install_package":
        """Install a Python package via pip."""
        pkg_name = data.get("package", "").strip()
        if not pkg_name:
            return jsonify({"output": "[ERROR] Package name required", "status": 1})
        try:
            result = subprocess.run(
                [sys.executable, "-m", "pip", "install", pkg_name, "--quiet"],
                capture_output=True, text=True, timeout=300,
            )
            output = result.stdout or f"Installed {pkg_name}"
            if result.stderr:
                output += "\n" + result.stderr
            return jsonify({"output": output, "status": result.returncode})
        except Exception as e:
            return jsonify({"output": f"[ERROR] {e}", "status": 1})

    elif action == "check_package":
        """Check if a Python package is installed."""
        pkg_name = data.get("package", "").strip()
        try:
            result = subprocess.run(
                [sys.executable, "-c", f"import {pkg_name.split('==')[0]}; print({pkg_name}.__version__ if hasattr({pkg_name.split('==')[0]}, '__version__') else 'installed')"],
                capture_output=True, text=True, timeout=10,
            )
            return jsonify({"output": result.stdout.strip(), "status": result.returncode})
        except Exception as e:
            return jsonify({"output": f"not installed", "status": 1})

    elif action == "system_info":
        """Get system information for dashboard."""
        import shutil
        info = {
            "python": platform.python_version(),
            "system": platform.system(),
            "machine": platform.machine(),
            "cpu_count": os.cpu_count(),
            "home": str(Path.home()),
        }
        try:
            info["disk_total"] = shutil.disk_usage("/").total
            info["disk_free"] = shutil.disk_usage("/").free
            info["disk_used"] = shutil.disk_usage("/").used
        except:
            pass
        return jsonify(info)

    return jsonify({"error": f"Unknown action: {action}", "status": 1}), 400


def _check_training_packages():
    """Check which common ML/data packages are available."""
    packages = ["numpy", "pandas", "matplotlib", "sklearn", "torch", "tensorflow", "requests", "flask"]
    available = {}
    for pkg in packages:
        try:
            result = subprocess.run(
                [sys.executable, "-c", f"import {pkg}; print('ok')"],
                capture_output=True, text=True, timeout=5,
            )
            available[pkg] = result.returncode == 0
        except:
            available[pkg] = False
    return available


@app.route("/api/proxy", methods=["GET", "POST"])
def web_proxy():
    """Fetch web page content for browser (bypasses CORS/X-Frame-Options)."""
    url = request.args.get("url", "") or (request.get_json(force=True, silent=True) or {}).get("url", "")
    if not url:
        return jsonify({"error": "URL required"}), 400

    if not url.startswith(("http://", "https://")):
        return jsonify({"error": "Invalid URL"}), 400

    try:
        req = urllib.request.Request(url, method="GET")
        req.add_header("User-Agent", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
        req.add_header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
        resp = urllib.request.urlopen(req, timeout=15)
        content = resp.read().decode("utf-8", errors="replace")

        # Rewrite relative URLs to absolute
        from html.parser import HTMLParser
        base = url.rsplit("/", 1)[0]

        return jsonify({
            "url": url,
            "status": resp.status,
            "content": content,
            "base_url": base,
        })
    except Exception as e:
        return jsonify({"error": str(e), "url": url}), 502


@app.route("/api/")
def api_root():
    ollama = _ollama_up()
    models = _ollama_models() if ollama else []
    return jsonify({
        "status": "running",
        "service": "MyanOS Web OS",
        "version": VERSION,
        "uptime_seconds": int(time.time() - START_TIME),
        "environment": ENV,
        "ai_backend": "Ollama (Primary) + HF Free (Fallback)",
        "ollama": {
            "available": ollama,
            "models": models,
            "worker": WORKER_MODEL,
            "manager": MANAGER_MODEL,
        },
        "auth": {
            "login": "POST /api/auth/login",
            "register": "POST /api/auth/register",
            "guest": "POST /api/auth/guest",
            "change_password": "POST /api/auth/change-password",
            "default_admin": "admin / admin (CHANGE AFTER FIRST LOGIN!)",
        },
        "endpoints": {
            "health": "/api/health",
            "heartbeat": "/api/heartbeat",
            "ai_chat": "/api/ai-chat",
            "multi_agent": "/api/multi-agent",
            "ai_dev": "/api/ai-dev",
            "memory": "/api/memory",
            "exec": "/api/exec",
            "shell": "/api/shell",
            "task_status": "/api/task-status",
            "task_logs": "/api/task-logs",
            "agent_status": "/api/agent-status",
            "ollama_status": "/api/ollama-status",
            "system": "/api/system",
            "system_stats": "/api/system-stats",
        },
        "github": "https://github.com/meonnmi-ops/Myanos",
    })


# ═══════════════════════════════════════════════════════════════════
#  MAIN ENTRY POINT
# ═══════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="MyanOS Universal Backend")
    parser.add_argument("--host", default=None, help="Host to bind to (default: 0.0.0.0 for Termux, 127.0.0.1 for Linux)")
    parser.add_argument("--port", type=int, default=PORT, help=f"Port to listen on (default: {PORT})")
    parser.add_argument("--debug", action="store_true", help="Enable debug mode")
    args = parser.parse_args()

    # Auto-detect host
    host = args.host
    if not host:
        if ENV["is_termux"]:
            host = "0.0.0.0"
        else:
            host = "127.0.0.1"

    port = args.port
    debug = args.debug

    # Initialize data directory and default admin
    _ensure_data_dir()

    # Print startup banner
    print()
    print("=" * 60)
    print("  MYANOS WEB OS — UNIVERSAL BACKEND v" + VERSION)
    print("=" * 60)
    print(f"  Environment : {ENV['system']}")
    print(f"  Machine     : {ENV['machine']}")
    print(f"  Python      : {ENV['python']}")
    print(f"  Hostname    : {ENV['hostname']}")
    print(f"  Home        : {ENV['home']}")
    print(f"  Base Dir    : {BASE_DIR}")
    print("-" * 60)
    print(f"  Server      : http://{host}:{port}")
    print(f"  (For phone  : http://0.0.0.0:{port})")
    print(f"  AI Backend  : Ollama + HF Free (Zero Cost)")
    print(f"  Worker      : {WORKER_MODEL}")
    print(f"  Manager     : {MANAGER_MODEL}")
    print("-" * 60)
    print(f"  Default Login: admin / admin")
    print(f"  IMPORTANT: Change password after first login!")
    print("=" * 60)
    print()

    # Run Flask
    app.run(
        host=host,
        port=port,
        debug=debug,
        threaded=True,
        use_reloader=False,
    )
