#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════
#  MyanOS Universal Engine Starter v4.2.1
# ═══════════════════════════════════════════════════════════════════
#  Works on:
#    - Phone  (Termux / Android)  — ARM64
#    - Laptop (antiX / Ubuntu / any Linux) — x86_64
#    - Desktop (Windows / macOS) — via Python
#
#  Usage:
#    chmod +x start-engine.sh
#    ./start-engine.sh              # Auto-detect and start
#    ./start-engine.sh --port 8080  # Custom port
#    ./start-engine.sh --debug      # Debug mode
# ═══════════════════════════════════════════════════════════════════

set -e

# Colors (if supported)
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo ""
echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}  MYANOS ENGINE STARTER v4.2.1${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
echo ""

# ── Step 1: Detect Environment ──
echo -e "${BLUE}[1/5] Detecting environment...${NC}"

IS_TERMUX=false
IS_ANDROID=false
IS_LINUX=false
IS_MACOS=false
IS_WINDOWS=false

if [ -n "$TERMUX_VERSION" ] || [ -n "$TERMUX__APK_VERSION" ] || echo "$PREFIX" | grep -q "com.termux" 2>/dev/null; then
    IS_TERMUX=true
    IS_ANDROID=true
    echo -e "  ${GREEN}Platform: Android (Termux)${NC}"
    echo -e "  ${GREEN}Arch: $(uname -m)${NC}"
elif [ "$(uname -s)" = "Linux" ]; then
    IS_LINUX=true
    echo -e "  ${GREEN}Platform: Linux${NC}"
    echo -e "  ${GREEN}Distro: $(cat /etc/os-release 2>/dev/null | grep PRETTY_NAME | cut -d= -f2 | tr -d '\"' || echo 'Unknown')${NC}"
    echo -e "  ${GREEN}Arch: $(uname -m)${NC}"
elif [ "$(uname -s)" = "Darwin" ]; then
    IS_MACOS=true
    echo -e "  ${GREEN}Platform: macOS${NC}"
else
    echo -e "  ${YELLOW}Platform: Unknown ($(uname -s))${NC}"
fi

echo ""

# ── Step 2: Check Python ──
echo -e "${BLUE}[2/5] Checking Python...${NC}"

PYTHON=""
if command -v python3 &>/dev/null; then
    PYTHON="python3"
elif command -v python &>/dev/null; then
    PYTHON="python"
else
    echo -e "  ${RED}Python not found!${NC}"
    echo -e "  ${YELLOW}Installing Python...${NC}"
    if [ "$IS_TERMUX" = true ]; then
        pkg install python -y
        PYTHON="python3"
    elif [ "$IS_LINUX" = true ]; then
        sudo apt-get update && sudo apt-get install -y python3 python3-pip 2>/dev/null || \
        sudo dnf install -y python3 python3-pip 2>/dev/null || \
        echo -e "  ${RED}Please install Python manually${NC}"
        PYTHON="python3"
    fi
fi

if [ -z "$PYTHON" ]; then
    echo -e "  ${RED}Failed to find Python. Please install it manually.${NC}"
    exit 1
fi

PY_VERSION=$($PYTHON --version 2>&1)
echo -e "  ${GREEN}Found: $PY_VERSION${NC}"
echo ""

# ── Step 3: Install Dependencies ──
echo -e "${BLUE}[3/5] Checking dependencies...${NC}"

# Check Flask
$PYTHON -c "import flask" 2>/dev/null
if [ $? -ne 0 ]; then
    echo -e "  ${YELLOW}Installing Flask...${NC}"
    $PYTHON -m pip install flask flask-cors requests --quiet 2>/dev/null || \
    pip install flask flask-cors requests --quiet 2>/dev/null || \
    echo -e "  ${YELLOW}Trying with --user flag...${NC}" && \
    $PYTHON -m pip install --user flask flask-cors requests --quiet 2>/dev/null
fi

# Check flask_cors
$PYTHON -c "import flask_cors" 2>/dev/null
if [ $? -ne 0 ]; then
    echo -e "  ${YELLOW}Installing flask-cors...${NC}"
    $PYTHON -m pip install flask-cors --quiet 2>/dev/null
fi

echo -e "  ${GREEN}Dependencies ready${NC}"
echo ""

# ── Step 4: Check Ollama (optional) ──
echo -e "${BLUE}[4/5] Checking Ollama...${NC}"

if command -v ollama &>/dev/null; then
    echo -e "  ${GREEN}Ollama found: $(ollama --version 2>&1 || echo 'installed')${NC}"
    
    # Check if Ollama is running
    if curl -s http://127.0.0.1:11434/api/tags > /dev/null 2>&1; then
        echo -e "  ${GREEN}Ollama is running on port 11434${NC}"
        
        # Show loaded models
        MODELS=$(curl -s http://127.0.0.1:11434/api/tags 2>/dev/null | $PYTHON -c "
import sys, json
try:
    data = json.load(sys.stdin)
    for m in data.get('models', []):
        name = m.get('name', 'unknown')
        size_gb = round(m.get('size', 0) / 1073741824, 2)
        print(f'  - {name} ({size_gb} GB)')
except:
    pass
" 2>/dev/null)
        if [ -n "$MODELS" ]; then
            echo -e "  ${CYAN}Loaded models:${NC}"
            echo -e "$MODELS"
        else
            echo -e "  ${YELLOW}No models loaded. Use: ollama pull qwen2.5:7b${NC}"
        fi
    else
        echo -e "  ${YELLOW}Ollama found but not running${NC}"
        echo -e "  ${YELLOW}Start it with: ollama serve &${NC}"
    fi
else
    echo -e "  ${YELLOW}Ollama not found (optional)${NC}"
    if [ "$IS_TERMUX" = true ]; then
        echo -e "  ${YELLOW}Install: pkg install ollama${NC}"
    elif [ "$IS_LINUX" = true ]; then
        echo -e "  ${YELLOW}Install: curl -fsSL https://ollama.com/install.sh | sh${NC}"
    fi
    echo -e "  ${GREEN}AI will use HF Free API as fallback (zero cost)${NC}"
fi

echo ""

# ── Step 5: Start MyanOS ──
echo -e "${BLUE}[5/5] Starting MyanOS Backend...${NC}"
echo ""

# Parse arguments
HOST_ARG=""
PORT_ARG="5000"
DEBUG_ARG=""

for arg in "$@"; do
    case $arg in
        --port=*)
            PORT_ARG="${arg#*=}"
            ;;
        --port)
            shift
            PORT_ARG="$1"
            ;;
        --host=*)
            HOST_ARG="--host ${arg#*=}"
            ;;
        --host)
            shift
            HOST_ARG="--host $1"
            ;;
        --debug)
            DEBUG_ARG="--debug"
            ;;
    esac
done

# Auto host for Termux
if [ -z "$HOST_ARG" ]; then
    if [ "$IS_TERMUX" = true ]; then
        HOST_ARG="--host 0.0.0.0"
    fi
fi

echo -e "${GREEN}Starting server on port $PORT_ARG...${NC}"
echo -e "${GREEN}Open your browser: http://localhost:$PORT_ARG${NC}"

if [ "$IS_TERMUX" = true ]; then
    echo ""
    echo -e "${CYAN}─────────────────────────────────────────────────${NC}"
    echo -e "${CYAN}  For laptop access via phone hotspot:${NC}"
    echo -e "${CYAN}  1. Turn on Mobile Hotspot on phone${NC}"
    echo -e "${CYAN}  2. Connect laptop to phone's WiFi${NC}"
    echo -e "${CYAN}  3. On laptop browser:${NC}"
    PHONE_IP=$(ip addr show wlan0 2>/dev/null | grep 'inet ' | awk '{print $2}' | cut -d/ -f1 || ip addr show 2>/dev/null | grep 'inet ' | head -1 | awk '{print $2}' | cut -d/ -f1)
    if [ -n "$PHONE_IP" ]; then
        echo -e "${CYAN}     http://$PHONE_IP:$PORT_ARG${NC}"
    fi
    echo -e "${CYAN}─────────────────────────────────────────────────${NC}"
fi

echo ""
echo -e "${YELLOW}Default login: admin / admin (change after first login!)${NC}"
echo ""
echo -e "Press Ctrl+C to stop"
echo ""

# Start the server
$PYTHON main.py $HOST_ARG --port $PORT_ARG $DEBUG_ARG
