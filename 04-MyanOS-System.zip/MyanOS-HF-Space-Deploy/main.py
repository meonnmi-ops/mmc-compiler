#!/usr/bin/env python3
"""
MyanOS Backend v4.1.0 — HuggingFace Spaces Edition
Flask + Gunicorn + CORS + Environment-aware configuration

Deployed at: https://meonnmi0ps-myanos-os.hf.space

Environment Variables:
  ZAI_API_KEY   — Z-AI API key for AI chat proxy
  ZAI_API_URL   — Z-AI API endpoint URL (default: internal)
  PORT          — Server port (default: 7860)
"""

import os
import sys
import json
import platform
import subprocess
import time
import re
import threading
from pathlib import Path
from datetime import datetime

from flask import Flask, request, jsonify
from flask_cors import CORS

# ─── Configuration ─────────────────────────────────────────────────────────────
VERSION = "4.1.0"
PORT = int(os.environ.get("PORT", 7860))
ZAI_API_KEY = os.environ.get("ZAI_API_KEY", "")
ZAI_API_URL = os.environ.get("ZAI_API_URL", "http://172.25.136.193:8080/v1/chat/completions")
START_TIME = time.time()

# ─── Flask App ─────────────────────────────────────────────────────────────────
app = Flask(__name__)
CORS(app, resources={r"/*": {"origins": "*"}})


# ═══════════════════════════════════════════════════════════════════════════════
#  ROOT — Health Status
# ═══════════════════════════════════════════════════════════════════════════════

@app.route("/")
def root():
    """MyanOS status page."""
    uptime = int(time.time() - START_TIME)
    return jsonify({
        "status": "running",
        "service": "MyanOS Web OS",
        "version": VERSION,
        "uptime_seconds": uptime,
        "uptime_formatted": f"{uptime // 3600}h {(uptime % 3600) // 60}m {uptime % 60}s",
        "ai_configured": bool(ZAI_API_KEY),
        "endpoints": {
            "health": "/api/health",
            "system": "/api/system",
            "system_stats": "/api/system-stats",
            "ai_chat": "/api/ai-chat",
            "exec": "/api/exec",
            "training": "/api/training",
            "packages": "/api/packages",
        },
        "frontend": "https://meonnmi-ops.github.io/Myanos/",
        "docs": "https://github.com/meonnmi-ops/Myanos",
    })


@app.route("/api/health", methods=["GET"])
def health_check():
    """Detailed health check."""
    try:
        import psutil
        mem = psutil.virtual_memory()
        disk = psutil.disk_usage("/")
        cpu = psutil.cpu_percent(interval=0.3)
    except ImportError:
        mem = type("obj", (object,), {"percent": 0, "available": 0})()
        disk = type("obj", (object,), {"percent": 0, "free": 0})()
        cpu = 0

    return jsonify({
        "status": "healthy",
        "version": VERSION,
        "port": PORT,
        "python": platform.python_version(),
        "platform": platform.platform(),
        "cpu_percent": cpu,
        "memory_percent": getattr(mem, "percent", 0),
        "memory_available_gb": round(getattr(mem, "available", 0) / (1024**3), 2),
        "disk_percent": getattr(disk, "percent", 0),
        "disk_free_gb": round(getattr(disk, "free", 0) / (1024**3), 2),
        "ai_configured": bool(ZAI_API_KEY),
        "uptime_seconds": int(time.time() - START_TIME),
        "timestamp": datetime.now().isoformat(),
    })


# ═══════════════════════════════════════════════════════════════════════════════
#  SYSTEM — Info & Stats
# ═══════════════════════════════════════════════════════════════════════════════

@app.route("/api/system", methods=["GET", "POST"])
def handle_system():
    """Return system information."""
    return jsonify({
        "os": f"MyanOS Web OS v{VERSION}",
        "hostname": platform.node(),
        "platform": f"{platform.system()} {platform.machine()}",
        "python": platform.python_version(),
        "shell": "mmr v1.0.0 (Myanmar Shell)",
        "user": os.environ.get("USER", "meonnmi"),
        "version": VERSION,
    })


@app.route("/api/system-stats", methods=["GET"])
def handle_system_stats():
    """Return real system metrics."""
    stats = {
        "cpu": {"percent": 0, "cores_physical": 0, "cores_logical": 0,
                "freq_current": 0, "freq_max": 0, "per_cpu": []},
        "memory": {"total_gb": 0, "used_gb": 0, "percent": 0,
                   "total": 0, "used": 0, "available": 0},
        "disk": {"total_gb": 0, "used_gb": 0, "free_gb": 0, "percent": 0,
                 "total": 0, "used": 0, "free": 0},
        "gpu": {"available": False, "gpus": []},
        "network": {"connected": True, "bytes_sent": 0, "bytes_recv": 0},
        "temperature": {"celsius": 0, "label": "N/A"},
        "processes": [],
        "os_info": {
            "system": platform.system(),
            "release": platform.release(),
            "machine": platform.machine(),
            "hostname": platform.node(),
            "myanos_version": VERSION,
        },
        "uptime_seconds": int(time.time() - START_TIME),
        "timestamp": datetime.now().isoformat(),
    }

    try:
        import psutil
        stats["cpu"]["percent"] = psutil.cpu_percent(interval=0.3)
        stats["cpu"]["cores_physical"] = psutil.cpu_count(logical=False) or 0
        stats["cpu"]["cores_logical"] = psutil.cpu_count(logical=True) or 0
        cpu_freq = psutil.cpu_freq()
        if cpu_freq:
            stats["cpu"]["freq_current"] = round(cpu_freq.current, 0)
            stats["cpu"]["freq_max"] = round(cpu_freq.max, 0)
        stats["cpu"]["per_cpu"] = psutil.cpu_percent(interval=0, percpu=True)

        mem = psutil.virtual_memory()
        stats["memory"] = {
            "total": mem.total, "used": mem.used, "available": mem.available,
            "percent": mem.percent,
            "total_gb": round(mem.total / 1e9, 1), "used_gb": round(mem.used / 1e9, 1),
        }
        disk = psutil.disk_usage("/")
        stats["disk"] = {
            "total": disk.total, "used": disk.used, "free": disk.free,
            "percent": disk.percent,
            "total_gb": round(disk.total / 1e9, 1), "used_gb": round(disk.used / 1e9, 1),
            "free_gb": round(disk.free / 1e9, 1),
        }
        net = psutil.net_io_counters()
        stats["network"] = {
            "bytes_sent": net.bytes_sent, "bytes_recv": net.bytes_recv,
            "packets_sent": net.packets_sent, "packets_recv": net.packets_recv,
            "connected": True,
        }
    except ImportError:
        pass

    return jsonify(stats)


# ═══════════════════════════════════════════════════════════════════════════════
#  AI CHAT — Z-AI SDK Proxy
# ═══════════════════════════════════════════════════════════════════════════════

@app.route("/api/ai-chat", methods=["POST"])
def handle_ai_chat():
    """Proxy AI chat requests to Z-AI API."""
    data = request.get_json(force=True, silent=True) or {}
    messages = data.get("messages", [])
    tools = data.get("tools", None)

    if not messages:
        return jsonify({"success": False, "error": "messages required"}), 400

    if not ZAI_API_KEY:
        return jsonify({
            "success": False,
            "error": "ZAI_API_KEY not configured. Set it in Space secrets."
        }), 503

    try:
        import urllib.request

        payload = {
            "model": "default",
            "messages": messages,
            "thinking": {"type": "disabled"},
            "stream": False,
        }
        if tools:
            payload["tools"] = tools

        req = urllib.request.Request(
            ZAI_API_URL,
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {ZAI_API_KEY}",
                "X-Z-AI-From": "Z",
            },
            timeout=120,
        )
        resp = urllib.request.urlopen(req)
        result = json.loads(resp.read().decode("utf-8"))

        reply = ""
        tool_calls = None
        if "choices" in result and len(result["choices"]) > 0:
            choice = result["choices"][0]
            reply = choice.get("message", {}).get("content", "")
            tool_calls = choice.get("message", {}).get("tool_calls", None)

        response = {"success": True, "response": reply, "model": result.get("model", "z-ai")}
        if tool_calls:
            response["tool_calls"] = tool_calls

        return jsonify(response)

    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


# ═══════════════════════════════════════════════════════════════════════════════
#  EXECUTE — Command Execution
# ═══════════════════════════════════════════════════════════════════════════════

@app.route("/api/exec", methods=["POST"])
def handle_exec():
    """Execute a Python code cell (sandboxed)."""
    data = request.get_json(force=True, silent=True) or {}
    cmd = data.get("cmd", "").strip()

    if not cmd:
        return jsonify({"output": "", "status": 0})

    try:
        # Allow only Python execution in the Space (no shell)
        if cmd.startswith("python") or cmd.startswith("!"):
            code = cmd.replace("python ", "").replace("python3 ", "").lstrip("! ")
        else:
            code = cmd

        result = subprocess.run(
            [sys.executable, "-c", code],
            capture_output=True, text=True, timeout=30,
        )
        output = result.stdout
        if result.stderr:
            output += ("\n" if output else "") + result.stderr
        return jsonify({"output": output, "status": result.returncode})
    except subprocess.TimeoutExpired:
        return jsonify({"output": "[TIMEOUT] Execution exceeded 30s limit", "status": 1})
    except Exception as e:
        return jsonify({"output": f"[ERR] {e}", "status": 1})


# ═══════════════════════════════════════════════════════════════════════════════
#  TRAINING — AI Training Center
# ═══════════════════════════════════════════════════════════════════════════════

@app.route("/api/training", methods=["GET", "POST"])
def handle_training():
    """AI Training Center endpoint."""
    if request.method == "GET":
        return jsonify({
            "status": "ok",
            "python": platform.python_version(),
            "platform": platform.platform(),
        })

    data = request.get_json(force=True, silent=True) or {}
    action = data.get("action", "")

    if action == "execute_cell":
        code = data.get("code", "").strip()
        if not code:
            return jsonify({"output": "", "status": 0})
        try:
            timeout = 120 if "for epoch" in code or "TRAINING" in code else 60
            result = subprocess.run(
                [sys.executable, "-c", code],
                capture_output=True, text=True, timeout=timeout,
            )
            output = result.stdout
            if result.stderr:
                output += ("\n" if output else "") + result.stderr
            return jsonify({"output": output, "status": result.returncode})
        except subprocess.TimeoutExpired:
            return jsonify({"output": "[TIMEOUT] Cell exceeded timeout", "status": 1})
        except Exception as e:
            return jsonify({"output": f"[ERR] {e}", "status": 1})

    elif action == "system_stats":
        stats = {
            "cpu_percent": 0, "memory_percent": 0,
            "memory_used": "N/A", "memory_total": "N/A",
            "disk_used": "N/A", "disk_total": "N/A",
            "gpu_available": False, "gpu_util": 0,
            "platform": platform.platform(),
            "python": platform.python_version(),
        }
        try:
            import psutil
            stats["cpu_percent"] = psutil.cpu_percent(interval=0.5)
            mem = psutil.virtual_memory()
            stats["memory_used"] = f"{mem.used/1e9:.1f} GB"
            stats["memory_total"] = f"{mem.total/1e9:.1f} GB"
            stats["memory_percent"] = mem.percent
            disk = psutil.disk_usage("/")
            stats["disk_used"] = f"{disk.used/1e9:.1f} GB"
            stats["disk_total"] = f"{disk.total/1e9:.1f} GB"
            stats["disk_percent"] = disk.percent
        except ImportError:
            pass
        return jsonify(stats)

    elif action == "check_ollama":
        # Ollama not available on HF Spaces
        return jsonify({"connected": False, "models": []})

    return jsonify({"error": "Unknown action"}), 400


# ═══════════════════════════════════════════════════════════════════════════════
#  PACKAGES — MyanPM
# ═══════════════════════════════════════════════════════════════════════════════

@app.route("/api/packages", methods=["GET"])
def handle_packages():
    """Return available/installed packages."""
    return jsonify({"packages": []})


@app.route("/api/myan", methods=["POST"])
def handle_myan():
    """Myan Package Manager endpoint."""
    data = request.get_json(force=True, silent=True) or {}
    action = data.get("action", "")
    return jsonify({"output": f"[INFO] MyanPM action: {action}", "status": 0})


# ═══════════════════════════════════════════════════════════════════════════════
#  BROWSER PROXY — Web search support
# ═══════════════════════════════════════════════════════════════════════════════

@app.route("/api/browser", methods=["GET", "POST"])
def handle_browser():
    """Browser proxy endpoint for search and URL fetching."""
    data = request.get_json(force=True, silent=True) or {}
    url = data.get("url", "")
    action = data.get("action", "fetch")

    if action == "search":
        query = data.get("query", "")
        return jsonify({"results": [{"title": f"Search: {query}", "url": f"https://duckduckgo.com/?q={query}", "snippet": "Open in browser"}]})

    if not url:
        return jsonify({"error": "url required"}), 400

    try:
        import urllib.request
        req = urllib.request.Request(url, headers={"User-Agent": "MyanOS/4.1.0"}, timeout=15)
        resp = urllib.request.urlopen(req)
        content = resp.read().decode("utf-8", errors="replace")
        return jsonify({"content": content[:50000], "status": 200})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ═══════════════════════════════════════════════════════════════════════════════
#  STANDALONE (for local dev)
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print(f"\n  MyanOS Backend v{VERSION}")
    print(f"  Port: {PORT}")
    print(f"  AI: {'configured' if ZAI_API_KEY else 'not set'}")
    print(f"  Running on http://localhost:{PORT}\n")
    app.run(host="0.0.0.0", port=PORT, debug=False)
