---
title: MyanOS Backend
emoji: 🇲🇲
colorFrom: red
colorTo: gold
sdk: docker
app_port: 7860
pinned: false
---

# 🇲🇲 MyanOS Backend — HuggingFace Spaces

**Myanmar AI-Powered Web Operating System** backend server.

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/` | Health status & endpoint map |
| GET | `/api/health` | Detailed system health check |
| GET | `/api/system` | System information |
| GET | `/api/system-stats` | Real CPU/RAM/Disk/GPU metrics |
| POST | `/api/ai-chat` | Z-AI chat proxy (needs ZAI_API_KEY) |
| POST | `/api/exec` | Execute Python code |
| POST | `/api/training` | AI Training Center |
| GET | `/api/packages` | Package list |

## Environment Variables

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `ZAI_API_KEY` | Yes | — | Z-AI API key for AI chat |
| `ZAI_API_URL` | No | Internal | Z-AI API endpoint URL |
| `PORT` | No | 7860 | Server port |

## Connect MyanOS Frontend

In MyanOS desktop → Settings → Network → Backend URL:
```
https://meonnmi0ps-myanos-os.hf.space
```

## License

MIT — [GitHub](https://github.com/meonnmi-ops/Myanos)
