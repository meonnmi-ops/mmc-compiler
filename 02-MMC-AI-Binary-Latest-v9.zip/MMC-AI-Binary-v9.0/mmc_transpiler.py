#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MMC Transpiler v9.0 - Professional Edition
Myanmar Code (MMC) -> Python 3

Professional-grade transpiler with:
  v4: Variables, Types, Control Flow, Loops, Functions, OOP,
      Dict/Map, Error Handling, File I/O, Import, String/List/Dict methods
  v5: Module System (export), Package Manager bridge, Enhanced Stdlib
  v6: Type Hints, Decorators, Generators (yield), Lambda, Comprehensions
  v7: Full async/await, Testing Framework, with statement
  v8: Source Maps, Debug markers, LLVM bridge, Pass/Global/Nonlocal/Del
  v9: AST Validation, Semantic Analysis, Professional Error Reporting,
      Traceback Mapper (Python -> MMC), Warning System, Lint Mode,
      Match/Case, Walrus Operator, Multi-error Recovery

Author: MyanOS AI Team
Version: 9.0.0
"""

import re
import sys
import io
import json
import os
import traceback
import textwrap
import difflib
from enum import Enum
from dataclasses import dataclass, field
from typing import List, Optional, Tuple, Dict, Any, Set


# ============================================================
# Error System - Professional Error Reporting
# ============================================================

class MMCErrorSeverity(Enum):
    ERROR = "ERROR"
    WARNING = "WARNING"
    INFO = "INFO"
    HINT = "HINT"


class MMCErrorKind(Enum):
    # Syntax Errors
    SYNTAX_ERROR = "E001"
    UNEXPECTED_TOKEN = "E002"
    MISSING_COLON = "E003"
    UNCLOSED_STRING = "E004"
    UNCLOSED_PAREN = "E005"
    INVALID_INDENT = "E006"
    DUPLICATE_PARAM = "E007"

    # Semantic Errors
    UNDECLARED_VAR = "E101"
    TYPE_MISMATCH = "E102"
    UNDEFINED_FUNCTION = "E103"
    WRONG_ARG_COUNT = "E104"
    MISSING_RETURN = "E105"
    REDEFINED_BUILTIN = "E106"

    # Runtime Error Mapping
    RUNTIME_ERROR = "E201"
    NAME_ERROR = "E202"
    TYPE_ERROR = "E203"
    VALUE_ERROR = "E204"
    INDEX_ERROR = "E205"
    KEY_ERROR = "E206"
    ATTR_ERROR = "E207"
    ZERO_DIVISION = "E208"
    IMPORT_ERROR = "E209"
    RECURSION_ERROR = "E210"

    # Warnings
    UNUSED_VAR = "W001"
    SHADOW_BUILTIN = "W002"
    MISSING_TYPE_HINT = "W003"
    COMPLEX_EXPRESSION = "W004"
    UNREACHABLE_CODE = "W005"
    DEPRECATED_SYNTAX = "W006"
    GLOBAL_USAGE = "W007"


@dataclass
class MMCError:
    kind: MMCErrorKind
    severity: MMCErrorSeverity
    message: str
    line: int = 0
    col: int = 0
    end_line: int = 0
    end_col: int = 0
    source_line: str = ""
    suggestions: List[str] = field(default_factory=list)
    context_before: List[str] = field(default_factory=list)
    context_after: List[str] = field(default_factory=list)

    def __str__(self):
        return self.format_message()

    def format_message(self, color=True):
        """Format a beautiful error message with source context."""
        # ANSI color codes
        if color and sys.stderr.isatty():
            RED = "\033[91m"
            YELLOW = "\033[93m"
            CYAN = "\033[96m"
            BOLD = "\033[1m"
            DIM = "\033[2m"
            RESET = "\033[0m"
            GREEN = "\033[92m"
        else:
            RED = YELLOW = CYAN = BOLD = DIM = RESET = GREEN = ""

        severity_colors = {
            MMCErrorSeverity.ERROR: RED,
            MMCErrorSeverity.WARNING: YELLOW,
            MMCErrorSeverity.INFO: CYAN,
            MMCErrorSeverity.HINT: DIM,
        }

        color = severity_colors.get(self.severity, RESET)
        lines = []

        # Header: severity + kind + message
        header = f"{color}{BOLD}{self.severity.value}{RESET} {DIM}{self.kind.value}{RESET}: {self.message}"
        lines.append(header)

        # Source location
        if self.line > 0:
            loc = f"  {BOLD}--> {self.source_line or ''}:{self.line}{RESET}"
            if self.col > 0:
                loc += f":{self.col}"
            lines.append(loc)

            # Source context
            all_lines = []
            if self.context_before:
                for ctx_line in self.context_before:
                    all_lines.append(f"  {DIM}{ctx_line}{RESET}")
            if self.source_line:
                # Show the problematic line
                line_display = self.source_line.rstrip()
                # Expand tabs for display
                line_display = line_display.expandtabs(4)
                line_prefix = f"{self.line:>4} | "
                lines.append(f"  {DIM}{line_prefix}{RESET}{line_display}")

                # Show the pointer (^ or ~~~)
                if self.col > 0:
                    pointer_prefix = " " * len(line_prefix)
                    pointer_start = max(0, self.col - 1)
                    pointer_len = max(1, self.end_col - self.col if self.end_col > self.col else 1)
                    pointer = " " * pointer_start + color + "^" * pointer_len + RESET
                    lines.append(f"  {pointer_prefix}{pointer}")
            if self.context_after:
                for ctx_line in self.context_after:
                    all_lines.append(f"  {DIM}{ctx_line}{RESET}")

        # Suggestions
        if self.suggestions:
            lines.append("")
            lines.append(f"  {GREEN}{BOLD}  ကျွန်းကြောင်းများ (Suggestions):{RESET}")
            for i, suggestion in enumerate(self.suggestions, 1):
                lines.append(f"  {GREEN}  {i}. {suggestion}{RESET}")

        return "\n".join(lines)


class ErrorReporter:
    """Collect and report MMC errors with professional formatting."""

    def __init__(self, source_lines=None, source_name="<mmc>"):
        self.errors: List[MMCError] = []
        self.warnings: List[MMCError] = []
        self.source_lines = source_lines or []
        self.source_name = source_name
        self.max_errors = 20  # Stop after 20 errors to avoid spam

    def _get_context(self, line_num, context_size=2):
        """Get surrounding source lines for context."""
        before = []
        after = []
        for i in range(max(0, line_num - 1 - context_size), line_num - 1):
            if i < len(self.source_lines):
                before.append(self.source_lines[i])
        source = self.source_lines[line_num - 1] if line_num - 1 < len(self.source_lines) else ""
        for i in range(line_num, min(len(self.source_lines), line_num + context_size)):
            after.append(self.source_lines[i])
        return before, source, after

    def report(self, kind, message, line=0, col=0, end_col=0,
               severity=None, suggestions=None):
        """Report an error or warning."""
        severity = severity or MMCErrorSeverity.ERROR

        # Respect max error limit
        if severity == MMCErrorSeverity.ERROR and len(self.errors) >= self.max_errors:
            return

        before, source_line, after = self._get_context(line) if line > 0 else ([], "", [])

        error = MMCError(
            kind=kind,
            severity=severity,
            message=message,
            line=line,
            col=col,
            end_col=end_col,
            source_line=source_line,
            suggestions=suggestions or [],
            context_before=before,
            context_after=after,
        )

        if severity == MMCErrorSeverity.ERROR:
            self.errors.append(error)
        elif severity == MMCErrorSeverity.WARNING:
            self.warnings.append(error)

    def error(self, kind, message, line=0, col=0, end_col=0, suggestions=None):
        self.report(kind, message, line, col, end_col,
                    MMCErrorSeverity.ERROR, suggestions)

    def warning(self, kind, message, line=0, col=0, end_col=0, suggestions=None):
        self.report(kind, message, line, col, end_col,
                    MMCErrorSeverity.WARNING, suggestions)

    def has_errors(self):
        return len(self.errors) > 0

    def error_count(self):
        return len(self.errors)

    def warning_count(self):
        return len(self.warnings)

    def format_all(self):
        """Format all errors and warnings."""
        parts = []
        for e in self.errors:
            parts.append(str(e))
            parts.append("")
        for w in self.warnings:
            parts.append(str(w))
            parts.append("")
        return "\n".join(parts)

    def format_summary(self):
        """Format error/warning summary."""
        errs = len(self.errors)
        warns = len(self.warnings)
        if errs == 0 and warns == 0:
            return ""
        parts = []
        if errs > 0:
            parts.append(f"{GREEN}{BOLD}{errs} ကွက်တာ{RESET}")
        if warns > 0:
            parts.append(f"{YELLOW}{BOLD}{warns} သတိပေးချက်{RESET}")
        return " | ".join(parts)


# ============================================================
# Python Traceback -> MMC Source Mapper
# ============================================================

class TracebackMapper:
    """Map Python runtime errors back to MMC source locations."""

    # Python exception -> MMC error kind mapping
    EXCEPTION_MAP = {
        'SyntaxError': MMCErrorKind.SYNTAX_ERROR,
        'IndentationError': MMCErrorKind.INVALID_INDENT,
        'NameError': MMCErrorKind.NAME_ERROR,
        'UnboundLocalError': MMCErrorKind.UNDECLARED_VAR,
        'TypeError': MMCErrorKind.TYPE_ERROR,
        'ValueError': MMCErrorKind.VALUE_ERROR,
        'IndexError': MMCErrorKind.INDEX_ERROR,
        'KeyError': MMCErrorKind.KEY_ERROR,
        'AttributeError': MMCErrorKind.ATTR_ERROR,
        'ZeroDivisionError': MMCErrorKind.ZERO_DIVISION,
        'ImportError': MMCErrorKind.IMPORT_ERROR,
        'ModuleNotFoundError': MMCErrorKind.IMPORT_ERROR,
        'RecursionError': MMCErrorKind.RECURSION_ERROR,
        'StopIteration': MMCErrorKind.RUNTIME_ERROR,
        'FileNotFoundError': MMCErrorKind.RUNTIME_ERROR,
        'PermissionError': MMCErrorKind.RUNTIME_ERROR,
        'OverflowError': MMCErrorKind.VALUE_ERROR,
        'NotImplementedError': MMCErrorKind.RUNTIME_ERROR,
    }

    # Python error patterns -> MMC keyword suggestions

    def __init__(self, source_map=None, mmc_source=""):
        self.source_map = source_map  # list of (mmc_line, py_line, mmc_col)
        self.mmc_lines = mmc_source.split('\n') if mmc_source else []

    def map_error(self, error_type, error_msg, py_line=None, py_col=None):
        """Map a Python error to an MMC error with source location."""
        # Find MMC line from source map
        mmc_line = py_line or 0
        mmc_col = py_col or 0

        if self.source_map and py_line:
            for ml, pl, mc in self.source_map:
                if pl == py_line:
                    mmc_line = ml
                    mmc_col = mc
                    break

        # Determine error kind
        kind = self.EXCEPTION_MAP.get(error_type, MMCErrorKind.RUNTIME_ERROR)

        # Generate friendly message
        message = self._friendly_message(error_type, error_msg)

        # Generate suggestions
        suggestions = self._generate_suggestions(error_type, error_msg, mmc_line)

        return kind, message, mmc_line, mmc_col, suggestions

    def _friendly_message(self, error_type, error_msg):
        """Convert Python error message to friendly MMC message."""
        type_messages = {
            'SyntaxError': "MMC ဓိက္ခာတွေ မှားနေပါသည်",
            'NameError': "'{name}' အမည်ရှိမရှိ မတွေ့ပါ",
            'UnboundLocalError': "'{name}' ကို လမ်းညွှန်မှုမပြီး သုံးစွဲနေပါသည်",
            'TypeError': "အမျိုးအစား မကိုက်ညီပါ",
            'ValueError': "တန်ဖိုး မမှန်ကန်ပါ",
            'IndexError': "မှန်နှင့်နေသော အနက်ရှိမရှိပါ (Index ကျော်နေပါသည်)",
            'KeyError': "မှတ်တမ်းထဲတွင် ပါဝင်မှု မရှိပါ (Key မတွေ့ပါ)",
            'AttributeError': "'{name}' အရာရည်ကို ရယူလို့မရပါ",
            'ZeroDivisionError': "သုံး (0) ဖြင့် သွက်လပ်မှု လုပ်မရပါ",
            'ImportError': "'{module}' မောက်မြူမားကို တင်သွင်းလို့မရပါ",
            'ModuleNotFoundError': "'{module}' မောက်မြူမားကို ရှာမတွေ့ပါ",
            'RecursionError': "ခေတ်တိုင်း ခံချင်း (Recursion) အပြည့်ပါ",
            'IndentationError': "MMC ခြေခံချက် မှားနေပါသည်",
            'FileNotFoundError': "'{name}' ဖိုင်ကို ရှာမတွေ့ပါ",
        }

        # Extract names from error message
        name_match = re.search(r"'(.+?)'", error_msg)
        name = name_match.group(1) if name_match else ""

        # Try to translate Python identifiers back to MMC
        msg_template = type_messages.get(error_type, "MMC အမှားတစ်ခုဖြစ်နေပါသည်")

        # Replace placeholders
        msg = msg_template.format(name=name, module=name)

        # If no template matched, use original but add context
        if msg == type_messages.get(error_type, ""):
            msg = f"MMC အမှား: {error_msg}"

        return msg

    def _generate_suggestions(self, error_type, error_msg, mmc_line):
        """Generate helpful suggestions based on error type."""
        suggestions = []

        name_match = re.search(r"'(.+?)'", error_msg)
        name = name_match.group(1) if name_match else ""

        if error_type in ('NameError', 'UnboundLocalError') and name:
            # Check if it's a misspelled MMC keyword
            all_mm_keywords = list(STMT_KEYWORDS.keys()) + list(FUNC_KEYWORDS.keys()) + \
                             list(METHOD_KEYWORDS.keys()) + list(VALUE_KEYWORDS.keys())
            close_matches = difflib.get_close_matches(name, all_mm_keywords, n=3, cutoff=0.4)
            if close_matches:
                for match in close_matches[:3]:
                    eng = STMT_KEYWORDS.get(match) or FUNC_KEYWORDS.get(match) or \
                          METHOD_KEYWORDS.get(match) or VALUE_KEYWORDS.get(match) or match
                    suggestions.append(f"'{name}' သည် '{match}' ({eng}) ဖြစ်ပါသလား?")

            # Check if the name looks like a Python keyword (user forgot MMC keyword)
            py_to_mmc = {v: k for k, v in STMT_KEYWORDS.items()}
            py_to_mmc.update({v: k for k, v in FUNC_KEYWORDS.items()})
            py_to_mmc.update({v: k for k, v in VALUE_KEYWORDS.items()})
            if name in py_to_mmc:
                mm_word = py_to_mmc[name]
                suggestions.append(f"MMC စကားလုံး အစား: '{name}' အစား '{mm_word}' ကို သုံးပါ")

            # Check if it's a variable that might not be declared
            if mmc_line > 0 and mmc_line - 1 < len(self.mmc_lines):
                line_content = self.mmc_lines[mmc_line - 1]
                if 'ဆက်' in line_content or 'ကျော်' in line_content:
                    pass  # Don't suggest for class/function lines

        elif error_type == 'TypeError':
            if 'unsupported operand' in error_msg:
                suggestions.append("အရာရည် နှစ်ခုကို တူသော အရာအထိ ဖြတ်လုပ်၍ မရပါ")
            elif 'not callable' in error_msg:
                suggestions.append("ဤအရာရည်ကို ခေါ်ဆို၍ မရပါ (function မဟုတ်ပါ)")
            elif 'missing' in error_msg and 'argument' in error_msg:
                suggestions.append("လက်ခံသော argument မပါနေပါ")
            elif 'takes' in error_msg and 'argument' in error_msg:
                suggestions.append("(argument) အရေအတွက် မမှန်ကန်ပါ")

        elif error_type == 'IndexError':
            suggestions.append("အရည်အသွေး (index) ကျော်နေပါသည်ကို စစ်ဆေးပါ")

        elif error_type == 'KeyError':
            suggestions.append("သော့ (key) ရှိမရှိ စစ်ဆေးပါ")

        elif error_type == 'ZeroDivisionError':
            suggestions.append("သွက်လပ်မှု မှာ သုံး (0) ဖြစ်မှုကို စစ်ဆေးပါ")

        elif error_type == 'RecursionError':
            suggestions.append("ခေတ်တိုင်း ခံချင်း (recursion) အပြည့်ကို သေချာပါလား စစ်ဆေးပါ")
            suggestions.append("base case ရှိမရှိ စစ်ဆေးပါ")

        elif error_type == 'IndentationError':
            suggestions.append("Space (4) ခု သုံးပါ")
            suggestions.append("Tab မသုံးပါ၊ Space သာ သုံးပါ")

        elif error_type in ('ImportError', 'ModuleNotFoundError'):
            suggestions.append("မောက်မြူမား အမည်ကို တိကျစေးပါ")
            suggestions.append("mmc_pkg.py ဖြင့် ထည့်သွင်းပါ")

        elif error_type == 'FileNotFoundError':
            suggestions.append("ဖိုင် လမ်းညွှန်ကို စစ်ဆေးပါ")

        return suggestions


# ============================================================
# Semantic Validator - Pre-compilation Checks
# ============================================================

class SemanticValidator:
    """Validate MMC source code for common errors before transpilation."""

    # MMC block starters (keywords that require colon)
    BLOCK_STARTERS = {
        'if', 'elif', 'else', 'for', 'while', 'def', 'class',
        'try', 'except', 'finally', 'with', 'async'
    }

    # MMC keywords that must be at block start (dedent level)
    BLOCK_ONLY_KEYWORDS = {
        'else', 'elif', 'except', 'finally', 'break', 'continue',
        'return', 'yield', 'pass'
    }

    def __init__(self, source: str, reporter: ErrorReporter):
        self.source = source
        self.lines = source.split('\n')
        self.reporter = reporter
        self.defined_vars: Set[str] = set()
        self.defined_funcs: Set[str] = set()
        self.defined_classes: Set[str] = set()
        self.current_scope: str = "module"
        self.scope_stack: List[Dict[str, Any]] = [{}]
        self.imported_modules: Set[str] = set()

    def validate(self):
        """Run all validation checks."""
        self._check_structure()
        self._check_unclosed_brackets()
        self._check_unclosed_strings()
        self._check_indentation()
        self._check_scopes()
        return not self.reporter.has_errors()

    def _check_structure(self):
        """Check for basic structural issues."""
        for i, line in enumerate(self.lines, 1):
            stripped = line.strip()

            if not stripped or stripped.startswith('#'):
                continue

            # Check for common mistakes
            # 1. Using = instead of == in conditions
            if re.search(r'\bif\b.*[^=!<>]=[^=]', stripped) and '==' not in stripped:
                if not re.search(r'for\b.*=', stripped):
                    self.reporter.warning(
                        MMCErrorKind.SYNTAX_ERROR,
                        "တောင်းခံချက်တွင် (=) ကို သုံးနေပါသည်၊ (==) ဖြစ်မည်မဟုတ်လား စစ်ဆေးပါ",
                        i, suggestions=[
                            "ပြောင်းပါ: = အစား == ကို သုံးပါ"
                        ]
                    )

            # 2. Check for missing colon after block starters
            tokens = tokenize(stripped)
            if tokens:
                first_word = None
                for t in tokens:
                    if t.type == 'WORD':
                        first_word = STMT_KEYWORDS.get(t.value, t.value)
                        break

                if first_word in self.BLOCK_STARTERS:
                    # Line should end with :
                    translated = _translate_tokens(tokens)
                    joined = _smart_join(translated)
                    if not joined.rstrip().endswith(':') and first_word not in ('else', 'pass', 'break', 'continue', 'return'):
                        # Check if it's a one-liner (has in-line body)
                        if ':' not in stripped and first_word in ('if', 'elif', 'for', 'while', 'def', 'class'):
                            self.reporter.warning(
                                MMCErrorKind.MISSING_COLON,
                                f"'{first_word}' အပြည့်တွင် : (colon) ပါဝင်သင့်ပါ",
                                i, suggestions=[
                                    f"ပြောင်းပါ: {first_word} ...:"
                                ]
                            )

    def _check_unclosed_brackets(self):
        """Check for unmatched brackets, parentheses, braces."""
        bracket_pairs = {'(': ')', '[': ']', '{': '}'}
        open_stack = []  # (char, line, col)

        for i, line in enumerate(self.lines, 1):
            for j, ch in enumerate(line):
                if ch in bracket_pairs:
                    open_stack.append((ch, i, j + 1))
                elif ch in bracket_pairs.values():
                    if not open_stack:
                        # Unexpected closing bracket
                        for open_ch, close_ch in bracket_pairs.items():
                            if close_ch == ch:
                                self.reporter.error(
                                    MMCErrorKind.UNCLOSED_PAREN,
                                    f"'{ch}' သည် မမိမိ ပိတ်ဆက်ဖော်ကောင်းမှု ဖြစ်နေပါသည်",
                                    i, j + 1, suggestions=[
                                        f"'{open_ch}' ဖြင့် စတင်ပါ"
                                    ]
                                )
                                break
                    else:
                        expected_close = bracket_pairs[open_stack[-1][0]]
                        if ch != expected_close:
                            # Mismatched bracket
                            open_ch, open_line, open_col = open_stack[-1]
                            self.reporter.error(
                                MMCErrorKind.UNCLOSED_PAREN,
                                f"'{open_ch}' ပိတ်ဆက်မှု မတူပါ၊ '{ch}' ရောက်နေပါသည်",
                                i, j + 1, suggestions=[
                                    f"{open_line} မှာ '{expected_close}' ဖြင့် ပိတ်ပါ"
                                ]
                            )
                            open_stack.pop()
                        else:
                            open_stack.pop()

        # Check for unclosed brackets
        for open_ch, open_line, open_col in open_stack:
            expected = bracket_pairs[open_ch]
            self.reporter.error(
                MMCErrorKind.UNCLOSED_PAREN,
                f"'{open_ch}' ကို ပိတ်မှုမရှိပါ၊ '{expected}' ကို လိုပါသည်",
                open_line, open_col, suggestions=[
                    f"{open_line} မှာ '{expected}' ဖြင့် ပိတ်ပါ"
                ]
            )

    def _check_unclosed_strings(self):
        """Check for unclosed string literals."""
        for i, line in enumerate(self.lines, 1):
            in_string = False
            string_char = None
            j = 0
            while j < len(line):
                ch = line[j]
                if in_string:
                    if ch == '\\':
                        j += 2
                        continue
                    if ch == string_char:
                        # Check for triple-quote
                        if j + 2 < len(line) and line[j:j+3] == string_char * 3:
                            j += 3
                        else:
                            j += 1
                        in_string = False
                    else:
                        j += 1
                else:
                    if ch in ('"', "'"):
                        # Check for triple-quote
                        if line[j:j+3] in ('"""', "'''"):
                            string_char = line[j:j+3]
                            j += 3
                            in_string = True
                        else:
                            string_char = ch
                            j += 1
                            in_string = True
                    else:
                        j += 1

            if in_string:
                self.reporter.error(
                    MMCErrorKind.UNCLOSED_STRING,
                    "စာသား ပိတ်ဆက်မှု မပြီးပါ",
                    i, suggestions=[
                        "စာသားကို အပြည့်အဖျက် ပိတ်ပါ"
                    ]
                )

    def _check_indentation(self):
        """Check for indentation errors."""
        prev_indent = 0
        for i, line in enumerate(self.lines, 1):
            if not line.strip():
                continue

            # Get indentation level
            leading = len(line) - len(line.lstrip())
            indent_level = leading

            # Check for mixed tabs and spaces
            if '\t' in line[:leading] and ' ' in line[:leading]:
                self.reporter.warning(
                    MMCErrorKind.INVALID_INDENT,
                    "ခြေခံချက်တွင် Tab နှင့် Space နှစ်ခုလုံး သုံးနေပါသည်",
                    i, suggestions=[
                        "Space (4) ခုသာ သုံးပါ"
                    ]
                )

            # Check for tab-only indentation
            if '\t' in line[:leading]:
                self.reporter.warning(
                    MMCErrorKind.INVALID_INDENT,
                    "ခြေခံချက်တွင် Tab သုံးနေပါသည်",
                    i, suggestions=[
                        "Space (4) ခု အစား သုံးပါ"
                    ]
                )

            # Indent jumps should be consistent (multiples of 4)
            if indent_level % 4 != 0 and indent_level > 0:
                self.reporter.warning(
                    MMCErrorKind.INVALID_INDENT,
                    f"ခြေခံချက် ({indent_level}) ဖြစ်နေပါသည်၊ (4 ၏ ဆယ်စုံး ဖြစ်သင့်ပါ)",
                    i, suggestions=[
                        "Space (4) ခု ၏ ဆယ်စုံး သုံးပါ"
                    ]
                )

            prev_indent = indent_level

    def _check_scopes(self):
        """Check for variable scope issues."""
        current_indent = 0
        func_indent = -1

        for i, line in enumerate(self.lines, 1):
            stripped = line.strip()
            if not stripped or stripped.startswith('#'):
                continue

            leading = len(line) - len(line.lstrip())
            current_indent = leading

            # Track function/class definitions
            tokens = tokenize(stripped)
            if tokens:
                first = tokens[0]
                if first.type == 'WORD':
                    kw = STMT_KEYWORDS.get(first.value, '')
                    if kw == 'def':
                        # Get function name
                        if len(tokens) > 1 and tokens[1].type == 'WORD':
                            func_name = tokens[1].value
                            if func_name in self.defined_funcs:
                                self.reporter.warning(
                                    MMCErrorKind.UNDEFINED_FUNCTION,
                                    f"'{func_name}' အဓိပ္ပာယ်ကို ထပ်မံ ပြောင်းလုပ်နေပါသည်",
                                    i
                                )
                            self.defined_funcs.add(func_name)
                    elif kw == 'class':
                        if len(tokens) > 1 and tokens[1].type == 'WORD':
                            cls_name = tokens[1].value
                            self.defined_classes.add(cls_name)

            # Track variable assignments
            if '=' in stripped and not any(
                stripped.startswith(kw) for kw in
                ['if ', 'elif ', 'for ', 'while ', 'def ', 'class ', 'return ',
                 'import ', 'from ', 'try', 'except', 'finally', 'with ', 'async ']
            ):
                # Simple variable assignment detection
                match = re.match(r'^(\w+)\s*=', stripped)
                if match:
                    var_name = match.group(1)
                    # Check if shadowing a builtin
                    py_name = VALUE_KEYWORDS.get(var_name) or FUNC_KEYWORDS.get(var_name)
                    if py_name:
                        self.reporter.warning(
                            MMCErrorKind.SHADOW_BUILTIN,
                            f"'{var_name}' သည် Python ပုံစံ '{py_name}' ကို အရေးပေးအုပ်ဝင်နေပါသည်",
                            i, suggestions=[
                                f"MMC: '{var_name}' ကို အခြေခံပေးခဲ့သော အမည် ပြောင်းပါ"
                            ]
                        )


# ============================================================
# Keyword Categories
# ============================================================

STMT_KEYWORDS = {
    # v4 - Control Flow
    'if': 'if',
    'else': 'else',
    'elif': 'elif',
    # v4 - Loops
    'for': 'for',
    'while': 'while',
    'break': 'break',
    'continue': 'continue',
    # v4 - Functions & Classes
    'def': 'def',
    'return': 'return',
    'class': 'class',
    # v4 - Import
    'import': 'import',
    'from': 'from',
    # v4 - Error Handling
    'try': 'try',
    'except': 'except',
    'finally': 'finally',
    'raise': 'raise',
    # v4 - Async
    'async': 'async',
    'await': 'await',
    # v4 - Logic
    'and': 'and',
    'or': 'or',
    'not': 'not',
    'as': 'as',
    'in': 'in',
    'is': 'is',
    # v5 - Module
    '__all__': '__all__',
    # v6 - Generators
    'yield': 'yield',
    'yield from': 'yield from',
    # v6 - Lambda
    'lambda': 'lambda',
    # v7 - With
    'with': 'with',
    # v7 - Assert
    'assert': 'assert',
    # v8 - Pass / Global / Nonlocal / Del
    'pass': 'pass',
    'global': 'global',
    'nonlocal': 'nonlocal',
    'del': 'del',
    # v9 - Match/Case
    'match': 'match',
    'case': 'case',
}

# Myanmar Statement Keywords
MM_STMT_KEYWORDS = {
    'အကယ်၍': 'if', 'မဟုတ်ပါက': 'else', 'မဟုတ်လျှင်': 'elif',
    'အတွက်': 'for', 'လုပ်နေစဉ်': 'while', 'ရပ်': 'break',
    'ဆက်လုပ်': 'continue', 'အဓိပ္ပာယ်': 'def', 'ပြန်ပေး': 'return',
    'အတန်း': 'class', 'တင်သွင်း': 'import', 'မှ': 'from',
    'ကြိုးစား': 'try', 'ဖမ်းမိ': 'except', 'နောက်ဆုံး': 'finally',
    'ချမြှောက်': 'raise', 'မတူညီ': 'async', 'မျှော်': 'await',
    'ညီမျှလျှင်': 'and', 'သို့မဟုတ်': 'or', 'မဟုတ်': 'not',
    'အဖြစ်': 'as', 'ဖြစ်ပြီး': 'while',
    'ပေးပါ': '__all__', 'ပေး': 'yield', 'ပြန်လုပ်ပေး': 'yield from',
    'များလိုက်': 'lambda', 'နုတ်ထုတ်': 'with', 'စာသေးခံ': 'assert',
    'ကျန်ရမ်း': 'pass', 'ကြွင်းလဲ': 'global', 'ဒေသခံ': 'nonlocal',
    'ဖျက်ပါ': 'del',
}
STMT_KEYWORDS.update(MM_STMT_KEYWORDS)

FUNC_KEYWORDS = {
    'print': 'print', 'input': 'input', 'len': 'len', 'type': 'type',
    'str': 'str', 'int': 'int', 'float': 'float', 'bool': 'bool',
    'list': 'list', 'dict': 'dict', 'set': 'set', 'tuple': 'tuple',
    'range': 'range', 'abs': 'abs', 'max': 'max', 'min': 'min',
    'sum': 'sum', 'sorted': 'sorted', 'map': 'map', 'filter': 'filter',
    'hex': 'hex', 'bin': 'bin', 'hash': 'hash', 'id': 'id',
    'enumerate': 'enumerate', 'zip': 'zip', 'round': 'round',
    'chr': 'chr', 'ord': 'ord', 'open': 'open',
    'frozenset': 'frozenset', 'bytes': 'bytes', 'bytearray': 'bytearray',
    'breakpoint': 'breakpoint', 'repr': 'repr', 'vars': 'vars',
    'dir': 'dir', 'isinstance': 'isinstance', 'issubclass': 'issubclass',
    'callable': 'callable', 'hasattr': 'hasattr', 'getattr': 'getattr',
    'setattr': 'setattr', 'delattr': 'delattr',
    'super': 'super', 'next': 'next', 'iter': 'iter',
    'exec': 'exec', 'eval': 'eval', 'compile': 'compile',
}

MM_FUNC_KEYWORDS = {
    'ပုံနှိပ်': 'print', 'မေးမြန်း': 'input', 'အရှည်': 'len',
    'ဇယား': 'type', 'ကျပန်း': 'str', 'အချိန်': 'int',
    'လော့ဂရစ်သမ်': 'float', 'တန်ဂျင့်': 'bool', 'စာရင်း': 'list',
    'အရာဝတ္ထု': 'dict', 'အဘိဓာန်': 'set', 'ဆိုင်': 'tuple',
    'ပတ်လမ်း': 'range', 'သင်္ချာ': 'abs', 'အမြင့်ဆုံး': 'max',
    'အနိမ့်ဆုံး': 'min', 'ပေါင်းလုံး': 'sum', 'ရွေးချယ်': 'sorted',
    'ပြဿနာ': 'map', 'ကုလသိုက်': 'filter', 'ဟိုပ်': 'hex',
    'ဒုန်းလံ': 'bin', 'ခဲမစ်တီ': 'hash', 'ရောကိုင်': 'enumerate',
    'ဇကာ': 'zip', 'မြှင့်တင်': 'round', 'ဖန်တီး': 'chr',
    'စကားလုံး': 'ord', 'ဖွင့်': 'open',
    'ပုံ_စုံ': 'frozenset', 'ဘိုးလံ': 'bytes', 'ဘိုးလံ_ပုံ': 'bytearray',
    'ကျေးဇူးပြု': 'breakpoint', 'ပုံ_မှတ်တမ်း': 'repr',
    'ရှင်းပြ': 'vars', 'အလေ့အကျင်': 'dir',
    'အမျိုးအစား': 'isinstance', 'အတိအကျ': 'issubclass',
    'လုပ်ဆောင်ချက်_ပေး': 'callable', 'သုံးစွဲ': 'hasattr',
    'ဖွင့်ဆိုင်': 'getattr', 'သတွေ့': 'setattr', 'ဖျက်ဆိုင်': 'delattr',
    'အထက်': 'super', 'နောက်_တိုင်း': 'next', 'အရေရှိ': 'iter',
    'ထည့်သွင်း_ဖိုင်': 'import_module',
    'ဖွင့်_သတိမှတ်': 'asyncio.get_event_loop', 'အလိုလို': 'asyncio.gather',
}
FUNC_KEYWORDS.update(MM_FUNC_KEYWORDS)

TYPE_NAMES = {
    'str': 'str', 'int': 'int', 'float': 'float', 'bool': 'bool',
    'list': 'list', 'dict': 'dict', 'set': 'set', 'tuple': 'tuple',
    'None': 'None', 'Any': 'Any', 'Callable': 'Callable',
    'Optional': 'Optional', 'Union': 'Union', 'Iterator': 'Iterator',
    'Iterable': 'Iterable', 'FrozenSet': 'FrozenSet', 'Bytes': 'Bytes',
}

MM_TYPE_NAMES = {
    'စာသား': 'str', 'အချိန်': 'int', 'လော့ဂရစ်သမ်': 'float',
    'တန်ဂျင့်': 'bool', 'စာရင်း': 'list', 'အရာဝတ္ထု': 'dict',
    'အဘိဓာန်': 'set', 'ဆိုင်': 'tuple', 'မပါ': 'None',
    'အရာရည်': 'Any', 'ခေါ်ဆိုချက်': 'Callable',
    'ဖျက်ရှင်း': 'Optional', 'ဖွင့်ထုတ်': 'Iterator',
    'ဖွင့်ထုတ်_အုပ်စု': 'Iterable',
    'ပုံ_စုံ_အတန်း': 'FrozenSet', 'ဘိုးလံ_အတန်း': 'Bytes',
}
TYPE_NAMES.update(MM_TYPE_NAMES)

DECORATOR_KEYWORDS = {
    'property': 'property', 'staticmethod': 'staticmethod',
    'classmethod': 'classmethod', 'abstractmethod': 'abstractmethod',
}

MM_DECORATOR_KEYWORDS = {
    'လက်မှတ်_ပေး': '', 'ခွဲခြမ်းစိတ်': 'property',
    'ခန့်မှန်း': 'staticmethod', 'ပုံ_အတန်း': 'classmethod',
    'ထိုင်သင့်': '', 'ပရော်ပါ': '', 'တင်သပ်ပါ': '',
    'မှတ်သား_ပေး': '', 'ကျွန်ုပ်တည်ငြိမ်': 'dataclass',
    'အခြေခံ': 'abstractmethod', 'တိကျ': '', 'စကားသား': '',
}
DECORATOR_KEYWORDS.update(MM_DECORATOR_KEYWORDS)

VALUE_KEYWORDS = {
    'True': 'True', 'False': 'False', 'None': 'None',
    'self': 'self', 'cls': 'cls',
}

MM_VALUE_KEYWORDS = {
    'မှန်': 'True', 'မှား': 'False', 'ဘာမှမရှိ': 'None',
    'ဗလာ': 'None', 'ဒီ': 'self', 'ဒါ': 'cls',
}
VALUE_KEYWORDS.update(MM_VALUE_KEYWORDS)

METHOD_KEYWORDS = {
    # String methods
    'upper': 'upper', 'lower': 'lower', 'capitalize': 'capitalize',
    'title': 'title', 'join': 'join', 'split': 'split', 'strip': 'strip',
    'replace': 'replace', 'find': 'find', 'isalpha': 'isalpha',
    'isdigit': 'isdigit', 'isalnum': 'isalnum', 'isupper': 'isupper',
    'islower': 'islower', 'startswith': 'startswith', 'endswith': 'endswith',
    'count': 'count', 'index': 'index', 'center': 'center',
    'ljust': 'ljust', 'rjust': 'rjust', 'format': 'format',
    'encode': 'encode', 'decode': 'decode', 'splitlines': 'splitlines',
    'partition': 'partition', 'rpartition': 'rpartition',
    'maketrans': 'maketrans', 'expandtabs': 'expandtabs', 'copy': 'copy',
    # List methods
    'append': 'append', 'insert': 'insert', 'extend': 'extend',
    'pop': 'pop', 'remove': 'remove', 'sort': 'sort', 'reverse': 'reverse',
    'clear': 'clear',
    # Dict methods
    'keys': 'keys', 'values': 'values', 'items': 'items',
    'get': 'get', 'update': 'update', 'popitem': 'popitem',
    'setdefault': 'setdefault', 'discard': 'discard',
    # Set methods
    'union': 'union', 'intersection': 'intersection',
    'difference': 'difference', 'add': 'add',
    # File methods
    'read': 'read', 'write': 'write', 'close': 'close',
    'readlines': 'readlines', 'readline': 'readline',
    'flush': 'flush', 'writelines': 'writelines',
    # Dunder methods
    '__next__': '__next__', '__iter__': '__iter__',
    '__repr__': '__repr__', '__str__': '__str__',
    '__eq__': '__eq__', '__lt__': '__lt__', '__gt__': '__gt__',
    '__le__': '__le__', '__ge__': '__ge__',
    '__add__': '__add__', '__sub__': '__sub__', '__mul__': '__mul__',
    '__truediv__': '__truediv__',
}

MM_METHOD_KEYWORDS = {
    'စာလုံးကြီး': 'upper', 'စာလုံးသေး': 'lower', 'စမြည့်': 'capitalize',
    'ဆုံးမြည့်': 'title', 'စာဆက်': 'join', 'စာခွဲ': 'split',
    'ဖြတ်': 'strip', 'အစားထိုး': 'replace', 'ရှာဖွေ': 'find',
    'အမှန်နေ': 'isalpha', 'ဂဏန်းဖြစ်': 'isdigit', 'စာသားဖြစ်': 'isalnum',
    'အသားဖြစ်': 'isupper', 'သေးဖြစ်': 'islower',
    'ပိုင်ဆိုင်': 'startswith', 'ပြီးဆုံးဖြစ်': 'endswith',
    'တိကျ_စာ': 'count', 'ရှာမှတ်': 'index', 'ကျေးဇူးပါ': 'center',
    'ဘယ်ကဲ့': 'ljust', 'ညာကဲ့': 'rjust', 'ဖော်ပြ': 'format',
    'ကိုယ်ပိုင်': 'encode', 'ဖွင့်ထုတ်': 'decode',
    'အရှည်_စာရင်း': 'splitlines', 'ပြုပြင်': 'expandtabs',
    'ပုံ_ပြောင်း': 'copy', 'ဖြစ်စဉ်': 'partition',
    'နောက်ဆုံး_ဖြစ်စဉ်': 'rpartition', 'ရောကိုင်ပြု': 'maketrans',
    # List
    'နောက်ဆုံး_ထည့်': 'append', 'ထည့်သွင်း': 'insert',
    'အရှည်_ထည့်': 'extend', 'ရှင်း': 'pop', 'တိကျ_ဖြစ်မရှိ': 'remove',
    'စီ': 'sort', 'ပြန်လဲ': 'reverse', 'ရှင်းလင်း': 'clear',
    'အမြင့်ပြဦး': 'index', 'ရှိမရှိ': 'count',
    # Dict
    'သော့များ': 'keys', 'တန်ဖိုးများ': 'values', 'အတွဲများ': 'items',
    'ရယူ': 'get', 'ပြန်လဲ_ပုံ': 'update', 'ချက်_ဖော်ပြ': 'popitem',
    'မှတ်သား': 'setdefault', 'ပေါင်းထည့်': 'update', 'ဖယ်ရှား': 'discard',
    # Set
    'ပေါင်းပါ': 'union', 'တူနေ_အပေါ်': 'intersection',
    'မတူနေ': 'difference', 'ပါဝင်': 'add',
    # File
    'ဖိုင်ဖတ်': 'read', 'ဖိုင်ရေး': 'write', 'ဖိုင်ဖျက်': 'close',
    'ဖိုင်စုံ': 'readlines', 'ဖိုင်လမ်း': 'readline',
    'ဖိုင်_ပြောင်း': 'flush', 'ဖိုင်_ရေးပါ': 'writelines',
    # Dunder
    'ပုံ_အတွေ့': '__repr__', 'ပုံ_စာသား': '__str__',
    'တိကျ': '__eq__', 'ပိုမို': '__lt__', 'ပိုမို_ကြီး': '__gt__',
    'ပိုမို_သေး': '__le__', 'ပိုမို_ကြီး_သေး': '__ge__',
    'ပေါင်း': '__add__', 'နုတ်': '__sub__', 'အထိ': '__mul__',
    'ပြောင်း': '__truediv__',
}
METHOD_KEYWORDS.update(MM_METHOD_KEYWORDS)

# Combined lookup
ALL_KEYWORDS = {}
ALL_KEYWORDS.update(STMT_KEYWORDS)
ALL_KEYWORDS.update(FUNC_KEYWORDS)
ALL_KEYWORDS.update(VALUE_KEYWORDS)
ALL_KEYWORDS.update(METHOD_KEYWORDS)
ALL_KEYWORDS.update(DECORATOR_KEYWORDS)
ALL_KEYWORDS.update(TYPE_NAMES)

SKIP_KEYWORDS = {'ကိန်း', 'အတည်', 'နေရာ', 'var', 'let', 'const'}
for k in SKIP_KEYWORDS:
    ALL_KEYWORDS[k] = ''

MYANMAR_DIGITS = {
    '၀': '0', '၁': '1', '၂': '2', '၃': '3', '၄': '4',
    '၅': '5', '၆': '6', '၇': '7', '၈': '8', '၉': '9',
}


# ============================================================
# Source Map Generator
# ============================================================

class SourceMap:
    """Track MMC line -> Python line mapping for debugging."""

    def __init__(self):
        self.mappings = []  # [(mmc_line, py_line, mmc_col)]

    def add(self, mmc_line, py_line, mmc_col=0):
        self.mappings.append((mmc_line, py_line, mmc_col))

    def to_dict(self):
        return {'version': 9, 'mappings': self.mappings}

    def to_json(self):
        return json.dumps(self.to_dict(), indent=2)


# ============================================================
# Tokenizer
# ============================================================

class Token:
    """MMC token with source location."""
    __slots__ = ('type', 'value', 'line', 'col')

    def __init__(self, type_, value, line=0, col=0):
        self.type = type_
        self.value = value
        self.line = line
        self.col = col

    def __repr__(self):
        return f"Token({self.type}, {self.value!r}, L{self.line}:C{self.col})"


def tokenize(source):
    """Tokenize MMC source code into Token objects with line/col tracking."""
    tokens = []
    i = 0
    line = 1
    col = 1

    while i < len(source):
        ch = source[i]

        # Newline
        if ch == '\n':
            tokens.append(Token('NEWLINE', '\n', line, col))
            line += 1
            col = 1
            i += 1
            continue

        # Whitespace
        if ch in ' \t\r':
            i += 1
            col += 1
            continue

        # Comment
        if ch == '#':
            j = i
            while j < len(source) and source[j] != '\n':
                j += 1
            tokens.append(Token('COMMENT', source[i:j], line, col))
            col += j - i
            i = j
            continue

        # f-strings
        if (ch == 'f' and i + 1 < len(source) and source[i + 1] in ('"', "'")
                and (i == 0 or not (source[i-1].isalnum() or source[i-1] == '_'
                                     or ord(source[i-1]) > 0x1000))):
            j = i + 2
            quote = source[i + 1]
            while j < len(source) and source[j] != quote:
                if source[j] == '\\':
                    j += 2
                    continue
                if source[j] == '{':
                    # Handle f-string expression - skip to matching }
                    depth = 1
                    j += 1
                    while j < len(source) and depth > 0:
                        if source[j] == '{':
                            depth += 1
                        elif source[j] == '}':
                            depth -= 1
                        j += 1
                    continue
                j += 1
            j = min(j + 1, len(source))
            tokens.append(Token('FSTRING', source[i:j], line, col))
            col += j - i
            i = j
            continue

        # String literals
        if ch in ('"', "'"):
            # Check for triple-quoted
            if source[i:i+3] in ('"""', "'''"):
                quote = source[i:i+3]
                j = i + 3
                while j < len(source) - 2:
                    if source[j:j+3] == quote:
                        j += 3
                        break
                    if source[j] == '\n':
                        line += 1
                        col = 1
                    j += 1
                else:
                    j = len(source)
                tokens.append(Token('STRING', source[i:j], line, col))
                col += j - i
                i = j
            else:
                j = i + 1
                while j < len(source) and source[j] != ch:
                    if source[j] == '\\':
                        j += 1
                    j += 1
                j = min(j + 1, len(source))
                tokens.append(Token('STRING', source[i:j], line, col))
                col += j - i
                i = j
            continue

        # Numbers (including Myanmar digits)
        if ch.isdigit() or ch in MYANMAR_DIGITS:
            j = i
            while j < len(source) and (source[j].isdigit() or source[j] in MYANMAR_DIGITS or source[j] == '.'):
                j += 1
            num = source[i:j]
            for my, ar in MYANMAR_DIGITS.items():
                num = num.replace(my, ar)
            tokens.append(Token('NUMBER', num, line, col))
            col += j - i
            i = j
            continue

        # Multi-char operators
        two = source[i:i+2] if i + 1 < len(source) else ''
        three = source[i:i+3] if i + 2 < len(source) else ''

        if three in ('**=', '//=', '>>=', '<<=', '@='):
            tokens.append(Token('OP', three, line, col))
            i += 3
            col += 3
            continue

        if two in ('==', '!=', '>=', '<=', '+=', '-=', '*=', '/=', '%=',
                    '**', '//', '->', '<<', '>>', '&&', '||', ':=', '??'):
            tokens.append(Token('OP', two, line, col))
            i += 2
            col += 2
            continue

        # Single-char operators and punctuation
        if ch in '=!<>+-*/%()[]{}:,.;@\\~^&|?':
            tokens.append(Token('OP', ch, line, col))
            i += 1
            col += 1
            continue

        # Identifiers / Myanmar words
        if ch.isalpha() or ch == '_' or ord(ch) > 0x1000:
            j = i
            while j < len(source) and (
                source[j].isalnum() or source[j] == '_' or
                ord(source[j]) > 0x1000 or source[j] in MYANMAR_DIGITS
            ):
                j += 1
            word = source[i:j]
            for my, ar in MYANMAR_DIGITS.items():
                word = word.replace(my, ar)
            tokens.append(Token('WORD', word, line, col))
            col += j - i
            i = j
            continue

        # Unknown
        tokens.append(Token('UNKNOWN', ch, line, col))
        i += 1
        col += 1

    return tokens


# ============================================================
# Translator: MMC Tokens -> Python Source
# ============================================================

def translate_to_python(tokens):
    """Translate MMC token list to Python source code."""
    lines = []
    current_tokens = []

    for tok in tokens:
        if tok.type == 'NEWLINE':
            if current_tokens:
                line_str = _tokens_to_str(current_tokens)
                lines.append(line_str)
            else:
                lines.append('')
            current_tokens = []
        elif tok.type == 'COMMENT':
            if not current_tokens:
                lines.append(tok.value)
        else:
            current_tokens.append(tok)

    if current_tokens:
        line_str = _tokens_to_str(current_tokens)
        lines.append(line_str)

    return '\n'.join(lines)


def _tokens_to_str(tokens):
    if not tokens:
        return ''
    py_parts = _translate_tokens(tokens)
    return _smart_join(py_parts)


def _translate_tokens(tokens):
    """Translate a list of tokens to Python parts."""
    parts = []
    i = 0
    after_dot = False
    after_at = False
    after_colon_type = False

    while i < len(tokens):
        tok = tokens[i]

        if tok.type == 'COMMENT':
            i += 1
            continue

        if tok.type in ('STRING', 'FSTRING', 'NUMBER'):
            parts.append(tok.value)
            i += 1
            after_dot = False
            after_at = False
            after_colon_type = False
            continue

        if tok.type == 'OP':
            parts.append(tok.value)
            after_dot = (tok.value == '.')
            after_at = (tok.value == '@')
            after_colon_type = (tok.value == ':')
            i += 1
            continue

        if tok.type == 'WORD':
            word = tok.value

            if word in SKIP_KEYWORDS:
                i += 1
                after_dot = False
                after_at = False
                continue

            if word in VALUE_KEYWORDS:
                val = VALUE_KEYWORDS[word]
                # Special: super -> super()
                if val == 'super':
                    # Check if next token is ( already
                    if i + 1 < len(tokens) and tokens[i+1].value == '(':
                        parts.append('super')
                        i += 1
                    else:
                        parts.append('super()')
                else:
                    parts.append(val)
                i += 1
                after_dot = False
                after_at = False
                after_colon_type = False
                continue

            if after_at and word in DECORATOR_KEYWORDS:
                py_dec = DECORATOR_KEYWORDS[word]
                parts.append(py_dec if py_dec else word)
                i += 1
                after_at = False
                after_dot = False
                continue

            if after_at:
                parts.append(word)
                i += 1
                after_at = False
                after_dot = False
                continue

            if after_dot and word in METHOD_KEYWORDS:
                parts.append(METHOD_KEYWORDS[word])
                i += 1
                after_dot = False
                after_colon_type = False
                continue

            if after_colon_type and word in TYPE_NAMES:
                parts.append(TYPE_NAMES[word])
                i += 1
                after_colon_type = False
                after_dot = False
                continue

            if word in FUNC_KEYWORDS:
                py_name = FUNC_KEYWORDS[word]
                i += 1
                # If followed by =, treat as variable name (not function call)
                if i < len(tokens) and tokens[i].value == '=':
                    parts.append(py_name)
                    after_dot = False
                    after_at = False
                    after_colon_type = False
                    continue
                if i < len(tokens) and tokens[i].value == '(':
                    parts.append(py_name)
                    parts.append('(')
                    i += 1
                    depth = 1
                    inner_parts = []
                    while i < len(tokens) and depth > 0:
                        t = tokens[i]
                        if t.value == '(':
                            depth += 1
                        elif t.value == ')':
                            depth -= 1
                            if depth == 0:
                                inner_py = _smart_join(_translate_tokens(inner_parts))
                                parts.append(inner_py)
                                parts.append(')')
                                i += 1
                                break
                        inner_parts.append(t)
                        i += 1
                else:
                    if py_name in ('breakpoint', '__next__', '__iter__', 'super', 'super()'):
                        parts.append(py_name)
                    elif py_name.startswith('asyncio.'):
                        parts.append(py_name)
                    else:
                        # Collect remaining tokens on this line as args
                        args = []
                        while i < len(tokens):
                            args.append(tokens[i])
                            i += 1
                        if args:
                            # Check if this looks like a function call (has meaningful args)
                            # vs a variable reference (next token is ) , ] or end)
                            first_arg = args[0].value if args else ''
                            if first_arg in (')', ']', ',', ':'):
                                # Used as variable/argument reference, not function call
                                parts.append(py_name)
                            else:
                                args_py = _smart_join(_translate_tokens(args))
                                parts.append(f"{py_name}({args_py})")
                        else:
                            # No args at all - just the name (variable reference)
                            parts.append(py_name)
                after_dot = False
                after_at = False
                after_colon_type = False
                continue

            if word in STMT_KEYWORDS:
                py_kw = STMT_KEYWORDS[word]

                if py_kw == '__all__':
                    parts.append('__all__')
                    i += 1
                    after_dot = False
                    after_at = False
                    continue

                if py_kw == 'for':
                    parts.append('for')
                    i += 1
                    if i < len(tokens):
                        parts.append(_translate_single_token(tokens[i]))
                        i += 1
                        while i < len(tokens) and tokens[i].value == ',':
                            parts.append(',')
                            i += 1
                            if i < len(tokens) and tokens[i].type == 'WORD':
                                parts.append(_translate_single_token(tokens[i]))
                                i += 1
                    if i < len(tokens) and tokens[i].type == 'WORD' and _translate_single_token(tokens[i]) == 'in':
                        i += 1
                    else:
                        parts.append('in')
                    after_dot = False
                    after_at = False
                    after_colon_type = False
                    continue

                if py_kw == 'lambda':
                    parts.append('lambda')
                    i += 1
                    if i < len(tokens) and tokens[i].value == '(':
                        i += 1
                        depth = 1
                        inner_parts = []
                        while i < len(tokens) and depth > 0:
                            t = tokens[i]
                            if t.value == '(':
                                depth += 1
                                inner_parts.append(t)
                            elif t.value == ')':
                                depth -= 1
                                if depth == 0:
                                    i += 1
                                    break
                                inner_parts.append(t)
                            else:
                                inner_parts.append(t)
                            i += 1
                        for ip in inner_parts:
                            parts.append(_translate_single_token(ip))
                    after_dot = False
                    after_at = False
                    after_colon_type = False
                    continue

                if py_kw == 'yield from':
                    parts.append('yield from')
                elif py_kw in ('match', 'case'):
                    parts.append(py_kw)
                else:
                    parts.append(py_kw)
                i += 1
                after_dot = False
                after_at = False
                after_colon_type = False
                continue

            parts.append(word)
            i += 1
            after_dot = False
            after_at = False
            after_colon_type = False
            continue

        parts.append(str(tok.value))
        i += 1
        after_dot = False
        after_at = False
        after_colon_type = False

    return parts


def _translate_single_token(tok):
    if tok.type == 'WORD':
        for d in (SKIP_KEYWORDS, VALUE_KEYWORDS, STMT_KEYWORDS,
                  FUNC_KEYWORDS, METHOD_KEYWORDS, TYPE_NAMES):
            if tok.value in d:
                return d[tok.value]
    return tok.value


def _smart_join(parts):
    """Join Python parts with proper spacing."""
    if not parts:
        return ''
    parts = [p for p in parts if p]
    if len(parts) <= 1:
        return ''.join(parts)

    result = [parts[0]]
    i = 1
    while i < len(parts):
        prev = result[-1]
        curr = parts[i]

        if prev == '.' or curr == '.':
            result.append(curr); i += 1; continue
        if prev == '@':
            result.append(curr); i += 1; continue
        if prev in ('(', '[', '{'):
            result.append(curr); i += 1; continue
        if curr in (')', ']', '}'):
            result.append(curr); i += 1; continue
        if curr in (',', ';', ':'):
            result.append(curr); i += 1; continue
        if curr in ('[', '(', '{') and prev == '=':
            result.append(' '); result.append(curr); i += 1; continue
        if curr == '(' and (prev[-1:].isdigit() or prev[-1:] in '+-*/%<>!&|^~?)\'"'):
            result.append(curr); i += 1; continue
        if curr == '[' and (prev[-1:].isdigit() or prev[-1:] in '+-*/%<>!&|^~?)\'"'):
            result.append(curr); i += 1; continue
        if curr == '[' and (prev[-1:].isalpha() or prev[-1:] == '_') and prev != '=':
            result.append(curr); i += 1; continue
        if curr in ('(', '[') and prev[-1:] in (')', ']', '}'):
            result.append(curr); i += 1; continue
        if prev[-1:] in (')', ']', '}'):
            if curr[0:1] not in (',', ';', ':', ')', ']', '}'):
                result.append(' ')
            result.append(curr); i += 1; continue
        if prev[0:1] in ('"', "'"):
            result.append(' '); result.append(curr); i += 1; continue

        if curr == '(':
            prev_clean = prev.lstrip()
            SPACE_BEFORE_PAREN = {
                'def', 'class', 'if', 'elif', 'else', 'while', 'for', 'with',
                'assert', 'return', 'raise', 'yield', 'yield from', 'lambda',
                'not', 'and', 'or', 'in', 'is', 'as', 'async', 'await',
                'del', 'global', 'nonlocal', 'pass', 'import', 'from',
                'except', 'finally', 'try', 'match', 'case',
            }
            if prev_clean in SPACE_BEFORE_PAREN:
                result.append(' '); result.append(curr)
            else:
                result.append(curr)
            i += 1; continue

        if prev == '=':
            result.append(' '); result.append(curr); i += 1; continue
        if prev in ('+=', '-=', '*=', '/=', '%=', '**=', '//=', '>>=', '<<=', '@='):
            result.append(' '); result.append(curr); i += 1; continue
        if prev in ('==', '!=', '>=', '<=', '**', '//', '->', '<<', '>>', '&&', '||', ':=', '??'):
            result.append(' '); result.append(curr); i += 1; continue

        result.append(' '); result.append(curr); i += 1

    return ''.join(result)


# ============================================================
# Main Transpiler API - Professional Edition
# ============================================================

def mmc_to_python(source, generate_map=False, validate=True):
    """MMC source -> Python source (main API).

    Args:
        source: MMC source code string
        generate_map: If True, also return a SourceMap
        validate: If True, run semantic validation

    Returns:
        If generate_map is False: Python source string
        If generate_map is True: (Python source, SourceMap)
    """
    source_map = SourceMap() if generate_map else None

    # Run semantic validation if requested
    if validate:
        reporter = ErrorReporter(source.split('\n'), '<mmc>')
        validator = SemanticValidator(source, reporter)
        validator.validate()

    lines = source.split('\n')
    py_lines = []

    for line_num, line in enumerate(lines, 1):
        stripped = line.strip()

        if not stripped:
            py_lines.append('')
            if source_map:
                source_map.add(line_num, len(py_lines))
            continue

        if stripped.startswith('#'):
            py_lines.append(line)
            if source_map:
                source_map.add(line_num, len(py_lines))
            continue

        leading = len(line) - len(line.lstrip())
        indent = '    ' * (leading // 4)

        tokens = tokenize(stripped)
        py_parts = _translate_tokens(tokens)
        py_code = _smart_join(py_parts)

        py_lines.append(indent + py_code)
        if source_map:
            source_map.add(line_num, len(py_lines), 0)

    py_source = '\n'.join(py_lines)

    if generate_map:
        return py_source, source_map
    return py_source


def run_mmc(source, timeout=10, show_traceback=False):
    """Execute MMC code with professional error reporting.

    Returns: (stdout, stderr, exit_code, python_code, errors_list)
    """
    py_code, source_map = mmc_to_python(source, generate_map=True, validate=True)
    mapper = TracebackMapper(source_map.mappings, source)
    reporter = ErrorReporter(source.split('\n'), '<mmc>')

    old_out = sys.stdout
    old_err = sys.stderr
    sys.stdout = out_buf = io.StringIO()
    sys.stderr = err_buf = io.StringIO()

    exit_code = 0
    try:
        ns = {'__builtins__': __builtins__, '__name__': '__mmc__'}
        exec(py_code, ns)
    except SystemExit as e:
        exit_code = e.code or 0
    except Exception as e:
        exit_code = 1
        exc_type = type(e).__name__
        exc_msg = str(e)

        # Extract Python line number from traceback
        py_line = None
        tb = sys.exc_info()[2]
        if tb:
            tb_lines = traceback.format_tb(tb)
            for tb_line in tb_lines:
                # Look for line number in traceback
                line_match = re.search(r'File "<string>", line (\d+)', tb_line)
                if line_match:
                    py_line = int(line_match.group(1))
                    break

        # Map to MMC source
        kind, message, mmc_line, mmc_col, suggestions = mapper.map_error(
            exc_type, exc_msg, py_line
        )

        reporter.error(kind, message, mmc_line, mmc_col,
                       suggestions=suggestions)

        # Write formatted error to stderr
        err_buf.write(reporter.format_all())

        if show_traceback:
            err_buf.write(f"\n{'='*50}\n")
            err_buf.write(f"Python Traceback (MMC -> Python -> Error):\n")
            err_buf.write(f"{'='*50}\n")
            traceback.print_exc(file=err_buf)

    sys.stdout = old_out
    sys.stderr = old_err

    return out_buf.getvalue(), err_buf.getvalue(), exit_code, py_code, reporter.errors


def lint_mmc(source):
    """Lint MMC source code - check for issues without running.

    Returns: (issues_list, warning_count, error_count)
    """
    reporter = ErrorReporter(source.split('\n'), '<mmc>')
    validator = SemanticValidator(source, reporter)
    validator.validate()

    # Additional lint checks
    lines = source.split('\n')
    for i, line in enumerate(lines, 1):
        stripped = line.strip()
        if not stripped or stripped.startswith('#'):
            continue

        # Check for very long lines
        if len(stripped) > 120:
            reporter.warning(
                MMCErrorKind.COMPLEX_EXPRESSION,
                f"တည်ဆောက်ထားသော စာကြောင်း လောက်ကျယ်နေပါသည် ({len(stripped)} အကြောင်း)၊ အမြင့်ဆုံး (120) ဖြစ်သင့်ပါ",
                i
            )

        # Check for bare except
        if 'except' in stripped and ':' in stripped:
            tokens = tokenize(stripped)
            has_except_type = False
            for j, t in enumerate(tokens):
                if t.type == 'WORD' and STMT_KEYWORDS.get(t.value) == 'except':
                    # Check if next non-colon token is a type
                    for k in range(j + 1, len(tokens)):
                        if tokens[k].value == ':':
                            break
                        if tokens[k].type == 'WORD' and tokens[k].value not in STMT_KEYWORDS:
                            has_except_type = True
                            break
                    if not has_except_type:
                        reporter.warning(
                            MMCErrorKind.TYPE_MISMATCH,
                            "except ဖြင့် အရာရည်အမျိုးအစား မပေးထားပါ",
                            i, suggestions=[
                                "except Exception ကို သုံးပါ:",
                                "except ValueError ကို သုံးပါ:",
                                "except (ValueError, TypeError) ကို သုံးပါ:",
                            ]
                        )

    return reporter.errors, reporter.warnings, reporter.format_all()


def compile_mmc(source, output_file=None):
    """Compile MMC to Python with source map and validation."""
    py_code, source_map = mmc_to_python(source, generate_map=True, validate=True)
    header = f"# Generated by MMC Transpiler v9.0 (Professional Edition)\n# Source Map: {len(source_map.mappings)} lines mapped\n\n"
    py_code = header + py_code

    if output_file:
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(py_code)
        map_file = output_file + '.map'
        with open(map_file, 'w', encoding='utf-8') as f:
            f.write(source_map.to_json())
        return py_code, map_file
    return py_code, source_map.to_json()


# ============================================================
# CLI - Professional Edition
# ============================================================

def main():
    if len(sys.argv) < 2:
        print("""
MMC Transpiler v9.0 - Professional Edition
Myanmar Code Programming Language

Usage:
  python mmc_transpiler.py run <file.mmc>        Run MMC code
  python mmc_transpiler.py compile <file.mmc>    Show Python output
  python mmc_transpiler.py build <file.mmc>       Compile to .py with source map
  python mmc_transpiler.py lint <file.mmc>        Lint MMC code (check errors)
  python mmc_transpiler.py debug <file.mmc>       Run with full traceback
  python mmc_transpiler.py version                Show version info
  python mmc_transpiler.py keywords               Show all keywords

v9.0 New Features:
  - Professional Error Reporting (MMC source context, suggestions)
  - Traceback Mapper (Python errors -> MMC source locations)
  - Semantic Validator (pre-compilation checks)
  - Lint Mode (code quality analysis)
  - Warning System (style issues, deprecations)
  - Multi-error Recovery (collect all errors, not just first)
  - Match/Case support
  - Walrus operator (:=)
  - 200+ keywords (Myanmar + English)
""")
        sys.exit(0)

    cmd = sys.argv[1]

    if cmd == 'run':
        if len(sys.argv) < 3:
            print("Error: Specify .mmc file"); sys.exit(1)
        with open(sys.argv[2], 'r', encoding='utf-8') as f:
            source = f.read()
        stdout, stderr, code, _, errors = run_mmc(source)
        if stdout: print(stdout, end='')
        if stderr: print(stderr, end='', file=sys.stderr)
        sys.exit(code)

    elif cmd == 'compile':
        if len(sys.argv) < 3:
            print("Error: Specify .mmc file"); sys.exit(1)
        with open(sys.argv[2], 'r', encoding='utf-8') as f:
            source = f.read()
        py = mmc_to_python(source)
        print("--- MMC -> Python ---")
        print(py)
        print("--- End ---")

    elif cmd == 'build':
        if len(sys.argv) < 3:
            print("Error: Specify .mmc file"); sys.exit(1)
        with open(sys.argv[2], 'r', encoding='utf-8') as f:
            source = f.read()
        out = sys.argv[2].replace('.mmc', '.py')
        py, map_json = compile_mmc(source, out)
        print(f"Compiled: {out}")
        print(f"Source map: {out}.map")

    elif cmd == 'lint':
        if len(sys.argv) < 3:
            print("Error: Specify .mmc file"); sys.exit(1)
        with open(sys.argv[2], 'r', encoding='utf-8') as f:
            source = f.read()
        errors, warnings, report = lint_mmc(source)
        print(report)
        if not errors and not warnings:
            print("No issues found. Code looks good!")

    elif cmd == 'debug':
        if len(sys.argv) < 3:
            print("Error: Specify .mmc file"); sys.exit(1)
        with open(sys.argv[2], 'r', encoding='utf-8') as f:
            source = f.read()
        stdout, stderr, code, py_code, errors = run_mmc(source, show_traceback=True)
        if stdout: print(stdout, end='')
        if stderr: print(stderr, end='', file=sys.stderr)

    elif cmd == 'version':
        print("MMC Transpiler v9.0 - Professional Edition")
        print("Myanmar Code Programming Language")
        print(f"Keywords: {len(ALL_KEYWORDS)}")
        print(f"  Statements: {len(STMT_KEYWORDS)}")
        print(f"  Functions: {len(FUNC_KEYWORDS)}")
        print(f"  Methods: {len(METHOD_KEYWORDS)}")
        print(f"  Decorators: {len(DECORATOR_KEYWORDS)}")
        print(f"  Types: {len(TYPE_NAMES)}")
        print(f"  Values: {len(VALUE_KEYWORDS)}")
        print(f"Features: Error Reporting, Traceback Mapper, Semantic Validation,")
        print(f"          Lint Mode, Source Maps, AST Validation, Warning System")

    elif cmd == 'keywords':
        print("=== MMC Keywords v9.0 ===\n")
        print(f"Total: {len(ALL_KEYWORDS)} keywords\n")

        print("--- Statement Keywords ---")
        for mm, py in sorted(STMT_KEYWORDS.items()):
            if ord(mm[0]) > 0x1000 or mm in MM_STMT_KEYWORDS:
                print(f"  {mm:20s} -> {py}")

        print("\n--- Function Keywords ---")
        for mm, py in sorted(FUNC_KEYWORDS.items()):
            if ord(mm[0]) > 0x1000 or mm in MM_FUNC_KEYWORDS:
                print(f"  {mm:20s} -> {py}")

        print("\n--- Method Keywords ---")
        for mm, py in sorted(METHOD_KEYWORDS.items()):
            if ord(mm[0]) > 0x1000 or mm in MM_METHOD_KEYWORDS:
                print(f"  {mm:20s} -> {py}")

        print("\n--- Value Keywords ---")
        for mm, py in sorted(VALUE_KEYWORDS.items()):
            if ord(mm[0]) > 0x1000 or mm in MM_VALUE_KEYWORDS:
                print(f"  {mm:20s} -> {py}")

        print("\n--- Type Names ---")
        for mm, py in sorted(TYPE_NAMES.items()):
            if ord(mm[0]) > 0x1000 or mm in MM_TYPE_NAMES:
                print(f"  {mm:20s} -> {py}")

        print("\n--- Decorator Keywords ---")
        for mm, py in sorted(DECORATOR_KEYWORDS.items()):
            if ord(mm[0]) > 0x1000 or mm in MM_DECORATOR_KEYWORDS:
                print(f"  {mm:20s} -> {py}")

    else:
        print(f"Unknown command: {cmd}")
        print("Run: python mmc_transpiler.py")
        sys.exit(1)


if __name__ == "__main__":
    main()
