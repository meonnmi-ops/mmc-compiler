#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MMC Debugger v8.0
Interactive debugger for Myanmar Code

Features:
  - Breakpoints
  - Step through code
  - Variable inspection
  - Call stack trace
  - Expression evaluation
  - Source mapping

Usage:
  python mmc_debug.py <file.mmc>           Debug MMC file
  python mmc_debug.py --break <line> <f>   Set initial breakpoint

Author: MyanOS AI Team
Version: 8.0.0
"""

import os
import sys
import re
import cmd
import io
import traceback
import linecache
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from mmc_transpiler import mmc_to_python


class MMCDebugBreakpoint:
    """Represents a breakpoint."""

    def __init__(self, line, condition=None):
        self.line = line
        self.condition = condition
        self.enabled = True
        self.hit_count = 0

    def __repr__(self):
        status = "enabled" if self.enabled else "disabled"
        cond = f" if {self.condition}" if self.condition else ""
        return f"Breakpoint at line {self.line} ({status}){cond}"


class MMCDebugger:
    """MMC source-level debugger."""

    def __init__(self, source, filename="<mmc>"):
        self.source = source
        self.filename = filename
        self.lines = source.split('\n')
        self.breakpoints = {}  # line_num -> MMCDebugBreakpoint
        self.call_stack = []
        self.variables = {}
        self.current_line = 0
        self.python_code = mmc_to_python(source)
        self.py_lines = self.python_code.split('\n')
        self.step_mode = False  # True = step-by-step
        self.running = False
        self.history = []

    def add_breakpoint(self, line, condition=None):
        """Add a breakpoint at a given MMC line number."""
        bp = MMCDebugBreakpoint(line, condition)
        self.breakpoints[line] = bp
        return bp

    def remove_breakpoint(self, line):
        """Remove a breakpoint."""
        if line in self.breakpoints:
            del self.breakpoints[line]
            return True
        return False

    def toggle_breakpoint(self, line):
        """Toggle a breakpoint on/off."""
        if line in self.breakpoints:
            self.breakpoints[line].enabled = not self.breakpoints[line].enabled
        else:
            self.add_breakpoint(line)

    def check_breakpoint(self, line):
        """Check if there's a breakpoint at this line."""
        if line in self.breakpoints:
            bp = self.breakpoints[line]
            if bp.enabled:
                bp.hit_count += 1
                if bp.condition is None:
                    return True
                # Evaluate condition
                try:
                    return bool(eval(bp.condition, {}, self.variables))
                except Exception:
                    return True
        return False

    def show_source(self, around_line=None, context=3):
        """Show source code around a line."""
        if around_line is None:
            around_line = self.current_line

        start = max(0, around_line - context)
        end = min(len(self.lines), around_line + context + 1)

        output = []
        for i in range(start, end):
            line_num = i + 1
            marker = ">"
            if line_num in self.breakpoints:
                marker = "*"
            elif line_num == around_line:
                marker = ">"
            else:
                marker = " "

            has_bp = line_num in self.breakpoints
            bp_marker = "B " if has_bp else "  "
            output.append(f"{bp_marker}{marker} {line_num:4d} | {self.lines[i]}")

        return '\n'.join(output)

    def show_python(self, around_line=None, context=3):
        """Show generated Python code."""
        if around_line is None:
            around_line = self.current_line
        # Map MMC line to Python line (approximate)
        py_line = min(around_line, len(self.py_lines))

        start = max(0, py_line - context)
        end = min(len(self.py_lines), py_line + context + 1)

        output = []
        for i in range(start, end):
            marker = ">" if i == py_line - 1 else " "
            output.append(f"  {marker} {i + 1:4d} | {self.py_lines[i]}")

        return '\n'.join(output)

    def inspect_variable(self, name):
        """Inspect a variable's value and type."""
        if name in self.variables:
            val = self.variables[name]
            return f"{name} = {val!r}  (type: {type(val).__name__})"
        return f"Variable '{name}' not found"

    def list_variables(self):
        """List all current variables."""
        if not self.variables:
            return "No variables in scope"

        output = []
        for name, val in sorted(self.variables.items()):
            if not name.startswith('__'):
                output.append(f"  {name:20s} = {val!r}  ({type(val).__name__})")

        return '\n'.join(output) if output else "No variables in scope"

    def evaluate(self, expression):
        """Evaluate an expression in current context."""
        try:
            result = eval(expression, {"__builtins__": __builtins__}, self.variables)
            self.history.append(expression)
            return f"{result!r}  (type: {type(result).__name__})"
        except Exception as e:
            return f"Error: {type(e).__name__}: {e}"

    def execute_statement(self, statement):
        """Execute a statement (modify state)."""
        try:
            exec(statement, {"__builtins__": __builtins__}, self.variables)
            return "OK"
        except Exception as e:
            return f"Error: {type(e).__name__}: {e}"

    def get_trace(self):
        """Get current call stack trace."""
        return '\n'.join(self.call_stack) if self.call_stack else "No call stack"

    def get_stats(self):
        """Get debugging session statistics."""
        return {
            'breakpoints': len(self.breakpoints),
            'variables': len(self.variables),
            'history_len': len(self.history),
            'source_lines': len(self.lines),
            'python_lines': len(self.py_lines),
        }


class MMCDebugREPL(cmd.Cmd):
    """Interactive debugger REPL."""

    intro = f"""
{MMCDebugger.__doc__}
Type 'help' for commands, 'quit' to exit.
"""
    prompt = "(mmc-dbg) "

    def __init__(self, debugger):
        super().__init__()
        self.dbg = debugger

    def do_step(self, arg):
        """Step to next line (s)"""
        self.dbg.step_mode = True
        self._advance()

    def do_next(self, arg):
        """Next line (n)"""
        self._advance()

    def do_continue(self, arg):
        """Continue until breakpoint (c)"""
        self.dbg.step_mode = False
        self._advance()

    def do_break(self, arg):
        """Set breakpoint: break <line> [condition] (b)"""
        parts = arg.strip().split(maxsplit=1)
        if not parts:
            print("Usage: break <line> [condition]")
            return
        try:
            line = int(parts[0])
            cond = parts[1] if len(parts) > 1 else None
            bp = self.dbg.add_breakpoint(line, cond)
            print(bp)
        except ValueError:
            print("Invalid line number")

    def do_delete(self, arg):
        """Delete breakpoint: delete <line> (d)"""
        if not arg:
            print("Usage: delete <line>")
            return
        try:
            line = int(arg)
            if self.dbg.remove_breakpoint(line):
                print(f"Breakpoint at line {line} removed")
            else:
                print(f"No breakpoint at line {line}")
        except ValueError:
            print("Invalid line number")

    def do_list(self, arg):
        """List source code: list [line] (l)"""
        line = int(arg) if arg.strip() else None
        print(self.dbg.show_source(line))

    def do_python(self, arg):
        """Show generated Python code: python (py)"""
        print(self.dbg.show_python())

    def do_vars(self, arg):
        """List all variables (v)"""
        print(self.dbg.list_variables())

    def do_inspect(self, arg):
        """Inspect variable: inspect <name> (i)"""
        if not arg:
            print("Usage: inspect <name>")
            return
        print(self.dbg.inspect_variable(arg.strip()))

    def do_eval(self, arg):
        """Evaluate expression: eval <expr> (e)"""
        if not arg:
            print("Usage: eval <expression>")
            return
        print(self.dbg.evaluate(arg.strip()))

    def do_exec(self, arg):
        """Execute statement: exec <stmt>"""
        if not arg:
            print("Usage: exec <statement>")
            return
        print(self.dbg.execute_statement(arg.strip()))

    def do_trace(self, arg):
        """Show call stack trace"""
        print(self.dbg.get_trace())

    def do_breakpoints(self, arg):
        """List all breakpoints"""
        if not self.dbg.breakpoints:
            print("No breakpoints set")
            return
        for line, bp in sorted(self.dbg.breakpoints.items()):
            print(f"  {bp}")

    def do_stats(self, arg):
        """Show debug session statistics"""
        stats = self.dbg.get_stats()
        print(f"  Breakpoints: {stats['breakpoints']}")
        print(f"  Variables:   {stats['variables']}")
        print(f"  History:     {stats['history_len']}")
        print(f"  MMC Lines:   {stats['source_lines']}")
        print(f"  Python Lines:{stats['python_lines']}")

    def do_run(self, arg):
        """Run the program"""
        print("Running...")
        self.dbg.running = True
        try:
            ns = {'__builtins__': __builtins__, '__name__': '__mmc__'}
            exec(self.dbg.python_code, ns)
            self.dbg.variables = {k: v for k, v in ns.items() if not k.startswith('__')}
            print("Program completed.")
        except Exception as e:
            print(f"Error: {type(e).__name__}: {e}")
            traceback.print_exc()
        self.dbg.running = False

    def do_quit(self, arg):
        """Quit debugger (q)"""
        print("Goodbye!")
        return True

    def _advance(self):
        """Advance to next interesting line."""
        self.dbg.current_line += 1
        if self.dbg.current_line > len(self.dbg.lines):
            print("End of program.")
            return

        line = self.dbg.current_line
        code = self.dbg.lines[line - 1].strip()

        # Skip empty lines and comments when stepping
        if self.dbg.step_mode:
            while (not code or code.startswith('#')) and line < len(self.dbg.lines):
                line += 1
                self.dbg.current_line = line
                code = self.dbg.lines[line - 1].strip()

        print(self.dbg.show_source(line))

        if self.dbg.check_breakpoint(line):
            print(f"\n*** Breakpoint hit at line {line} ***")

    # Shortcuts
    do_s = do_step
    do_n = do_next
    do_c = do_continue
    do_b = do_break
    do_d = do_delete
    do_l = do_list
    do_py = do_python
    do_v = do_vars
    do_i = do_inspect
    do_e = do_eval
    do_q = do_quit
    do_r = do_run


def debug_file(filepath, initial_break=None):
    """Debug an MMC file."""
    with open(filepath, 'r', encoding='utf-8') as f:
        source = f.read()

    dbg = MMCDebugger(source, os.path.basename(filepath))

    if initial_break:
        dbg.add_breakpoint(initial_break)
        print(f"Initial breakpoint set at line {initial_break}")

    print(f"Debugging: {filepath}")
    print(f"Lines: {len(dbg.lines)}")
    print(f"Python output: {len(dbg.py_lines)} lines")
    print()

    print(dbg.show_source(1))

    repl = MMCDebugREPL(dbg)
    try:
        repl.cmdloop()
    except KeyboardInterrupt:
        print("\nDebugger interrupted.")


def main():
    if len(sys.argv) < 2:
        print("""
MMC Debugger v8.0 - Myanmar Code Interactive Debugger

Usage:
  python mmc_debug.py <file.mmc>              Debug MMC file
  python mmc_debug.py --break <line> <file>   Set initial breakpoint

Commands (in debugger):
  s(tep)          Step to next line
  n(ext)          Next line
  c(ontinue)      Continue to breakpoint
  b(reak) <line>  Set breakpoint
  d(elete) <line> Delete breakpoint
  l(ist) [line]   Show source
  py(thon)        Show generated Python
  v(ars)          List variables
  i(nspect) <var> Inspect variable
  e(val) <expr>   Evaluate expression
  exec <stmt>     Execute statement
  trace           Show call stack
  breakpoints     List breakpoints
  stats           Show statistics
  r(un)           Run program
  q(uit)          Quit
""")
        sys.exit(0)

    args = sys.argv[1:]
    initial_break = None

    if '--break' in args:
        idx = args.index('--break')
        if idx + 1 < len(args):
            initial_break = int(args[idx + 1])
            args = args[:idx] + args[idx + 2:]
        else:
            print("Error: --break requires a line number")
            sys.exit(1)

    if not args:
        print("Error: Specify .mmc file to debug")
        sys.exit(1)

    debug_file(args[0], initial_break)


if __name__ == '__main__':
    main()
