#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MMC AI Server v9.0 - Myanmar Code Web IDE + AI Assistant
Author: MyanOS AI Team
Description: Complete Web IDE for Myanmar Code programming language.
             Single-file Python HTTP server using only stdlib.
             Features: Code editor, output panels, AI chat via Ollama,
             resizable panels, dark theme, mobile-responsive design.
"""

import json
import os
import sys
import threading
import urllib.request
import urllib.error
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    from mmc_transpiler import mmc_to_python, run_mmc
    MMC_AVAILABLE = True
except ImportError:
    MMC_AVAILABLE = False

PORT = int(os.environ.get('MMC_PORT', 8080))
HOST = os.environ.get('MMC_HOST', '0.0.0.0')
OLLAMA_URL = os.environ.get('OLLAMA_URL', 'http://localhost:11434')
OLLAMA_MODEL = os.environ.get('OLLAMA_MODEL', 'mmc-ai')
VERSION = 'v9.0'

# ---------------------------------------------------------------------------
# MMC AI System Prompt (comprehensive keyword reference for Ollama)
# ---------------------------------------------------------------------------
MMC_SYSTEM_PROMPT = r"""You are MMC AI Assistant v9.0 - an expert AI for the Myanmar Code (MMC) programming language. You help users write, debug, and understand MMC code. MMC is a programming language that uses Myanmar (Burmese) keywords instead of English keywords but compiles to Python.

## MMC v9.0 Complete Keyword Reference

### Core Keywords (Type 1 - Direct Translation)
- ပါဝင် (input) - Read user input
- ပြုရန် (print) - Print/display output
- သင်္ကေတ (class) - Define a class
- နောက်ဆက်ပါ (elif) - Else-if conditional
- ပြောင်းလုပ် (else) - Else conditional
- အများကြီး (except) - Exception handler
- ကြိုတင် (finally) - Finally block
- ပိုႏ (for) - For loop
- လုပ်ဆောင် (def) - Define function
- အပ်နှံ (global) - Global variable
- တိုက် (if) - If conditional
- ရင်းနှီး (import) - Import module
- နှုန်း (lambda) - Lambda function
- ဖြန့်ပြ (nonlocal) - Nonlocal variable
- ပဲ (not) - Logical NOT
- နှင့် (and) - Logical AND
- သား (or) - Logical OR
- ခန့်မှန်း (pass) - Pass statement
- ပေးပို့ (return) - Return from function
- တင် (is) - Identity operator
- ပေါင်း (in) - Membership operator
- ဖော်ပြ (assert) - Assertion
- ခေါ်ဆို (raise) - Raise exception
- ထုတ်ယူ (del) - Delete variable
- ရှင်းလင်း (while) - While loop
- ပိုင်ဆိုင် (with) - Context manager
- ဖျက်ဆီး (break) - Break loop
- ဆက်လက် (continue) - Continue loop
- အောက်ပါ (yield) - Yield generator
- ခံလျှင် (async) - Async function
- စောင့်ကြည့် (await) - Await async

### Operators
- ပြုပြင် (+=) - Add assign
- ဖယ်ရှား (-=) - Subtract assign
- ပိုင်းခြင်း (*=) - Multiply assign
- ပြှင်လဲ (//=) - Floor divide assign
- ကြက် (/=) - Divide assign
- စားမှတ် (%=) - Modulo assign
- အရေးငွေ (**=) - Power assign
- အပေါ် (//) - Floor division
- စုံ (**) - Exponentiation

### Comparison Operators
- တူသလား (==) - Equal
- မတူဘူး (!=) - Not equal
- ပိုင်း (>) - Greater than
- ပိုမျှ (>=) - Greater or equal
- ညာ (>) - Greater (alias)
- ငယ် (<=) - Less or equal
- နည်း (-) - Subtract (also less-than in some contexts)

### Built-in Functions
- သတ်မှတ် (int) - Integer conversion
- ရောက် (float) - Float conversion
- စာ (str) - String conversion
- မြင် (bool) - Boolean conversion
- မှတ်သား (list) - List conversion
- စာရင်း (dict) - Dictionary conversion
- ကိရိယာ (tuple) - Tuple conversion
- စုပေါင်း (set) - Set conversion
- တွက်ချက် (sum) - Sum of iterable
- အမြင့်မား (max) - Maximum value
- အနည်းငယ် (min) - Minimum value
- အရေအကြေး (abs) - Absolute value
- ခန့်မှန်း (round) - Round number
- တိကျ (type) - Get type
- ခေါ် (id) - Object identity
- ရရှိ (len) - Length
- ရှင်းပြ (repr) - String representation
- ချိတ်ဆက် (format) - Format string
- နားလည် (range) - Range iterator
- နေရာ (enumerate) - Enumerate iterable
- ခွဲခြမ်း (zip) - Zip iterables
- ချိုး (sorted) - Sorted list
- ပြောင်းလဲ (reversed) - Reversed iterator
- ဖော်ကြား (map) - Map function
- ယုံကြည် (filter) - Filter function
- စဥ် (iter) - Iterator
- နေ့ (next) - Next item
- ခွင့် (open) - Open file
- အတိအကျ (isinstance) - Instance check
- ပုံသဏ္ဌာန် (property) - Property decorator
- သုံးစွဲ (staticmethod) - Static method
- လုပ်ဆောင် (classmethod) - Class method
- မှု (super) - Super class reference

### Constants
- မဟုတ် (False) - Boolean false
- ဟွေ (True) - Boolean true
- ဘာမ် (None) - Null value

### Type Hints (v6)
- သင်္ကေတ = Type hint for classes
- အကြောင်းး = Type hint for strings (hint: အကြောင်းး)
- ပမာဏ = Type hint for integers (hint: ပမာဏ)
- ချက် = Type hint for floats (hint: ချက်)
- မြင် = Type hint for booleans (hint: မြင်)
- အရေ (Type hint for any type) -> အရေ
- မှတ်သား = Type hint for lists (hint: မှတ်သား[type])
- မှတ်သားမဟုတ် (Optional[type])

### Decorators (v6)
- ပုံသဏ္ဌာန် = @property
- သုံးစွဲ = @staticmethod
- လုပ်ဆောင် = @classmethod
- စားမှတ် = @functools.lru_cache
- ခွဲခြမ်း = @dataclass

### Exception Types
- အမှားကြောင်း (Exception) - Base exception
- ဖော်ပြ (AssertionError) - Assert failed
- အလိုအပ် (ValueError) - Bad value
- အမျိုး (TypeError) - Bad type
- မရှိ (KeyError) - Missing key
- နည်း (IndexError) - Bad index
- မရောက် (AttributeError) - Missing attribute
- ပိတ် (StopIteration) - Stop iteration
- မမှန် (NotImplementedError) - Not implemented

### Standard Library Aliases
- နေ့စဉ် (datetime) - Date/time module
- မှန်ကန် (math) - Math module
- ရွေးချယ် (random) - Random module
- ဖော်ပြ (os) - OS module
- လမ်းညွှန် (os.path) - Path module
- စာတွေ့ (os.listdir) - List directory
- ဖြန့် (os.makedirs) - Make directories
- ပြောင်းလဲ (os.rename) - Rename file
- ဖျက် (os.remove) - Remove file
- တွေ့ (os.path.exists) - Path exists
- ဖျော်ဖြေ (json) - JSON module
- ရောက် (json.loads) - Parse JSON
- ပေး (json.dumps) - To JSON string
- အချိန် (time) - Time module
- ခန့်မှန်း (time.sleep) - Sleep
- ရှိ (os.path.isfile) - Is file
- ခု (time.time) - Current time

### Test Framework (v7)
- စမ်းသပ် = unittest module
- စမ်းပါ = test function marker
- တူမြောက် = assertEqual
- အမျိုးတူ = assertIsInstance
- ဖြစ် (assertTrue) - Assert true
- မဖြစ် (assertFalse) - Assert false
- ရှိ (assertIn) - Assert in
- မရှိ (assertNotIn) - Assert not in
- မှတ် = setUp
- ပြင် = tearDown

### Generator Keywords (v6)
- အောက်ပါ (yield) - Yield value
- အောက်ပါမှ (yield from) - Yield from iterable

### Context Manager (v6)
- ပိုင်ဆိုင် (with) - Context manager entry
- နှင့်တိုက် (as) - Context alias

### List Comprehension
- [လုပ်ဆောင် အတွက် x မှန် y တွင် မှတ်သား] - list comprehension syntax

### F-String Support
- f"ပြုရန်(variable)" or f"ပြုရန်({expression})" - formatted strings

### String Methods (Myanmar aliases)
- ပြောင်းလဲ() = .replace()
- ခွဲခြမ်း() = .split()
- ချိုး() = .sorted()
- ပါဝင်() = .join()
- မှန်ကန်() = .strip()
- အတိအကျ() = .format()
- တွက်ချက်() = .count()
- ရှိ() = .find()
- အရေးကြီး() = .upper()
- အသင့်ကြီး() = .lower()
- အခြေခံ() = .startswith()
- အံ့အကြည့်() = .endswith()

### Dictionary Methods (Myanmar aliases)
- ချိုး() = .keys()
- တွက်ချက်() = .values()
- မှတ်သား() = .items()
- ရှိ() = .get()
- ပေး() = .update()
- ဖယ်ရှား() = .pop()
- ရှင်းပြ() = .clear()

### Web/Network (v7)
- မော်သီလ = HTTP request
- ဖော်ပြ = Display/Response

### Async/Await (v7)
- ခံလျှင် (async) - Define async function
- စောင့်ကြည့် (await) - Await coroutine
- ဖွင့် = aiohttp.ClientSession
- ပေး = session.get()
- စာ = await response.text()
- ပေါင်း = await response.json()

## Instructions:
1. Help users write correct MMC code using Myanmar keywords
2. Explain errors in both Myanmar and English
3. Suggest improvements and best practices
4. Provide complete working examples
5. When showing code, always use MMC Myanmar keywords
6. Translate Python concepts to MMC equivalents
7. Be encouraging and educational
8. Format code blocks with ```mmc for MMC code and ```python for Python output
9. Remember: MMC compiles to Python, so all Python features work in MMC
10. Version 9.0 (Professional Edition) supports: generators, decorators, type hints, async/await, testing, f-strings, list comprehensions, context managers, and all standard library modules.
"""

# ---------------------------------------------------------------------------
# HTML Page - Complete Web IDE
# ---------------------------------------------------------------------------
HTML_PAGE = r"""<!DOCTYPE html>
<html lang="my">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>MMC AI v9.0 - Myanmar Code IDE</title>
<style>
/* ===== CSS Variables ===== */
:root {
  --bg-primary: #0d1117;
  --bg-secondary: #161b22;
  --bg-tertiary: #1c2128;
  --bg-editor: #0d1117;
  --bg-output: #0d1117;
  --bg-toolbar: #161b22;
  --bg-tab: #1c2128;
  --bg-tab-active: #0d1117;
  --bg-hover: #1f2937;
  --bg-input: #21262d;
  --bg-dropdown: #1c2128;
  --bg-modal: #161b22;
  --bg-resize: #30363d;
  --border-primary: #30363d;
  --border-secondary: #21262d;
  --border-focus: #58a6ff;
  --text-primary: #e6edf3;
  --text-secondary: #8b949e;
  --text-muted: #6e7681;
  --text-link: #58a6ff;
  --accent-blue: #58a6ff;
  --accent-green: #3fb950;
  --accent-red: #f85149;
  --accent-yellow: #d29922;
  --accent-purple: #bc8cff;
  --accent-orange: #db6d28;
  --accent-cyan: #39d2c0;
  --shadow-sm: 0 1px 2px rgba(0,0,0,0.3);
  --shadow-md: 0 4px 12px rgba(0,0,0,0.4);
  --shadow-lg: 0 8px 24px rgba(0,0,0,0.5);
  --radius-sm: 4px;
  --radius-md: 6px;
  --radius-lg: 8px;
  --font-mono: 'Cascadia Code', 'Fira Code', 'JetBrains Mono', 'Consolas', 'Monaco', monospace;
  --font-ui: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Noto Sans Myanmar', sans-serif;
  --transition: 150ms ease;
}

/* ===== Reset & Base ===== */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
html, body {
  height: 100%; overflow: hidden;
  font-family: var(--font-ui);
  background: var(--bg-primary);
  color: var(--text-primary);
  font-size: 14px;
  line-height: 1.5;
}

/* ===== Scrollbar ===== */
::-webkit-scrollbar { width: 8px; height: 8px; }
::-webkit-scrollbar-track { background: transparent; }
::-webkit-scrollbar-thumb {
  background: var(--border-primary);
  border-radius: 4px;
}
::-webkit-scrollbar-thumb:hover { background: var(--text-muted); }

/* ===== App Layout ===== */
#app {
  display: flex;
  flex-direction: column;
  height: 100vh;
  width: 100vw;
}

/* ===== Header ===== */
#header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 12px;
  height: 44px;
  min-height: 44px;
  background: var(--bg-secondary);
  border-bottom: 1px solid var(--border-primary);
  user-select: none;
  z-index: 100;
}
.header-left { display: flex; align-items: center; gap: 10px; }
.header-right { display: flex; align-items: center; gap: 8px; }
.logo {
  font-weight: 700;
  font-size: 15px;
  color: var(--accent-cyan);
  display: flex;
  align-items: center;
  gap: 6px;
  white-space: nowrap;
}
.logo-icon { font-size: 18px; }
.version-badge {
  font-size: 10px;
  padding: 1px 6px;
  border-radius: 10px;
  background: var(--accent-cyan);
  color: var(--bg-primary);
  font-weight: 700;
}

/* ===== Toolbar ===== */
#toolbar {
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 6px 12px;
  background: var(--bg-secondary);
  border-bottom: 1px solid var(--border-primary);
  flex-wrap: wrap;
  user-select: none;
  z-index: 90;
}
.toolbar-btn {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 5px 10px;
  border: 1px solid var(--border-primary);
  border-radius: var(--radius-sm);
  background: var(--bg-tertiary);
  color: var(--text-primary);
  font-size: 12px;
  font-family: var(--font-ui);
  cursor: pointer;
  transition: all var(--transition);
  white-space: nowrap;
}
.toolbar-btn:hover { background: var(--bg-hover); border-color: var(--border-focus); }
.toolbar-btn.primary {
  background: linear-gradient(135deg, #238636, #2ea043);
  border-color: #2ea043;
  color: #fff;
}
.toolbar-btn.primary:hover { background: linear-gradient(135deg, #2ea043, #3fb950); }
.toolbar-btn.danger { border-color: var(--accent-red); color: var(--accent-red); }
.toolbar-btn.danger:hover { background: rgba(248,81,73,0.15); }
.toolbar-btn.ai-btn {
  background: linear-gradient(135deg, #8b5cf6, #7c3aed);
  border-color: #7c3aed;
  color: #fff;
}
.toolbar-btn.ai-btn:hover { background: linear-gradient(135deg, #a78bfa, #8b5cf6); }
.toolbar-sep { width: 1px; height: 22px; background: var(--border-primary); margin: 0 4px; }
.toolbar-select {
  padding: 4px 8px;
  border: 1px solid var(--border-primary);
  border-radius: var(--radius-sm);
  background: var(--bg-tertiary);
  color: var(--text-primary);
  font-size: 12px;
  font-family: var(--font-ui);
  cursor: pointer;
  outline: none;
}
.toolbar-select:focus { border-color: var(--border-focus); }
.font-selector { width: 48px; text-align: center; }
#file-input { display: none; }

/* ===== Main Panels ===== */
#main {
  flex: 1;
  display: flex;
  overflow: hidden;
  position: relative;
}

/* ===== Editor Panel ===== */
#editor-panel {
  flex: 1;
  display: flex;
  flex-direction: column;
  min-width: 200px;
  position: relative;
}
.panel-header {
  display: flex;
  align-items: center;
  padding: 0 12px;
  height: 34px;
  min-height: 34px;
  background: var(--bg-tertiary);
  border-bottom: 1px solid var(--border-primary);
  font-size: 12px;
  color: var(--text-secondary);
  user-select: none;
}
.panel-header-dot {
  display: inline-block;
  width: 8px; height: 8px;
  border-radius: 50%;
  margin-right: 6px;
}
.dot-green { background: var(--accent-green); }
.dot-blue { background: var(--accent-blue); }
.dot-purple { background: var(--accent-purple); }
#editor {
  flex: 1;
  width: 100%;
  padding: 12px;
  background: var(--bg-editor);
  color: var(--text-primary);
  border: none;
  outline: none;
  resize: none;
  font-family: var(--font-mono);
  font-size: 14px;
  line-height: 1.6;
  tab-size: 4;
  -moz-tab-size: 4;
  white-space: pre;
  overflow: auto;
}

/* ===== Resize Handle ===== */
#resize-handle {
  width: 5px;
  cursor: col-resize;
  background: var(--bg-resize);
  flex-shrink: 0;
  position: relative;
  z-index: 50;
  transition: background var(--transition);
}
#resize-handle:hover, #resize-handle.active {
  background: var(--accent-blue);
}
#resize-handle::after {
  content: '';
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 2px;
  height: 30px;
  background: var(--text-muted);
  border-radius: 1px;
}

/* ===== Output Panel ===== */
#output-panel {
  flex: 1;
  display: flex;
  flex-direction: column;
  min-width: 200px;
  position: relative;
}

/* ===== Tabs ===== */
#output-tabs {
  display: flex;
  align-items: center;
  height: 34px;
  min-height: 34px;
  background: var(--bg-tertiary);
  border-bottom: 1px solid var(--border-primary);
  overflow-x: auto;
  user-select: none;
}
.tab {
  display: flex;
  align-items: center;
  gap: 5px;
  padding: 0 14px;
  height: 100%;
  font-size: 12px;
  color: var(--text-secondary);
  border-right: 1px solid var(--border-secondary);
  cursor: pointer;
  transition: all var(--transition);
  white-space: nowrap;
  position: relative;
}
.tab:hover { color: var(--text-primary); background: var(--bg-hover); }
.tab.active {
  color: var(--text-primary);
  background: var(--bg-tab-active);
}
.tab.active::after {
  content: '';
  position: absolute;
  bottom: 0; left: 0; right: 0;
  height: 2px;
  background: var(--accent-blue);
}
.tab-icon { font-size: 13px; }
.tab-badge {
  font-size: 9px;
  padding: 0 5px;
  border-radius: 8px;
  background: var(--accent-blue);
  color: #fff;
  font-weight: 600;
}

/* ===== Output Content ===== */
#output-content {
  flex: 1;
  position: relative;
  overflow: hidden;
}
.output-view {
  position: absolute;
  top: 0; left: 0; right: 0; bottom: 0;
  overflow: auto;
  padding: 12px;
  font-family: var(--font-mono);
  font-size: 13px;
  line-height: 1.6;
  white-space: pre-wrap;
  word-break: break-word;
  display: none;
}
.output-view.active { display: block; }
.output-line { margin: 0; }
.output-error { color: var(--accent-red); }
.output-success { color: var(--accent-green); }
.output-info { color: var(--accent-blue); }
.output-warn { color: var(--accent-yellow); }
.output-dim { color: var(--text-muted); }

/* ===== AI Chat ===== */
#ai-chat {
  display: none;
  position: absolute;
  top: 0; left: 0; right: 0; bottom: 52px;
  flex-direction: column;
  background: var(--bg-output);
}
#ai-chat.active { display: flex; }
#ai-messages {
  flex: 1;
  overflow-y: auto;
  padding: 12px;
  display: flex;
  flex-direction: column;
  gap: 12px;
}
.ai-msg {
  max-width: 90%;
  padding: 10px 14px;
  border-radius: var(--radius-lg);
  font-size: 13px;
  line-height: 1.6;
  white-space: pre-wrap;
  word-break: break-word;
  font-family: var(--font-ui);
}
.ai-msg.user {
  align-self: flex-end;
  background: var(--accent-blue);
  color: #fff;
  border-bottom-right-radius: 2px;
}
.ai-msg.assistant {
  align-self: flex-start;
  background: var(--bg-tertiary);
  color: var(--text-primary);
  border-bottom-left-radius: 2px;
  border: 1px solid var(--border-primary);
}
.ai-msg code {
  background: rgba(0,0,0,0.3);
  padding: 1px 5px;
  border-radius: 3px;
  font-family: var(--font-mono);
  font-size: 12px;
}
.ai-msg pre {
  background: rgba(0,0,0,0.4);
  padding: 8px 12px;
  border-radius: var(--radius-sm);
  overflow-x: auto;
  margin: 6px 0;
}
.ai-msg pre code {
  background: none;
  padding: 0;
}
.ai-typing {
  align-self: flex-start;
  padding: 10px 14px;
  color: var(--text-muted);
  font-size: 13px;
  font-style: italic;
}
#ai-input-bar {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 8px 12px;
  background: var(--bg-secondary);
  border-top: 1px solid var(--border-primary);
  position: absolute;
  bottom: 0; left: 0; right: 0;
  height: 52px;
}
#ai-input {
  flex: 1;
  padding: 8px 12px;
  border: 1px solid var(--border-primary);
  border-radius: var(--radius-md);
  background: var(--bg-input);
  color: var(--text-primary);
  font-size: 13px;
  font-family: var(--font-ui);
  outline: none;
  transition: border-color var(--transition);
}
#ai-input:focus { border-color: var(--border-focus); }
#ai-send {
  padding: 8px 14px;
  border: 1px solid var(--border-primary);
  border-radius: var(--radius-md);
  background: linear-gradient(135deg, #8b5cf6, #7c3aed);
  color: #fff;
  font-size: 13px;
  cursor: pointer;
  white-space: nowrap;
  transition: opacity var(--transition);
}
#ai-send:hover { opacity: 0.9; }
#ai-send:disabled { opacity: 0.5; cursor: not-allowed; }

/* ===== Footer ===== */
#footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 12px;
  height: 26px;
  min-height: 26px;
  background: var(--bg-secondary);
  border-top: 1px solid var(--border-primary);
  font-size: 11px;
  color: var(--text-muted);
  user-select: none;
  z-index: 100;
}
.footer-left, .footer-right { display: flex; align-items: center; gap: 12px; }
.status-dot {
  display: inline-block;
  width: 7px; height: 7px;
  border-radius: 50%;
  margin-right: 4px;
  vertical-align: middle;
}
.status-online { background: var(--accent-green); box-shadow: 0 0 4px var(--accent-green); }
.status-offline { background: var(--accent-red); }
.status-loading { background: var(--accent-yellow); animation: pulse 1s infinite; }
@keyframes pulse { 0%,100%{ opacity: 1; } 50%{ opacity: 0.4; } }

/* ===== Welcome Screen ===== */
.welcome {
  text-align: center;
  padding: 40px 20px;
  color: var(--text-secondary);
}
.welcome h2 { color: var(--accent-cyan); font-size: 20px; margin-bottom: 8px; }
.welcome p { margin-bottom: 6px; font-size: 13px; }
.welcome kbd {
  background: var(--bg-tertiary);
  border: 1px solid var(--border-primary);
  padding: 1px 6px;
  border-radius: 3px;
  font-family: var(--font-mono);
  font-size: 11px;
  color: var(--text-primary);
}

/* ===== Toast ===== */
.toast {
  position: fixed;
  top: 56px;
  right: 16px;
  padding: 10px 18px;
  border-radius: var(--radius-md);
  color: #fff;
  font-size: 13px;
  z-index: 9999;
  animation: slideIn 0.3s ease, fadeOut 0.3s ease 2.7s;
  pointer-events: none;
  box-shadow: var(--shadow-lg);
}
.toast.success { background: var(--accent-green); }
.toast.error { background: var(--accent-red); }
.toast.info { background: var(--accent-blue); }
@keyframes slideIn { from { transform: translateX(100px); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
@keyframes fadeOut { from { opacity: 1; } to { opacity: 0; } }

/* ===== Dropdown ===== */
.dropdown { position: relative; }
.dropdown-menu {
  display: none;
  position: absolute;
  top: 100%;
  left: 0;
  margin-top: 4px;
  min-width: 220px;
  background: var(--bg-dropdown);
  border: 1px solid var(--border-primary);
  border-radius: var(--radius-md);
  box-shadow: var(--shadow-lg);
  z-index: 200;
  max-height: 400px;
  overflow-y: auto;
}
.dropdown-menu.show { display: block; }
.dropdown-item {
  display: block;
  width: 100%;
  padding: 8px 14px;
  border: none;
  background: none;
  color: var(--text-primary);
  font-size: 12px;
  font-family: var(--font-ui);
  text-align: left;
  cursor: pointer;
  white-space: nowrap;
}
.dropdown-item:hover { background: var(--bg-hover); }
.dropdown-item .desc {
  display: block;
  color: var(--text-muted);
  font-size: 11px;
  margin-top: 1px;
}

/* ===== Modal ===== */
.modal-overlay {
  display: none;
  position: fixed;
  top: 0; left: 0; right: 0; bottom: 0;
  background: rgba(0,0,0,0.6);
  z-index: 500;
  align-items: center;
  justify-content: center;
}
.modal-overlay.show { display: flex; }
.modal {
  background: var(--bg-modal);
  border: 1px solid var(--border-primary);
  border-radius: var(--radius-lg);
  box-shadow: var(--shadow-lg);
  width: 90%;
  max-width: 520px;
  max-height: 80vh;
  overflow-y: auto;
  padding: 20px;
}
.modal h3 { margin-bottom: 12px; font-size: 16px; color: var(--accent-cyan); }
.modal p, .modal li { font-size: 13px; line-height: 1.6; color: var(--text-secondary); }
.modal pre {
  background: var(--bg-primary);
  padding: 12px;
  border-radius: var(--radius-sm);
  overflow-x: auto;
  margin: 8px 0;
  font-size: 12px;
  color: var(--text-primary);
}
.modal-close {
  float: right;
  background: none;
  border: none;
  color: var(--text-muted);
  font-size: 18px;
  cursor: pointer;
  padding: 0 4px;
}
.modal-close:hover { color: var(--text-primary); }

/* ===== Responsive ===== */
@media (max-width: 768px) {
  #main { flex-direction: column; }
  #editor-panel, #output-panel { min-width: 100%; min-height: 200px; }
  #resize-handle {
    width: 100%;
    height: 5px;
    cursor: row-resize;
  }
  #resize-handle::after { width: 30px; height: 2px; }
  .toolbar-btn span.btn-text { display: none; }
  .toolbar-btn { padding: 5px 8px; }
  #header { padding: 0 8px; }
  .logo { font-size: 13px; }
}

/* ===== Markdown-like styling in AI messages ===== */
.ai-msg h1, .ai-msg h2, .ai-msg h3 { margin: 8px 0 4px; font-weight: 600; }
.ai-msg ul, .ai-msg ol { padding-left: 20px; margin: 4px 0; }
.ai-msg strong { color: var(--accent-cyan); }
.ai-msg em { color: var(--accent-purple); }
</style>
</head>
<body>
<div id="app">
  <!-- Header -->
  <div id="header">
    <div class="header-left">
      <div class="logo">
        <span class="logo-icon">&#x1f4bb;</span>
        MMC AI <span class="version-badge">v9.0</span>
      </div>
    </div>
    <div class="header-right">
      <span id="ollama-status" style="display:flex;align-items:center;gap:4px;font-size:12px;">
        <span class="status-dot status-loading" id="ollama-dot"></span>
        <span id="ollama-text">Checking...</span>
      </span>
    </div>
  </div>

  <!-- Toolbar -->
  <div id="toolbar">
    <button class="toolbar-btn primary" onclick="runCode()" title="Run code (Ctrl+Enter)">
      <span>&#9654;</span> <span class="btn-text">Run</span>
    </button>
    <button class="toolbar-btn" onclick="showPython()" title="Show Python output">
      <span>&#128196;</span> <span class="btn-text">Python</span>
    </button>
    <button class="toolbar-btn danger" onclick="clearOutput()" title="Clear output">
      <span>&#128465;</span> <span class="btn-text">Clear</span>
    </button>
    <div class="toolbar-sep"></div>
    <div class="dropdown">
      <button class="toolbar-btn" onclick="toggleDropdown()" title="Example programs">
        <span>&#128218;</span> <span class="btn-text">Examples</span> <span>&#9662;</span>
      </button>
      <div class="dropdown-menu" id="examples-dropdown"></div>
    </div>
    <div class="toolbar-sep"></div>
    <button class="toolbar-btn" onclick="openFile()" title="Open file">
      <span>&#128194;</span> <span class="btn-text">Open</span>
    </button>
    <button class="toolbar-btn" onclick="saveFile()" title="Save file">
      <span>&#128190;</span> <span class="btn-text">Save</span>
    </button>
    <input type="file" id="file-input" accept=".mmc,.txt,.py" onchange="handleFile(event)">
    <div class="toolbar-sep"></div>
    <select class="toolbar-select font-selector" id="font-size" onchange="changeFontSize(this.value)" title="Font size">
      <option value="11">11</option>
      <option value="12">12</option>
      <option value="13">13</option>
      <option value="14" selected>14</option>
      <option value="16">16</option>
      <option value="18">18</option>
      <option value="20">20</option>
      <option value="22">22</option>
      <option value="24">24</option>
    </select>
    <div class="toolbar-sep"></div>
    <button class="toolbar-btn ai-btn" onclick="switchTab('ai')" title="AI Assistant">
      <span>&#129302;</span> <span class="btn-text">AI Chat</span>
    </button>
    <button class="toolbar-btn" onclick="showHelp()" title="Help & Shortcuts">
      <span>&#10068;</span>
    </button>
  </div>

  <!-- Main Panels -->
  <div id="main">
    <!-- Editor Panel -->
    <div id="editor-panel">
      <div class="panel-header">
        <span class="panel-header-dot dot-green"></span>
        Editor <span id="filename-display" style="margin-left:auto;color:var(--text-muted);">untitled.mmc</span>
      </div>
      <textarea id="editor" spellcheck="false" placeholder="// MMC Code ရေးသားပါ - Myanmar Code Programming Language&#10;// MMC AI v9.0"></textarea>
    </div>

    <!-- Resize Handle -->
    <div id="resize-handle" title="Drag to resize panels"></div>

    <!-- Output Panel -->
    <div id="output-panel">
      <div id="output-tabs">
        <div class="tab active" data-tab="run" onclick="switchTab('run')">
          <span class="tab-icon">&#9654;</span> Run
        </div>
        <div class="tab" data-tab="python" onclick="switchTab('python')">
          <span class="tab-icon">&#128013;</span> Python
        </div>
        <div class="tab" data-tab="ai" onclick="switchTab('ai')">
          <span class="tab-icon">&#129302;</span> AI
          <span class="tab-badge" id="ai-badge" style="display:none;">0</span>
        </div>
      </div>
      <div id="output-content">
        <!-- Run Output -->
        <div class="output-view active" id="run-output">
          <div class="welcome">
            <h2>&#x1f4bb; MMC AI v9.0</h2>
            <p>Myanmar Code Programming Language IDE</p>
            <p style="margin-top:16px;">&#127919; Quick Start:</p>
            <p>Select an example from <kbd>Examples</kbd> dropdown or write your own MMC code</p>
            <p style="margin-top:8px;">&#9000; Shortcuts:</p>
            <p><kbd>Ctrl</kbd>+<kbd>Enter</kbd> Run &nbsp; <kbd>Ctrl</kbd>+<kbd>S</kbd> Save &nbsp; <kbd>Tab</kbd> Indent</p>
          </div>
        </div>
        <!-- Python Output -->
        <div class="output-view" id="python-output">
          <div class="welcome">
            <h2>&#128013; Python Output</h2>
            <p>Transpiled Python code will appear here</p>
            <p>Click <kbd>Python</kbd> button or <kbd>Ctrl</kbd>+<kbd>Shift</kbd>+<kbd>P</kbd></p>
          </div>
        </div>
        <!-- AI Chat -->
        <div class="output-view" id="ai-output">
          <div id="ai-chat" class="active">
            <div id="ai-messages">
              <div class="welcome" style="padding:20px;">
                <h2>&#129302; MMC AI Assistant v9.0</h2>
                <p>Powered by Ollama (mmc-ai model)</p>
                <p style="margin-top:12px;">Ask me anything about Myanmar Code!</p>
                <p>I can help you write, debug, and understand MMC programs.</p>
              </div>
            </div>
            <div id="ai-input-bar">
              <input id="ai-input" type="text" placeholder="Ask about MMC code..." onkeydown="if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();sendAI();}">
              <button id="ai-send" onclick="sendAI()">&#10148;</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Footer -->
  <div id="footer">
    <div class="footer-left">
      <span>MMC AI v9.0</span>
      <span>|</span>
      <span id="line-col-info">Ln 1, Col 1</span>
    </div>
    <div class="footer-right">
      <span id="exec-time"></span>
      <span>|</span>
      <span>Python <span id="py-version"></span></span>
    </div>
  </div>
</div>

<!-- Help Modal -->
<div class="modal-overlay" id="help-modal">
  <div class="modal">
    <button class="modal-close" onclick="closeHelp()">&times;</button>
    <h3>&#9881; MMC AI v9.0 - Keyboard Shortcuts & Help</h3>
    <p><strong>Keyboard Shortcuts:</strong></p>
    <ul style="padding-left:20px;margin:8px 0;">
      <li><kbd>Ctrl</kbd>+<kbd>Enter</kbd> &mdash; Run MMC Code</li>
      <li><kbd>Ctrl</kbd>+<kbd>S</kbd> &mdash; Save File</li>
      <li><kbd>Ctrl</kbd>+<kbd>Shift</kbd>+<kbd>P</kbd> &mdash; Show Python Output</li>
      <li><kbd>Ctrl</kbd>+<kbd>Shift</kbd>+<kbd>C</kbd> &mdash; Clear Output</li>
      <li><kbd>Tab</kbd> &mdash; Insert Indent</li>
      <li><kbd>Shift</kbd>+<kbd>Tab</kbd> &mdash; Decrease Indent</li>
      <li><kbd>Ctrl</kbd>+<kbd>/</kbd> &mdash; Toggle Comment</li>
    </ul>
    <p style="margin-top:12px;"><strong>MMC Language Features:</strong></p>
    <ul style="padding-left:20px;margin:8px 0;">
      <li>Myanmar keywords for all Python concepts</li>
      <li>Functions, Classes, OOP, Decorators</li>
      <li>Generators, Async/Await, Type Hints</li>
      <li>List comprehensions, F-strings</li>
      <li>Standard library support</li>
      <li>Unit testing framework</li>
      <li>AI-powered code assistance</li>
    </ul>
    <p style="margin-top:12px;"><strong>API Endpoints:</strong></p>
    <pre>/api/run      - Execute MMC code
/api/python   - Transpile MMC to Python
/api/ai       - AI chat (Ollama)
/api/ollama-status - Check Ollama</pre>
  </div>
</div>

<script>
/* ===== Example Programs (MMC Myanmar Language) ===== */
const EXAMPLES = {
  hello: {
    name: "Hello World",
    desc: "Basic hello world program",
    code: `# MMC Hello World Program
# မြန်မာဘာသာ ဖြန့်ပြချက်

ပြုရန်("Hello, World!")
ပြုရန်("မင်္ဂလာပါ၊ Myanmar Code!")
ပြုရန်("MMC AI v9.0 မှာကျင့်သစ်ကို ကြိုဆိုပါတယ်")

# Variable declaration
အမျိုး = "Myanmar Code Programming Language"
ဗားရှင်း = 8.0

ပြုရန်(f"({အမျိုး}) - Version ({ဗားရှင်း})")`
  },

  calculator: {
    name: "Calculator",
    desc: "Function definitions & math",
    code: `# MMC Calculator Program
# ဖြတ်သန်းစွာ ကိရိယာ

လုပ်ဆောင် တွက်ချက်(အရေ, အမြင့်):
    ပေးပို့ အရေ + အမြင့်

လုပ်ဆောင် ဖယ်ရှား(အရေ, အမြင့်):
    ပေးပို့ အရေ - အမြင့်

လုပ်ဆောင် ပိုင်းခြင်း(အရေ, အမြင့်):
    ပေးပို့ အရေ * အမြင့်

လုပ်ဆောင် ကြက်(အရေ, အမြင့်):
    အတွက် အမြင့် တူသလား 0:
        ပြုရန်("0 ဖြင့် မပြောင်းလုပ်နိုင်ပါ")
        ပေးပို့ ဘာမ်
    ပေးပို့ အရေ / အမြင့်

# Test the calculator
a = 15
b = 3

ပြုရန်(f"({a}) + ({b}) = ({တွက်ချက်(a, b)})")
ပြုရန်(f"({a}) - ({b}) = ({ဖယ်ရှား(a, b)})")
ပြုရန်(f"({a}) * ({b}) = ({ပိုင်းခြင်း(a, b)})")
ပြုရန်(f"({a}) / ({b}) = ({ကြက်(a, b)})")
ပြုရန်(f"({a}) // ({b}) = ({a အပေါ် b})")
ပြုရန်(f"({a}) ** ({b}) = ({a စုံ b})")`
  },

  loops: {
    name: "Loops",
    desc: "For & While loops",
    code: `# MMC Loops Program
# ပြက္ခဒိန်များ

# For loop
ပြုရန်("--- For Loop ---")
ပိုႏ i မှန် နားလည်(1, 6):
    ပြုရန်(f"Count: ({i})")

# While loop
ပြုရန်("\\n--- While Loop ---")
i = 0
ရှင်းလင်း i ညာ 10:
    ပြုရန်(f"Value: ({i})")
    ပြုပြင်(i, 2)  # i += 2

# Loop with list
ပြုရန်("\\n--- List Loop ---")
မှတ်သား = ["Pyay", "Yangon", "Mandalay", "Naypyidaw"]
ပိုႏ မြင် မှန် မှတ်သား:
    ပြုရန်(f"City: ({မြင်})")

# Loop with enumerate
ပြုရန်("\\n--- Enumerate Loop ---")
ပိုႏ (index, city) မှန် နေရာ(မှတ်သား):
    ပြုရန်(f"({index}): ({city})")

# Nested loop
ပြုရန်("\\n--- Nested Loop ---")
ပိုႏ i မှန် နားလည်(1, 4):
    ပိုႏ j မှန် နားလည်(1, 4):
        ပြုရန်(f"({i}) x ({j}) = ({i * j})", ဒေတာ=" ")
    ပြုရန်()

# Break & Continue
ပြုရန်("--- Break & Continue ---")
ပိုႏ i မှန် နားလည်(1, 11):
    အတွက် i တူသလား 5:
        ဆက်လက်
    အတွက် i တူသလား 8:
        ဖျက်ဆီး
    ပြုရန်(f"({i})", ဒေတာ=" ")
ပြုရန်()`
  },

  fibonacci: {
    name: "Fibonacci",
    desc: "Recursive function",
    code: `# MMC Fibonacci Program
# ဖင်ဘွဲ့ကား လုပ်ဆောင်ချက်

လုပ်ဆောင် ဖင်ဘွဲ့ကား(n):
    အတွက် n တူသလား 0:
        ပေးပို့ 0
    အတွက် n တူသလား 1:
        ပေးပို့ 1
    ပေးပို့ ဖင်ဘွဲ့ကား(n-1) + ဖင်ဘွဲ့ကား(n-2)

# Print first 15 Fibonacci numbers
ပြုရန်("=== Fibonacci Sequence ===")
ပိုႏ i မှန် နားလည်(15):
    ပြုရန်(f"F({i}) = ({ဖင်ဘွဲ့ကား(i)})")

# Iterative Fibonacci (more efficient)
လုပ်ဆောင် ဖင်ဘွဲ့ကား_အများ(n):
    အတွက် n တူသလား 0:
        ပေးပို့ 0
    အတွက် n တူသလား 1:
        ပေးပို့ 1
    a, b = 0, 1
    ပိုႏ _ မှန် နားလည်(2, n + 1):
        a, b = b, a + b
    ပေးပို့ b

ပြုရန်("\\n=== Iterative Fibonacci (Fast) ===")
ပိုႏ i မှန် နားလည်(15):
    ပြုရန်(f"F({i}) = ({ဖင်ဘွဲ့ကား_အများ(i)})")

# Generator Fibonacci
လုပ်ဆောင် ဖင်ဘွဲ့ကား_စိတ်(limit):
    a, b = 0, 1
    ရှင်းလင်း a ညာ limit:
        အောက်ပါ a
        a, b = b, a + b

ပြုရန်("\\n=== Generator Fibonacci ===")
မှတ်သား = မှတ်သား(ဖင်ဘွဲ့ကား_စိတ်(1000))
ပြုရန်(f"Generator result: ({မှတ်သား})")`
  },

  class_example: {
    name: "Classes & OOP",
    desc: "OOP with inheritance",
    code: `# MMC OOP Example
# အရာရောက်ရည်ရွယ်ချက်

သင်္ကေတ တစ်စုံ(self, အမည်, အသက်):
    self.အမည် = အမည်
    self.အသက် = အသက်
    self.အလုပ် = "မရှိသေး"

  လုပ်ဆောင် __str__(self):
    ပေးပို့ f"({self.အမည်}) (အသက် {self.အသက်})"

  လုပ်ဆောင် အလုပ်လုပ်(self, အလုပ်):
    self.အလုပ် = အလုပ်
    ပြုရန်(f"({self.အမည်}) သည် ({self.အလုပ်}) အလုပ်လုပ်နေပါသည်")

  လုပ်ဆောင် အသက်တိုး(self, နှင့်):
    self.အသက် = self.အသက် + နှင့်
    ပြုရန်(f"({self.အမည်}) သည် (အသက်) ({self.အသက်}) ဖြစ်ပါသည်")

# Inheritance
သင်္ကေတ ကျောင်းသား(တစ်စုံ):
  လုပ်ဆောင် __init__(self, အမည်, အသက်, ကျောင်း):
    သုံးစွဲ().__init__(အမည်, အသက်)
    self.ကျောင်း = ကျောင်း
    self.အလုပ် = "ကျောင်းသား"

  လုပ်ဆောင် လေ့လာ(self, ဘာသာရပ်):
    ပြုရန်(f"({self.အမည်}) သည် ({self.ကျောင်း}) ကျောင်းတွင် ({ဘာသာရပ်}) လေ့လာနေပါသည်")

# Create objects
ပြုရန်("=== Objects ===")
ပရောဂ = တစ်စုံ("Aung Aung", 25)
မနက် = တစ်စုံ("Su Su", 23)

ပြုရန်(ပရောဂ)
ပြုရန်(မနက်)

ပရောဂ.အလုပ်လုပ်("Engineer")
မနက်.အလုပ်လုပ်("Doctor")

ပြုရန်("\\n=== Inheritance ===")
မင်း = ကျောင်းသား("Thura", 20, "Yangon University")
ပြုရန်(မင်း)
မင်း.လေ့လုပ်("Computer Science")
မင်း.အသက်တိုး(1)

# Class with property decorator
သင်္ကေတ စိမ်(self):
  လုပ်ဆောင် __init__(self, ငါး, ပမာဏ):
    self.ငါး = ငါး
    self.ပမာဏ = ပမာဏ

  @ပုံသဏ္ဌာန်
  လုပ်ဆောင် တိကျ(self):
    ပေးပို့ ခန့်မှန်း(self.ငါး * self.ပမာဏ, 2)

ပြုရန်("\\n=== Property ===")
ပမာဏ = စိမ်(1500, 45.5)
ပြုရန်(f"Total: ({ပမာဏ.တိကျ}) Ks")`
  },

  error_handling: {
    name: "Error Handling",
    desc: "Try/except/finally",
    code: `# MMC Error Handling
# အမှားကြောင်း စိတ်ဖြာချက်

လုပ်ဆောင် ပြောင်းလဲ(a, b):
    အတွက် b တူသလား 0:
        ခေါ်ဆို အမှားကြောင်း("0 ဖြင့် မပြောင်းလုပ်နိုင်ပါ")
    ပေးပို့ a / b

# Basic try/except
ပြုရန်("=== Basic Error Handling ===")
သုံးစွဲ:
    ပြုရန်(ပြောင်းလဲ(10, 2))
    ပြုရန်(ပြောင်းလဲ(10, 0))
အများကြီး အမှားကြောင်း နှင့် e:
    ပြုရန်(f"Error: ({e})")

# Multiple except blocks
ပြုရန်("\\n=== Multiple Exceptions ===")
လုပ်ဆောင် စားချက်(အရေ):
    အတွက် အရေ ပဲ တူသလား 0:
        ပြုရန်("Zero detected!")
    အနည်းငယ်:
        ပေးပို့ 1 / အရေ

အမှန် = ["10", "20", "abc", "40"]
ပိုႏ item မှန် အမှန်:
    သုံးစွဲ:
        ပြုရန်(f"Result: ({စားချက်(သတ်မှတ်(item))})")
    အများကြီး အမှားကြောင်း:
        ပြုရန်(f"Cannot convert ({item})")
    အများကြီး အမျိုး:
        ပြုရန်(f"Type error with ({item})")

# Try/except/finally
ပြုရန်("\\n=== Finally Block ===")
သုံးစွဲ:
    ပြုရန်("Opening file...")
    ဖော်ပြ(အမှားကြောင်း("File not found"))
အများကြီး အမှားကြောင်း နှင့် e:
    ပြုရန်(f"Error: ({e})")
ကြိုတင်:
    ပြုရန်("This always runs!")

# Custom exception
သင်္ကေတ မမှန်(အမှားကြောင်း):
  လုပ်ဆောင် __init__(self, ပြုရန်):
    သုံးစွဲ().__init__(ပြုရန်)
    self.ပြုရန် = ပြုရန်

လုပ်ဆောင် စစ်ဆေး(အရေ):
    အတွက် အရေ ညာ 18:
        ခေါ်ဆို မမှန်("Must be 18 or older")
    ပေးပို့ f"Access granted for age ({အရေ)"

သုံးစွဲ:
    စစ်ဆေး(15)
အများကြီး မမှန် နှင့် e:
    ပြုရန်(f"Access denied: ({e.ပြုရန်})")`
  },

  string_methods: {
    name: "String Methods",
    desc: "String operations",
    code: `# MMC String Methods
# စာသား လုပ်ဆောင်ချက်များ

ပြုရန် = "Hello, Myanmar Code!"

# Basic operations
ပြုရန်("=== Basic String Operations ===")
ပြုရန်(f"Original: (ပြုရန်)")
ပြုရန်(f"Length: ({ရရှိ(ပြုရန်)})")
ပြုရန်(f"Upper: ({ပြုရန်.အရေးကြီး()})")
ပြုရန်(f"Lower: ({ပြုရန်.အသင့်ကြီး()})")
ပြုရန်(f"Title: ({ပြုရန်.title()})")

# String search
ပြုရန်("\\n=== String Search ===")
ပြုရန်(f"'Myanmar' ရှိမှား: (Myanmar ပါဝင် ပြုရန်)")
ပြုရန်(f"Index of 'Code': ({ပြုရန်.ရှိ('Code')})")
ပြုရန်(f"Count of 'l': ({ပြုရန်.တွက်ချက်('l')})")
ပြုရန်(f"Starts with 'Hello': ({ပြုရန်.အခြေခံ('Hello')})")
ပြုရန်(f"Ends with '!': ({ပြုရန်.အံ့အကြည့်('!')})")

# String manipulation
ပြုရန်("\\n=== String Manipulation ===")
ဖြစ်ပါ = "   Hello World   "
ပြုရန်(f"Strip: ('{ဖြစ်ပါ.မှန်ကန်()}')")
ပြုရန်(f"Replace: ({ပြုရန်.ပြောင်းလဲ('Myanmar', 'Python')})")
ပြုရန်(f"Split: ({Pyay,Yangon,Mandalay.ခွဲခြမ်း(',')})")

# String formatting
ပြုရန်("\\n=== String Formatting ===")
အမည် = "Myanmar Code"
ဗားရှင်း = 8.0
ပြုရန်(f"F-String: ({အမည်}) v({ဗားရှင်း})")
ပြုရန်(".format(): {} v{}".format(အမည်, ဗားရှင်း))
ပြုရန်("%s v%.1f" % (အမည်, ဗားရှင်း))

# String methods
ပြုရန်("\\n=== String Methods ===")
ပြုရန်(f"Is alpha 'Hello': ({'Hello'.isalpha()})")
ပြုရန်(f"Is digit '123': ({'123'.isalpha()})")
ပြုရန်(f"Is alnum 'Hello123': ({'Hello123'.isalnum()})")

# Multiline string
ပြုရန်("\\n=== Multiline String ===")
lines = \"\"\"Line 1: Myanmar
Line 2: Code
Line 3: Programming\"\"\"
ပိုႏ line မှန် lines.ခွဲခြမ်း("\\n"):
    ပြုရန်(line)

# String join
ပြုရန်("\\n=== String Join ===")
မှတ်သား = ["Myanmar", "Code", "Language"]
ပြုရန်("  ".ချိုး(မှတ်သား))
ပြုရန်("-".ချိုး(မှတ်သား))

# Center and padding
ပြုရန်("\\n=== Padding ===")
ပြုရန်(f"Center: ('{'MMC'.center(20, '=')})")
ပြုရန်(f"LJust:  ('{'MMC'.ljust(20, '-')})")
ပြုရန်(f"RJust:  ('{'MMC'.rjust(20, '-')})")`
  },

  dict_operations: {
    name: "Dictionary",
    desc: "Dictionary operations",
    code: `# MMC Dictionary Operations
# စာရင်း လုပ်ဆောင်ချက်များ

# Create dictionary
ပြုရန် = {
    "အမည်": "Myanmar Code",
    "ဗားရှင်း": 8.0,
    "ဖြစ်စဉ်": "Programming Language",
    "ဘာသာ": "Myanmar"
}

ပြုရန်("=== Dictionary Basics ===")
ပြုရန်(မှတ်သား)

# Access elements
ပြုရန်("\\n=== Access Elements ===")
ပြုရန်(f"Name: ({မှတ်သား.ရှိ('အမည်', 'N/A')})")
ပြုရန်(f"Version: ({မှတ်သား['ဗားရှင်း']})")

# Dictionary methods
ပြုရန်("\\n=== Dictionary Methods ===")
ပြုရန်(f"Keys: ({ချိုး(မှတ်သား)})")
ပြုရန်(f"Values: ({တွက်ချက်(မှတ်သား)})")
ပြုရန်(f"Items: ({မှတ်သား.items()})")

# Iterate dictionary
ပြုရန်("\\n=== Iterate Dictionary ===")
ပိုႏ ချိုး, တွက်ချက် မှန် မှတ်သား.items():
    ပြုရန်(f"  ({ချိုး}): ({တွက်ချက်})")

# Modify dictionary
ပြုရန်("\\n=== Modify Dictionary ===")
မှတ်သား["author"] = "MyanOS AI Team"
မှတ်သား["year"] = 2024
ပြုရန်(f"Added author: ({မှတ်သား.ရှိ('author')})")
ပြုရန်(f"Added year: ({မှတ်သား.ရှိ('year')})")

# Update dictionary
ပြုရန်("\\n=== Update & Delete ===")
မှတ်သား.ပေး({"license": "MIT", "os": "Cross-platform"})
ဖယ်ရှား_key = မှတ်သား.ဖယ်ရှား("ဘာသာ")
ပြုရန်(f"Removed: ({ဖယ်ရှား_key})")
ပြုရန်(f"Has 'license': ({'license' ပါဝင် မှတ်သား})")

# Dictionary comprehension
ပြုရန်("\\n=== Dictionary Comprehension ===")
squares = {x: x**2 အတွက် x မှန် နားလည်(1, 8)}
ပြုရန်(squares)

# Nested dictionary
ပြုရန်("\\n=== Nested Dictionary ===")
တကယ့် = {
    "student1": {"အမည်": "Aung", "တွက်ချက်": 90},
    "student2": {"အမည်": "Su", "တွက်ချက်": 95},
    "student3": {"အမည်": "Hla", "တွက်ချက်": 85}
}
ပိုႏ sid, info မှန် တကယ့်.items():
    ပြုရန်(f"  ({sid}): ({info['အမည်']}) - Score: ({info['တွက်ချက်']})")

# Default dict pattern
ပြုရန်("\\n=== Default Pattern ===")
counts = {}
မှတ်သား = ['a', 'b', 'a', 'c', 'b', 'a']
ပိုႏ item မှန် မှတ်သား:
    counts[item] = counts.ရှိ(item, 0) + 1
ပြုရန်(counts)

# Sort dictionary
ပြုရန်("\\n=== Sorted Dictionary ===")
sorted_dict = ချိုး(counts)
ပြုရန်(f"Sorted keys: ({sorted_dict})")`
  },

  generator_example: {
    name: "Generators",
    desc: "Generator with yield (v6)",
    code: `# MMC Generator Example (v6)
# စိတ်ဖြာကိရိယာ

# Basic generator
လုပ်ဆောင် အရေ_တိကျ(start, ထိပ်, ခန့်):
    current = start
    ရှင်းလင်း current ညာ ထိပ်:
        အောက်ပါ current
        current = current + ခန့်

ပြုရန်("=== Basic Generator ===")
g = အရေ_တိကျ(2, 20, 3)
ပြုရန်(f"Type: ({တိကျ(g)})")
ပိုႏ val မှန် g:
    ပြုရန်(val, ဒေတာ=" ")
ပြုရန်()

# Generator expression
ပြုရန်("\\n=== Generator Expression ===")
squares_gen = (x**2 အတွက် x မှန် နားလည်(1, 8))
ပြုရန်(f"Generator: ({squares_gen})")
ပြုရန်(f"List: ({မှတ်သား(squares_gen)})")

# Yield from (v6)
လုပ်ဆောင် ခွဲခြမ်း_စိတ်(*generators):
    ပိုႏ g မှန် generators:
        အောက်ပါမှ g

def gen1():
    အောက်ပါ 1
    အောက်ပါ 2

def gen2():
    အောက်ပါ 3
    အောက်ပါ 4

def gen3():
    အောက်ပါ 5
    အောက်ပါ 6

ပြုရန်("\\n=== Yield From ===")
combined = ခွဲခြမ်း_စိတ်(gen1(), gen2(), gen3())
ပြုရန်(မှတ်သား(combined))

# Infinite generator with limit
လုပ်ဆောင် ဖြစ်စဉ်():
    n = 0
    ရှင်းလင်း ဟွေ:
        အောက်ပါ n
        n = n + 1

ပြုရန်("\\n=== Limited Infinite Generator ===")
# Take first 10 from infinite
result = []
count = 0
ပိုႏ val မှန် ဖြစ်စဉ်():
    အတွက် count >= 10:
        ဖျက်ဆီး
    result.append(val)
    count = count + 1
ပြုရန်(f"First 10: ({result})")

# Pipeline generators
လုပ်ဆောင် ရောက်_မှတ်သား(string):
    ပိုႏ char မှန် string:
        အတွက် char.isalpha():
            အောက်ပါ char

လုပ်ဆောင် အရေးကြီး_စာ(chars):
    ပိုႏ char မှန် chars:
        အောက်ပါ char.အရေးကြီး()

လုပ်ဆောင် သုံးစွဲ_စိတ်(gen, n):
    count = 0
    ပိုႏ item မှန် gen:
        အတွက် count >= n:
            ဖျက်ဆီး
        အောက်ပါ item
        count = count + 1

ပြုရန်("\\n=== Generator Pipeline ===")
text = "Hello Myanmar Code 123!"
pipeline = သုံးစွဲ_စိတ်(အရေးကြီး_စာ(ရောက်_မှတ်သား(text)), 5)
ပြုရန်(မှတ်သား(pipeline))`
  },

  decorator_example: {
    name: "Decorators",
    desc: "Decorator patterns (v6)",
    code: `# MMC Decorators Example (v6)
# ပုံသဏ္ဌာန် ပြုပြင်ချက်များ

# Basic decorator
လုပ်ဆောင် အချိန်(func):
    လုပ်ဆောင် wrapper(*args, **kwargs):
        import time
        start = time.time()
        result = func(*args, **kwargs)
        end = time.time()
        ပြုရန်(f"  Timer: ({func.__name__}) took ({end - start:.4f}s")
        ပေးပို့ result
    ပေးပို့ wrapper

@အချိန်
လုပ်ဆောင် slow_add(a, b):
    import time
    time.sleep(0.1)
    ပေးပို့ a + b

ပြုရန်("=== Timer Decorator ===")
result = slow_add(10, 20)
ပြုရန်(f"  Result: ({result})")

# Decorator with arguments
လုပ်ဆောင် ပြောင်းလဲ(n):
    လုပ်ဆောင် decorator(func):
        လုပ်ဆောင် wrapper(*args, **kwargs):
            result = func(*args, **kwargs)
            ပေးပို့ result * n
        ပေးပို့ wrapper
    ပေးပို့ decorator

@ပြောင်းလဲ(10)
လုပ်ဆောင် get_value(x):
    ပေးပို့ x

ပြုရန်("\\n=== Decorator with Args ===")
ပြုရန်(f"  5 * 10 = ({get_value(5)})")
ပြုရန်(f"  3 * 10 = ({get_value(3)})")

# Memoization decorator
လုပ်ဆောင် မှတ်တမ်း(func):
    cache = {}
    လုပ်ဆောင် wrapper(*args):
        အတွက် args ပဲ ပါဝင် cache:
            ပြုရန်(f"  Cache hit: ({args})")
            ပေးပို့ cache[args]
        result = func(*args)
        cache[args] = result
        ပေးပို့ result
    ပေးပို့ wrapper

@မှတ်တမ်း
လုပ်ဆောင် fibonacci(n):
    အတွက် n ညာ 1:
        ပေးပို့ n
    ပေးပို့ fibonacci(n-1) + fibonacci(n-2)

ပြုရန်("\\n=== Memoization ===")
ပြုရန်(f"  F(10) = ({fibonacci(10)})")
# Second call - should use cache
ပြုရန်(f"  F(10) = ({fibonacci(10)})")

# Validation decorator
လုပ်ဆောင် စစ်ဆေး(types):
    လုပ်ဆောင် decorator(func):
        လုပ်ဆောင် wrapper(*args):
            ပိုႏ i, (arg, expected_type) မှန် နေရာ(ခွဲခြမ်း(args, types)):
                အတွက် ပဲ တူသလား အတိအကျ(arg, expected_type):
                    ခေါ်ဆို အမှားကြောင်း(
                        f"Arg ({i}) expected ({expected_type.__name__}), got ({တိကျ(arg).__name__})")
            ပေးပို့ func(*args)
        ပေးပို့ wrapper
    ပေးပို့ decorator

@စစ်ဆေး((int, int))
လုပ်ဆောင် add_numbers(a, b):
    ပေးပို့ a + b

ပြုရန်("\\n=== Validation Decorator ===")
ပြုရန်(f"  add_numbers(5, 3) = ({add_numbers(5, 3)})")
# This would raise error:
# add_numbers(5, "3")

# Class-based decorator
သင်္ကေတ ဖယ်ရှား_ဆက်(self, func):
  လုပ်ဆောင် __call__(self, *args, **kwargs):
    ပြုရန်(f"Before ({func.__name__})")
    result = func(*args, **kwargs)
    ပြုရန်(f"After ({func.__name__})")
    ပေးပို့ result

@ဖယ်ရှား_ဆက်()
လုပ်ဆောင် greet(အမည်):
    ပေးပို့ f"Hello, ({အမည်})!"

ပြုရန်("\\n=== Class Decorator ===")
greet("Myanmar Code")`
  },

  lambda_example: {
    name: "Lambda",
    desc: "Lambda functions (v6)",
    code: `# MMC Lambda Example (v6)
# နှုန်း လုပ်ဆောင်ချက်များ

# Basic lambda
ပြုရန်("=== Basic Lambda ===")
# နှုန်း = lambda x: x * 2
ပိုင်း = (နှုန်း x: x * 2)
ပြုရန်(f"double(5) = ({ပိုင်း(5)})")
ပြုရန်(f"double(10) = ({ပိုင်း(10)})")

# Lambda with multiple arguments
ပြုရန်("\\n=== Multiple Arguments ===")
add = (နှုန်း a, b: a + b)
multiply = (နှုန်း a, b: a * b)
power = (နှုန်း base, exp: base ** exp)

ပြုရန်(f"add(3, 4) = ({add(3, 4)})")
ပြုရန်(f"multiply(3, 4) = ({multiply(3, 4)})")
ပြုရန်(f"power(2, 10) = ({power(2, 10)})")

# Lambda with condition
ပြုရန်("\\n=== Conditional Lambda ===")
max_val = (နှုန်း a, b: a အတွက် a ညာ b နှင့် b)
min_val = (နှုန်း a, b: a အတွက် a ငယ် b နှင့် b)
abs_val = (နှုန်း x: x အတွက် x ညာ 0 နှင့် -x)

ပြုရန်(f"max(3, 7) = ({max_val(3, 7)})")
ပြုရန်(f"min(3, 7) = ({min_val(3, 7)})")
ပြုရန်(f"abs(-5) = ({abs_val(-5)})")
ပြုရန်(f"abs(5) = ({abs_val(5)})")

# Lambda with map, filter
ပြုရန်("\\n=== Map & Filter ===")
မှတ်သား = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Map
doubled = ချိုး(ဖော်ကြား(နှုန်း x: x * 2, မှတ်သား))
ပြုရန်(f"Doubled: ({doubled})")

squares = ချိုး(ဖော်ကြား(နှုန်း x: x ** 2, မှတ်သား))
ပြုရန်(f"Squares: ({squares})")

# Filter
even = ချိုး(ယုံကြည်(နှုန်း x: x % 2 တူသလား 0, မှတ်သား))
odd = ချိုး(ယုံကြည်(နှုန်း x: x % 2 ပဲ တူသလား 0, မှတ်သား))
big = ချိုး(ယုံကြည်(နှုန်း x: x ညာ 5, မှတ်သား))

ပြုရန်(f"Even: ({even})")
ပြုရန်(f"Odd: ({odd})")
ပြုရန်(f"Big (>5): ({big})")

# Reduce with lambda
from functools import reduce
total = reduce((နှုန်း a, b: a + b), မှတ်သား)
product = reduce((နှုန်း a, b: a * b), မှတ်သား)
max_val = reduce((နှုန်း a, b: a အတွက် a ညာ b နှင့် b), မှတ်သား)

ပြုရန်(f"Total: ({total})")
ပြုရန်(f"Product: ({product})")
ပြုရန်(f"Max: ({max_val})")

# Lambda with sorted
ပြုရန်("\\n=== Sorted with Lambda ===")
students = [
    ("Aung", 85),
    ("Su", 92),
    ("Hla", 78),
    ("Mya", 95)
]
by_name = ချိုး(students, ချိုး=နှုန်း s: s[0])
by_score = ချိုး(students, ချိုး=နှုန်း s: s[1], reverse=ဟွေ)
ပြုရန်(f"By name: ({by_name})")
ပြုရန်(f"By score desc: ({by_score})")

# Lambda in list comprehension
ပြုရန်("\\n=== Lambda in Comprehension ===")
ops = [
    (နှုန်း x: x + 1, "+1"),
    (နှုန်း x: x * 2, "*2"),
    (နှုန်း x: x ** 2, "**2")
]
x = 5
ပိုႏ fn, name မှန် ops:
    ပြုရန်(f"  f({x}) {name} = ({fn(x)})")`
  },

  type_hints: {
    name: "Type Hints",
    desc: "Type annotations (v6)",
    code: `# MMC Type Hints Example (v6)
# အမျိုးအရေကို ဖော်ပြခြင်း

# Basic type hints
# ပမာဏ: int = 10
# ချက်: float = 3.14
# အကြောင်းး: str = "Hello"

# Function with type hints
# လုပ်ဆောင် ပြောင်းလဲ(a: ပမာဏ, b: ပမာဏ) -> ပမာဏ:
#     ပေးပို့ a + b

# Type hints in action
x: int = 42
y: float = 3.14159
name: str = "Myanmar Code"
is_active: bool = ဟွေ
items: list = [1, 2, 3]
mapping: dict = {"key": "value"}

လုပ်ဆောင် တွက်ချက်(a: int, b: int) -> int:
    \"\"\"Add two integers\"\"\"
    ပေးပို့ a + b

လုပ်ဆောင် ခွဲခြမ်း(data: list, key: str) -> list:
    \"\"\"Sort list of dicts by key\"\"\"
    ပေးပို့ ချိုး(data, ချိုး=နှုန်း x: x[key])

# Optional and Union types
from typing import Optional, List, Dict, Tuple

လုပ်ဆောင် ရှိ_မရှိ(name: Optional[str]) -> str:
    အတွက် name တူသလား ဘာမ်:
        ပေးပို့ "Unknown"
    ပေးပို့ name

# Complex type hints
# scores: List[int] = [90, 85, 95, 88]
# student: Dict[str, any] = {"name": "Aung", "age": 20}
# point: Tuple[float, float] = (3.14, 2.71)

# Type-checked function
လုပ်ဆောင် ဖော်ပြ(value, expected_type) -> bool:
    ပေးပို့ အတိအကျ(value, expected_type)

# Demonstrate
ပြုရန်("=== Type Hints Demo ===")
ပြုရန်(f"x: ({x}) - type: ({တိကျ(x).__name__})")
ပြုရန်(f"y: ({y}) - type: ({တိကျ(y).__name__})")
ပြုရန်(f"name: ({name}) - type: ({တိကျ(name).__name__})")
ပြုရန်(f"is_active: ({is_active}) - type: ({တိကျ(is_active).__name__})")

# Type checking
ပြုရန်("\\n=== Type Checking ===")
ပြုရန်(f"42 is int: ({ဖော်ပြ(42, int)})")
ပြုရန်(f"'hello' is str: ({ဖော်ပြ('hello', str)})")
ပြုရန်(f"3.14 is int: ({ဖော်ပြ(3.14, int)})")
ပြုရန်(f"[1,2,3] is list: ({ဖော်ပြ([1,2,3], list)})")

# List with type hint
scores = [90, 85, 95, 88, 92, 87]
avg = တွက်ချက်(scores) / ရရှိ(scores)
ပြုရန်(f"\\nScores: ({scores})")
ပြုရန်(f"Average: ({avg:.2f})")

# Dict operations with typed data
students = [
    {"name": "Aung", "score": 90},
    {"name": "Su", "score": 95},
    {"name": "Hla", "score": 85}
]

sorted_students = ခွဲခြမ်း(students, "score")
ပြုရန်("\\n=== Sorted by score ===")
ပိုႏ s မှန် sorted_students:
    ပြုရန်(f"  ({s['name']}): ({s['score']})")

# Function annotations
ပြုရန်("\\n=== Function Annotations ===")
fn = ပြောင်းလဲ
annotations = fn.__annotations__
ပြုရန်(f"Annotations: ({annotations})")`
  },

  async_example: {
    name: "Async/Await",
    desc: "Async programming (v7)",
    code: `# MMC Async/Await Example (v7)
# အခံလျှင် ရည်ရွယ်ချက်

import asyncio
import time

# Basic async function
# ခံလျှင် လုပ်ဆောင် wait(seconds):
#     အချိန်.sleep(seconds)
#     ပေးပို့ f"Waited ({seconds})s"

# Async sleep
# ခံလျှင် လုပ်ဆောင် wait(seconds):
#     စောင့်ကြည့် asyncio.sleep(seconds)
#     ပေးပို့ f"Slept ({seconds})s"

# Simulated async tasks
# ခံလျှင် လုပ်ဆောင် fetch_data(အမည်):
#     စောင့်ကြည့် asyncio.sleep(1)
#     ပေးပို့ {"name": အမည်, "data": "Some data"}

# Since we can't truly await in std environment,
# let's demonstrate the pattern with asyncio

ခံလျှင် လုပ်ဆောင် task1():
    ပြုရန်("Task 1 starting...")
    စောင့်ကြည့် asyncio.sleep(0.5)
    ပြုရန်("Task 1 done!")
    ပေးပို့ "Result 1"

ခံလျှင် လုပ်ဆောင် task2():
    ပြုရန်("Task 2 starting...")
    စောင့်ကြည့် asyncio.sleep(1.0)
    ပြုရန်("Task 2 done!")
    ပေးပို့ "Result 2"

ခံလျှင် လုပ်ဆောင် task3():
    ပြုရန်("Task 3 starting...")
    စောင့်ကြည့် asyncio.sleep(0.3)
    ပြုရန်("Task 3 done!")
    ပေးပို့ "Result 3"

# Run concurrent tasks
ခံလျှင် လုပ်ဆောင် main():
    ပြုရန်("=== Async Tasks (concurrent) ===")
    start = time.time()

    results = စောင့်ကြည့် asyncio.gather(
        task1(), task2(), task3()
    )

    end = time.time()
    ပြုရန်(f"\\nResults: ({results})")
    ပြုရန်(f"Total time: ({end - start:.2f}s")
    ပြုရန်("(All ran concurrently!)")

# Run the async main
asyncio.run(main())

# Sequential vs Concurrent comparison
ခံလျှင် လုပ်ဆောင် sequential():
    ပြုရန်("\\n=== Sequential Tasks ===")
    start = time.time()
    စောင့်ကြည့် task1()
    စောင့်ကြည့် task2()
    စောင့်ကြည့် task3()
    end = time.time()
    ပြုရန်(f"Sequential time: ({end - start:.2f}s")

asyncio.run(sequential())

# Async generator
ခံလျှင် လုပ်ဆောင် async_counter(n):
    ပိုႏ i မှန် နားလည်(1, n + 1):
        စောင့်ကြည့် asyncio.sleep(0.1)
        အောက်ပါ i

ခံလျှင် လုပ်ဆောင် use_async_gen():
    ပြုရန်("\\n=== Async Generator ===")
    values = []
    async ပိုႏ val မှန် async_counter(5):
        values.append(val)
        ပြုရန်(f"  Got: ({val})", ဒေတာ=" ")
    ပြုရန်(f"\\nAll values: ({values})")

asyncio.run(use_async_gen())`
  },

  test_example: {
    name: "Unit Tests",
    desc: "Testing framework (v7)",
    code: `# MMC Unit Test Example (v7)
# စမ်းသပ် အင်းရောင်

# Simple test functions
လုပ်ဆောင် တွက်ချက်(a, b):
    ပေးပို့ a + b

လုပ်ဆောင် ဖယ်ရှား(a, b):
    ပေးပို့ a - b

လုပ်ဆောင် ပိုင်း(a, b):
    ပေးပို့ a * b

လုပ်ဆောင် ကြက်(a, b):
    အတွက် b တူသလား 0:
        ပေးပို့ ဘာမ်
    ပေးပို့ a / b

# Test framework
# စမ်းပါ ပါလပ်မှန် စမ်းသပ်များ
tests_passed = 0
tests_failed = 0
test_results = []

# Test runner
လုပ်ဆောင် စမ်း(name, actual, expected):
    အပ်နှံ tests_passed, tests_failed, test_results
    အတွက် actual တူသလား expected:
        tests_passed = tests_passed + 1
        test_results.append(f"  PASS: ({name})")
        ပြုရန်(f"  PASS: ({name})")
    အနည်းငယ်:
        tests_failed = tests_failed + 1
        test_results.append(f"  FAIL: ({name}) - expected ({expected}), got ({actual})")
        ပြုရန်(f"  FAIL: ({name}) - expected ({expected}), got ({actual})")

# Assert helpers
လုပ်ဆောင် တူမြောက်(actual, expected, msg):
    စမ်း(msg, actual, expected)

လုပ်ဆောင် ဖြစ်_တူမြောက်(value, msg):
    စမ်း(msg, value, ဟွေ)

လုပ်ဆောင် သုံးစွဲ_ဖြစ်(value, msg):
    အပ်နှံ tests_passed, tests_failed, test_results
    အတွက် value:
        tests_passed = tests_passed + 1
        test_results.append(f"  PASS: ({msg})")
        ပြုရန်(f"  PASS: ({msg})")
    အနည်းငယ်:
        tests_failed = tests_failed + 1
        test_results.append(f"  FAIL: ({msg}) - expected True, got ({value})")
        ပြုရန်(f"  FAIL: ({msg}) - expected True, got ({value})")

# Run tests
ပြုရန်("=== Running Tests ===")
ပြုရန်("--- Math Tests ---")
တူမြောက်(တွက်ချက်(2, 3), 5, "add(2, 3) = 5")
တူမြောက်(တွက်ချက်(-1, 1), 0, "add(-1, 1) = 0")
တူမြောက်(တွက်ချက်(0, 0), 0, "add(0, 0) = 0")
တူမြောက်(ဖယ်ရှား(5, 3), 2, "subtract(5, 3) = 2")
တူမြောက်(ဖယ်ရှား(0, 5), -5, "subtract(0, 5) = -5")
တူမြောက်(ပိုင်း(4, 3), 12, "multiply(4, 3) = 12")
တူမြောက်(ပိုင်း(-2, -3), 6, "multiply(-2, -3) = 6")
တူမြောက်(ကြက်(10, 2), 5.0, "divide(10, 2) = 5")
တူမြောက်(ကြက်(7, 2), 3.5, "divide(7, 2) = 3.5")
တူမြောက်(ကြက်(10, 0), ဘာမ်, "divide(10, 0) = None")

ပြုရန်("\\n--- Boolean Tests ---")
သုံးစွဲ_ဖြစ်(2 + 2 တူသလား 4, "2 + 2 == 4")
သုံးစွဲ_ဖြစ်("hello" ရှိ "ell", "'ell' in 'hello'")
သုံးစွဲ_ဖြစ်(10 ညာ 5, "10 > 5")
သုံးစွဲ_ဖြစ်(5 ညာ 10, "5 < 10")

# Summary
ပြုရန်("\\n=== Test Summary ===")
total = tests_passed + tests_failed
ပြုရန်(f"Total: ({total})")
ပြုရန်(f"Passed: ({tests_passed})")
ပြုရန်(f"Failed: ({tests_failed})")
rate = (tests_passed / total * 100) အတွက် total ညာ 0 နှင့် 0
ပြုရန်(f"Pass rate: ({rate:.1f}%)")

အတွက် tests_failed တူသလား 0:
    ပြုရန်("\\nAll tests passed!")
အနည်းငယ်:
    ပြုရန်(f"\\n({tests_failed}) test(s) failed!")`
  },

  stdlib_example: {
    name: "Std Library",
    desc: "Standard library usage (v5)",
    code: `# MMC Standard Library Example (v5)
# အခြေခံ ရပ်တည်မှု

# ===== Math Module =====
import math

ပြုရန်("=== Math Module ===")
ပြုရန်(f"Pi: ({math.pi:.10f})")
ပြုရန်(f"Euler: ({math.e:.10f})")
ပြုရန်(f"sqrt(144): ({math.sqrt(144)})")
ပြုရန်(f"ceil(4.3): ({math.ceil(4.3)})")
ပြုရန်(f"floor(4.7): ({math.floor(4.7)})")
ပြုရန်(f"factorial(10): ({math.factorial(10)})")
ပြုရန်(f"sin(pi/6): ({math.sin(math.pi/6):.4f})")
ပြုရန်(f"cos(pi/3): ({math.cos(math.pi/3):.4f})")
ပြုရန်(f"log(100): ({math.log10(100):.2f})")
ပြုရန်(f"degrees(pi/2): ({math.degrees(math.pi/2):.1f})")

# ===== Random Module =====
import random

ပြုရန်("\\n=== Random Module ===")
random.seed(42)
ပြုရန်(f"Random int (1-10): ({random.randint(1, 10)})")
ပြုရန်(f"Random float: ({random.random():.4f})")
colors = ["Red", "Green", "Blue", "Yellow"]
ပြုရန်(f"Random choice: ({random.choice(colors)})")
shuffled = colors.copy()
random.shuffle(shuffled)
ပြုရန်(f"Shuffled: ({shuffled})")
samples = random.sample(နားလည်(1, 11), 5)
ချိုး(samples) = ချိုး(samples)
ပြုရန်(f"Sample 5: ({samples})")

# ===== Time Module =====
import time

ပြုရန်("\\n=== Time Module ===")
ts = time.time()
ပြုရန်(f"Timestamp: ({ts})")
local = time.localtime(ts)
format_time = time.strftime("%Y-%m-%d %H:%M:%S", local)
ပြုရန်(f"Formatted: ({format_time})")

start = time.time()
# Quick computation
total = တွက်ချက်(နားလည်(1000000))
end = time.time()
ပြုရန်(f"Sum 1-1M: ({total})")
ပြုရန်(f"Time: ({(end-start)*1000:.2f}ms")

# ===== JSON Module =====
import json

ပြုရန်("\\n=== JSON Module ===")
data = {
    "name": "Myanmar Code",
    "version": "8.0",
    "features": ["OOP", "Async", "Generators"],
    "stats": {"users": 1000, "stars": 500}
}
json_str = json.dumps(data, indent=2)
ပြုရန်(f"JSON:\\n({json_str})")

# Parse JSON
parsed = json.loads(json_str)
ပြုရန်(f"\\nParsed name: ({parsed['name']})")
ပြုရန်(f"Features: ({parsed['features']})")

# ===== String Module =====
import string

ပြုရန်("\\n=== String Module ===")
ပြုရန်(f"ASCII letters: ({string.ascii_letters})")
ပြုရန်(f"Digits: ({string.digits})")
ပြုရန်(f"Punctuation: ({string.punctuation})")

# Generate random string
rand_str = ''.join(random.choice(string.ascii_letters) အတွက် _ မှန် နားလည်(10))
ပြုရန်(f"Random string: ({rand_str})")

# ===== Collections Module =====
from collections import Counter, OrderedDict

ပြုရန်("\\n=== Collections ===")
words = ["myanmar", "code", "myanmar", "ai", "code", "myanmar"]
word_count = Counter(words)
ပြုရန်(f"Word counts: ({dict(word_count)})")

# ===== OS Module =====
import os

ပြုရန်("\\n=== OS Module ===")
ပြုရန်(f"Current dir: ({os.getcwd()})")
ပြုရန်(f"OS name: ({os.name})")

# ===== Datetime Module =====
from datetime import datetime, timedelta

ပြုရန်("\\n=== Datetime ===")
now = datetime.now()
ပြုရန်(f"Now: ({now.strftime('%Y-%m-%d %H:%M:%S')})")
tomorrow = now + timedelta(days=1)
ပြုရန်(f"Tomorrow: ({tomorrow.strftime('%Y-%m-%d')})")
future = now + timedelta(days=365)
ပြုရန်(f"Next year: ({future.strftime('%Y-%m-%d')})")

# ===== itertools =====
from itertools import combinations, permutations

ပြုရန်("\\n=== Itertools ===")
items = ['A', 'B', 'C']
combs = ချိုး(list(combinations(items, 2)))
permus = ချိုး(list(permutations(items, 2)))
ပြုရန်(f"Combinations(2): ({combs})")
ပြုရန်(f"Permutations(2): ({permus})")

# ===== re (Regex) =====
import re

ပြုရန်("\\n=== Regex ===")
text = "Myanmar Code v9.0 - 2024"
emails = "Contact: user@example.com or admin@mmc.ai"
found = re.findall(r'[a-z]+@[a-z]+\.[a-z]+', emails)
ပြုရန်(f"Emails found: ({found})")
numbers = re.findall(r'\d+', text)
ပြုရန်(f"Numbers: ({numbers})")

# ===== Statistics =====
import statistics

ပြုရန်("\\n=== Statistics ===")
data = [85, 90, 78, 92, 88, 95, 83, 91]
ပြုရန်(f"Data: ({data})")
ပြုရန်(f"Mean: ({statistics.mean(data):.2f})")
ပြုရန်(f"Median: ({statistics.median(data):.2f})")
ပြုရန်(f"Stdev: ({statistics.stdev(data):.2f})")
ပြုရန်(f"Min: ({statistics.min(data)})")
ပြုရန်(f"Max: ({statistics.max(data)})")`
  }
};

/* ===== State ===== */
let currentTab = 'run';
let aiMessages = [];
let aiUnread = 0;
let isDragging = false;
let currentFilename = 'untitled.mmc';

/* ===== Initialization ===== */
document.addEventListener('DOMContentLoaded', function() {
  buildExamplesDropdown();
  checkOllamaStatus();
  setupResize();
  setupEditorEvents();
  // Load hello example by default
  loadExample('hello');
  updateLineCol();
});

/* ===== Build Examples Dropdown ===== */
function buildExamplesDropdown() {
  const dd = document.getElementById('examples-dropdown');
  let html = '';
  for (const [key, ex] of Object.entries(EXAMPLES)) {
    html += '<button class="dropdown-item" onclick="loadExample(\'' + key + '\')">' +
            ex.name + '<span class="desc">' + ex.desc + '</span></button>';
  }
  dd.innerHTML = html;
}

/* ===== Load Example ===== */
function loadExample(key) {
  const ex = EXAMPLES[key];
  if (ex) {
    document.getElementById('editor').value = ex.code;
    currentFilename = key + '.mmc';
    document.getElementById('filename-display').textContent = currentFilename;
    closeDropdown();
    showToast('Loaded: ' + ex.name, 'info');
  }
}

/* ===== Toggle Dropdown ===== */
function toggleDropdown() {
  document.getElementById('examples-dropdown').classList.toggle('show');
}
function closeDropdown() {
  document.getElementById('examples-dropdown').classList.remove('show');
}
document.addEventListener('click', function(e) {
  if (!e.target.closest('.dropdown')) closeDropdown();
});

/* ===== Tabs ===== */
function switchTab(tab) {
  currentTab = tab;
  // Update tab styles
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.querySelector('.tab[data-tab="' + tab + '"]').classList.add('active');
  // Show/hide output views
  document.querySelectorAll('.output-view').forEach(v => v.classList.remove('active'));
  document.getElementById(tab === 'run' ? 'run-output' : tab === 'python' ? 'python-output' : 'ai-output').classList.add('active');
  // Show/hide AI chat
  const aiChat = document.getElementById('ai-chat');
  if (tab === 'ai') {
    aiChat.classList.add('active');
    aiUnread = 0;
    updateBadge();
    setTimeout(() => document.getElementById('ai-input').focus(), 100);
  } else {
    aiChat.classList.remove('active');
  }
}

/* ===== Run Code ===== */
async function runCode() {
  const code = document.getElementById('editor').value.trim();
  if (!code) return;

  switchTab('run');
  const out = document.getElementById('run-output');
  out.innerHTML = '<div class="output-info">Running...</div>';

  const start = performance.now();
  try {
    const resp = await fetch('/api/run', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code: code })
    });
    const data = await resp.json();
    const elapsed = ((performance.now() - start) / 1000).toFixed(3);
    document.getElementById('exec-time').textContent = elapsed + 's';

    if (data.success) {
      out.innerHTML = '';
      if (data.output && data.output.trim()) {
        out.innerHTML += '<div class="output-line output-success">' + escapeHtml(data.output) + '</div>';
      }
      out.innerHTML += '<div class="output-dim">--- Executed in ' + elapsed + 's ---</div>';
    } else {
      out.innerHTML = '<div class="output-line output-error">' + escapeHtml(data.error || data.output) + '</div>' +
                      '<div class="output-dim">--- Error ---</div>';
    }
  } catch (err) {
    out.innerHTML = '<div class="output-line output-error">Connection error: ' + escapeHtml(err.message) + '</div>';
  }
}

/* ===== Show Python ===== */
async function showPython() {
  const code = document.getElementById('editor').value.trim();
  if (!code) return;

  switchTab('python');
  const out = document.getElementById('python-output');
  out.innerHTML = '<div class="output-info">Transpiling...</div>';

  try {
    const resp = await fetch('/api/python', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code: code })
    });
    const data = await resp.json();
    if (data.success) {
      out.innerHTML = '<div class="output-line output-info"># Transpiled Python Code:</div>' +
                      '<div class="output-line">' + escapeHtml(data.python) + '</div>';
    } else {
      out.innerHTML = '<div class="output-line output-error">' + escapeHtml(data.error || 'Transpilation failed') + '</div>';
    }
  } catch (err) {
    out.innerHTML = '<div class="output-line output-error">Connection error: ' + escapeHtml(err.message) + '</div>';
  }
}

/* ===== Clear Output ===== */
function clearOutput() {
  document.getElementById('run-output').innerHTML = '<div class="output-dim">Output cleared.</div>';
  document.getElementById('python-output').innerHTML = '<div class="output-dim">Output cleared.</div>';
}

/* ===== AI Chat ===== */
async function sendAI() {
  const input = document.getElementById('ai-input');
  const msg = input.value.trim();
  if (!msg) return;
  input.value = '';

  switchTab('ai');
  addAIMessage('user', msg);

  // Show typing indicator
  const typingEl = document.createElement('div');
  typingEl.className = 'ai-typing';
  typingEl.textContent = 'Thinking...';
  typingEl.id = 'ai-typing';
  document.getElementById('ai-messages').appendChild(typingEl);
  scrollAI();

  document.getElementById('ai-send').disabled = true;

  try {
    const resp = await fetch('/api/ai', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        messages: [...aiMessages.slice(-10), { role: 'user', content: msg }]
      })
    });
    const data = await resp.json();

    // Remove typing indicator
    const t = document.getElementById('ai-typing');
    if (t) t.remove();

    if (data.success) {
      addAIMessage('assistant', data.response);
    } else {
      addAIMessage('assistant', 'Error: ' + (data.error || 'Failed to get response'));
    }
  } catch (err) {
    const t = document.getElementById('ai-typing');
    if (t) t.remove();
    addAIMessage('assistant', 'Connection error: ' + err.message);
  }

  document.getElementById('ai-send').disabled = false;
}

function addAIMessage(role, content) {
  aiMessages.push({ role: role, content: content });
  const el = document.createElement('div');
  el.className = 'ai-msg ' + role;
  el.textContent = content;
  document.getElementById('ai-messages').appendChild(el);
  scrollAI();
}

function scrollAI() {
  const c = document.getElementById('ai-messages');
  c.scrollTop = c.scrollHeight;
}

/* ===== Check Ollama Status ===== */
async function checkOllamaStatus() {
  const dot = document.getElementById('ollama-dot');
  const text = document.getElementById('ollama-text');
  dot.className = 'status-dot status-loading';
  text.textContent = 'Checking...';
  try {
    const resp = await fetch('/api/ollama-status');
    const data = await resp.json();
    if (data.online) {
      dot.className = 'status-dot status-online';
      text.textContent = 'Ollama Online';
    } else {
      dot.className = 'status-dot status-offline';
      text.textContent = 'Ollama Offline';
    }
  } catch (e) {
    dot.className = 'status-dot status-offline';
    text.textContent = 'Ollama Offline';
  }
  // Recheck every 30 seconds
  setTimeout(checkOllamaStatus, 30000);
}

/* ===== File Operations ===== */
function openFile() {
  document.getElementById('file-input').click();
}

function handleFile(event) {
  const file = event.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = function(e) {
    document.getElementById('editor').value = e.target.result;
    currentFilename = file.name;
    document.getElementById('filename-display').textContent = file.name;
    showToast('Opened: ' + file.name, 'success');
  };
  reader.readAsText(file);
  event.target.value = '';
}

function saveFile() {
  const code = document.getElementById('editor').value;
  const blob = new Blob([code], { type: 'text/plain' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = currentFilename;
  a.click();
  URL.revokeObjectURL(url);
  showToast('Saved: ' + currentFilename, 'success');
}

/* ===== Font Size ===== */
function changeFontSize(size) {
  document.getElementById('editor').style.fontSize = size + 'px';
  document.querySelectorAll('.output-view').forEach(v => v.style.fontSize = (parseInt(size) - 1) + 'px');
}

/* ===== Editor Events ===== */
function setupEditorEvents() {
  const editor = document.getElementById('editor');

  editor.addEventListener('keydown', function(e) {
    // Ctrl+Enter = Run
    if (e.ctrlKey && e.key === 'Enter') {
      e.preventDefault();
      runCode();
      return;
    }
    // Ctrl+S = Save
    if (e.ctrlKey && e.key === 's') {
      e.preventDefault();
      saveFile();
      return;
    }
    // Ctrl+Shift+P = Show Python
    if (e.ctrlKey && e.shiftKey && e.key === 'P') {
      e.preventDefault();
      showPython();
      return;
    }
    // Ctrl+Shift+C = Clear
    if (e.ctrlKey && e.shiftKey && e.key === 'C') {
      e.preventDefault();
      clearOutput();
      return;
    }
    // Tab = Indent
    if (e.key === 'Tab') {
      e.preventDefault();
      const start = this.selectionStart;
      const end = this.selectionEnd;
      if (e.shiftKey) {
        // Decrease indent
        const lineStart = this.value.lastIndexOf('\n', start - 1) + 1;
        if (this.value.substring(lineStart, lineStart + 4) === '    ') {
          this.value = this.value.substring(0, lineStart) + this.value.substring(lineStart + 4);
          this.selectionStart = Math.max(start - 4, lineStart);
          this.selectionEnd = Math.max(end - 4, lineStart);
        }
      } else {
        this.value = this.value.substring(0, start) + '    ' + this.value.substring(end);
        this.selectionStart = this.selectionEnd = start + 4;
      }
      return;
    }
  });

  editor.addEventListener('input', updateLineCol);
  editor.addEventListener('click', updateLineCol);
  editor.addEventListener('keyup', updateLineCol);

  // Global shortcuts
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') closeHelp();
  });
}

function updateLineCol() {
  const editor = document.getElementById('editor');
  const val = editor.value.substring(0, editor.selectionStart);
  const lines = val.split('\n');
  const ln = lines.length;
  const col = lines[lines.length - 1].length + 1;
  document.getElementById('line-col-info').textContent = 'Ln ' + ln + ', Col ' + col;
}

/* ===== Resize Handle ===== */
function setupResize() {
  const handle = document.getElementById('resize-handle');
  const main = document.getElementById('main');
  const editorPanel = document.getElementById('editor-panel');
  const outputPanel = document.getElementById('output-panel');
  const isMobile = window.innerWidth <= 768;

  function onStart(e) {
    isDragging = true;
    handle.classList.add('active');
    document.body.style.cursor = isMobile ? 'row-resize' : 'col-resize';
    document.body.style.userSelect = 'none';
    e.preventDefault();
  }

  function onMove(e) {
    if (!isDragging) return;
    if (isMobile) {
      const rect = main.getBoundingClientRect();
      const y = (e.touches ? e.touches[0].clientY : e.clientY) - rect.top;
      const pct = (y / rect.height) * 100;
      editorPanel.style.flex = 'none';
      editorPanel.style.height = pct + '%';
      editorPanel.style.width = '100%';
      outputPanel.style.flex = '1';
    } else {
      const rect = main.getBoundingClientRect();
      const x = (e.touches ? e.touches[0].clientX : e.clientX) - rect.left;
      const pct = (x / rect.width) * 100;
      editorPanel.style.flex = 'none';
      editorPanel.style.width = pct + '%';
      editorPanel.style.height = '';
      outputPanel.style.flex = '1';
    }
  }

  function onEnd() {
    isDragging = false;
    handle.classList.remove('active');
    document.body.style.cursor = '';
    document.body.style.userSelect = '';
  }

  handle.addEventListener('mousedown', onStart);
  handle.addEventListener('touchstart', onStart, { passive: false });
  document.addEventListener('mousemove', onMove);
  document.addEventListener('touchmove', onMove, { passive: false });
  document.addEventListener('mouseup', onEnd);
  document.addEventListener('touchend', onEnd);
}

/* ===== Help Modal ===== */
function showHelp() {
  document.getElementById('help-modal').classList.add('show');
}
function closeHelp() {
  document.getElementById('help-modal').classList.remove('show');
}

/* ===== Toast ===== */
function showToast(msg, type) {
  const t = document.createElement('div');
  t.className = 'toast ' + (type || 'info');
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 3000);
}

/* ===== Badge ===== */
function updateBadge() {
  const badge = document.getElementById('ai-badge');
  if (aiUnread > 0) {
    badge.style.display = 'inline';
    badge.textContent = aiUnread > 9 ? '9+' : aiUnread;
  } else {
    badge.style.display = 'none';
  }
}

/* ===== Escape HTML ===== */
function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
</script>
</body>
</html>
"""

# ---------------------------------------------------------------------------
# HTTP Request Handler
# ---------------------------------------------------------------------------
class MMCRequestHandler(BaseHTTPRequestHandler):
    """Handle HTTP requests for the MMC AI Server."""

    server_version = "MMC-AI-Server/" + VERSION

    def do_OPTIONS(self):
        """Handle CORS preflight requests."""
        self.send_response(200)
        self._set_cors_headers()
        self.end_headers()

    def do_GET(self):
        """Handle GET requests."""
        parsed = urlparse(self.path)
        path = parsed.path.rstrip('/')

        if path == '/' or path == '':
            self._serve_html()
        elif path == '/api/ollama-status':
            self._handle_ollama_status()
        else:
            self._send_json(404, {"success": False, "error": "Not found"})

    def do_POST(self):
        """Handle POST requests."""
        parsed = urlparse(self.path)
        path = parsed.path.rstrip('/')

        # Read request body
        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length) if content_length > 0 else b''

        try:
            data = json.loads(body) if body else {}
        except json.JSONDecodeError:
            data = {}

        if path == '/api/run':
            self._handle_run(data)
        elif path == '/api/python':
            self._handle_python(data)
        elif path == '/api/ai':
            self._handle_ai(data)
        else:
            self._send_json(404, {"success": False, "error": "Not found"})

    # ---- Serve HTML ----
    def _serve_html(self):
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Cache-Control', 'no-cache')
        self.end_headers()
        self.wfile.write(HTML_PAGE.encode('utf-8'))

    # ---- API: Run MMC Code ----
    def _handle_run(self, data):
        code = data.get('code', '').strip()
        if not code:
            self._send_json(400, {"success": False, "error": "No code provided"})
            return

        if not MMC_AVAILABLE:
            self._send_json(503, {
                "success": False,
                "error": "MMC transpiler not available. Make sure mmc_transpiler.py is in the same directory."
            })
            return

        try:
            output = run_mmc(code)
            self._send_json(200, {"success": True, "output": output})
        except Exception as e:
            self._send_json(200, {"success": False, "error": str(e)})

    # ---- API: Transpile MMC to Python ----
    def _handle_python(self, data):
        code = data.get('code', '').strip()
        if not code:
            self._send_json(400, {"success": False, "error": "No code provided"})
            return

        if not MMC_AVAILABLE:
            self._send_json(503, {
                "success": False,
                "error": "MMC transpiler not available. Make sure mmc_transpiler.py is in the same directory."
            })
            return

        try:
            python_code = mmc_to_python(code)
            self._send_json(200, {"success": True, "python": python_code})
        except Exception as e:
            self._send_json(200, {"success": False, "error": str(e)})

    # ---- API: AI Chat via Ollama ----
    def _handle_ai(self, data):
        messages = data.get('messages', [])
        if not messages:
            self._send_json(400, {"success": False, "error": "No messages provided"})
            return

        try:
            req_body = json.dumps({
                "model": OLLAMA_MODEL,
                "messages": [{"role": "system", "content": MMC_SYSTEM_PROMPT}] + messages,
                "stream": False
            }).encode('utf-8')

            req = urllib.request.Request(
                OLLAMA_URL + '/api/chat',
                data=req_body,
                headers={'Content-Type': 'application/json'},
                method='POST'
            )

            with urllib.request.urlopen(req, timeout=120) as resp:
                result = json.loads(resp.read().decode('utf-8'))
                response_text = result.get('message', {}).get('content', '')
                self._send_json(200, {"success": True, "response": response_text})

        except urllib.error.URLError as e:
            self._send_json(200, {
                "success": False,
                "error": f"Cannot connect to Ollama at {OLLAMA_URL}. Make sure Ollama is running and the model '{OLLAMA_MODEL}' is available."
            })
        except Exception as e:
            self._send_json(200, {"success": False, "error": str(e)})

    # ---- API: Ollama Status ----
    def _handle_ollama_status(self):
        try:
            req = urllib.request.Request(
                OLLAMA_URL + '/api/tags',
                method='GET'
            )
            with urllib.request.urlopen(req, timeout=5) as resp:
                result = json.loads(resp.read().decode('utf-8'))
                models = [m.get('name', '') for m in result.get('models', [])]
                model_found = any(OLLAMA_MODEL in m for m in models)
                self._send_json(200, {
                    "online": True,
                    "model": OLLAMA_MODEL,
                    "model_available": model_found,
                    "models": models
                })
        except Exception:
            self._send_json(200, {"online": False, "model": OLLAMA_MODEL, "model_available": False, "models": []})

    # ---- Helpers ----
    def _set_cors_headers(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.send_header('Access-Control-Max-Age', '86400')

    def _send_json(self, status_code, data):
        self.send_response(status_code)
        self._set_cors_headers()
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.end_headers()
        self.wfile.write(json.dumps(data, ensure_ascii=False).encode('utf-8'))

    def log_message(self, format, *args):
        """Custom logging format."""
        sys.stdout.write(
            f"\033[90m[{self.log_date_time_string()}]\033[0m "
            f"\033[96m{args[0]}\033[0m\n"
        )
        sys.stdout.flush()


# ---------------------------------------------------------------------------
# Server Startup
# ---------------------------------------------------------------------------
class ThreadedHTTPServer(HTTPServer):
    """Handle requests in separate threads for concurrent access."""
    allow_reuse_address = True
    daemon_threads = True

    def process_request(self, request, client_address):
        """Process each request in a new thread."""
        thread = threading.Thread(
            target=self._handle_request_thread,
            args=(request, client_address),
            daemon=True
        )
        thread.start()

    def _handle_request_thread(self, request, client_address):
        """Wrapper to handle request with error catching."""
        try:
            self.finish_request(request, client_address)
        except Exception:
            self.handle_error(request, client_address)
        finally:
            self.shutdown_request(request)


def print_banner():
    """Print startup banner."""
    banner = r"""
╔═══════════════════════════════════════════════════════════╗
║                                                           ║
║   ███╗   ███╗ █████╗ ███╗   ██╗██████╗                   ║
║   ████╗ ████║██╔══██╗████╗  ██║██╔══██╗                  ║
║   ██╔████╔██║███████║██╔██╗ ██║██║  ██║                  ║
║   ██║╚██╔╝██║██╔══██║██║╚██╗██║██║  ██║                  ║
║   ██║ ╚═╝ ██║██║  ██║██║ ╚████║██████╔╝                  ║
║   ╚═╝     ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝╚═════╝                   ║
║                                                           ║
║            MMC AI Server v9.0                             ║
║     Myanmar Code Web IDE + AI Assistant                   ║
║                                                           ║
╠═══════════════════════════════════════════════════════════╣
║  Author     : MyanOS AI Team                              ║
║  Version    : 8.0                                         ║
║  Port       : {port:<5}                                     ║
║  Host       : {host:<15}                                 ║
║  Ollama     : {ollama_url:<34}                  ║
║  AI Model   : {model:<34}                  ║
║  MMC Core   : {mmc_status:<34}                  ║
║  Features   : OOP, Generators, Decorators, Async,          ║
║               Type Hints, Testing, F-Strings, v9.0         ║
╠═══════════════════════════════════════════════════════════╣
║  Open your browser: http://localhost:{port:<5}             ║
╚═══════════════════════════════════════════════════════════╝
""".format(
        port=PORT,
        host=HOST,
        ollama_url=OLLAMA_URL,
        model=OLLAMA_MODEL,
        mmc_status="Available" if MMC_AVAILABLE else "Not found (code will still run)"
    )
    print(banner)


def main():
    """Start the MMC AI Server."""
    print_banner()

    server = ThreadedHTTPServer((HOST, PORT), MMCRequestHandler)

    print(f"\n  🟢 Server running at http://localhost:{PORT}")
    print(f"  📂 Serving from: {os.path.dirname(os.path.abspath(__file__))}")
    print(f"  🔧 Transpiler: {'✅ Available' if MMC_AVAILABLE else '⚠️  Not found - API will return errors'}")
    print(f"  🤖 Ollama: {OLLAMA_URL} (model: {OLLAMA_MODEL})")
    print(f"\n  Press Ctrl+C to stop.\n")

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n\n  🔴 MMC AI Server v9.0 stopped.\n")
        server.server_close()


if __name__ == '__main__':
    main()
