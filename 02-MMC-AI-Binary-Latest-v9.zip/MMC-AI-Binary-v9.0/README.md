MMC AI v9.0 - Professional Edition
=====================================================

Myanmar Code (MMC) - Myanmar Language Programming Language

Version: 9.0.0 (Professional Edition)
Author: MyanOS AI Team
License: MIT

What's New in v9.0 (Professional Edition)
------------------------------------------

v9.0 is the biggest upgrade in MMC history. It transforms MMC from a
simple token-translator into a professional-grade transpiler with
world-class error reporting.

### v9.0 Features:
- **Professional Error Reporting** - Color-coded errors with source context
- **Traceback Mapper** - Python errors mapped back to MMC source locations
- **Semantic Validation** - Pre-compilation checks (brackets, strings, indentation)
- **Lint Mode** - Code quality analysis without running
- **Warning System** - Style warnings, deprecation notices
- **Myanmar Error Messages** - All errors and suggestions in Myanmar language
- **Smart Suggestions** - Fuzzy keyword matching for typos
- **Multi-error Recovery** - Collects ALL errors, not just the first one
- **Match/Case Support** - Python 3.10+ structural pattern matching
- **Walrus Operator** - Assignment expressions (:=)
- **357+ Keywords** - Myanmar + English keywords
- **Source Maps** - MMC line -> Python line mapping

### v9.0 vs v8.0 Comparison:

| Feature | v8.0 | v9.0 |
|---------|------|------|
| Error Messages | Raw Python errors | Myanmar with source context |
| Suggestions | None | Smart fuzzy matching |
| Validation | None | Pre-compilation checks |
| Lint Mode | No | Yes |
| Traceback Map | Basic | Full (MMC source lines) |
| Keywords | 181 | 357 |
| Error Recovery | Stop at first | Collect all errors |
| Warning System | No | 7 warning types |
| Bracket Check | No | Yes |
| String Check | No | Yes |
| Indentation Check | No | Yes |

## Quick Start

### Install (Copy Paste - Termux/PC)

```bash
# 1. Extract the zip
unzip MMC-AI-Binary-v9.0.zip
cd MMC-AI-Binary-v9.0

# 2. Run installer
bash install.sh

# 3. Start Web IDE
cd ~/mmc-ai
python3 mmc_ai_server.py

# 4. Open browser
# http://localhost:8080
```

### Run MMC Code

```bash
# Basic run
python3 mmc_transpiler.py run examples/hello.mmc

# Show Python output
python3 mmc_transpiler.py compile examples/calculator.mmc

# Compile to .py with source map
python3 mmc_transpiler.py build examples/fibonacci.mmc

# Lint (check for errors)
python3 mmc_transpiler.py lint examples/loops.mmc

# Debug mode (full traceback)
python3 mmc_transpiler.py debug examples/calculator.mmc

# Version info
python3 mmc_transpiler.py version

# Show all keywords
python3 mmc_transpiler.py keywords
```

### Test

```bash
python3 mmc_test.py
```

### Package Manager

```bash
python3 mmc_pkg.py init
python3 mmc_pkg.py create mypackage
python3 mmc_pkg.py list
python3 mmc_pkg.py install somepackage
```

## Error Reporting Examples

### NameError - Variable not found:
```
ERROR E202: 'myVariable' အမည်ရှိမရှိ မတွေ့ပါ
  --> mycode.mmc:5
     5 | ပုံနှိပ်(myVariable)
                      ^

    ကျွန်းကြောင်းများ (Suggestions):
    1. 'myVariable' သည် 'my_var' ဖြစ်ပါသလား?
```

### ZeroDivisionError - Division by zero:
```
ERROR E208: MMC အမှား: division by zero
  --> calc.mmc:3
     3 | x = ၁၀ / ၀
                  ^

    ကျွန်းကြောင်းများ (Suggestions):
    1. သွက်လပ်မှု မှာ သုံး (0) ဖြစ်မှုကို စစ်ဆေးပါ
```

### TypeError - Type mismatch:
```
ERROR E203: MMC အမှား: unsupported operand type(s)
  --> app.mmc:7
     7 | ပုံနှိပ်(၁ + "hello")

    ကျွန်းကြောင်းများ (Suggestions):
    1. အရာရည် နှစ်ခုကို တူသော အရာအထိ ဖြတ်လုပ်၍ မရပါ
```

## Files

| File | Description |
|------|-------------|
| mmc_transpiler.py | Core MMC -> Python transpiler (v9.0 Professional) |
| mmc_pkg.py | Package Manager |
| mmc_test.py | Testing Framework |
| mmc_debug.py | Interactive Debugger |
| install.sh | Copy-paste installer |
| stdlib/ | Standard Library (Math, OS, DateTime, Random, JSON, Net) |
| examples/ | 18+ example MMC programs |
| tests/ | Test suite |

## Version Roadmap

### v4.0 - Foundation (Done)
- Variables, Types, Control Flow, Loops, Functions, OOP
- Dictionary, Error Handling, File I/O, Import
- 80+ String/List/Dict Methods, Myanmar Digits

### v5.0 - Package Manager (Done)
- Package Manager, Standard Library, Module System

### v6.0 - Type System (Done)
- Type Hints, Decorators, Generators, Lambda, Comprehensions

### v7.0 - Concurrency (Done)
- Async/Await, Testing Framework, with statement

### v8.0 - Production (Done)
- Source Maps, Debugger, Pass/Global/Nonlocal/Del

### v9.0 - Professional (Done)
- Error Reporting, Traceback Mapper, Semantic Validation
- Lint Mode, Warning System, Multi-error Recovery

### v10.0 - Future (Planned)
- Full AST Parser (no more token-based translation)
- Type Inference Engine
- Code Formatter (mmc fmt)
- Language Server Protocol (LSP) for IDE integration
- Static Type Checker (mmc check)
- Interactive REPL (mmc repl)
- Documentation Generator (mmc doc)
- Performance Optimizer

## GitHub Repository

LLVM-based native compiler: https://github.com/meonnmi-ops/mmc-compiler

## License

MIT License - Free to use, modify, and distribute.
Myanmar Code - Programming in Myanmar Language.
