#!/bin/bash
# MMC AI v9.0 - Professional Edition Installer
# Copy-paste ready for Termux and PC

set -e

echo "============================================"
echo "  MMC v9.0 - Professional Edition Installer"
echo "  Myanmar Code Programming Language"
echo "============================================"
echo ""

# Create install directory
MMC_DIR="$HOME/mmc-ai"
mkdir -p "$MMC_DIR"

# Copy main files
echo "[1/5] Installing transpiler..."
cp mmc_transpiler.py "$MMC_DIR/"

echo "[2/5] Installing tools..."
[ -f mmc_test.py ] && cp mmc_test.py "$MMC_DIR/"
[ -f mmc_pkg.py ] && cp mmc_pkg.py "$MMC_DIR/"
[ -f mmc_debug.py ] && cp mmc_debug.py "$MMC_DIR/"
[ -f mmc_ai_server.py ] && cp mmc_ai_server.py "$MMC_DIR/"

echo "[3/5] Installing standard library..."
mkdir -p "$MMC_DIR/stdlib"
[ -d stdlib ] && cp stdlib/*.py "$MMC_DIR/stdlib/"

echo "[4/5] Installing examples..."
mkdir -p "$MMC_DIR/examples"
[ -d examples ] && cp examples/*.mmc "$MMC_DIR/examples/"

echo "[5/5] Setting up PATH..."
# Add to .bashrc if not already there
if ! grep -q "mmc-ai" "$HOME/.bashrc" 2>/dev/null; then
    echo 'export PATH="$HOME/mmc-ai:$PATH"' >> "$HOME/.bashrc"
    export PATH="$HOME/mmc-ai:$PATH"
fi

echo ""
echo "============================================"
echo "  Installation Complete!"
echo "============================================"
echo ""
echo "Usage:"
echo "  mmc_run <file.mmc>      Run MMC code"
echo "  mmc_compile <file.mmc>  Show Python output"
echo "  mmc_lint <file.mmc>     Check for errors"
echo "  mmc_debug <file.mmc>    Run with full traceback"
echo "  mmc_version             Show version info"
echo "  mmc_keywords            Show all keywords"
echo ""
echo "Or use directly:"
echo "  python3 $MMC_DIR/mmc_transpiler.py run <file.mmc>"
echo "  python3 $MMC_DIR/mmc_transpiler.py lint <file.mmc>"
echo ""
echo "Web IDE:"
echo "  python3 $MMC_DIR/mmc_ai_server.py"
echo "  Open http://localhost:8080"
echo ""
echo "Package Manager:"
echo "  python3 $MMC_DIR/mmc_pkg.py list"
echo "  python3 $MMC_DIR/mmc_pkg.py create mypackage"
echo ""

# Create convenience aliases
alias mmc_run="python3 $MMC_DIR/mmc_transpiler.py run"
alias mmc_compile="python3 $MMC_DIR/mmc_transpiler.py compile"
alias mmc_lint="python3 $MMC_DIR/mmc_transpiler.py lint"
alias mmc_debug="python3 $MMC_DIR/mmc_transpiler.py debug"
alias mmc_version="python3 $MMC_DIR/mmc_transpiler.py version"
alias mmc_keywords="python3 $MMC_DIR/mmc_transpiler.py keywords"
