#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MMC Package Manager v8.0
Manage MMC packages - install, create, publish, list

Usage:
  python mmc_pkg.py install <package>
  python mmc_pkg.py create <name>
  python mmc_pkg.py publish
  python mmc_pkg.py list
  python mmc_pkg.py search <keyword>
  python mmc_pkg.py update
  python mmc_pkg.py init

Author: MyanOS AI Team
Version: 8.0.0
"""

import os
import sys
import json
import shutil
import subprocess
from datetime import datetime

# Package registry URL (local file-based for now)
DEFAULT_REGISTRY = "https://registry.mmc-lang.org"
PKG_DIR = os.path.expanduser("~/.mmc/packages")
PKG_CACHE = os.path.expanduser("~/.mmc/cache")
LOCAL_REGISTRY = os.path.join(PKG_DIR, "registry.json")


def ensure_dirs():
    """Create package directories if needed."""
    os.makedirs(PKG_DIR, exist_ok=True)
    os.makedirs(PKG_CACHE, exist_ok=True)


def init_project(name=None):
    """Initialize a new MMC package project."""
    if not name:
        name = os.path.basename(os.getcwd())

    pkg = {
        "name": name,
        "version": "1.0.0",
        "description": f"{name} - MMC Package",
        "author": "",
        "license": "MIT",
        "main": f"{name}.mmc",
        "keywords": [],
        "dependencies": {},
        "devDependencies": {},
        "exports": [],
        "created": datetime.now().isoformat(),
    }

    with open("mmc_package.json", 'w', encoding='utf-8') as f:
        json.dump(pkg, f, indent=2, ensure_ascii=False)

    # Create standard directories
    os.makedirs("src", exist_ok=True)
    os.makedirs("tests", exist_ok=True)
    os.makedirs("examples", exist_ok=True)

    # Create main file
    main_file = f"{name}.mmc"
    if not os.path.exists(main_file):
        with open(main_file, 'w', encoding='utf-8') as f:
            f.write(f"# {name}\n# {pkg['description']}\n\n")

    print(f"Package '{name}' initialized!")
    print(f"  mmc_package.json created")
    print(f"  src/ tests/ examples/ directories created")
    print(f"  {main_file} created")
    return pkg


def load_package():
    """Load mmc_package.json from current directory."""
    if not os.path.exists("mmc_package.json"):
        print("Error: No mmc_package.json found. Run 'mmc_pkg init' first.")
        sys.exit(1)
    with open("mmc_package.json", 'r', encoding='utf-8') as f:
        return json.load(f)


def install_package(name, version=None):
    """Install an MMC package."""
    ensure_dirs()
    pkg_path = os.path.join(PKG_DIR, name)
    os.makedirs(pkg_path, exist_ok=True)

    print(f"Installing '{name}'{' v' + version if version else ''}...")

    # Check local cache first
    cached = os.path.join(PKG_CACHE, f"{name}-{version or 'latest'}.zip")
    if os.path.exists(cached):
        print(f"  Found in cache: {cached}")
        shutil.unpack_archive(cached, pkg_path)
        print(f"  Installed: {name}")
        return

    # Try git install
    git_urls = [
        f"https://github.com/mmc-packages/{name}.git",
        f"https://github.com/meonnmi-ops/mmc-{name}.git",
    ]

    installed = False
    for url in git_urls:
        try:
            result = subprocess.run(
                ['git', 'clone', '--depth', '1', url, pkg_path],
                capture_output=True, text=True, timeout=30
            )
            if result.returncode == 0:
                print(f"  Cloned from: {url}")
                installed = True
                break
        except (subprocess.TimeoutExpired, FileNotFoundError):
            continue

    if not installed:
        # Create a placeholder package
        os.makedirs(os.path.join(pkg_path, "src"), exist_ok=True)
        placeholder = {
            "name": name,
            "version": version or "1.0.0",
            "installed": datetime.now().isoformat(),
            "source": "placeholder",
        }
        with open(os.path.join(pkg_path, "mmc_package.json"), 'w') as f:
            json.dump(placeholder, f, indent=2)
        print(f"  Created placeholder for '{name}'")
        print(f"  Note: Install from source or add to registry")

    print(f"  Done! Package available at: {pkg_path}")


def create_package(name):
    """Create a new package template."""
    pkg_dir = os.path.join(os.getcwd(), name)
    if os.path.exists(pkg_dir):
        print(f"Error: Directory '{name}' already exists")
        sys.exit(1)

    os.makedirs(pkg_dir)
    os.chdir(pkg_dir)
    init_project(name)
    os.chdir("..")
    print(f"\nPackage created at: {pkg_dir}")


def publish_package():
    """Publish current package (saves to local registry)."""
    pkg = load_package()
    ensure_dirs()

    # Copy to local registry
    reg = {}
    if os.path.exists(LOCAL_REGISTRY):
        with open(LOCAL_REGISTRY, 'r') as f:
            reg = json.load(f)

    pkg["published"] = datetime.now().isoformat()
    reg[pkg["name"]] = pkg

    with open(LOCAL_REGISTRY, 'w', encoding='utf-8') as f:
        json.dump(reg, f, indent=2, ensure_ascii=False)

    print(f"Package '{pkg['name']}' v{pkg['version']} published to local registry")


def list_packages():
    """List installed packages."""
    ensure_dirs()
    if not os.path.exists(PKG_DIR) or not os.listdir(PKG_DIR):
        print("No packages installed.")
        return

    print("Installed MMC Packages:")
    print("-" * 50)
    for name in sorted(os.listdir(PKG_DIR)):
        pkg_file = os.path.join(PKG_DIR, name, "mmc_package.json")
        if os.path.exists(pkg_file):
            with open(pkg_file, 'r') as f:
                info = json.load(f)
            ver = info.get("version", "?")
            desc = info.get("description", "")
            print(f"  {name:20s} v{ver:<8s} {desc}")
        else:
            print(f"  {name}")


def search_packages(keyword):
    """Search packages in local registry."""
    ensure_dirs()
    if not os.path.exists(LOCAL_REGISTRY):
        print("No local registry found. Publish packages first.")
        return

    with open(LOCAL_REGISTRY, 'r') as f:
        reg = json.load(f)

    results = []
    for name, info in reg.items():
        if keyword.lower() in name.lower() or keyword.lower() in str(info.get("description", "")).lower():
            results.append((name, info))

    if not results:
        print(f"No packages found for '{keyword}'")
        return

    print(f"Search results for '{keyword}':")
    print("-" * 50)
    for name, info in results:
        ver = info.get("version", "?")
        desc = info.get("description", "")
        print(f"  {name:20s} v{ver:<8s} {desc}")


def update_package():
    """Update installed packages."""
    ensure_dirs()
    print("Updating all packages...")

    if not os.path.exists(PKG_DIR):
        print("No packages to update.")
        return

    for name in sorted(os.listdir(PKG_DIR)):
        pkg_path = os.path.join(PKG_DIR, name)
        git_dir = os.path.join(pkg_path, ".git")
        if os.path.exists(git_dir):
            try:
                result = subprocess.run(
                    ['git', 'pull'],
                    cwd=pkg_path,
                    capture_output=True, text=True, timeout=15
                )
                if result.returncode == 0:
                    print(f"  Updated: {name}")
                else:
                    print(f"  Failed: {name} - {result.stderr.strip()}")
            except (subprocess.TimeoutExpired, FileNotFoundError):
                print(f"  Skipped: {name}")
        else:
            print(f"  Skipped: {name} (not a git repo)")


def main():
    if len(sys.argv) < 2:
        print("""
MMC Package Manager v8.0

Usage:
  python mmc_pkg.py init                  Initialize package in current dir
  python mmc_pkg.py create <name>         Create new package
  python mmc_pkg.py install <name>        Install package
  python mmc_pkg.py publish               Publish to local registry
  python mmc_pkg.py list                  List installed packages
  python mmc_pkg.py search <keyword>      Search packages
  python mmc_pkg.py update                Update all packages
""")
        sys.exit(0)

    cmd = sys.argv[1]

    if cmd == 'init':
        name = sys.argv[2] if len(sys.argv) > 2 else None
        init_project(name)
    elif cmd == 'create':
        if len(sys.argv) < 3:
            print("Error: Specify package name")
            sys.exit(1)
        create_package(sys.argv[2])
    elif cmd == 'install':
        if len(sys.argv) < 3:
            print("Error: Specify package name")
            sys.exit(1)
        ver = sys.argv[3] if len(sys.argv) > 3 else None
        install_package(sys.argv[2], ver)
    elif cmd == 'publish':
        publish_package()
    elif cmd == 'list':
        list_packages()
    elif cmd == 'search':
        if len(sys.argv) < 3:
            print("Error: Specify search keyword")
            sys.exit(1)
        search_packages(sys.argv[2])
    elif cmd == 'update':
        update_package()
    else:
        print(f"Unknown command: {cmd}")


if __name__ == '__main__':
    main()
