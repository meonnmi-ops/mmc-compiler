#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MMC Test Framework v8.0
Testing framework for Myanmar Code

Keywords:
  စာသေးခံ (assert)          - Assert a condition
  သတိမှတ်ပါ (describe)       - Test group
  တင်သပ်ပါ (it)             - Individual test case
  တွက်ချက်ပါ (expect)        - Expectation
  ပုံ_တိကျ (be_equal)       - Equality check
  ရှိပါ (be_true)           - Truthy check
  မရှိပါ (be_false)         - Falsy check
  ပုံ_နေရာချိန် (be_none)   - None check
  အမြင့်_ပေါ် (be_above)      - Greater than
  အနိမ့်_အောက် (be_below)    - Less than
  အကျရှိ (contain)          - Contains check
  ပုံစံ (match_pattern)     - Pattern match

Usage:
  python mmc_test.py <file.mmc>           Run tests
  python mmc_test.py <file.mmc> --verbose Verbose output
  python mmc_test.py discover              Find all test files

Author: MyanOS AI Team
Version: 8.0.0
"""

import os
import sys
import json
import time
import traceback
import io

# Add transpiler to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from mmc_transpiler import mmc_to_python, run_mmc

# ANSI colors
RED = '\033[91m'
GREEN = '\033[92m'
YELLOW = '\033[93m'
BLUE = '\033[94m'
MAGENTA = '\033[95m'
CYAN = '\033[96m'
RESET = '\033[0m'
BOLD = '\033[1m'

# Test state
_test_suites = []
_current_suite = None
_results = {'passed': 0, 'failed': 0, 'skipped': 0, 'total': 0}
_verbose = False


class MMCExpectation:
    """MMC test expectation wrapper."""

    def __init__(self, value, negate=False):
        self.value = value
        self.negate = negate

    def _check(self, result, message):
        if self.negate:
            ok = not result
        else:
            ok = result
        _results['total'] += 1
        if ok:
            _results['passed'] += 1
            return True
        else:
            _results['failed'] += 1
            return False

    def ပုံ_တိကျ(self, other, msg=""):
        r = self.value == other
        if not self._check(r, msg):
            print(f"    {RED}Expected {self.value!r} {'!=' if self.negate else '=='} {other!r}{RESET}")
            if msg:
                print(f"    {RED}{msg}{RESET}")
        return self

    def ရှိပါ(self, msg=""):
        r = bool(self.value)
        if not self._check(r, msg):
            print(f"    {RED}Expected {self.value!r} to be truthy{RESET}")
        return self

    def မရှိပါ(self, msg=""):
        r = not bool(self.value)
        if not self._check(r, msg):
            print(f"    {RED}Expected {self.value!r} to be falsy{RESET}")
        return self

    def ပုံ_နေရာချိန်(self, msg=""):
        r = self.value is None
        if not self._check(r, msg):
            print(f"    {RED}Expected {self.value!r} to be None{RESET}")
        return self

    def အမြင့်_ပေါ်(self, other, msg=""):
        r = self.value > other
        if not self._check(r, msg):
            print(f"    {RED}Expected {self.value!r} > {other!r}{RESET}")
        return self

    def အနိမ့်_အောက်(self, other, msg=""):
        r = self.value < other
        if not self._check(r, msg):
            print(f"    {RED}Expected {self.value!r} < {other!r}{RESET}")
        return self

    def အကျရှိ(self, other, msg=""):
        r = other in self.value
        if not self._check(r, msg):
            print(f"    {RED}Expected {other!r} in {self.value!r}{RESET}")
        return self

    def ပုံစံ(self, pattern, msg=""):
        if hasattr(pattern, 'search'):
            r = bool(pattern.search(str(self.value)))
        else:
            r = pattern in str(self.value)
        if not self._check(r, msg):
            print(f"    {RED}Expected {self.value!r} to match {pattern!r}{RESET}")
        return self

    def ရှိပြီး(self, exc_type, msg=""):
        """Check that value raises an exception."""
        try:
            if callable(self.value):
                self.value()
            r = False
        except exc_type:
            r = True
        except Exception:
            r = False
        if not self._check(r, msg):
            print(f"    {RED}Expected {self.value!r} to raise {exc_type.__name__}{RESET}")
        return self


def တွက်ချက်ပါ( value):
    """Create an expectation."""
    return MMCExpectation(value)


def မ_တွက်ချက်ပါ(value):
    """Create a negated expectation."""
    return MMCExpectation(value, negate=True)


class TestSuite:
    """MMC test suite."""

    def __init__(self, name):
        self.name = name
        self.tests = []
        self.setup_fn = None
        self.teardown_fn = None

    def တင်သပ်ပါ(self, name):
        """Register a test case."""
        def decorator(fn):
            self.tests.append((name, fn))
            return fn
        return decorator

    def တွေ့ငွေ(self, fn):
        """Setup function."""
        self.setup_fn = fn
        return fn

    def ပြီးဆုံး(self, fn):
        """Teardown function."""
        self.teardown_fn = fn
        return fn

    def run(self):
        """Run all tests in this suite."""
        global _results
        print(f"\n  {BOLD}{BLUE}{self.name}{RESET}")

        if self.setup_fn:
            try:
                self.setup_fn()
            except Exception as e:
                print(f"    {RED}Setup failed: {e}{RESET}")
                return

        passed = 0
        failed = 0
        start = time.time()

        for name, fn in self.tests:
            try:
                fn()
                passed += 1
                status = f"{GREEN}PASS{RESET}"
                if _verbose:
                    print(f"    {status} {name} ({time.time() - start:.3f}s)")
            except AssertionError as e:
                failed += 1
                status = f"{RED}FAIL{RESET}"
                print(f"    {status} {name}: {e}")
            except Exception as e:
                failed += 1
                status = f"{RED}ERROR{RESET}"
                print(f"    {status} {name}: {type(e).__name__}: {e}")
                if _verbose:
                    traceback.print_exc()

        if self.teardown_fn:
            try:
                self.teardown_fn()
            except Exception as e:
                print(f"    {RED}Teardown failed: {e}{RESET}")

        total = passed + failed
        color = GREEN if failed == 0 else RED
        print(f"    {color}{passed}/{total} passed{RESET}")
        return passed, failed


def သတိမှတ်ပါ(name):
    """Create a test suite."""
    global _current_suite
    suite = TestSuite(name)
    _current_suite = suite
    _test_suites.append(suite)
    return suite


def run_mmc_tests(source):
    """Run MMC test code."""
    py_code = mmc_to_python(source)

    # Prepend test framework imports
    framework_code = f"""
import sys, os
sys.path.insert(0, {os.path.dirname(os.path.abspath(__file__))!r})
from mmc_test import သတိမှတ်ပါ, တင်သပ်ပါ, တွက်ချက်ပါ, မ_တွက်ချက်ပါ

"""

    old_out = sys.stdout
    old_err = sys.stderr
    sys.stdout = out_buf = io.StringIO()
    sys.stderr = err_buf = io.StringIO()

    global _test_suites, _results, _verbose
    _test_suites = []
    _results = {'passed': 0, 'failed': 0, 'skipped': 0, 'total': 0}

    try:
        exec(framework_code + py_code, {'__name__': '__test__'})
        # Run all suites
        for suite in _test_suites:
            suite.run()
    except Exception as e:
        err_buf.write(f"{type(e).__name__}: {e}\n")
        traceback.print_exc(file=err_buf)

    sys.stdout = old_out
    sys.stderr = old_err

    output = out_buf.getvalue()
    error = err_buf.getvalue()
    return output, error, _results


def run_file(filepath):
    """Run MMC test file."""
    with open(filepath, 'r', encoding='utf-8') as f:
        source = f.read()

    print(f"\n{BOLD}MMC Test Runner v8.0{RESET}")
    print(f"File: {filepath}")
    print("=" * 60)

    output, error, results = run_mmc_tests(source)

    if output:
        print(output)

    if error:
        print(f"{RED}{error}{RESET}")

    # Summary
    print(f"\n{'=' * 60}")
    total = results['passed'] + results['failed']
    color = GREEN if results['failed'] == 0 else RED
    print(f"{color}{BOLD}Results: {results['passed']}/{total} passed{RESET}")

    if results['failed'] > 0:
        return 1
    return 0


def discover_tests(directory='.'):
    """Discover and run all test files."""
    print(f"\n{BOLD}MMC Test Discovery{RESET}")
    print("=" * 60)

    test_files = []
    for root, dirs, files in os.walk(directory):
        for f in files:
            if f.endswith('_test.mmc') or f.endswith('test.mmc') or f.startswith('test_'):
                test_files.append(os.path.join(root, f))

    if not test_files:
        print("No test files found.")
        return 0

    print(f"Found {len(test_files)} test file(s):\n")

    all_passed = True
    for f in sorted(test_files):
        rc = run_file(f)
        if rc != 0:
            all_passed = False

    return 0 if all_passed else 1


def main():
    global _verbose

    if len(sys.argv) < 2:
        print("""
MMC Test Framework v8.0

Usage:
  python mmc_test.py <file.mmc>           Run test file
  python mmc_test.py discover             Discover and run all tests
  python mmc_test.py <file.mmc> --verbose Verbose output

MMC Test Keywords:
  သတိမှတ်ပါ("name")           Test suite
  တင်သပ်ပါ("name")             Test case
  တွက်ချက်ပါ( value)            Expectation
  မ_တွက်ချက်ပါ(value)           Negated expectation
  စာသေးခံ condition          Assert
  ပုံ_တိကျ (be_equal)
  ရှိပါ (be_true)
  မရှိပါ (be_false)
  ပုံ_နေရာချိန် (be_none)
  အမြင့်_ပေါ် (be_above)
  အနိမ့်_အောက် (be_below)
  အကျရှိ (contain)
""")
        sys.exit(0)

    if '--verbose' in sys.argv or '-v' in sys.argv:
        _verbose = True
        sys.argv = [a for a in sys.argv if a not in ('--verbose', '-v')]

    cmd = sys.argv[1]

    if cmd == 'discover':
        directory = sys.argv[2] if len(sys.argv) > 2 else '.'
        sys.exit(discover_tests(directory))
    elif cmd.endswith('.mmc'):
        sys.exit(run_file(cmd))
    else:
        print(f"Unknown command: {cmd}")
        sys.exit(1)


if __name__ == '__main__':
    main()
