#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MMC Stdlib - အသစ်ပြောင်း (Random Module)
Myanmar Code Standard Library - Random Numbers

Usage in MMC:
  တင်သွင်း မှ mmc_stdlib.အသစ်ပြောင်း အဖြစ် မက်

Provides:
  အသစ် (random), အသစ်_ပေါင်း (randint),
  ရွေးချယ် (choice), ရွေးချယ်_စာရင်း (choices),
  ပြောင်း (shuffle), အသစ်_ရွေး (sample),
  အသစ်_လော့ဂရစ်သမ် (random_float),
  အသစ်_စာရင်း (random_list),
  ခန့်မှန်း (uniform)
"""

import random as _random


def အသစ် ():
    """Random float between 0 and 1."""
    return _random.random()

def အသစ်_ပေါင်း (start, end):
    """Random integer between start and end (inclusive)."""
    return _random.randint(start, end)

def အသစ်_လော့ဂရစ်သမ် (start=0.0, end=1.0):
    """Random float between start and end."""
    return _random.uniform(start, end)

def ရွေးချယ် (seq):
    """Choose random element from sequence."""
    return _random.choice(seq)

def ရွေးချယ်_စာရင်း (seq, k=1):
    """Choose k elements with replacement."""
    return _random.choices(seq, k=k)

def ရွေးချယ်_မတူ (seq, k=1):
    """Choose k unique elements."""
    return _random.sample(seq, k=k)

def ပြောင်း (seq):
    """Shuffle sequence in place."""
    return _random.shuffle(seq)

def ခန့်မှန်း (start, end):
    """Random float uniformly distributed."""
    return _random.uniform(start, end)


def အသစ်_စာရင်း (n, start=0, end=100):
    """Generate list of n random integers."""
    return [_random.randint(start, end) for _ in range(n)]


def အသစ်_ဆုံး_ပေါင်း (seq, k=None):
    """Randomly reorder (return new list)."""
    if k is None:
        k = len(seq)
    return _random.sample(seq, k=k)


def အချိန်း ():
    """Random float triangular distribution."""
    return _random.triangular(0, 1)


def အမှန်_သတိမှတ် ():
    """Get/set random seed."""
    return _random.seed


def အတွေ့ (population, weights, k=1):
    """Weighted random choices."""
    return _random.choices(population, weights=weights, k=k)


__all__ = [
    'အသစ်', 'အသစ်_ပေါင်း', 'အသစ်_လော့ဂရစ်သမ်',
    'ရွေးချယ်', 'ရွေးချယ်_စာရင်း', 'ရွေးချယ်_မတူ',
    'ပြောင်း', 'ခန့်မှန်း',
    'အသစ်_စာရင်း', 'အသစ်_ဆုံး_ပေါင်း',
    'အချိန်း', 'အမှန်_သတိမှတ်', 'အတွေ့',
]
