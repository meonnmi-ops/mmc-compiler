#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MMC Stdlib - စွမ်းအင် (Math Module)
Myanmar Code Standard Library - Mathematics

Usage in MMC:
  တင်သွင်း မှ mmc_stdlib.စွမ်းအင် အဖြစ် မက်

Provides:
  PI, E, TAU, INF, NAN
  ပြီးချင်း (sqrt), ရပ်အထိ (abs), ပမာဏ (ceil),
  ကုန် (floor), ပေါင်း (round), အားလုံး (pow),
  လွန်ချက် (log), လွန်ချက်_၁၀ (log10),
  အကြောင်း (sin), ကြည့် (cos), သကြား (tan),
  ခံ_အကြောင်း (asin), ခံ_ကြည့် (acos), ခံ_သကြား (atan),
  အမြင့်ဆုံး (max), အနိမ့်ဆုံး (min),
  ကွက်လပ် (factorial), စစ်_ဆက် (gcd),
  အရေအတွက် (comb), အရွယ်_အတွက် (perm),
  အကုန် (trunc), သင်္ချာ (fabs),
  သေး_ဆုံး (fmod), ခန့်မှန်း (remainder)
"""

import math as _math

# Constants
PI = _math.pi
E = _math.e
TAU = _math.tau
INF = _math.inf
NAN = _math.nan


# Core functions
def ပြီးချင်း(x):
    """Square root."""
    return _math.sqrt(x)

def ရပ်အထိ(x):
    """Absolute value."""
    return abs(x)

def ပမာဏ(x):
    """Ceiling."""
    return _math.ceil(x)

def ကုန်(x):
    """Floor."""
    return _math.floor(x)

def ပေါင်း(x, n=0):
    """Round to n decimal places."""
    return round(x, n)

def အားလုံး(base, exp):
    """Power."""
    return _math.pow(base, exp)

def လွန်ချက်(x, base=_math.e):
    """Logarithm."""
    return _math.log(x, base)

def လွန်ချက်_၁၀(x):
    """Base-10 logarithm."""
    return _math.log10(x)

def လွန်ချက်_၂(x):
    """Base-2 logarithm."""
    return _math.log2(x)


# Trigonometry
def အကြောင်း(x):
    """Sine."""
    return _math.sin(x)

def ကြည့်(x):
    """Cosine."""
    return _math.cos(x)

def သကြား(x):
    """Tangent."""
    return _math.tan(x)

def ခံ_အကြောင်း(x):
    """Arc sine."""
    return _math.asin(x)

def ခံ_ကြည့်(x):
    """Arc cosine."""
    return _math.acos(x)

def ခံ_သကြား(x):
    """Arc tangent."""
    return _math.atan(x)

def အကြောင်း_မြင့် (x):
    """Hyperbolic sine."""
    return _math.sinh(x)

def ကြည့်_မြင့် (x):
    """Hyperbolic cosine."""
    return _math.cosh(x)


# Combinatorics
def ကွက်လပ်(n):
    """Factorial."""
    return _math.factorial(n)

def စစ်_ဆက်(a, b):
    """Greatest common divisor."""
    return _math.gcd(a, b)

def ပိုင်ဆက်(a, b):
    """Least common multiple."""
    return _math.lcm(a, b)

def အရေအတွက်(n, k):
    """Combinations."""
    return _math.comb(n, k)

def အရွယ်_အတွက်(n, k):
    """Permutations."""
    return _math.perm(n, k)


# Number theory
def အကုန်(x):
    """Truncate toward zero."""
    return _math.trunc(x)

def သင်္ချာ(x):
    """Absolute value (float)."""
    return _math.fabs(x)

def သေး_ဆုံး(x, y):
    """Float modulus."""
    return _math.fmod(x, y)

def ခန့်မှန်း(x, y):
    """Remainder."""
    return _math.remainder(x, y)

def ကိုယ်ပိုင်_မှတ်(x):
    """Is finite?"""
    return _math.isfinite(x)

def အကြီးလွယ်ကူ (x):
    """Is infinite?"""
    return _math.isinf(x)

def အမှန်တရား (x):
    """Is NaN?"""
    return _math.isnan(x)

def အရည်အသွေး(x):
    """Is close (floating point comparison)."""
    return _math.isclose(x)


# Angle conversion
def ဒီဂရီ_ရှိ (degrees):
    """Degrees to radians."""
    return _math.radians(degrees)

def ရဲဒီဂရီ (radians):
    """Radians to degrees."""
    return _math.degrees(radians)


__all__ = [
    'PI', 'E', 'TAU', 'INF', 'NAN',
    'ပြီးချင်း', 'ရပ်အထိ', 'ပမာဏ', 'ကုန်', 'ပေါင်း',
    'အားလုံး', 'လွန်ချက်', 'လွန်ချက်_၁၀', 'လွန်ချက်_၂',
    'အကြောင်း', 'ကြည့်', 'သကြား',
    'ခံ_အကြောင်း', 'ခံ_ကြည့်', 'ခံ_သကြား',
    'ကွက်လပ်', 'စစ်_ဆက်', 'ပိုင်ဆက်',
    'အရေအတွက်', 'အရွယ်_အတွက်',
    'ဒီဂရီ_ရှိ', 'ရဲဒီဂရီ',
]
