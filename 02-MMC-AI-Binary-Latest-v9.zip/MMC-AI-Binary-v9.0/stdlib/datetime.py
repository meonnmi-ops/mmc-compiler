#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MMC Stdlib - အချိန်_ကိရိယာ (DateTime Module)
Myanmar Code Standard Library - Date and Time

Usage in MMC:
  တင်သွင်း မှ mmc_stdlib.အချိန်_ကိရိယာ အဖြစ် မက်

Provides:
  လက်ရှိ (now), ပြောင်း (format), ဖော်ပြ (parse),
  ရေဒီ (add_days), နံရံ (subtract),
  အချိန် (time_only), ရက်စွဲ (date_only),
  ပတ်_အရေကြီး (diff), အချိန်_ပြဿနာ (timer)
"""

import datetime as _dt
import time as _time


def လက်ရှိ ():
    """Get current date and time."""
    return _dt.datetime.now()

def လက်ရှိ_ရက် ():
    """Get current date only."""
    return _dt.date.today()

def အချိန်_လိုက် ():
    """Get current time."""
    return _dt.datetime.now().time()

def အချိန်_ရက် (year, month, day, hour=0, minute=0, second=0):
    """Create a specific date/time."""
    return _dt.datetime(year, month, day, hour, minute, second)


def ပြောင်း (dt=None, fmt="%Y-%m-%d %H:%M:%S"):
    """Format date/time to string."""
    if dt is None:
        dt = _dt.datetime.now()
    return dt.strftime(fmt)

def ဖော်ပြ (date_str, fmt="%Y-%m-%d"):
    """Parse string to datetime."""
    return _dt.datetime.strptime(date_str, fmt)


def ရေဒီ (dt, days=0, hours=0, minutes=0, seconds=0):
    """Add time to a datetime."""
    delta = _dt.timedelta(days=days, hours=hours, minutes=minutes, seconds=seconds)
    return dt + delta

def နံရံ (dt1, dt2):
    """Subtract two datetimes. Returns timedelta."""
    return dt2 - dt1

def ပတ်_အရေကြီး (dt1, dt2):
    """Get difference in seconds."""
    return abs((dt2 - dt1).total_seconds())

def ပတ်_ရက် (dt1, dt2):
    """Get difference in days."""
    return abs((dt2 - dt1).days)


def ရက်_အမည် (dt, lang="my"):
    """Get day name."""
    names_en = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    names_my = ["တနင်္လာ", "အင်္ဂလာ", "ဗုဒ္ဓဟူး", "ကြာသပတေး", "သပတေး", "သောကြာ", "ငနောက်"]
    names = names_my if lang == "my" else names_en
    return names[dt.weekday()]

def လ_အမည် (dt, lang="my"):
    """Get month name."""
    names_en = ["January", "February", "March", "April", "May", "June",
                "July", "August", "September", "October", "November", "December"]
    names_my = ["ဇန်နဝါရီ", "ဖေဖော်ဝါရီ", "မတ်", "ဧပြီ", "မေ", "ဇွန်",
                "ဇူလိုင်း", "သြဂုတ်", "စက်တင်ဘာ", "အောက်တိုဘာ", "နိုဝင်ဘာ", "ဒီဇင်ဘာ"]
    names = names_my if lang == "my" else names_en
    return names[dt.month - 1]


def နောက်ဆုံး_ပြောင်း (seconds, fmt=None):
    """Format seconds to human-readable string."""
    seconds = int(seconds)
    days = seconds // 86400
    hours = (seconds % 86400) // 3600
    minutes = (seconds % 3600) // 60
    secs = seconds % 60

    parts = []
    if days:
        parts.append(f"{days}d")
    if hours:
        parts.append(f"{hours}h")
    if minutes:
        parts.append(f"{minutes}m")
    if secs:
        parts.append(f"{secs}s")

    return " ".join(parts) if parts else "0s"


class အချိန်_ပြဿနာ:
    """Timer context manager for measuring time."""

    def __enter__(self):
        self.start = _time.perf_counter()
        return self

    def __exit__(self, *args):
        self.end = _time.perf_counter()
        self.elapsed = self.end - self.start

    def __repr__(self):
        return f"{self.elapsed:.4f}s"


def အချိန်_ရောင် ():
    """Sleep for seconds."""
    return _time.sleep

def ကျေးဇူး_ပြီး ():
    """Get high-resolution timestamp."""
    return _time.perf_counter()


# Myanmar calendar helpers
def မြန်မာ_နှစ် ():
    """Get approximate Myanmar year."""
    return _dt.datetime.now().year - 638

def မြန်မာ_လ (month):
    """Get Myanmar month names."""
    months = ["ကော်မတီ", "ပုံးသီ", "နွေးကျော်", "ဝတ်ဆ", "နေါက်လ", "ပုဒ်သွေး",
              "နွေးထွေး", "ဝတ်ထုတ်", "ပုဒ်ည", "ကျားသွေး", "နိုဝင်ထုတ်", "ပုဒ်သီ"]
    return months[month - 1] if 1 <= month <= 12 else ""


__all__ = [
    'လက်ရှိ', 'လက်ရှိ_ရက်', 'အချိန်_လိုက်', 'အချိန်_ရက်',
    'ပြောင်း', 'ဖော်ပြ', 'ရေဒီ', 'နံရံ',
    'ပတ်_အရေကြီး', 'ပတ်_ရက်',
    'ရက်_အမည်', 'လ_အမည်', 'နောက်ဆုံး_ပြောင်း',
    'အချိန်_ပြဿနာ', 'အချိန်_ရောင်', 'ကျေးဇူး_ပြီး',
    'မြန်မာ_နှစ်', 'မြန်မာ_လ',
]
