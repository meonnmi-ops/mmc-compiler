#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MMC Stdlib - သတင်းစာ (JSON Module)
Myanmar Code Standard Library - JSON Handling

Usage in MMC:
  တင်သွင်း မှ mmc_stdlib.သတင်းစာ အဖြစ် မက်

Provides:
  ဖော်ပြ (dumps), ဖော်ပြ_ဖိုင် (dump),
  ဖွင့် (loads), ဖွင့်_ဖိုင် (load),
  အတည်_ဖော်ပြ (pretty)
"""

import json as _json


def ဖော်ပြ (obj, ensure_ascii=False, indent=None):
    """Serialize object to JSON string."""
    return _json.dumps(obj, ensure_ascii=ensure_ascii, indent=indent, default=str)

def ဖော်ပြ_အတည် (obj):
    """Pretty print JSON."""
    return _json.dumps(obj, ensure_ascii=False, indent=4, default=str)

def ဖွင့် (text):
    """Parse JSON string to object."""
    return _json.loads(text)

def ဖော်ပြ_ဖိုင် (obj, filepath, ensure_ascii=False):
    """Write JSON to file."""
    with open(filepath, 'w', encoding='utf-8') as f:
        _json.dump(obj, f, ensure_ascii=ensure_ascii, indent=4, default=str)

def ဖွင့်_ဖိုင် (filepath):
    """Read JSON from file."""
    with open(filepath, 'r', encoding='utf-8') as f:
        return _json.load(f)


__all__ = ['ဖော်ပြ', 'ဖော်ပြ_အတည်', 'ဖွင့်', 'ဖော်ပြ_ဖိုင်', 'ဖွင့်_ဖိုင်']
