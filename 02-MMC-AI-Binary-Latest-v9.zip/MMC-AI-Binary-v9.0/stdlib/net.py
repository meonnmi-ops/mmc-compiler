#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MMC Stdlib - ကွန်ပျူတာ (Network/HTTP Module)
Myanmar Code Standard Library - HTTP Requests

Usage in MMC:
  တင်သွင်း မှ mmc_stdlib.ကွန်ပျူတာ အဖြစ် မက်

Provides:
  ဖွင့် (get), ထိုင် (post), ပြောင်း (put),
  ဖျက်ပါ (delete), ခေါ် (fetch),
  ဖော်ပြ_ခံ (status_code), ဖော်ပြ_အကြောင်း (headers),
  ဖော်ပြ_အရာ (body)
"""

import urllib.request as _urllib_request
import urllib.parse as _urllib_parse
import urllib.error as _urllib_error
import json as _json


class ဖော်ပြ_ပြဿနာ:
    """HTTP Response object."""

    def __init__(self, status, headers, body, url=""):
        self.status = status
        self.ခေါ်ဆိုပါ = status
        self.headers = headers
        self.ခံ_အကြောင်း = headers
        self.body = body
        self.အရာ = body
        self.url = url
        self.လမ်းညွှန် = url

    def __repr__(self):
        return f"Response({self.status}, {self.url})"

    def ထိုင်ရှိ (self):
        """Is successful (2xx)?"""
        return 200 <= self.status < 300

    def ဖွင့်_သတင်းစာ (self):
        """Parse body as JSON."""
        return _json.loads(self.body)

    def စာသား (self):
        """Get body as string."""
        return self.body

    def __bool__(self):
        return self.ထိုင်ရှိ()


def ခေါ် (url, method="GET", data=None, headers=None, timeout=30):
    """Generic fetch function."""
    if headers is None:
        headers = {}

    if data and isinstance(data, dict):
        data = _json.dumps(data).encode('utf-8')
        headers['Content-Type'] = 'application/json'

    req = _urllib_request.Request(url, data=data, headers=headers, method=method)

    try:
        with _urllib_request.urlopen(req, timeout=timeout) as resp:
            body = resp.read().decode('utf-8', errors='replace')
            resp_headers = dict(resp.getheaders())
            return ဖော်ပြ_ပြဿနာ(resp.status, resp_headers, body, url)
    except _urllib_error.HTTPError as e:
        body = e.read().decode('utf-8', errors='replace') if e.fp else str(e)
        return ဖော်ပြ_ပြဿနာ(e.code, {}, body, url)
    except Exception as e:
        return ဖော်ပြ_ပြဿနာ(0, {}, str(e), url)


def ဖွင့် (url, params=None, headers=None, timeout=30):
    """HTTP GET request."""
    if params:
        url = url + "?" + _urllib_parse.urlencode(params)
    return ခေါ်(url, "GET", headers=headers, timeout=timeout)


def ထိုင် (url, data=None, json_data=None, headers=None, timeout=30):
    """HTTP POST request."""
    if json_data:
        payload = _json.dumps(json_data).encode('utf-8')
        h = headers or {}
        h['Content-Type'] = 'application/json'
        return ခေါ်(url, "POST", data=payload, headers=h, timeout=timeout)
    return ခေါ်(url, "POST", data=data, headers=headers, timeout=timeout)


def ပြောင်း (url, data=None, json_data=None, headers=None, timeout=30):
    """HTTP PUT request."""
    if json_data:
        payload = _json.dumps(json_data).encode('utf-8')
        h = headers or {}
        h['Content-Type'] = 'application/json'
        return ခေါ်(url, "PUT", data=payload, headers=h, timeout=timeout)
    return ခေါ်(url, "PUT", data=data, headers=headers, timeout=timeout)


def ဖျက်ပါ (url, headers=None, timeout=30):
    """HTTP DELETE request."""
    return ခေါ်(url, "DELETE", headers=headers, timeout=timeout)


def ပုံ_ပြောင်း (url, params):
    """Build URL with query parameters."""
    return url + "?" + _urllib_parse.urlencode(params)


__all__ = [
    'ခေါ်', 'ဖွင့်', 'ထိုင်', 'ပြောင်း', 'ဖျက်ပါ',
    'ပုံ_ပြောင်း', 'ဖော်ပြ_ပြဿနာ',
]
