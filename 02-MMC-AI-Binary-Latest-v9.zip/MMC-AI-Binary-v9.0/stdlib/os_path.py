#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MMC Stdlib - လမ်းညွှန် (OS/Path Module)
Myanmar Code Standard Library - Operating System & File Paths

Usage in MMC:
  တင်သွင်း မှ mmc_stdlib.လမ်းညွှန် အဖြစ် မက်

Provides:
  လမ်းညွှန် (path), ဖိုင်_ရှဲ (dirname), ဖိုင်_အမည် (basename),
  ပြောင်း (rename), ဖျက် (remove), ဖိုင်ရှဲ (makedirs),
  စာရင်း (listdir), ရှိမရှိ (exists), ဖိုင်ဖတ် (read_file),
  ဖိုင်ရေး (write_file), လမ်း_လေ့လာ (walk),
  လက်ရှိ_လမ်းညွှန် (cwd), လမ်းညွှန်_ပြောင်း (chdir),
  ဖိုင်_အရေကြီး (filesize)
"""

import os as _os
import shutil as _shutil


# Path operations
def လမ်းညွှန်(*parts):
    """Join path parts."""
    return _os.path.join(*parts)

def ဖိုင်_ရှဲ(path):
    """Get directory name."""
    return _os.path.dirname(path)

def ဖိုင်_အမည်(path):
    """Get base file name."""
    return _os.path.basename(path)

def ဖိုင်_ထိုင် (path):
    """Get file extension."""
    return _os.path.splitext(path)[1]

def လမ်းညွှန်_ပေါင်း (old, new):
    """Rename file or directory."""
    return _os.rename(old, new)


# File operations
def ဖျက်(path):
    """Remove file."""
    return _os.remove(path)

def ဖိုင်ရှဲ (path):
    """Create directories recursively."""
    return _os.makedirs(path, exist_ok=True)

def ဖိုင်_ချိုး (path):
    """Remove directory."""
    return _os.rmdir(path)

def ဖိုင်_ချိုး_အားလုံး (path):
    """Remove directory tree."""
    return _shutil.rmtree(path, ignore_errors=True)

def ပြောင်း (src, dst):
    """Copy file."""
    return _shutil.copy2(src, dst)

def ပြောင်း_လမ်းညွှန် (src, dst):
    """Copy directory tree."""
    return _shutil.copytree(src, dst)


# Directory listing
def စာရင်း (path="."):
    """List directory contents."""
    return _os.listdir(path)

def လမ်း_လေ့လာ (path="."):
    """Walk directory tree (returns list of all files)."""
    result = []
    for root, dirs, files in _os.walk(path):
        for f in files:
            result.append(_os.path.join(root, f))
    return result


# File info
def ရှိမရှိ (path):
    """Check if path exists."""
    return _os.path.exists(path)

def ဖိုင်_ဖြစ် (path):
    """Check if path is a file."""
    return _os.path.isfile(path)

def ဖိုင်ရှဲ_ဖြစ် (path):
    """Check if path is a directory."""
    return _os.path.isdir(path)

def ဖိုင်_အရေကြီး (path):
    """Get file size in bytes."""
    return _os.path.getsize(path)

def ဖိုင်_ပြောင်း (path):
    """Get last modification time."""
    return _os.path.getmtime(path)


# Working directory
def လက်ရှိ_လမ်းညွှန် ():
    """Get current working directory."""
    return _os.getcwd()

def လမ်းညွှန်_ပြောင်း (path):
    """Change working directory."""
    return _os.chdir(path)


# File read/write (high-level)
def ဖိုင်ဖတ် (path, encoding="utf-8"):
    """Read entire file as string."""
    with open(path, 'r', encoding=encoding) as f:
        return f.read()

def ဖိုင်ဖတ်_စာရင်း (path, encoding="utf-8"):
    """Read file as list of lines."""
    with open(path, 'r', encoding=encoding) as f:
        return f.readlines()

def ဖိုင်ရေး (path, content, encoding="utf-8"):
    """Write string to file."""
    with open(path, 'w', encoding=encoding) as f:
        f.write(content)

def ဖိုင်_ထည့် (path, content, encoding="utf-8"):
    """Append to file."""
    with open(path, 'a', encoding=encoding) as f:
        f.write(content)


# Environment
def ပတ်ဝန်းကျင် (name, default=None):
    """Get environment variable."""
    return _os.environ.get(name, default)

def ပတ်ဝန်းကျင်_ထည့် (name, value):
    """Set environment variable."""
    _os.environ[name] = value


__all__ = [
    'လမ်းညွှန်', 'ဖိုင်_ရှဲ', 'ဖိုင်_အမည်', 'ဖိုင်_ထိုင်',
    'ဖျက်', 'ဖိုင်ရှဲ', 'ဖိုင်_ချိုး', 'ပြောင်း',
    'စာရင်း', 'လမ်း_လေ့လာ',
    'ရှိမရှိ', 'ဖိုင်_ဖြစ်', 'ဖိုင်ရှဲ_ဖြစ်',
    'ဖိုင်_အရေကြီး', 'ဖိုင်_ပြောင်း',
    'လက်ရှိ_လမ်းညွှန်', 'လမ်းညွှန်_ပြောင်း',
    'ဖိုင်ဖတ်', 'ဖိုင်ဖတ်_စာရင်း', 'ဖိုင်ရေး', 'ဖိုင်_ထည့်',
    'ပတ်ဝန်းကျင်', 'ပတ်ဝန်းကျင်_ထည့်',
]
