#!/usr/bin/env bash
# ================================================================
#   MMC AI - Quick Setup for Termux / PC
#   One-command setup for Ollama + MMC AI Model
# ================================================================

echo ""
echo "  ╔══════════════════════════════════════╗"
echo "  ║   MMC AI - Quick Setup              ║"
echo "  ║   Myanmar Code AI for Ollama        ║"
echo "  ╚══════════════════════════════════════╝"
echo ""

# Detect platform
PLATFORM="unknown"
if [ -n "$TERMUX_VERSION" ]; then
    PLATFORM="termux"
elif [ "$(uname -s)" = "Linux" ]; then
    PLATFORM="linux"
elif [ "$(uname -s)" = "Darwin" ]; then
    PLATFORM="macos"
fi

echo "  Platform: $PLATFORM"
echo ""

# Step 1: Install Ollama
echo "  [1/4] Installing Ollama..."

if command -v ollama &> /dev/null; then
    echo "  [OK] Ollama already installed"
else
    case $PLATFORM in
        termux)
            echo "  Installing Ollama for Termux..."
            pkg install ollama -y 2>/dev/null || {
                echo "  [!] Termux package not available"
                echo "  Installing from GitHub..."
                curl -fsSL https://ollama.com/install.sh | sh
            }
            ;;
        linux)
            echo "  Installing Ollama for Linux..."
            curl -fsSL https://ollama.com/install.sh | sh
            ;;
        macos)
            echo "  Installing Ollama for macOS..."
            curl -fsSL https://ollama.com/install.sh | sh
            ;;
        *)
            echo "  [!] Unknown platform. Install Ollama manually:"
            echo "  https://ollama.com/download"
            exit 1
            ;;
    esac
fi

# Step 2: Start Ollama
echo ""
echo "  [2/4] Starting Ollama..."

if curl -s http://localhost:11434/api/tags > /dev/null 2>&1; then
    echo "  [OK] Ollama is running"
else
    if [ "$PLATFORM" = "termux" ]; then
        ollama serve > /dev/null 2>&1 &
        sleep 3
    else
        # Try systemctl first
        if command -v systemctl &> /dev/null; then
            sudo systemctl start ollama 2>/dev/null || ollama serve > /dev/null 2>&1 &
        else
            ollama serve > /dev/null 2>&1 &
        fi
        sleep 3
    fi

    if curl -s http://localhost:11434/api/tags > /dev/null 2>&1; then
        echo "  [OK] Ollama started"
    else
        echo "  [!] Ollama might need manual start"
        echo "  Run: ollama serve"
    fi
fi

# Step 3: Download base model
echo ""
echo "  [3/4] Downloading base model (Qwen2.5 1.5B)..."

if ollama list 2>/dev/null | grep -q "qwen2.5:1.5b"; then
    echo "  [OK] Base model already exists"
else
    ollama pull qwen2.5:1.5b
fi

# Step 4: Create MMC AI model
echo ""
echo "  [4/4] Creating MMC AI model..."

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

if [ -f "$SCRIPT_DIR/Modelfile" ]; then
    # Create model from local Modelfile
    cd "$SCRIPT_DIR"

    # Update Modelfile FROM to use downloaded model
    if grep -q "qwen2.5:1.5b" "$SCRIPT_DIR/Modelfile" 2>/dev/null; then
        : # already correct
    elif grep -q "FROM" "$SCRIPT_DIR/Modelfile" 2>/dev/null; then
        sed -i 's|FROM .*|FROM qwen2.5:1.5b|' "$SCRIPT_DIR/Modelfile" 2>/dev/null || \
        sed -i '' 's|FROM .*|FROM qwen2.5:1.5b|' "$SCRIPT_DIR/Modelfile" 2>/dev/null
    fi

    ollama create mmc-ai -f "$SCRIPT_DIR/Modelfile"
else
    # Create inline model
    ollama create mmc-ai -f - <<'MODELEOF'
FROM qwen2.5:1.5b

PARAMETER temperature 0.6
PARAMETER num_ctx 8192
PARAMETER repeat_penalty 1.15
PARAMETER top_k 40
PARAMETER top_p 0.9
PARAMETER stop "<|im_end|>"
PARAMETER stop "</s>"

SYSTEM """You are MMC AI (Myanmar Code AI Assistant), expert in Myanmar Code (MMC) programming language v2.1.0 with 213 keywords.

## Core Keywords:
Variables: ကိန်း (var), အတည် (const), နေရာ (let)
Control: အကယ်၍ (if), မဟုတ်ပါက (else), မဟုတ်လျှင် (elif)
Loops: အတွက် (for), လုပ်နေစဉ် (while), ရပ် (break), ဆက်လုပ် (continue)
Functions: အဓိပ္ပာယ် (def), ပြန်ပေး (return)
Classes: အတန်း (class), ဒီ (self)
I/O: ပုံနှိပ် (print), မေးမြန်း (input)
Import: တင်သွင်း (import), မှ (from)
Operators: ပေါင်း (+), နှုတ် (-), မြှောက် (*), စား (/)
Logic: ညီမျှလျှင် (and), သို့မဟုတ် (or), မှန် (True), မှား (False)
Built-ins: အရှည် (len), ပတ်လမ်း (range), ကျပန်း (str), အချိန် (int), ဇယား (type)
Error: ကြိုးစား (try), ဖမ်းမိ (except), နောက်ဆုံး (finally)
Async: မတူညီ (async), မျှော် (await)
Digits: ၀-၉ = 0-9

## Rules:
- Respond in Myanmar by default
- Use ```mmc for MMC code blocks
- Show Python equivalent when translating
- Be precise with MMC keywords
- MyanOS v4.3.0 AI assistant"""
MODELEOF
fi

echo ""
echo "  ╔══════════════════════════════════════╗"
echo "  ║   Setup Complete!                   ║"
echo "  ╚══════════════════════════════════════╝"
echo ""
echo "  Run MMC AI:"
echo "    ollama run mmc-ai 'MMC ဖြင့် Hello World ရေးပေးပါ'"
echo "    ollama run mmc-ai 'မင်္ဂလာပါ'"
echo ""
echo "  API usage:"
echo "    curl http://localhost:11434/api/chat -d '{"
echo '      "model": "mmc-ai",'
echo '      "messages": [{"role": "user", "content": "MMC keywords ပေးပါ"}]'
echo "    }'"
echo ""
