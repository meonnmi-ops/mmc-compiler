/**
 * MMC AI Tool for z-ai Agent
 * Myanmar Code AI Assistant - Ollama Integration
 * 
 * Usage: node z_ai_mmc_tool.js "MMC ဖြင့် Hello World ရေးပေးပါ"
 */

const http = require('http');

const OLLAMA_URL = process.env.OLLAMA_URL || 'http://localhost:11434';
const MODEL_NAME = process.env.MMC_MODEL || 'mmc-ai';

function askMMC(prompt) {
    return new Promise((resolve, reject) => {
        const data = JSON.stringify({
            model: MODEL_NAME,
            messages: [
                {
                    role: 'system',
                    content: 'You are MMC AI (Myanmar Code AI Assistant). Expert in Myanmar Code (MMC) programming language v2.1.0 with 213 keywords. Respond in Myanmar. Use ```mmc code blocks.'
                },
                {
                    role: 'user',
                    content: prompt
                }
            ],
            stream: false,
            options: {
                temperature: 0.6,
                num_ctx: 8192,
                repeat_penalty: 1.15,
                top_k: 40,
                top_p: 0.9
            }
        });

        const options = {
            hostname: 'localhost',
            port: 11434,
            path: '/api/chat',
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Content-Length': Buffer.byteLength(data)
            },
            timeout: 60000
        };

        const req = http.request(options, (res) => {
            let body = '';
            res.on('data', (chunk) => body += chunk);
            res.on('end', () => {
                try {
                    const result = JSON.parse(body);
                    const content = result.message?.content || result.response || 'No response';
                    resolve(content);
                } catch (e) {
                    reject(new Error('Parse error: ' + e.message));
                }
            });
        });

        req.on('error', (e) => reject(e));
        req.on('timeout', () => {
            req.destroy();
            reject(new Error('Request timeout'));
        });

        req.write(data);
        req.end();
    });
}

function generateCode(prompt) {
    return new Promise((resolve, reject) => {
        const data = JSON.stringify({
            model: MODEL_NAME,
            prompt: `Generate MMC (Myanmar Code) for: ${prompt}\n\nRules:\n- Use MMC keywords only (ကိန်း, အကယ်၍, ပုံနှိပ်, etc.)\n- Show Python equivalent\n- Add comments in Myanmar\n\nMMC Code:\n`,
            stream: false,
            options: {
                temperature: 0.4,
                num_ctx: 4096
            }
        });

        const options = {
            hostname: 'localhost',
            port: 11434,
            path: '/api/generate',
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Content-Length': Buffer.byteLength(data)
            },
            timeout: 60000
        };

        const req = http.request(options, (res) => {
            let body = '';
            res.on('data', (chunk) => body += chunk);
            res.on('end', () => {
                try {
                    const result = JSON.parse(body);
                    resolve(result.response || 'No response');
                } catch (e) {
                    reject(new Error('Parse error: ' + e.message));
                }
            });
        });

        req.on('error', (e) => reject(e));
        req.write(data);
        req.end();
    });
}

function translateCode(mmcCode, targetLang = 'python') {
    return new Promise((resolve, reject) => {
        const data = JSON.stringify({
            model: MODEL_NAME,
            prompt: `Translate this MMC code to ${targetLang}:\n\n${mmcCode}\n\nOnly show the ${targetLang} code, no explanation.`,
            stream: false,
            options: {
                temperature: 0.3,
                num_ctx: 4096
            }
        });

        const options = {
            hostname: 'localhost',
            port: 11434,
            path: '/api/generate',
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Content-Length': Buffer.byteLength(data)
            },
            timeout: 60000
        };

        const req = http.request(options, (res) => {
            let body = '';
            res.on('data', (chunk) => body += chunk);
            res.on('end', () => {
                try {
                    const result = JSON.parse(body);
                    resolve(result.response || 'No response');
                } catch (e) {
                    reject(new Error('Parse error: ' + e.message));
                }
            });
        });

        req.on('error', (e) => reject(e));
        req.write(data);
        req.end();
    });
}

// CLI usage
if (require.main === module) {
    const args = process.argv.slice(2);
    
    if (args.length === 0) {
        console.log('MMC AI Tool - z-ai Agent Integration');
        console.log('');
        console.log('Usage:');
        console.log('  node z_ai_mmc_tool.js "your prompt"          # Chat with MMC AI');
        console.log('  node z_ai_mmc_tool.js --gen "description"     # Generate MMC code');
        console.log('  node z_ai_mmc_tool.js --translate "mmc code"  # Translate to Python');
        console.log('  MMC_MODEL=myanmar-seallm node z_ai_mmc_tool.js "prompt"');
        console.log('');
        console.log('Examples:');
        console.log('  node z_ai_mmc_tool.js "MMC ဖြင့် calculator ရေးပေးပါ"');
        console.log('  node z_ai_mmc_tool.js --gen "fibonacci series"');
        console.log('  node z_ai_mmc_tool.js --translate "ပုံနှိပ် \'hello\'"');
        process.exit(0);
    }

    const mode = args[0];
    const prompt = args.slice(1).join(' ');

    async function main() {
        try {
            let result;
            
            if (mode === '--gen') {
                console.log(`[MMC AI] Generating code for: ${prompt}`);
                result = await generateCode(prompt);
            } else if (mode === '--translate') {
                console.log('[MMC AI] Translating MMC code to Python...');
                result = await translateCode(prompt);
            } else {
                console.log(`[MMC AI] Asking: ${mode}`);
                result = await askMMC(mode);
            }
            
            console.log('\n' + result);
        } catch (err) {
            console.error(`[Error] ${err.message}`);
            console.error('\nMake sure Ollama is running:');
            console.error('  ollama serve');
            console.error('\nAnd mmc-ai model exists:');
            console.error('  ollama create mmc-ai -f Modelfile');
        }
    }

    main();
}

// Export for use as module
module.exports = { askMMC, generateCode, translateCode };
