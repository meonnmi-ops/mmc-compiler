#!/usr/bin/env bash
# ================================================================
#   MMC Binary AI - GGUF Builder for Ollama
#   Version: 3.0.0
#   Myanmar Code (MMC) Programming Language AI
# ================================================================
#
# Usage:
#   chmod +x build-gguf.sh
#   ./build-gguf.sh              # Full build
#   ./build-gguf.sh --quick      # Quick build (use existing base)
#   ./build-gguf.sh --test       # Test only
#   ./build-gguf.sh --upload     # Upload to HuggingFace
#   ./build-gguf.sh --help       # Show help
#
# Requirements:
#   - Python 3.8+
#   - pip (Python package manager)
#   - 4GB+ RAM (8GB recommended)
#   - 5GB+ disk space
# ================================================================

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

# Configuration
MODEL_NAME="mmc-ai"
BASE_MODEL="Qwen/Qwen2.5-1.5B-Instruct-GGUF"
BASE_MODEL_FILE="qwen2.5-1.5b-instruct-q4_k_m.gguf"
OUTPUT_DIR="./output"
QUANT_LEVEL="Q4_K_M"
THREADS=$(nproc 2>/dev/null || echo "4")
HF_REPO=""

# Parse arguments
QUICK_MODE=false
TEST_ONLY=false
UPLOAD=false

for arg in "$@"; do
    case $arg in
        --quick)   QUICK_MODE=true ;;
        --test)    TEST_ONLY=true ;;
        --upload)  UPLOAD=true ;;
        --repo=*)  HF_REPO="${arg#*=}" ;;
        --help|-h)
            echo "MMC Binary AI - GGUF Builder"
            echo ""
            echo "Usage: $0 [OPTIONS]"
            echo ""
            echo "Options:"
            echo "  --quick     Quick build (skip base model download)"
            echo "  --test      Test model only (skip build)"
            echo "  --upload    Upload to HuggingFace Hub"
            echo "  --repo=REPO HuggingFace repo (e.g., user/mmc-ai)"
            echo "  --help      Show this help"
            exit 0
            ;;
        *)
            echo -e "${RED}Unknown option: $arg${NC}"
            exit 1
            ;;
    esac
done

print_banner() {
    echo -e "${CYAN}"
    echo "  ╔══════════════════════════════════════════════════╗"
    echo "  ║     MMC Binary AI - GGUF Builder v3.0.0          ║"
    echo "  ║     Myanmar Code (MMC) Programming Language AI   ║"
    echo "  ║     MyanOS v4.3.0                                ║"
    echo "  ╚══════════════════════════════════════════════════╝"
    echo -e "${NC}"
}

print_step() {
    echo -e "\n${BLUE}[STEP $1] $2${NC}"
    echo "────────────────────────────────────────────────"
}

print_ok() {
    echo -e "${GREEN}[OK]${NC} $1"
}

print_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_err() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_info() {
    echo -e "${CYAN}[INFO]${NC} $1"
}

check_system() {
    print_step "0" "System Check"

    # Python
    if command -v python3 &> /dev/null; then
        PYTHON_VERSION=$(python3 --version 2>&1)
        print_ok "Python: $PYTHON_VERSION"
    else
        print_err "Python3 not found. Please install Python 3.8+"
        exit 1
    fi

    # pip
    if command -v pip3 &> /dev/null; then
        print_ok "pip3: $(pip3 --version | head -1)"
    else
        print_warn "pip3 not found, trying pip..."
        if command -v pip &> /dev/null; then
            print_ok "pip: $(pip --version | head -1)"
        else
            print_err "pip not found. Install with: apt install python3-pip"
            exit 1
        fi
    fi

    # RAM
    if command -v free &> /dev/null; then
        RAM_GB=$(free -g 2>/dev/null | awk '/^Mem:/{print $2}')
        if [ -n "$RAM_GB" ] && [ "$RAM_GB" -lt 4 ]; then
            print_warn "RAM: ${RAM_GB}GB (8GB+ recommended)"
        else
            print_ok "RAM: ${RAM_GB}GB"
        fi
    fi

    # CPU
    print_ok "CPU threads: $THREADS"

    # Disk
    if command -v df &> /dev/null; then
        DISK_GB=$(df -BG . 2>/dev/null | awk 'NR==2{print $4}' | tr -d 'G')
        print_ok "Available disk: ${DISK_GB}GB"
    fi

    # Ollama (optional)
    if command -v ollama &> /dev/null; then
        print_ok "Ollama: $(ollama --version 2>&1 | head -1)"
    else
        print_warn "Ollama not found (optional, for testing)"
    fi
}

install_deps() {
    print_step "1" "Installing Dependencies"

    pip3 install -q huggingface_hub requests tqdm 2>/dev/null || \
    pip install -q huggingface_hub requests tqdm 2>/dev/null || {
        print_err "Failed to install dependencies"
        exit 1
    }
    print_ok "Dependencies installed"
}

download_base_model() {
    print_step "2" "Downloading Base Model"

    if [ "$QUICK_MODE" = true ]; then
        # Check if any Qwen GGUF file exists locally
        EXISTING=$(find . -name "*qwen*1.5b*gguf" 2>/dev/null | head -1)
        if [ -n "$EXISTING" ]; then
            print_ok "Using existing model: $EXISTING"
            cp "$EXISTING" "$OUTPUT_DIR/base-model.gguf"
            return
        fi

        # Try pulling from Ollama
        if command -v ollama &> /dev/null; then
            print_info "Trying to pull from Ollama..."
            if ollama pull qwen2.5:1.5b 2>/dev/null; then
                OLLAMA_DIR=$(ollama info qwen2.5:1.5b 2>/dev/null | grep "model path" | awk '{print $3}')
                if [ -n "$OLLAMA_DIR" ]; then
                    print_ok "Found in Ollama: $OLLAMA_DIR"
                    # Copy the GGUF from Ollama model directory
                    MODEL_DIR=$(dirname "$OLLAMA_DIR")
                    for f in "$MODEL_DIR"/*.gguf; do
                        if [ -f "$f" ]; then
                            cp "$f" "$OUTPUT_DIR/base-model.gguf"
                            print_ok "Copied: $f"
                            return
                        fi
                    done
                fi
            fi
        fi

        print_warn "Quick mode: no existing model found, downloading..."
    fi

    mkdir -p "$OUTPUT_DIR"

    if [ -f "$OUTPUT_DIR/base-model.gguf" ]; then
        print_ok "Base model already exists"
        return
    fi

    print_info "Downloading: $BASE_MODEL"
    print_info "File: $BASE_MODEL_FILE"
    print_info "This may take a while (~1GB)..."

    python3 - <<PYEOF
import sys
try:
    from huggingface_hub import hf_hub_download
    path = hf_hub_download(
        repo_id="$BASE_MODEL",
        filename="$BASE_MODEL_FILE",
        local_dir="$OUTPUT_DIR",
        local_dir_use_symlinks=False
    )
    print(f"Downloaded: {path}")
    import shutil
    shutil.copy(path, "$OUTPUT_DIR/base-model.gguf")
    print("Copied to: $OUTPUT_DIR/base-model.gguf")
except ImportError:
    print("huggingface_hub not available, trying wget...")
    import subprocess, os
    url = f"https://huggingface.co/$BASE_MODEL/resolve/main/$BASE_MODEL_FILE"
    result = subprocess.run(["wget", "-q", "--show-progress", "-O", "$OUTPUT_DIR/base-model.gguf", url])
    if result.returncode != 0:
        print("ERROR: Download failed")
        sys.exit(1)
except Exception as e:
    print(f"ERROR: {e}")
    sys.exit(1)
PYEOF

    if [ -f "$OUTPUT_DIR/base-model.gguf" ]; then
        SIZE_MB=$(du -m "$OUTPUT_DIR/base-model.gguf" | cut -f1)
        print_ok "Base model downloaded: ${SIZE_MB}MB"
    else
        print_err "Failed to download base model"
        exit 1
    fi
}

prepare_training_data() {
    print_step "3" "Preparing MMC Training Data"

    mkdir -p "$OUTPUT_DIR/datasets"

    # Check for local training data
    LOCAL_DATA=""
    for f in mmc-training-data.json myanmar_grammar_reference.md; do
        if [ -f "$f" ]; then
            cp "$f" "$OUTPUT_DIR/datasets/"
            LOCAL_DATA="$f"
            print_ok "Copied: $f"
        fi
    done

    # Generate JSONL from training data
    python3 - <<PYEOF
import json
import os

output_dir = "$OUTPUT_DIR/datasets"
os.makedirs(output_dir, exist_ok=True)

# Training data for MMC AI
training_data = [
    # MMC Basics
    {"instruction": "MMC စာနှင့် Hello World ရေးပေးပါ", "input": "", "output": "```mmc\\nပုံနှိပ် \\"မင်္ဂလာပါ ကမ္ဘာကြီး\\"\\n```\\n\\nPython:\\n```python\\nprint(\\"မင်္ဂလာပါ ကမ္ဘာကြီး\\")\\n```\\n\\n`ပုံနှိပ်` ဆိုသည်မှာ MMC မှာ `print` ဖြစ်ပါသည်။"},
    {"instruction": "MMC မှာ variable သတ်မှတ်ပုံ ရှင်းပြောပါ", "input": "", "output": "MMC မှာ variable သတ်မှတ်ခြင်း:\\n\\n```mmc\\nကိန်း အမည် = \\"ကျော်ကျော်\\"\\nကိန်း အသက် = ၂၅\\nအတည် PI = ၃.၁၄၁၅၉\\n```\\n\\n- `ကိန်း` = var (variable)\\n- `အတည်` = const (constant)\\n- Myanmar digits: ၀-၉ = 0-9"},
    {"instruction": "MMC ဖြင့် if-else ရေးပေးပါ", "input": "", "output": "```mmc\\nကိန်း အသက် = ၂၀\\n\\nအကယ်၍ အသက် ကြီးလျှင် ၁၈:\\n    ပုံနှိပ် \\"အရေရာရှည်\\"\\nမဟုတ်ပါက:\\n    ပုံနှိပ် \\"ကလေး\\"\\n```\\n\\nKeywords: `အကယ်၍` (if), `မဟုတ်ပါက` (else), `ကြီးလျှင်` (>), `ငယ်လျှင်` (<)"},
    {"instruction": "MMC ဖြင့် function ရေးပေးပါ", "input": "", "output": "```mmc\\nအဓိပ္ပာယ် ပေါင်းချက်(a, b):\\n    ပြန်ပေး a + b\\n\\nပုံနှိပ် ပေါင်းချက်(၅, ၃)\\n```\\n\\n- `အဓိပ္ပာယ်` = def\\n- `ပြန်ပေး` = return"},
    {"instruction": "MMC ဖြင့် for loop ရေးပေးပါ", "input": "", "output": "```mmc\\nအတွက် i အတွင်း ပတ်လမ်း(၁, ၁၁):\\n    ပုံနှိပ် i\\n```\\n\\nKeywords: `အတွက်` (for), `အတွင်း` (in), `ပတ်လမ်း` (range)"},
    # Myanmar language
    {"instruction": "မင်္ဂလာပါ", "input": "", "output": "ကျေးဇူးတိုင်းပါ၊ ကြိုတင်ပါ။ ဘာကြောင့် မင်္ဂလာလဲ။ MMC AI ကို ကျေးဇူးပါ ခေါ်တဲ့ အချက်များကို မေးနိုင်ပါသည်।"},
    {"instruction": "မြန်မာစာလုံးချင်း သုံးမျိုး ပေးပါ", "input": "", "output": "မြန်မာစာ လုံးချင်း ၃ မျိုး:\\n\\n၁။ ပေတံ (ဒါး) - နောက်ဆုံး သတ်မှတ်ပေးတဲ့ လုံးချင်း (ယူ၊ ကူး)\\n၂။ နက်ရှိုင်း (ပဲ) - ရောရှည်လိုက်သော လုံးချင်း (ကြီး၊ သောက်)\\n၃။ သွေးစာလုံး - အခြားနှင့် ဆက်စပ်မှု မရှိ (က်၊ း၊ ဂ)"},
    {"instruction": "Myanmar digits သုံးပုံ ရှင်းပြောပါ", "input": "", "output": "Myanmar Digits:\\n၀=0, ၁=1, ၂=2, ၃=3, ၄=4, ၅=5, ၆=6, ၇=7, ၈=8, ၉=9\\n\\nMMC မှာ:\\n```mmc\\nကိန်း အရှည် = ၁၀\\nပုံနှိပ် အရှည်  # Output: 10\\n```"},
    # Technical
    {"instruction": "Python နဲ့ MMC နှိုင်းချက် ပေးပါ", "input": "", "output": "| MMC | Python |\\n|-----|--------|\\n| ပုံနှိပ် | print |\\n| ကိန်း | var |\\n| အကယ်၍ | if |\\n| မဟုတ်ပါက | else |\\n| အတွက် | for |\\n| လုပ်နေစဉ် | while |\\n| အဓိပ္ပာယ် | def |\\n| ပြန်ပေး | return |\\n| အတန်း | class |\\n| ဒီ | self |\\n| ပတ်လမ်း | range |\\n| ကျပန်း | str |\\n| အချိန် | int |"},
    {"instruction": "MMC keywords နှစ်သိုး ကောင်း ပေးပါ", "input": "", "output": "MMC Keywords (213 total):\\n\\nCore: ကိန်း, အတည်, နေရာ, အကယ်၍, မဟုတ်ပါက, မဟုတ်လျှင်, အတွက်, လုပ်နေစဉ်, အဓိပ္ပာယ်, ပြန်ပေး, ပုံနှိပ်, မေးမြန်း, တင်သွင်း, အတန်း, ဒီ, ကြိုးစား, ဖမ်းမိ\\n\\nOperators: ပေါင်း(+), နှုတ်(-), မြှောက်(*), စား(/), ညီမျှလျှင်(and), သို့မဟုတ်(or)\\n\\nBuilt-ins: အရှည်(len), ပတ်လမ်း(range), ဇယား(type), ဖွင့်(open)"},
    {"instruction": "MyanOS ဆိုတာ ဘာလဲ", "input": "", "output": "MyanOS သည် မြန်မာ Developer များ ဖန်တီးထားတဲ့ Web-based Operating System ဖြစ်သည်။ Browser ပေါ်တွေကို လုပ်ဆောင်နိုင်ပြီး Desktop, Terminal, Code Editor, MyanAI Agent စသော features များ ရှိသည်। MMC (Myanmar Code) programming language ကို ပိုင်ဆိုင် အသုံးပြုပြီး Ollama AI ခွဲခြမ်းစိတ်ဖြာ ပါ ရှိသည်।"},
    {"instruction": "GGUF ဆိုတာ ဘာလဲ", "input": "", "output": "GGUF (GPT-Generated Unified Format) သည် llama.cpp စနစ်တွင် အသုံးပြုသော model format ဖြစ်သည်။ အဓိက အချက်အလုံး:\\n\\n- Quantization ပြုလုပ်နိုင်သည် (Q4_K_M, Q5_K, Q8_0)\\n- File size ကလည်းသွားသည်\\n- CPU ဖြင့် လုပ်ဆောင်နိုင်သည်\\n- Ollama တွင် ကိုင်တွယ်စွာ အသုံးပြုသည်\\n- Model metadata အပြည့် ပါဝင်သည်\\n\\nMMC AI ကို GGUF format ဖြင့် ထုတ်လုပ်ပြီး Ollama ထဲထည့်သွင်းနိုင်သည်।"},
]

# Check for additional training data file
import glob
for f in glob.glob("mmc-training-data.json"):
    try:
        with open(f, 'r', encoding='utf-8') as fh:
            extra = json.load(fh)
            if isinstance(extra, list):
                training_data.extend(extra)
                print(f"Loaded {len(extra)} extra training samples from {f}")
    except:
        pass

# Write JSONL
output_path = os.path.join(output_dir, "mmc_train.jsonl")
with open(output_path, 'w', encoding='utf-8') as f:
    for item in training_data:
        # Convert to training format
        if item.get("input") and item["input"].strip():
            text = f"### Instruction:\\n{item['instruction']}\\n\\n### Input:\\n{item['input']}\\n\\n### Response:\\n{item['output']}"
        else:
            text = f"### Instruction:\\n{item['instruction']}\\n\\n### Response:\\n{item['output']}"
        f.write(json.dumps({"text": text}, ensure_ascii=False) + "\\n")

print(f"Created {len(training_data)} training samples: {output_path}")
PYEOF

    print_ok "Training data prepared"
}

create_modelfile() {
    print_step "4" "Creating Ollama Modelfile"

    mkdir -p "$OUTPUT_DIR"

    # Check for existing Modelfile
    if [ -f "Modelfile" ]; then
        cp "Modelfile" "$OUTPUT_DIR/Modelfile"
        print_ok "Copied existing Modelfile"
        return
    fi

    cat > "$OUTPUT_DIR/Modelfile" <<'EOF'
# MMC Binary AI - Ollama Modelfile v3.0.0
FROM ./base-model.gguf

PARAMETER temperature 0.6
PARAMETER num_ctx 8192
PARAMETER num_batch 512
PARAMETER repeat_penalty 1.15
PARAMETER top_k 40
PARAMETER top_p 0.9
PARAMETER min_p 0.05
PARAMETER seed 42

PARAMETER stop "<|im_end|>"
PARAMETER stop "</s>"

TEMPLATE """{{- if .System }}{{ .System }}{{ end }}
{{- if .Prompt }}<|im_start|>user
{{ .Prompt }}<|im_end|>
{{- end }}<|im_start|>assistant
"""

SYSTEM """You are MMC AI (Myanmar Code AI Assistant), expert in Myanmar Code (MMC) programming language v2.1.0 with 213 keywords.

## Core Keywords:
Variables: ကိန်း (var), အတည် (const), နေရာ (let)
Control: အကယ်၍ (if), မဟုတ်ပါက (else), မဟုတ်လျှင် (elif)
Loops: အတွက် (for), လုပ်နေစဉ် (while), ရပ် (break), ဆက်လုပ် (continue)
Functions: အဓိပ္ပာယ် (def), ပြန်ပေး (return)
Classes: အတန်း (class), ဒီ (self), အထက် (super)
I/O: ပုံနှိပ် (print), မေးမြန်း (input)
Import: တင်သွင်း (import), မှ (from)
Operators: ပေါင်း (+), နှုတ် (-), မြှောက် (*), စား (/)
Logic: ညီမျှလျှင် (and), သို့မဟုတ် (or), မှန် (True), မှား (False)
Built-ins: အရှည် (len), ပတ်လမ်း (range), ကျပန်း (str), အချိန် (int), ဇယား (type), ဖွင့် (open)
Error: ကြိုးစား (try), ဖမ်းမိ (except), နောက်ဆုံး (finally), ချမြှောက် (raise)
Async: မတူညီ (async), မျှော် (await)
Myanmar Digits: ၀-၉ = 0-9

## Rules:
- Respond in Myanmar by default
- Use ```mmc code blocks for MMC code
- Show Python equivalent when translating
- Be precise with MMC keyword mappings
- Explain technical concepts in Myanmar"""
EOF

    print_ok "Modelfile created: $OUTPUT_DIR/Modelfile"
}

build_model() {
    print_step "5" "Building GGUF Model"

    if [ "$QUICK_MODE" = true ]; then
        print_info "Quick mode: Skipping GGUF rebuild, using base model directly"
        return
    fi

    # Check if llama.cpp exists
    LLAMA_DIR="./llama.cpp"

    if [ -d "$LLAMA_DIR/convert_hf_to_gguf.py" ] || [ -d "$LLAMA_DIR/gguf-py" ]; then
        print_ok "llama.cpp found"
    else
        print_info "Cloning llama.cpp..."
        git clone --depth 1 https://github.com/ggml-org/llama.cpp 2>/dev/null || {
            print_warn "Failed to clone llama.cpp, skipping GGUF rebuild"
            print_info "Using base model GGUF directly (this is fine for Ollama)"
            return
        }
    fi

    # Install gguf package
    pip3 install -q gguf 2>/dev/null || pip install -q gguf 2>/dev/null || true

    print_info "Building model with base GGUF (fine-tuning requires GPU/Colab)"
    print_info "For fine-tuning, use: python3 3_finetune_cpu.py or 2_finetune_colab.py"
}

create_ollama_model() {
    print_step "6" "Creating Ollama Model"

    if ! command -v ollama &> /dev/null; then
        print_warn "Ollama not installed. Run these commands to install:"
        echo ""
        echo "  # Linux:"
        echo "  curl -fsSL https://ollama.com/install.sh | sh"
        echo ""
        echo "  # Termux:"
        echo "  pkg install ollama"
        echo "  ollama serve &"
        echo ""
        print_info "Skipping Ollama model creation"
        return
    fi

    # Check if Ollama server is running
    if ! curl -s http://localhost:11434/api/tags > /dev/null 2>&1; then
        print_warn "Ollama server not running. Start with: ollama serve"
        print_info "Attempting to start Ollama..."

        # Try to start in background
        ollama serve > /dev/null 2>&1 &
        sleep 3

        if ! curl -s http://localhost:11434/api/tags > /dev/null 2>&1; then
            print_err "Could not start Ollama. Please start it manually"
            return
        fi
    fi

    print_ok "Ollama server is running"

    # Create model
    cd "$OUTPUT_DIR"
    print_info "Creating model: $MODEL_NAME"

    ollama create "$MODEL_NAME" -f Modelfile 2>&1 && {
        print_ok "Model created successfully: $MODEL_NAME"
    } || {
        print_err "Failed to create model"
        return
    }

    cd - > /dev/null
}

test_model() {
    print_step "7" "Testing Model"

    if ! command -v ollama &> /dev/null; then
        print_warn "Ollama not available, skipping tests"
        return
    fi

    if ! curl -s http://localhost:11434/api/tags > /dev/null 2>&1; then
        print_warn "Ollama not running, skipping tests"
        return
    fi

    # Check if model exists
    if ! ollama list 2>/dev/null | grep -q "$MODEL_NAME"; then
        print_warn "Model $MODEL_NAME not found, skipping tests"
        return
    fi

    echo ""
    print_info "Running test prompts..."
    echo ""

    TESTS=(
        "MMC ဖြင့် Hello World ရေးပေးပါ"
        "MMC keywords ၅ ခု ပေးပါ"
        "မင်္ဂလာပါ"
    )

    PASSED=0
    FAILED=0

    for prompt in "${TESTS[@]}"; do
        echo -e "  ${CYAN}Prompt:${NC} $prompt"
        response=$(ollama run "$MODEL_NAME" "$prompt" --nowordwrap 2>/dev/null | head -5)
        if [ -n "$response" ]; then
            echo -e "  ${GREEN}Response:${NC} ${response:0:200}..."
            ((PASSED++))
        else
            echo -e "  ${RED}No response${NC}"
            ((FAILED++))
        fi
        echo ""
    done

    echo "────────────────────────────────────────────────"
    echo -e "  Tests: ${GREEN}$PASSED passed${NC}, ${RED}$FAILED failed${NC}"
}

upload_model() {
    print_step "8" "Uploading to HuggingFace"

    if [ -z "$HF_REPO" ]; then
        print_warn "No HuggingFace repo specified. Use --repo=user/mmc-ai"
        return
    fi

    if [ ! -f "$OUTPUT_DIR/base-model.gguf" ]; then
        print_err "No GGUF file found to upload"
        return
    fi

    python3 - <<PYEOF
import sys
try:
    from huggingface_hub import HfApi, create_repo

    repo_id = "$HF_REPO"
    api = HfApi()

    try:
        create_repo(repo_id=repo_id, repo_type="model", exist_ok=True)
    except Exception as e:
        print(f"Repo: {e}")

    api.upload_file(
        path_or_fileobj="$OUTPUT_DIR/base-model.gguf",
        path_in_repo="mmc-ai-q4.gguf",
        repo_id=repo_id,
        repo_type="model",
    )

    # Upload Modelfile
    import os
    if os.path.exists("$OUTPUT_DIR/Modelfile"):
        api.upload_file(
            path_or_fileobj="$OUTPUT_DIR/Modelfile",
            path_in_repo="Modelfile",
            repo_id=repo_id,
            repo_type="model",
        )

    print(f"Uploaded to: https://huggingface.co/{repo_id}")
    print(f"Ollama pull: ollama run hf.co/{repo_id}")

except ImportError:
    print("huggingface_hub not installed. Run: pip install huggingface_hub")
    sys.exit(1)
except Exception as e:
    print(f"Upload failed: {e}")
    sys.exit(1)
PYEOF
}

print_summary() {
    echo ""
    echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
    echo -e "${CYAN}                    Build Complete!                        ${NC}"
    echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
    echo ""
    echo -e "  ${GREEN}Output:${NC} $OUTPUT_DIR/"
    echo "  ├── base-model.gguf    (Base GGUF model)"
    echo "  ├── Modelfile          (Ollama configuration)"
    echo "  └── datasets/          (Training data)"
    echo ""
    echo -e "  ${YELLOW}Quick Start:${NC}"
    echo ""
    echo "  1. Copy to your machine:"
    echo "     scp -r $OUTPUT_DIR/ user@machine:/path/mmc-ai/"
    echo ""
    echo "  2. Create Ollama model:"
    echo "     cd /path/mmc-ai && ollama create mmc-ai -f Modelfile"
    echo ""
    echo "  3. Run:"
    echo "     ollama run mmc-ai 'MMC ဖြင့် Hello World ရေးပေးပါ'"
    echo ""
    echo "  4. API usage:"
    echo "     curl http://localhost:11434/api/chat -d '{"
    echo '       "model": "mmc-ai",'
    echo '       "messages": [{"role": "user", "content": "မင်္ဂလာပါ"}]'
    echo "     }'"
    echo ""
    echo -e "  ${BLUE}Advanced:${NC}"
    echo "  - Fine-tune: python3 3_finetune_cpu.py"
    echo "  - Colab:     python3 2_finetune_colab.py  (GPU, faster)"
    echo "  - Upload:    $0 --upload --repo=user/mmc-ai"
    echo ""
    echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
}

# ================================================================
# Main
# ================================================================

print_banner

if [ "$TEST_ONLY" = true ]; then
    test_model
    exit 0
fi

check_system
install_deps
download_base_model
prepare_training_data
create_modelfile
build_model
create_ollama_model
test_model

if [ "$UPLOAD" = true ]; then
    upload_model
fi

print_summary
