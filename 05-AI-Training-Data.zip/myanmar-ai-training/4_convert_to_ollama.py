#!/usr/bin/env python3
"""
================================================================
  MyanOS AI Training - Convert & Deploy to Ollama
================================================================
  
  Fine-tuning ပြီးပြည့် ကုဒ码 ကို GGUF ပြောင်းလဲပြီး Ollama ထဲထည့်သွင်းပါ။
  HuggingFace Hub မှာလည်း အပြည့် upload လုပ်နိုင်သည်။
  
  Usage:
    python 4_convert_to_ollama.py --gguf ./myanmar-qwen3b-q4.gguf
    python 4_convert_to_ollama.py --lora ./myanmar_lora --base unsloth/qwen2.5-3b
    python 4_convert_to_ollama.py --help
================================================================
"""

import os
import sys
import json
import argparse
import subprocess
from pathlib import Path


SYSTEM_PROMPT = """သင်သည် မြန်မာစာကျွမ်းကျင်သော AI assistant ဖြစ်သည်။ အမြဲတမ်း မြန်မာစာဖြင့် ဖြေဆိုပါ။ MyanOS v4.2.0 တွေကို အခြေခံထားသော MyanAI Agent ဖြစ်သည်။ coding နဲ့ technical အကြောင်းများကို မြန်မာစာဖြင့် ရှောမြောက်ပေးပါ။ စာမှန်ကန်အောင် ရေးပါ။ ကျေးဇူးတိုင်းပါ ပြောတဲ့ အချက်တွေကို ကျေးဇူးတိုင်း ဖြေပါ."""


def create_modelfile(gguf_path, output_path="./Modelfile"):
    """Create Ollama Modelfile."""
    print(f"\n[*] Creating Modelfile for: {gguf_path}")
    
    content = f'''FROM {gguf_path}
PARAMETER temperature 0.7
PARAMETER num_ctx 4096
PARAMETER repeat_penalty 1.1
PARAMETER top_k 40
PARAMETER top_p 0.9
SYSTEM """{SYSTEM_PROMPT}"""
'''
    
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(content)
    
    print(f"[+] Modelfile created: {output_path}")
    return output_path


def convert_hf_to_gguf(model_path, output_path, quantize="Q4_K_M"):
    """Convert HuggingFace model to GGUF format."""
    print(f"\n[*] Converting {model_path} to GGUF...")
    
    # Step 1: Clone llama.cpp if not exists
    if not os.path.exists("./llama.cpp"):
        subprocess.run(
            "git clone --depth 1 https://github.com/ggml-org/llama.cpp",
            shell=True, capture_output=True
        )
    
    # Step 2: Build convert script
    subprocess.run(
        "pip install -q gguf",
        shell=True, capture_output=True
    )
    
    # Step 3: Convert to F16 GGUF
    f16_path = output_path.replace(".gguf", "-f16.gguf")
    result = subprocess.run(
        f"python llama.cpp/convert_hf_to_gguf.py {model_path} "
        f"--outfile {f16_path} --outtype f16",
        shell=True, capture_output=True, text=True
    )
    
    if result.returncode != 0:
        print(f"[!] Conversion failed: {result.stderr[-300:]}")
        return False
    
    print(f"[+] F16 GGUF created: {f16_path}")
    
    # Step 4: Quantize
    print(f"[*] Quantizing to {quantize}...")
    result = subprocess.run(
        f"./llama.cpp/llama-quantize {f16_path} {output_path} {quantize}",
        shell=True, capture_output=True, text=True
    )
    
    if result.returncode != 0:
        print(f"[!] Quantization failed: {result.stderr[-300:]}")
        return False
    
    size_gb = os.path.getsize(output_path) / 1024**3
    print(f"[+] Quantized GGUF: {output_path} ({size_gb:.2f} GB)")
    
    # Clean up F16
    if os.path.exists(f16_path) and f16_path != output_path:
        os.remove(f16_path)
    
    return True


def upload_to_huggingface(gguf_path, repo_name):
    """Upload GGUF to HuggingFace Hub."""
    print(f"\n[*] Uploading to HuggingFace Hub: {repo_name}")
    
    try:
        from huggingface_hub import HfApi, create_repo
        
        api = HfApi()
        
        # Create repo if not exists
        try:
            create_repo(repo_id=repo_name, repo_type="model", exist_ok=True)
        except Exception as e:
            print(f"  [!] Repo creation: {e}")
        
        # Upload file
        api.upload_file(
            path_or_fileobj=gguf_path,
            path_in_repo=os.path.basename(gguf_path),
            repo_id=repo_name,
            repo_type="model",
        )
        
        print(f"[+] Uploaded to: https://huggingface.co/{repo_name}")
        print(f"    Ollama pull: ollama run hf.co/{repo_name}")
        return True
    except ImportError:
        print("[!] huggingface_hub not installed. Run: pip install huggingface_hub")
        return False
    except Exception as e:
        print(f"[!] Upload failed: {e}")
        return False


def test_model(model_name="myanmar-ai"):
    """Test the model with sample prompts."""
    print(f"\n[*] Testing model: {model_name}")
    print("=" * 40)
    
    test_prompts = [
        "မင်္ဂလာပါ",
        "မြန်မာစာလုံးချင်း သုံးမျိုးပေးပါ",
        "Python ဖြင့် Hello World ရေးပေးပါ",
        "MyanOS ဆိုတာ ဘာလဲ",
    ]
    
    for prompt in test_prompts:
        print(f"\n  Prompt: {prompt}")
        result = subprocess.run(
            f"ollama run {model_name} \"{prompt}\" 2>/dev/null",
            shell=True, capture_output=True, text=True, timeout=30
        )
        if result.returncode == 0:
            response = result.stdout.strip()[:200]
            print(f"  Response: {response}")
        else:
            print(f"  Error: Make sure Ollama is running and model is created")
            break


def main():
    parser = argparse.ArgumentParser(
        description="MyanOS AI Training - Convert & Deploy to Ollama"
    )
    parser.add_argument("--gguf", help="Path to existing GGUF file")
    parser.add_argument("--lora", help="Path to LoRA adapter directory")
    parser.add_argument("--base", help="Base model name (for LoRA)")
    parser.add_argument("--hf-repo", help="HuggingFace repo to upload (e.g., username/myanmar-qwen3b)")
    parser.add_argument("--output", default="./myanmar-ai.gguf", help="Output GGUF path")
    parser.add_argument("--quantize", default="Q4_K_M", help="Quantization level")
    parser.add_argument("--test", action="store_true", help="Test model after creation")
    args = parser.parse_args()
    
    print("=" * 60)
    print("  MyanOS AI Training - Ollama Deployment")
    print("  MyanOS v4.2.0 - MyanAI Agent")
    print("=" * 60)
    
    gguf_path = args.gguf
    
    # If LoRA adapter provided, merge and convert
    if args.lora:
        print(f"\n[*] Merging LoRA adapter: {args.lora}")
        print("    (Run in Colab: model.save_pretrained_merged)")
        print("    Then use --gguf with the merged model path")
        return
    
    # If HF model provided, convert
    if args.base and not gguf_path:
        print(f"\n[*] Converting HF model: {args.base}")
        success = convert_hf_to_gguf(args.base, args.output, args.quantize)
        if success:
            gguf_path = args.output
    
    if not gguf_path:
        print("\n[!] Please provide --gguf path or --base model name")
        print("    Examples:")
        print("      python 4_convert_to_ollama.py --gguf ./myanmar-qwen3b-q4.gguf")
        print("      python 4_convert_to_ollama.py --base myanmar_qwen_full")
        return
    
    # Create Modelfile
    modelfile = create_modelfile(gguf_path)
    
    # Upload to HF if requested
    if args.hf_repo:
        upload_to_huggingface(gguf_path, args.hf_repo)
    
    # Test if requested
    if args.test:
        test_model()
    
    print("\n" + "=" * 60)
    print("  Deployment Instructions")
    print("=" * 60)
    print(f"\n  1. Copy GGUF file to your server:")
    print(f"     scp {gguf_path} user@server:/path/")
    print(f"\n  2. Create Ollama model:")
    print(f"     ollama create myanmar-ai -f Modelfile")
    print(f"\n  3. Run:")
    print(f"     ollama run myanmar-ai 'မင်္ဂလာပါ'")
    print(f"\n  4. Use in MyanOS Terminal:")
    print(f"     ai chat မင်္ဂလာပါ")
    print(f"\n  5. Use via API:")
    print(f"     curl http://localhost:11434/api/generate -d '{{")
    print(f'       "model": "myanmar-ai",')
    print(f'       "prompt": "မင်္ဂလာပါ"')
    print(f"     }}'")
    print("=" * 60)


if __name__ == "__main__":
    main()
