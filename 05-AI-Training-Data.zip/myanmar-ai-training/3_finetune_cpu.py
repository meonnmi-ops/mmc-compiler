#!/usr/bin/env python3
"""
================================================================
  MyanOS AI Training - CPU Fine-Tuning Pipeline (HF Space)
================================================================
  
  ကုဒ码 ကို HF Space (132GB RAM) တွေကို run ပေးနိုင်သည်။
  GPU မလိုပါ။ CPU ဖြင့်သာ လုပ်ဆောင်နိုင်သည်။
  
  ကိုယ်ပိုင်း machine တွေကိုလည်း run နိုင်သည် ( RAM 8GB+ လိုသည် )
  
  အဆင့်များ:
  1. ဒေတာ ရည်ရွယ်ချက် ကို ထည့်သွင်းပါ
  2. python 3_finetune_cpu.py ကို run ပေးပါ
  3. GGUF file ကို ထုတ်လုပ်မည်
  4. Ollama ထဲ ထည့်သွင်းပါ
  
  Output: myanmar-qwen3b-cpu.gguf
================================================================
"""

import os
import sys
import json
import subprocess
import shutil
from pathlib import Path

# ================================================================
# CONFIGURATION
# ================================================================

# Base model (Qwen 2.5 1.5B - small enough for CPU training)
BASE_MODEL = "Qwen/Qwen2.5-1.5B-Instruct-GGUF"
BASE_MODEL_FILE = "qwen2.5-1.5b-instruct-q4_k_m.gguf"

# Training data path
TRAIN_DATA_PATH = "./datasets/instruction_tuning/myanmar_master_instructions.jsonl"

# Output paths
LORA_OUTPUT = "./output/myanmar_lora"
GGUF_OUTPUT = "./output/myanmar-qwen3b-cpu.gguf"
GGUF_QUANT = "./output/myanmar-qwen3b-cpu-q4.gguf"
MODELFILE_PATH = "./output/Modelfile"

# Training parameters
EPOCHS = 3
BATCH_SIZE = 4
CONTEXT_LENGTH = 512
THREADS = os.cpu_count() or 4  # Use all available CPU cores

# System prompt for the model
SYSTEM_PROMPT = """သင်သည် မြန်မာစာကျွမ်းကျင်သော AI assistant ဖြစ်သည်။ အမြဲတမ်း မြန်မာစာဖြင့် ဖြေဆိုပါ။ MyanOS v4.2.0 တွေကို အခြေခံထားသော MyanAI Agent ဖြစ်သည်။ coding နဲ့ technical အကြောင်းများကို မြန်မာစာဖြင့် ရှောမြောက်ပေးပါ။ စာမှန်ကန်အောင် ရေးပါ။ ကျေးဇူးတိုင်းပါ ပြောတဲ့ အချက်တွေကို ကျေးဇူးတိုင်း ဖြေပါ."""


def check_system():
    """Check system requirements."""
    print("=" * 60)
    print("  System Requirements Check")
    print("=" * 60)
    
    ram_gb = os.popen("free -g 2>/dev/null || echo '0'").read()
    cpu_count = os.cpu_count() or 1
    print(f"  CPU cores: {cpu_count}")
    print(f"  RAM info: {ram_gb.strip()[:200]}")
    
    # Check if llama.cpp exists
    llama_cpp_path = shutil.which("llama-finetune")
    if llama_cpp_path:
        print(f"  llama.cpp finetune: FOUND at {llama_cpp_path}")
    else:
        print(f"  llama.cpp finetune: NOT FOUND (will build)")
    
    # Check disk space
    if os.path.exists("/data"):
        disk = os.popen("df -h /data 2>/dev/null").read()
        print(f"  Disk (/data): {disk.strip()[:200]}")
    
    disk_root = os.popen("df -h / 2>/dev/null").read()
    print(f"  Disk (/): {disk_root.strip()[:200]}")
    
    print(f"\n  Thread count: {THREADS}")
    return True


def install_dependencies():
    """Install required packages."""
    print("\n[*] Installing dependencies...")
    
    packages = [
        "pip install huggingface_hub requests tqdm",
    ]
    
    for cmd in packages:
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        if result.returncode != 0:
            print(f"  [!] Warning: {result.stderr[:100]}")
    
    print("[+] Dependencies ready.")


def download_base_model():
    """Download base model GGUF file."""
    model_path = f"./{BASE_MODEL_FILE}"
    
    if os.path.exists(model_path):
        print(f"\n[+] Base model already exists: {model_path}")
        return model_path
    
    print(f"\n[*] Downloading base model: {BASE_MODEL}")
    print(f"    This may take a while (~1-2 GB)...")
    
    try:
        from huggingface_hub import hf_hub_download
        model_path = hf_hub_download(
            repo_id=BASE_MODEL,
            filename=BASE_MODEL_FILE,
            local_dir=".",
        )
        print(f"[+] Downloaded: {model_path}")
        return model_path
    except ImportError:
        print("[!] huggingface_hub not installed, trying wget...")
        url = f"https://huggingface.co/{BASE_MODEL}/resolve/main/{BASE_MODEL_FILE}"
        result = subprocess.run(
            f"wget -q --show-progress -O {model_path} {url}",
            shell=True, capture_output=False
        )
        if result.returncode == 0:
            print(f"[+] Downloaded: {model_path}")
            return model_path
        else:
            print(f"[!] Download failed. Please download manually:")
            print(f"    {url}")
            sys.exit(1)


def prepare_training_data():
    """Prepare training data in llama.cpp finetune format."""
    print("\n[*] Preparing training data...")
    
    output_file = "./train_data.jsonl"
    
    # Check if master dataset exists
    if os.path.exists(TRAIN_DATA_PATH):
        print(f"  Using: {TRAIN_DATA_PATH}")
        with open(TRAIN_DATA_PATH, "r", encoding="utf-8") as f_in, \
             open(output_file, "w", encoding="utf-8") as f_out:
            for line in f_in:
                item = json.loads(line.strip())
                instruction = item.get("instruction", "")
                inp = item.get("input", "")
                output = item.get("output", "")
                
                if instruction and output:
                    if inp and inp.strip():
                        text = f"### Instruction:\n{instruction}\n\n### Input:\n{inp}\n\n### Response:\n{output}"
                    else:
                        text = f"### Instruction:\n{instruction}\n\n### Response:\n{output}"
                    
                    f_out.write(json.dumps({"text": text}, ensure_ascii=False) + "\n")
        
        count = sum(1 for _ in open(output_file, encoding="utf-8"))
        print(f"  [+] Prepared {count} training samples")
        return output_file
    
    else:
        # Create inline training data
        print(f"  Master dataset not found, creating inline data...")
        
        inline_data = [
            "### Instruction:\nမင်္ဂလာပါ\n\n### Response:\nကျေးဇူးတိုင်းပါ၊ ကြိုတင်ပါ။ ဘာကြောင့် မင်္ဂလာလဲ။ ကျေးဇူးပါ ခေါ်တဲ့ အချက်များကို မေးနိုင်ပါသည်။",
            "### Instruction:\nနေ့ခင်းကျေးဇူးပါ\n\n### Response:\nနေ့ခင်းကျေးဇူးတိုင်းပါ။ နေ့ခင်း ကောင်းပါသလား။ ဘာများ ဝန်ဆောင်ပေးနိုင်ပါသလဲ။",
            "### Instruction:\nမြန်မာစာလုံးချင်း သုံးမျိုးကို ရှောမြောက်ပါ\n\n### Response:\nမြန်မာစာ လုံးချင်း (၃) မျိုးရှိသည်။ ပေတံ - စာအုပ်ပြီးနောက် နောက်ဆုံးသတ်မှတ်ပေးတဲ့ လုံးချင်း။ နက်ရှိုင်း - ရောရှည်လိုက်သော လုံးချင်း။ သွေးစာလုံး - အခြားနှင့် ဆက်စပ်မှု မရှိသော စာလုံးများ။",
            "### Instruction:\nPython ဖြင့် Hello World ရေးပေးပါ\n\n### Response:\n```python\nprint('Hello World')\n```\nဤကုဒ码သည် Hello World စာသာရကို screen ပေါ်တွေက်ပြပေးမည်။",
            "### Instruction:\nGit commands အဓိကပေးပါ\n\n### Response:\ngit init repo စတင်၊ git add . အကြောင်းအားလုံး add၊ git commit -m message သိမ်းဆည်း၊ git push origin main ပေးပို့၊ git pull origin main ပြန်လည်ရယူ၊ git status အခြေအနေကြည့်။ Git သည် version control system ဖြစ်သည်।",
            "### Instruction:\nMyanOS ဆိုတာ ဘာလဲ\n\n### Response:\nMyanOS သည် မြန်မာ Developer တွေ ဖန်တီးထားတဲ့ Web-based Operating System ဖြစ်သည်။ Browser ပေါ်တွေကို လုပ်ဆောင်နိုင်ပြီး Desktop Environment၊ Terminal၊ Code Editor၊ MyanAI Agent စသော ဖွင့်လုံးများ ရှိသည်။",
            "### Instruction:\nDocker ဆိုတာ ဘာလဲ\n\n### Response:\nDocker သည် ကုဒ码 များကို container တွေကို ထုတ်လုပ်ပေးပြီး အမြဲတမ်းတွေကို ပိုမို တိုက်ရိုက် အသုံးပြုနိုင်အောင် လုပ်ပေးသော စကားလုံးဖြစ်သည်။",
            "### Instruction:\nAPI ဆိုတာ ဘာလဲ\n\n### Response:\nAPI (Application Programming Interface) သည် နောက်ပိုင်း system နှင့် ပူးပေါင်းလုပ်ဆောင်ရန် အသုံးပြုသော မှုတ်ပုဒ် စနစ်ဖြစ်သည်။",
            "### Instruction:\nPython error handling ရှင်းပြောပါ\n\n### Response:\n```python\ntry:\n    result = 10 / 0\nexcept ZeroDivisionError:\n    print('သာ: သုံးနဲ့ မပြောင်းနိုင်ပါ')\nfinally:\n    print('ခန့်မှှတ်ပြီးပြီ')\n```\nError handling သည် program ကို အမှားတွေကို ကျွန်ုပ်တို့ ကိုယ်တိုင် စိတ်ဖြာထားပြီး ပြဿနာတွေကို ဖြေဖြေရှင်းနိုင်ရန် အရေးကြီးသည်။",
            "### Instruction:\nGPU နဲ့ CPU ကို နှိုင်းပြောပါ\n\n### Response:\nCPU သည် နောက်ဆုံး ခွဲခြမ်းစိတ်ဖြာ ဒေတာများကို တိုက်ရိုက် လုပ်ဆောင်ခြင်း အကောင်းပါသည်။ GPU သည် အလိုလို တိုက်ရိုက် လုပ်ဆောင်ခြင်း (parallel processing) အတွက် အကောင်းပါသည်။ AI training တွေကို GPU ကို အသုံးပြုပြီး ပိုမို မြင့်မားသော ရလဒ်များ ရရှိနိုင်သည်။",
            "### Instruction:\nဘာများလုပ်ပေးနိုင်မလဲ\n\n### Response:\nကျွန်ုပ်တို့ အောက်ပါ အရာများကို လုပ်ပေးနိုင်ပါသည်။ မြန်မာစာ ကျွမ်းကျင်စွာ ဖြေရှင်းပေးခြင်း၊ ကုဒ码 ရေးခြင်း အကြံပြုပေးခြင်း (Python, JavaScript, HTML/CSS)၊ ဒေတာ ရှာဖွေခြင်း နှင့် ပြဿနာ ဖြေဆိုခြင်း၊ မြန်မာစာ သုံးပြီး ရေးသားခြင်း၊ MyanOS ခွဲခြမ်းစိတ်ဖြာ ပေးခြင်း။",
        ]
        
        with open(output_file, "w", encoding="utf-8") as f:
            for text in inline_data:
                f.write(json.dumps({"text": text}, ensure_ascii=False) + "\n")
        
        print(f"  [+] Created {len(inline_data)} inline training samples")
        return output_file


def build_llama_cpp():
    """Build llama.cpp with finetune support."""
    llama_dir = "./llama.cpp"
    
    if os.path.exists(f"{llama_dir}/build/bin/llama-finetune"):
        print("\n[+] llama.cpp finetune already built.")
        return
    
    print("\n[*] Building llama.cpp (this may take 10-20 minutes)...")
    
    # Clone if not exists
    if not os.path.exists(llama_dir):
        subprocess.run(
            "git clone --depth 1 https://github.com/ggml-org/llama.cpp",
            shell=True, capture_output=True
        )
    
    # Build with cmake (CPU only)
    os.makedirs(f"{llama_dir}/build", exist_ok=True)
    
    cmake_cmd = f"cd {llama_dir}/build && cmake .. -DGGML_CUDA=OFF -DGGML_BLAS=ON -DLLAMA_FINETUNE=ON"
    result = subprocess.run(cmake_cmd, shell=True, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"  [!] CMake error: {result.stderr[:200]}")
        print("  Trying make instead...")
        make_cmd = f"cd {llama_dir} && make llama-finetune -j{THREADS}"
        result = subprocess.run(make_cmd, shell=True, capture_output=False)
    else:
        make_cmd = f"cd {llama_dir}/build && cmake --build . --config Release -j{THREADS}"
        result = subprocess.run(make_cmd, shell=True, capture_output=False)
    
    if os.path.exists(f"{llama_dir}/build/bin/llama-finetune") or \
       os.path.exists(f"{llama_dir}/llama-finetune"):
        print("[+] llama.cpp finetune built successfully!")
    else:
        print("[!] Build may have issues. Checking...")
        result = subprocess.run(f"ls {llama_dir}/llama-finetune 2>/dev/null", shell=True, capture_output=True)
        if result.returncode == 0:
            print("[+] Found llama-finetune in main directory.")


def run_finetune(base_model_path, train_data_path):
    """Run llama.cpp finetune."""
    print("\n" + "=" * 60)
    print("  Starting CPU Fine-Tuning")
    print("=" * 60)
    print(f"  Base model: {base_model_path}")
    print(f"  Training data: {train_data_path}")
    print(f"  Epochs: {EPOCHS}")
    print(f"  Batch size: {BATCH_SIZE}")
    print(f"  Context length: {CONTEXT_LENGTH}")
    print(f"  Threads: {THREADS}")
    print(f"  Output: {LORA_OUTPUT}")
    print("=" * 60)
    
    # Find the finetune binary
    finetune_bin = None
    possible_paths = [
        "./llama.cpp/build/bin/llama-finetune",
        "./llama.cpp/llama-finetune",
    ]
    
    for p in possible_paths:
        if os.path.exists(p):
            finetune_bin = p
            break
    
    if not finetune_bin:
        print("[!] llama-finetune not found. Building...")
        build_llama_cpp()
        for p in possible_paths:
            if os.path.exists(p):
                finetune_bin = p
                break
    
    if not finetune_bin:
        print("[!] ERROR: Cannot find llama-finetune binary.")
        print("    Please build llama.cpp manually or use the Colab pipeline instead.")
        print("    Alternative: Use 2_finetune_colab.py (GPU, much faster)")
        return False
    
    os.makedirs(LORA_OUTPUT, exist_ok=True)
    
    # Run finetune
    cmd = [
        finetune_bin,
        f"--model-base={base_model_path}",
        f"--train-data={train_data_path}",
        f"--lora-out={LORA_OUTPUT}/lora-myanmar.gguf",
        f"--epoch={EPOCHS}",
        f"--batch-size={BATCH_SIZE}",
        f"--context-length={CONTEXT_LENGTH}",
        f"--threads={THREADS}",
        "--verbose",
    ]
    
    print(f"\n[*] Running: {' '.join(cmd)}")
    print("[*] This will take a while (30 min - 4 hours depending on CPU)...")
    
    result = subprocess.run(cmd, capture_output=True, text=True)
    
    if result.returncode == 0:
        print("[+] Fine-tuning complete!")
        print(result.stdout[-500:] if len(result.stdout) > 500 else result.stdout)
        return True
    else:
        print(f"[!] Fine-tuning failed:")
        print(result.stderr[-500:] if len(result.stderr) > 500 else result.stderr)
        return False


def create_modelfile():
    """Create Ollama Modelfile."""
    print("\n[*] Creating Ollama Modelfile...")
    
    modelfile_content = f'''FROM ./myanmar-qwen3b-cpu-q4.gguf
PARAMETER temperature 0.7
PARAMETER num_ctx 4096
PARAMETER repeat_penalty 1.1
SYSTEM """{SYSTEM_PROMPT}"""
'''
    
    os.makedirs(os.path.dirname(MODELFILE_PATH), exist_ok=True)
    with open(MODELFILE_PATH, "w", encoding="utf-8") as f:
        f.write(modelfile_content)
    
    print(f"[+] Modelfile created: {MODELFILE_PATH}")
    return MODELFILE_PATH


def main():
    print("=" * 60)
    print("  MyanOS AI Training - CPU Fine-Tuning Pipeline")
    print("  MyanOS v4.2.0 - MyanAI Agent Training")
    print("=" * 60)
    
    # Step 1: Check system
    check_system()
    
    # Step 2: Install dependencies
    install_dependencies()
    
    # Step 3: Download base model
    base_model_path = download_base_model()
    
    # Step 4: Prepare training data
    train_data_path = prepare_training_data()
    
    # Step 5: Build llama.cpp
    build_llama_cpp()
    
    # Step 6: Run fine-tuning
    success = run_finetune(base_model_path, train_data_path)
    
    if success:
        # Step 7: Create Modelfile
        create_modelfile()
        
        print("\n" + "=" * 60)
        print("  Fine-Tuning Complete!")
        print("=" * 60)
        print(f"  LoRA output: {LORA_OUTPUT}/lora-myanmar.gguf")
        print(f"  Modelfile: {MODELFILE_PATH}")
        print(f"\n  Next steps:")
        print(f"  1. Copy GGUF file and Modelfile to your server")
        print(f"  2. Run: ollama create myanmar-ai -f Modelfile")
        print(f"  3. Test: ollama run myanmar-ai 'မင်္ဂလာပါ'")
        print(f"  4. Use in MyanOS AI Training Center")
        print("=" * 60)
    else:
        print("\n[!] Fine-tuning failed.")
        print("    Alternative: Use 2_finetune_colab.py (Google Colab, free GPU)")
        print("    It's much faster and more reliable for fine-tuning.")


if __name__ == "__main__":
    main()
