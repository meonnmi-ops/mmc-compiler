"""
================================================================
  MyanOS AI Training Center - Google Colab Backend Server
================================================================
  
  Colab မှာ Run ပေးပြီး Myanos အတွက် Backend ဖြစ်စေမည်။
  
  အဆင့်များ:
  1. Google Colab မှာ အသစ် Notebook ဖွင့်ပါ
  2. Runtime > Change runtime type > T4 GPU ရွေးပါ
  3. ကုဒ码 ကို Copy-Paste လုပ်ပြီး Run ပေးပါ
  4. ထုတ်လုပ်သော URL ကို Copy ပြီး Myanos Settings မှာ Paste ပေးပါ
  5. Myanos AI Training Center ကို ဖွင့်ပါ - Real Working!
  
  Features:
  - Python code execution
  - GPU/CPU monitoring  
  - Ollama model management
  - Myanmar dataset tools
  - File management
  - Fine-tuning pipeline
  
================================================================
"""

# ================================================================
# CELL 1: Install Dependencies & Start Server
# ================================================================
# Run this cell first!

import subprocess
import sys
import os
import json
import threading
import time
import traceback
from io import StringIO
from datetime import datetime

# Install dependencies
subprocess.check_call([sys.executable, "-m", "pip", "install", "-q",
    "flask", "flask-cors", "psutil", "pyidaungsu", "datasets"])

from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
import psutil

app = Flask(__name__)
CORS(app)  # Allow Myanos to connect

# ================================================================
# CELL 2: Server State
# ================================================================

SERVER_INFO = {
    "started_at": datetime.now().isoformat(),
    "gpu_type": None,
    "gpu_memory": None,
    "cells_executed": 0,
    "last_command": None,
    "uptime": 0,
}

# Check GPU
try:
    import torch
    if torch.cuda.is_available():
        SERVER_INFO["gpu_type"] = torch.cuda.get_device_name(0)
        SERVER_INFO["gpu_memory"] = f"{torch.cuda.get_device_properties(0).total_mem / 1024**3:.1f} GB"
except:
    pass


# ================================================================
# CELL 3: Core API Endpoints
# ================================================================

@app.route("/api/health", methods=["GET"])
def health():
    """Health check - Myanos uses this to verify connection."""
    uptime = int(time.time() - datetime.fromisoformat(SERVER_INFO["started_at"]).timestamp())
    SERVER_INFO["uptime"] = uptime
    return jsonify({
        "status": "online",
        "gpu": SERVER_INFO["gpu_type"],
        "gpu_memory": SERVER_INFO["gpu_memory"],
        "cells_executed": SERVER_INFO["cells_executed"],
        "uptime_seconds": uptime,
        "started_at": SERVER_INFO["started_at"],
        "python_version": sys.version.split()[0],
        "platform": "Google Colab",
    })


@app.route("/api/training", methods=["POST"])
def execute_cell():
    """
    Execute Python code from Myanos AI Training Center.
    This is the MAIN endpoint - every code cell goes here.
    """
    try:
        data = request.json
        action = data.get("action", "execute_cell")
        
        if action == "execute_cell":
            code = data.get("code", "")
            if not code.strip():
                return jsonify({"status": 0, "output": "(no code to execute)"})
            
            SERVER_INFO["last_command"] = code[:100]
            SERVER_INFO["cells_executed"] += 1
            
            # Capture stdout/stderr
            old_stdout = sys.stdout
            old_stderr = sys.stderr
            sys.stdout = StringIO()
            sys.stderr = StringIO()
            
            result = ""
            status = 0
            
            try:
                # Create execution namespace with useful imports
                exec_globals = {
                    "print": print,
                    "__builtins__": __builtins__,
                }
                
                # Auto-import common libraries
                auto_imports = [
                    ("import os", "os"),
                    ("import json", "json"),
                    ("import sys", "sys"),
                    ("import math", "math"),
                    ("import random", "random"),
                    ("from datetime import datetime", "datetime"),
                    ("from collections import Counter, defaultdict", "Counter"),
                ]
                
                for import_code, name in auto_imports:
                    try:
                        exec(import_code, exec_globals)
                    except:
                        pass
                
                exec(code, exec_globals)
                
                result = sys.stdout.getvalue()
                if not result:
                    result = "(executed successfully)"
                    
            except Exception as e:
                result = f"{type(e).__name__}: {e}"
                status = 1
                if sys.stderr.getvalue():
                    result += "\n" + sys.stderr.getvalue()
                
            finally:
                sys.stdout = old_stdout
                sys.stderr = old_stderr
            
            return jsonify({"status": status, "output": result.strip()})
        
        elif action == "system_info":
            return jsonify(get_system_info())
        
        elif action == "check_packages":
            packages = data.get("packages", [])
            return jsonify(check_packages(packages))
        
        else:
            return jsonify({"status": 1, "output": f"Unknown action: {action}"})
            
    except Exception as e:
        return jsonify({"status": 1, "output": f"Server error: {e}"})


@app.route("/api/exec", methods=["POST"])
def exec_command():
    """Execute code via /api/exec (fallback endpoint)."""
    try:
        data = request.json
        code = data.get("cmd", "")
        if not code.strip():
            return jsonify({"status": 0, "output": ""})
        
        SERVER_INFO["cells_executed"] += 1
        
        old_stdout = sys.stdout
        old_stderr = sys.stderr
        sys.stdout = StringIO()
        sys.stderr = StringIO()
        
        try:
            exec_globals = {"__builtins__": __builtins__, "print": print}
            for imp in ["import os", "import json", "import sys"]:
                try: exec(imp, exec_globals)
                except: pass
            
            exec(code, exec_globals)
            result = sys.stdout.getvalue() or "(executed)"
            status = 0
        except Exception as e:
            result = f"{type(e).__name__}: {e}"
            status = 1
        finally:
            sys.stdout = old_stdout
            sys.stderr = old_stderr
        
        return jsonify({"status": status, "output": result.strip()})
    except Exception as e:
        return jsonify({"status": 1, "output": str(e)})


@app.route("/api/system-info", methods=["GET"])
def system_info():
    """Get system stats for Training Center Dashboard."""
    return jsonify(get_system_info())


@app.route("/api/system-stats", methods=["GET"])
def system_stats():
    """Get detailed system stats."""
    info = get_system_info()
    info["server_info"] = SERVER_INFO
    return jsonify(info)


# ================================================================
# CELL 4: System Info Functions
# ================================================================

def get_system_info():
    """Collect system metrics."""
    info = {
        "cpu_percent": psutil.cpu_percent(interval=0.5),
        "memory_total_gb": round(psutil.virtual_memory().total / 1024**3, 1),
        "memory_used_gb": round(psutil.virtual_memory().used / 1024**3, 1),
        "memory_percent": psutil.virtual_memory().percent,
        "disk_free_gb": round(psutil.disk("/").free / 1024**3, 1),
        "python_version": sys.version.split()[0],
        "gpu": None,
        "gpu_util": 0,
        "gpu_memory_used": 0,
        "gpu_memory_total": 0,
    }
    
    try:
        import torch
        if torch.cuda.is_available():
            info["gpu"] = torch.cuda.get_device_name(0)
            info["gpu_util"] = torch.cuda.utilization(0)
            info["gpu_memory_used"] = round(torch.cuda.memory_allocated(0) / 1024**3, 2)
            info["gpu_memory_total"] = round(torch.cuda.get_device_properties(0).total_mem / 1024**3, 1)
    except:
        pass
    
    return info


def check_packages(packages):
    """Check if Python packages are installed."""
    results = {}
    for pkg in packages:
        try:
            __import__(pkg)
            results[pkg] = True
        except ImportError:
            results[pkg] = False
    return results


# ================================================================
# CELL 5: Ollama Management (if installed on Colab)
# ================================================================

@app.route("/api/ollama/list", methods=["GET"])
def ollama_list():
    """List available Ollama models."""
    try:
        import subprocess
        result = subprocess.run(["ollama", "list"], capture_output=True, text=True)
        models = []
        for line in result.stdout.strip().split("\n")[1:]:
            parts = line.split()
            if parts:
                models.append({"name": parts[0], "size": parts[1] if len(parts)>1 else "?"})
        return jsonify({"status": 0, "models": models})
    except:
        return jsonify({"status": 1, "models": [], "error": "Ollama not installed"})


@app.route("/api/ollama/pull", methods=["POST"])
def ollama_pull():
    """Pull an Ollama model."""
    try:
        data = request.json
        model = data.get("model", "qwen2.5:3b")
        import subprocess
        result = subprocess.run(["ollama", "pull", model], capture_output=True, text=True, timeout=600)
        return jsonify({"status": 0, "output": result.stdout or result.stderr})
    except Exception as e:
        return jsonify({"status": 1, "output": str(e)})


# ================================================================
# CELL 6: Myanmar Dataset Tools
# ================================================================

@app.route("/api/myanmar/datasets", methods=["GET"])
def myanmar_datasets():
    """Get list of available Myanmar datasets."""
    datasets = [
        {"id": "myanmar_instructions", "name": "Myanmar Instruction Dataset (40+ QA)", "type": "instruction", "rows": 40},
        {"id": "wikipedia_my", "name": "Wikipedia Burmese", "type": "corpus", "rows": "700K+"},
        {"id": "oscar_my", "name": "OSCAR Corpus (Burmese)", "type": "corpus", "rows": "~1.2GB"},
        {"id": "myanmar_microbiology", "name": "Burmese Microbiology 1K", "type": "instruction", "rows": 1000},
        {"id": "myanmar_agriculture", "name": "Myanmar Agriculture 1K", "type": "instruction", "rows": 1000},
        {"id": "burmese_coder", "name": "Burmese-Coder-4B Data", "type": "code", "rows": 974},
        {"id": "myanmar_dictionary", "name": "Burmese Dictionary (18K words)", "type": "dictionary", "rows": 18000},
    ]
    return jsonify({"status": 0, "datasets": datasets})


# ================================================================
# CELL 7: Start Server with Public URL
# ================================================================

# Try localtunnel first (no signup needed)
def start_server(port=5000):
    """Start the Flask server."""
    app.run(host="0.0.0.0", port=port, debug=False, use_reloader=False)

# Start in background thread
import _thread
_thread.start_new_thread(start_server, (5000,))

time.sleep(2)

# Install and run localtunnel to get a public URL
print("=" * 60)
print("  MyanOS Colab Backend Server")
print("=" * 60)
print(f"\n[+] Server running on port 5000")
print(f"[+] GPU: {SERVER_INFO['gpu_type'] or 'Not detected (change to GPU runtime!)'}")
print(f"[+] GPU Memory: {SERVER_INFO['gpu_memory'] or 'N/A'}")
print()

# Install localtunnel
subprocess.run([sys.executable, "-m", "pip", "install", "-q", "localtunnel"], check=False)

print("[*] Creating public URL with localtunnel...")
print("[*] This may take 10-20 seconds...")
print()

import subprocess
import os

# Kill any existing lt process
os.system("pkill -f 'localtunnel' 2>/dev/null || true")
time.sleep(1)

# Start localtunnel
proc = subprocess.Popen(
    ["npx", "localtunnel", "--port", "5000"],
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE,
    text=True
)

# Wait for URL
import select
time.sleep(5)

# Try to read the URL from output
url = None
try:
    import urllib.request
    import json
    
    # Wait longer for localtunnel to initialize
    for i in range(30):
        try:
            req = urllib.request.urlopen("http://127.0.0.1:4040/api/tunnels")
            data = json.loads(req.read())
            url = data["tunnels"][0]["public_url"]
            break
        except:
            time.sleep(1)
except:
    pass

if url:
    print("=" * 60)
    print(f"  PUBLIC URL: {url}")
    print("=" * 60)
    print(f"\n  Copy this URL and paste it in Myanos:")
    print(f"  1. Open Myanos Settings")
    print(f"  2. Paste in 'Backend URL' field:")
    print(f"     {url}")
    print(f"  3. Click Save")
    print(f"  4. Open AI Training Center")
    print(f"  5. Start coding! Everything is now REAL WORKING!")
    print(f"\n  The server will keep running as long as this Colab is open.")
    print(f"  Keep this tab alive!")
else:
    print("[!] Could not auto-generate public URL.")
    print("[*] Try one of these alternatives:")
    print("    1. ngrok: !pip install pyngrok && from pyngrok import ngrok; ngrok.connect(5000)")
    print("    2. Or use the Colab notebook sharing link + run cells manually")
    print(f"\n  Server is running on port 5000 (internal Colab)")

print()
