#!/usr/bin/env python3
"""
================================================================
  MyanOS AI Training - Google Colab Fine-Tuning Pipeline
================================================================
  
  ကုဒံ ကို Google Colab မှာ run ပေးပါ (Free T4 GPU)
  
  အဆင့်များ:
  1. Google Colab မှာ အသစ် notebook ဖွင့်ပါ
  2. Runtime > Change runtime type > T4 GPU ရွေးပါ
  3. ကုဒံ ကို copy-paste လုပ်ပြီး run ပေးပါ
  4. ပြီးလျှင် GGUF file ကို download ပေးပါ
  5. Ollama ထဲထည့်သွင်းပါ
  
  Dependencies: တရားဝင် - Colab တွေကို install လုပ်ပေးမည်
  
  Output: myanmar-qwen3b.gguf (Ollama ဖို့ အသုံးပြုနိုင်သော GGUF file)
================================================================
"""

# ================================================================
# CELL 1: Install Dependencies
# ================================================================
# Run this cell first!

"""
%%capture
import subprocess
import sys

def install(pkg):
    subprocess.check_call([sys.executable, "-m", "pip", "install", "-q", pkg])

# Install Unsloth (2x faster training, 60% less VRAM)
install("unsloth")
install("datasets")
install("huggingface_hub")

# Get latest Unsloth
!pip install --force-reinstall --no-cache-dir --no-deps \
    git+https://github.com/unslothai/unsloth.git

print("[+] All dependencies installed!")
"""

# ================================================================
# CELL 2: Load Model
# ================================================================

"""
from unsloth import FastLanguageModel
import torch

# Model selection - Qwen 2.5 3B is BEST for Myanmar
# Works on free T4 GPU (16GB VRAM)!
model, tokenizer = FastLanguageModel.from_pretrained(
    model_name="unsloth/qwen2.5-3b-bnb-4bit",
    max_seq_length=2048,
    dtype=None,           # Auto-detect
    load_in_4bit=True,    # 4-bit quantization (saves VRAM)
)

# Apply LoRA (Low-Rank Adaptation) - trains only small adapter
model = FastLanguageModel.get_peft_model(
    model,
    r=16,                # LoRA rank (higher = more capacity)
    target_modules=[
        "q_proj", "k_proj", "v_proj", "o_proj",
        "gate_proj", "up_proj", "down_proj",
    ],
    lora_alpha=16,
    lora_dropout=0,
    bias="none",
    use_gradient_checkpointing="unsloth",  # Saves VRAM
    random_state=3407,
    use_rslora=False,
    loftq_config=None,
)

print("[+] Model loaded with LoRA adapter!")
print(f"    VRAM used: {torch.cuda.memory_allocated() / 1024**3:.1f} GB")
"""

# ================================================================
# CELL 3: Prepare Myanmar Training Data
# ================================================================

"""
from datasets import load_dataset
import json

# === Option A: Load from our dataset collector output ===
# Upload myanmar_master_instructions.jsonl to Colab first
try:
    dataset = load_dataset("json", data_files="myanmar_master_instructions.jsonl", split="train")
    print(f"[A] Loaded {len(dataset)} instructions from local file")
except:
    dataset = None

# === Option B: Load from HuggingFace ===
if dataset is None:
    try:
        dataset = load_dataset(
            "chuuhtetnaing/myanmar-instruction-tuning-dataset",
            split="train"
        )
        print(f"[B] Loaded {len(dataset)} from HuggingFace")
    except:
        dataset = None

# === Option C: Create inline Myanmar training data ===
if dataset is None:
    myanmar_data = [
        # === Basic Greetings ===
        {"instruction": "မင်္ဂလာပါ", "input": "", "output": "ကျေးဇူးတိုင်းပါ၊ ကြိုတင်ပါ။ ဘာကြောင့် မင်္ဂလာလဲ။ ကျေးဇူးပါ ခေါ်တဲ့ အချက်များကို မေးနိုင်ပါသည်။"},
        {"instruction": "နေ့ခင်းကျေးဇူးပါ", "input": "", "output": "နေ့ခင်းကျေးဇူးတိုင်းပါ။ နေ့ခင်း ကောင်းပါသလား။ ရှင်းရှင်းပြောရရင် ဘာများ ဝန်ဆောင်ပေးနိုင်ပါသလဲ။"},
        
        # === Myanmar Language ===
        {"instruction": "မြန်မာစာလုံးချင်း သုံးမျိုးကို ရှောမြောက်ပါ", "input": "", "output": "မြန်မာစာ လုံးချင်း (၃) မျိုးရှိသည်:\\n\\n၁။ ပေတံ (ဒါး) - စာအုပ်ပြီးနောက် နောက်ဆုံးတွေကို သတ်မှတ်ပေးတဲ့ လုံးချင်း\\n၂။ နက်ရှိုင်း (ပဲ) - ရောရှည်လိုက်သော လုံးချင်း\\n၃။ သွေးစာလုံး - အခြားနှင့် ဆက်စပ်မှု မရှိသော စာလုံးများ"},
        
        {"instruction": "မြန်မာစာ စာလုံး (၃၃) လုံးကို ရေးပါ", "input": "", "output": "မြန်မာစာ စာလုံး (၃၃) လုံးမှာ:\\nအ - ချ - ဂ - က - သ - ဂါ - ငါ - ခ် - တ - အ် - ဉ - ရ - ဣ - ဦ - ဈ - တ် - ဝ - လ - ဝ် - သု - သို - ဦး - ဉါ - ဣ် - ဈါ - ဃါ - ဩ - ဈိ - ဠ - ကျ - အှ် - န် - လ် - ဥ်\\n\\nဤစာလုံးများသည် ဗျူးာနီယာ ဘာသာစကားမှ ဆက်ခံလာပြီး မြန်မာဘာသာ၏ အခြေခံအကြောင်းဖြစ်သည်।"},
        
        # === Coding ===
        {"instruction": "Python ဖြင့် 'Hello World' ရေးပေးပါ", "input": "", "output": "Python ဖြင့် 'Hello World' ရေးရန်:\\n\\n```python\\nprint('Hello World')\\n```\\n\\nဤကုဒ်သည် 'Hello World' စာသာရကို screen ပေါ်တွေက်ပြပေးမည်။ Python တွေကို စမ်းသပ်ရန် အကောင်းဆုံးပြီး ရိုးဖြစ်သော ပမာဏဖြစ်သည်।"},
        
        {"instruction": "Python for loop ရှင်းပြောပါ", "input": "", "output": "Python for loop ဆိုတာ:\\n\\n```python\\n# 1 ကနေ 5 ထိ\\nfor i in range(1, 6):\\n    print(i)\\n\\n# စာရင်းထဲက တစ်ခုခုခန့်မှှတ်\\nfruits = ['သကြား', 'သံချေး', 'ပဲလီး']\\nfor fruit in fruits:\\n    print(fruit)\\n```\\n\\nfor loop သည် စာရင်းတွေကို တိုက်ရိုက် iterate လုပ်နိုင်တဲ့ အရေးကြီးပစ္စည်းဖြစ်သည်।"},
        
        {"instruction": "JavaScript နဲ့ Python ကို နှိုင်းပြောပါ", "input": "", "output": "JavaScript နဲ့ Python နှိုင်းချက်:\\n- JS တွေကို browser တွေကို မြှင့်တင်ရန် သုံးပါသည်\\n- Python တွေကို AI၊ data science လုပ်ရန် သုံးပါသည်\\n- JS တွေကို {} block separator သုံးပါသည်\\n- Python တွေကို indentation သုံးပါသည်\\n- JS တွေကို let/const သုံးပါသည်\\n- Python တွေကို အသုံးမပြုဘဲ variable ခေါ်ပါသည်"},
        
        {"instruction": "Python function တစ်ခု ရေးပေးပါ", "input": "", "output": "```python\\ndef say_hello(name):\\n    return f'မင်္ဂလာပါ {name}၊ ကြိုတင်ပါ။'\\n\\nresult = say_hello('ကျော်ကျော်')\\nprint(result)\\n# ရလဒ်: မင်္ဂလာပါ ကျော်ကျော်၊ ကြိုတင်ပါ။\\n```\\n\\nfunction ဆိုသည်မှာ ချက်ချက်လုပ်နေတဲ့ ကုဒ်ကို တစ်ခုခုအဖြစ် ထုတ်လုပ်ထားပြီး အမြဲတမ်းအသုံးပြုနိုင်ရန် အကောင်းပါ။"},
        
        {"instruction": "Git commands အဓိကအများဆုံးပေးပါ", "input": "", "output": "Git အဓိက commands:\\n\\n```bash\\ngit init                      # repo စတင်\\ngit add .                     # အကြောင်းအားလုံး add\\ngit commit -m 'message'      # သိမ်းဆည်း\\ngit push origin main          # ပေးပို့\\ngit pull origin main          # ပြန်လည်ရယူ\\ngit status                    # အခြေအနေကြည့်\\ngit log                       # မှတ်တမ်းကြည့်\\n```\\n\\nGit သည် ကုဒ码 ပြင်ပြင်လဲလှယ်မှုများကို မှတ်တမ်းတင်ပေးသော version control system ဖြစ်သည်।"},
        
        # === Error Handling ===
        {"instruction": "Python error handling ရှင်းပြောပါ", "input": "", "output": "```python\\ntry:\\n    result = 10 / 0\\nexcept ZeroDivisionError:\\n    print('သာ: သုံးနဲ့ မပြောင်းနိုင်ပါ')\\nexcept TypeError:\\n    print('သာ: နံပတ်တွေ မမှန်ပါ')\\nfinally:\\n    print('ခန့်မှှတ်ပြီးပြီ')\\n```\\n\\nError handling သည် program ကို အမှားတွေကို ကျွန်ုပ်တို့ ကိုယ်တိုင် စိတ်ဖြာထားပြီး ပြဿနာတွေကို ဖြေဖြေရှင်းနိုင်ရန် အရေးကြီးသည်။"},
        
        # === Technical ===
        {"instruction": "Docker ဆိုတာ ဘာလဲ", "input": "", "output": "Docker သည် ကုဒ码 များကို container များတွေကို ထုတ်လုပ်ပေးပြီး အမြဲတမ်းတွေကို ပိုမို တိုက်ရိုက် အသုံးပြုနိုင်အောင် လုပ်ပေးသော စကားလုံးဖြစ်သည်။ Container ဆိုတာတွေကို ကုဒ码 တစ်ခုခုကို ပိုင်နက် ဖွဲ့ထဲတွေကို ထိန်းသိမ်းပေးတဲ့ ပိုင်နက် ဖွဲ့လောကကြီး ဖြစ်သည်।"},
        
        {"instruction": "API ဆိုတာ ဘာလဲ", "input": "", "output": "API (Application Programming Interface) သည် နောက်ပိုင်း system နှင့် ပူးပေါင်းလုပ်ဆောင်ရန် အသုံးပြုသော မှုတ်ပုဒ် စနစ်ဖြစ်သည်။ REST API ဆိုတာ HTTP protocol ကို အသုံးပြုပြီး GET (ရယူ), POST (ပေးပို့), PUT (ပြင်), DELETE (ဖျက်) စသော လုပ်ဆောင်ချက်များ လုပ်ဆောင်နိုင်သည်။"},
        
        {"instruction": "GPU နဲ့ CPU ကို နှိုင်းပြောပါ", "input": "", "output": "CPU သည် နောက်ဆုံး ခွဲခြမ်းစိတ်ဖြာ ဒေတာများကို တိုက်ရိုက် လုပ်ဆောင်ခြင်း အကောင်းပါသည်။ GPU သည် အလိုလို တိုက်ရိုက် လုပ်ဆောင်ခြင်း (parallel processing) အတွက် အကောင်းပါသည်။ AI training တွေကို GPU ကို အသုံးပြုပြီး ပိုမို မြင့်မားသော မှုတ်သားများ ရရှိနိုင်သည်။"},
        
        # === MyanOS ===
        {"instruction": "MyanOS ဆိုတာ ဘာလဲ", "input": "", "output": "MyanOS သည် မြန်မာအရေးသား Developer တွေ ဖန်တီးထားတဲ့ Web-based Operating System ဖြစ်သည်။ ဗားရှင်း (Browser) ပေါ်တွေကို လုပ်ဆောင်နိုင်ပြီး Desktop Environment၊ Terminal၊ Code Editor၊ MyanAI Agent၊ Myanmar Keyboard စသော အခြေခံဖွင့်လုံးများပါ ရှိသည်။ MyanOS v4.2.0 သည် မြန်မာစာကို အဓိကထားပြီး AI ခွဲခြမ်းစိတ်ဖြာ တွေကို ပါဝင်ထားသည်।"},
        
        # === General ===
        {"instruction": "ကျေးဇူးတိုင်းပါ", "input": "", "output": "ကျေးဇူးတိုင်းပါ။ ဘာကြောင့် မင်္ဂလာလဲ။ ကျေးဇူးပါ ခေါ်တဲ့ အချက်များကို မေးနိုင်ပါသည်။ ကျွန်ုပ်တို့ မြန်မာစာ ကျွမ်းကျင်သော AI assistant ဖြစ်ပါသည်।"},
        
        {"instruction": "ဘာများလုပ်ပေးနိုင်မလဲ", "input": "", "output": "ကျွန်ုပ်တို့ အောက်ပါ အရာများကို လုပ်ပေးနိုင်ပါသည်:\\n၁။ မြန်မာစာ ကျွမ်းကျင်စွာ ဖြေရှင်းပေးခြင်း\\n၂။ ကုဒ码 ရေးခြင်း အကြံပြုပေးခြင်း\\n၃။ ဒေတာ ရှာဖွေခြင်း နှင့် ပြဿနာ ဖြေဆိုခြင်း\\n၄။ မြန်မာစာ သုံးပြီး ရေးသားခြင်း\\n၅။ MyanOS ခွဲခြမ်းစိတ်ဖြာ ပေးခြင်း"},
        
        {"instruction": "မြန်မာနိုင်ငံ၏ နေရာချိန်", "input": "", "output": "မြန်မာနိုင်ငံသည် GMT+6:30 ကို အသုံးပြုသည်။ မြန်မာစံနှုန်းနေရာချိန် (MST) ဟု ခေါ်သည်။ ထိုင်းနိုင်ငံနေရာချိန် (ICT) ထက် တစ်နာရီတိုင်း (၃၀ မိနစ်) ခန့်ကာလ နောက်ကျသည်။"},
    ]
    
    import pandas as pd
    dataset = load_dataset("json", data_files=json.dumps(myanmar_data), split="train")
    print(f"[C] Created {len(dataset)} inline instructions")

# Format for training
def formatting_prompts_func(examples):
    outputs = []
    for inst, inp, out in zip(examples["instruction"], examples["input"], examples["output"]):
        if inp and inp.strip():
            text = f"### Instruction:\n{inst}\n\n### Input:\n{inp}\n\n### Response:\n{out}"
        else:
            text = f"### Instruction:\n{inst}\n\n### Response:\n{out}"
        outputs.append(text)
    return {"text": outputs}

dataset = dataset.map(formatting_prompts_func, batched=True)
print(f"\n[+] Training data prepared: {len(dataset)} samples")
print(f"    Example:\n{dataset[0]['text'][:200]}...")
"""

# ================================================================
# CELL 4: Start Training!
# ================================================================

"""
from trl import SFTTrainer
from transformers import TrainingArguments
import torch

trainer = SFTTrainer(
    model=model,
    tokenizer=tokenizer,
    train_dataset=dataset,
    dataset_text_field="text",
    max_seq_length=2048,
    dataset_num_proc=2,
    packing=False,          # True for small datasets (faster)
    args=TrainingArguments(
        per_device_train_batch_size=2,
        gradient_accumulation_steps=4,
        warmup_steps=5,
        max_steps=500,       # Increase for larger datasets!
        learning_rate=2e-4,  # Higher LR for low-resource languages
        fp16=not torch.cuda.is_bf16_supported(),
        bf16=torch.cuda.is_bf16_supported(),
        logging_steps=10,
        optim="adamw_8bit",
        weight_decay=0.01,
        lr_scheduler_type="linear",
        seed=3407,
        output_dir="outputs",
    ),
)

print("[+] Starting training...")
print(f"    Training steps: 500")
print(f"    Batch size: 2 x 4 accumulation = 8 effective")
print(f"    Learning rate: 2e-4")

trainer_stats = trainer.train()
print(f"\n[+] Training complete!")
print(f"    Training time: {trainer_stats.metrics['train_runtime']:.1f} seconds")
"""

# ================================================================
# CELL 5: Save Model
# ================================================================

"""
# Save LoRA adapter (small, ~50-200MB)
model.save_pretrained("myanmar_lora")
tokenizer.save_pretrained("myanmar_lora")
print("[+] LoRA adapter saved to myanmar_lora/")

# Merge and save full model (for GGUF conversion)
model.save_pretrained_merged(
    "myanmar_qwen_full",
    tokenizer,
    save_method="merged_16bit",
)
print("[+] Full merged model saved to myanmar_qwen_full/")

# Optional: Push to HuggingFace Hub
# model.push_to_hub_merged("your-username/myanmar-qwen3b", tokenizer, save_method="merged_16bit")
# print("[+] Pushed to HuggingFace Hub!")
"""

# ================================================================
# CELL 6: Convert to GGUF for Ollama
# ================================================================

"""
import subprocess

print("[+] Converting to GGUF format for Ollama...")

# Step 1: Clone llama.cpp
!git clone https://github.com/ggml-org/llama.cpp 2>/dev/null || true

# Step 2: Build convert script
print("[+] Building llama.cpp...")
result = subprocess.run(
    ["python", "llama.cpp/convert_hf_to_gguf.py", 
     "myanmar_qwen_full", 
     "--outfile", "myanmar-qwen3b-f16.gguf",
     "--outtype", "f16"],
    capture_output=True, text=True
)
print(result.stdout)
if result.returncode != 0:
    print(f"[!] Error: {result.stderr}")
else:
    print("[+] F16 GGUF created: myanmar-qwen3b-f16.gguf")

# Step 3: Quantize to Q4_K_M (smaller, faster, still good quality)
print("[+] Quantizing to Q4_K_M...")
result = subprocess.run(
    ["./llama.cpp/llama-quantize", 
     "myanmar-qwen3b-f16.gguf",
     "myanmar-qwen3b-q4.gguf",
     "Q4_K_M"],
    capture_output=True, text=True
)
print(result.stdout)
if result.returncode != 0:
    print(f"[!] Error: {result.stderr}")
else:
    print("[+] Quantized GGUF created: myanmar-qwen3b-q4.gguf")
    print(f"    File size: {os.path.getsize('myanmar-qwen3b-q4.gguf') / 1024**3:.2f} GB")

# Step 4: Download the file
from google.colab import files
files.download("myanmar-qwen3b-q4.gguf")
print("\n[+] Download started! Save this file.")
"""

# ================================================================
# CELL 7: Import to Ollama (on your machine)
# ================================================================
# After downloading the GGUF file, run these commands:

"""
# On your machine / HF Space / Termux:

# Step 1: Copy GGUF file to your server
# scp myanmar-qwen3b-q4.gguf user@server:/path/

# Step 2: Create Modelfile
# Note: SYSTEM prompt uses triple quotes in Ollama Modelfile format
cat > Modelfile << 'MODELEOF'
FROM ./myanmar-qwen3b-q4.gguf
PARAMETER temperature 0.7
PARAMETER num_ctx 4096
SYSTEM 'You are a Myanmar language AI assistant. Always respond in Myanmar. MyanOS v4.2.0 MyanAI Agent. Explain coding and technical topics in Myanmar. Write correct Myanmar grammar.'
MODELEOF

# Step 3: Create Ollama model
ollama create myanmar-ai -f Modelfile

# Step 4: Test!
ollama run myanmar-ai "မင်္ဂလာပါ၊ ကျေးဇူးတိုင်းပါ။ ဘာများလုပ်ပေးနိုင်မလဲ"

# Step 5: Use in MyanOS
# MyanOS AI Training Center မှာ myanmar-ai model ကို ရွေးချယ်ပါ
"""

# ================================================================
# QUICK START GUIDE
# ================================================================
"""
=== MyanOS Myanmar AI Fine-Tuning Quick Start ===

1. Google Colab မှာ အသစ် notebook ဖွင့်ပါ
   https://colab.research.google.com

2. Runtime > Change runtime type > T4 GPU ရွေးပါ

3. Cell 1 ကနေ Cell 7 အထိ Copy-Paste လုပ်ပြီး Run ပေးပါ
   (တစ် Cell ချင်း Run ပေးပါ)

4. myanmar-qwen3b-q4.gguf file ကို download ပေးပါ

5. ကိုယ်ပိုင်း server / HF Space ကို ထည့်သွင်းပါ

6. Ollama ထဲထည့်သွင်းပါ:
   ollama create myanmar-ai -f Modelfile

7. MyanOS ထဲမှာ အသုံးပြုပါ:

သတိပေးချက်:
- Free Colab T4 GPU မှာ တစ်ကြိမ် လုပ်ရင် ၃၀ မိနစ် - ၁ နာရီ ကျား ကုန်သည်
- Dataset ပိုမိုရှိရင် max_steps ကို ပိုမို တိုးမည်
- လေးကျင့် လေးကျင့် ပြင်ပြင်လုပ်နိုင်သည် (iteration)
- LoRA adapter ကို သိမ်းထားပြီး နောက်ပြည့် ပိုမို train လုပ်နိုင်သည်
"""
