#!/usr/bin/env python3
"""
Myanmar AI Training - Dataset Collector
========================================
This script downloads and prepares ALL available Myanmar language datasets
for fine-tuning Ollama/LLaMA models.

Usage:
    pip install datasets huggingface_hub requests tqdm
    python 1_collect_datasets.py

Output: ./datasets/ directory with all prepared datasets
"""

import os
import json
import sys
import csv
from pathlib import Path
from tqdm import tqdm

DATASETS_DIR = Path("./datasets")
DATASETS_DIR.mkdir(exist_ok=True)

INSTRUCTION_DIR = DATASETS_DIR / "instruction_tuning"
INSTRUCTION_DIR.mkdir(exist_ok=True)

CORPUS_DIR = DATASETS_DIR / "corpus"
CORPUS_DIR.mkdir(exist_ok=True)


def check_dependencies():
    """Check and install required packages."""
    missing = []
    try:
        import datasets
    except ImportError:
        missing.append("datasets")
    try:
        from huggingface_hub import HfApi
    except ImportError:
        missing.append("huggingface_hub")
    try:
        from tqdm import tqdm
    except ImportError:
        missing.append("tqdm")

    if missing:
        print(f"[!] Installing missing packages: {', '.join(missing)}")
        os.system(f"{sys.executable} -m pip install {' '.join(missing)} -q")
        print("[+] Dependencies installed.")
    else:
        print("[+] All dependencies available.")


def download_hf_dataset(repo_id, subset=None, split="train", save_path=None, text_field="text"):
    """Download a HuggingFace dataset and save locally."""
    from datasets import load_dataset

    if save_path is None:
        save_name = repo_id.replace("/", "_")
        save_path = CORPUS_DIR / f"{save_name}.jsonl"

    print(f"\n[*] Downloading: {repo_id}")
    try:
        if subset:
            ds = load_dataset(repo_id, subset, split=split, trust_remote_code=True)
        else:
            ds = load_dataset(repo_id, split=split, trust_remote_code=True)

        with open(save_path, "w", encoding="utf-8") as f:
            for item in tqdm(ds, desc=f"  Writing {save_path.name}"):
                if text_field in item:
                    text = item[text_field]
                    if isinstance(text, str) and len(text.strip()) > 10:
                        f.write(json.dumps({"text": text.strip()}, ensure_ascii=False) + "\n")

        count = sum(1 for _ in open(save_path, encoding="utf-8"))
        print(f"  [+] Saved {count} samples to {save_path}")
        return count
    except Exception as e:
        print(f"  [!] Error: {e}")
        return 0


def download_instruction_dataset(repo_id, instruction_field="instruction",
                                   input_field="input", output_field="output",
                                   split="train", save_path=None):
    """Download instruction-tuning dataset."""
    from datasets import load_dataset

    if save_path is None:
        save_name = repo_id.replace("/", "_")
        save_path = INSTRUCTION_DIR / f"{save_name}.jsonl"

    print(f"\n[*] Downloading: {repo_id}")
    try:
        ds = load_dataset(repo_id, split=split, trust_remote_code=True)

        count = 0
        with open(save_path, "w", encoding="utf-8") as f:
            for item in tqdm(ds, desc=f"  Writing {save_path.name}"):
                instruction = item.get(instruction_field, "")
                inp = item.get(input_field, "")
                output = item.get(output_field, "")

                if isinstance(instruction, str) and isinstance(output, str):
                    if len(instruction.strip()) > 2 and len(output.strip()) > 2:
                        entry = {
                            "instruction": instruction.strip(),
                            "input": inp.strip() if isinstance(inp, str) else "",
                            "output": output.strip()
                        }
                        f.write(json.dumps(entry, ensure_ascii=False) + "\n")
                        count += 1

        print(f"  [+] Saved {count} instruction pairs to {save_path}")
        return count
    except Exception as e:
        print(f"  [!] Error: {e}")
        return 0


def create_myanmar_instruction_dataset():
    """
    Create a comprehensive Myanmar instruction-tuning dataset
    by combining multiple sources and generating high-quality QA pairs.
    """
    output_path = INSTRUCTION_DIR / "myanmar_master_instructions.jsonl"

    instructions = []

    # === Category 1: Myanmar Language Basics ===
    basics = [
        {"instruction": "မြန်မာစာတွေကို အဘယ်ကဲ့သို့ ရေးသားထားသလဲ", "input": "", "output": "မြန်မာစာသည် အိမ်နိုင်ငံရေး လူထုခွဲကို လက်ခံထားပြီး ဗျူးာနီယာ ဘာသာစကားများမှ ဆက်ခံလာသော ဘာသာစကားဖြစ်သည်။ အပြည့်အစုံ စာလုံး (၃၃) လုံးနဲ့ သွေးစာလုံး (၁၂) လုံး ရှိသည်။ မြန်မာစာသည် အောက်ပါ လုံးချင်းများကို အသုံးပြုသည် - မှန်ကန်သော တိကျသော ပြက္ခဒိန် လုံးချင်း၊ စာပေတွေကို သတ်မှတ်ပေးတဲ့ ရောရှည်လိုက်သော နက်ရှိုင်း လုံးချင်း၊ နောက်ဆုံးမှတ်ပုတ်ပေးတဲ့ ပေတံ လုံးချင်း တို့ဖြစ်သည်။"},
        {"instruction": "မြန်မာစာလုံးချင်း သုံးမျိုးကို ရှောမြောက်ပါ", "input": "", "output": "မြန်မာစာ လုံးချင်း (၃) မျိုးရှိသည်:\n\n၁။ ပေတံ (ဒါး) - စာအုပ်ပြီးနောက် နောက်ဆုံးတွေကို သတ်မှတ်ပေးတဲ့ လုံးချင်း (ယူ၊ ကူး စသည်)\n\n၂။ နက်ရှိုင်း (ပဲ) - ရောရှည်လိုက်သော လုံးချင်း (ကြီး၊ သောက် စသည်)\n\n၃။ သွေးစာလုံး - အခြားနှင့် ဆက်စပ်မှု မရှိသော စာလုံးများ (က်၊ း၊ ဂ စသည်)"},
        {"instruction": "မြန်မာစာ စာလုံး (၃၃) လုံးကို ရေးပါ", "input": "", "output": "မြန်မာစာ စာလုံး (၃၃) လုံးမှာ:\n\nအ - ချ - ဂ - က - သ - ဂါ - ငါ - ခ် - တ - အ် - ဉ - ရ - ဣ - ဦ - ဈ - တ် - ဝ - လ - ဝ် - သု - သို - ဦး - ဉါ - ဣ် - ဈါ - ဣါ - ဩ - ဈိ - ဠ - ကျ - အှ် - န် - လ် - ဥ်\n\nဤစာလုံးများသည် ဗျူးာနီယာ ဘာသာစကားမှ ဆက်ခံလာပြီး မြန်မာဘာသာ၏ အခြေခံအကြောင်းဖြစ်သည်။"},
        {"instruction": "မြန်မာစာတွေ မှန်ကန်စရာ အဓိကအမှန်းတရားများကို ရှောမြောက်ပါ", "input": "", "output": "မြန်မာစာ မှန်ကန်စရာ အဓိကအမှန်းတရားများ:\n\n၁။ ပေတံ မွှေ့မြှင့် - ကျေးဇူးတိုင်း (သာ၊ မ) တို့ကို နောက်မှ သတ်ရမည်\n\n၂။ သွေးစာလုံးသုံးချင်း - 'က်'၊ 'း'၊ 'ဂ' စသော သွေးစာလုံးများကို မှန်မှန်တိုက်ရိုက်သုံးရမည်\n\n၃။ နက်ရှိုင်း လုံးချင်း - ကြီး/သောက် စသော ရောရှည်လုံးချင်းကို မှန်မှန်အသုံးပြုရမည်\n\n၄။ ဝေါဟာရ - တစ်ခုခု၏ အဓိပ္ပာယ်ကို နားလည်စဉ်းစားရမည်\n\n၅။ စကားလုံး - မျက်စိ/မကွေးတို့နဲ့ ကိုင်တွယ်စွာ ပြောဆိုရမည်"},
    ]
    instructions.extend(basics)

    # === Category 2: Coding / Programming ===
    coding = [
        {"instruction": "Python ဖြင့် 'Hello World' ရေးပေးပါ", "input": "", "output": "Python ဖြင့် 'Hello World' ရေးရန် အောက်ပါအတိုင်း ရေးဆိုပါ:\n\n```python\nprint('Hello World')\n```\n\nဤကုဒ်သည် 'Hello World' စာသာရကို screen ပေါ်တွေက်ပြပေးမည်။ Python တွေကို စမ်းသပ်ရန် အကောင်းဆုံးပြီး ရိုးဖြစ်သော ပမာဏဖြစ်သည်။"},
        {"instruction": "Python for loop ရှင်းပြောပါ", "input": "", "output": "Python for loop ဆိုတာတွေ:\n\n```python\n# ပမာဏ - 1 ကနေ 5 ထိ\nfor i in range(1, 6):\n    print(i)\n\n# စာရင်းထဲက တစ်ခုခုခန့်မှှတ်\nfruits = ['သကြား', 'သံချေး', 'ပဲလီး']\nfor fruit in fruits:\n    print(fruit)\n\n# dictionary ကို iterate လုပ်ခြင်း\nperson = {'အမည်': 'ကျော်ကျော်', 'အသက်': 25}\nfor key, value in person.items():\n    print(f'{key}: {value}')\n```\n\nfor loop သည် စာရင်း၊ tuple အုတ်စု စသည်များကို တိုက်ရိုက်လမ်းကျော်နိုင်သော အရေးကြီးပစ္စည်းဖြစ်သည်။"},
        {"instruction": "Python function တစ်ခု ရေးပေးပါ။ နားလည်ရေး ပါ။", "input": "", "output": "Python function ရေးပုံ:\n\n```python\n# ရိုးဖြစ် function\ndef say_hello(name):\n    '''အမည်ကို ချိတ်ဆိုပေးတဲ့ function'''\n    return f'မင်္ဂလာပါ {name}၊ ကြိုတင်ပါ။'\n\n# အသုံးပြုခြင်း\nresult = say_hello('ကျော်ကျော်')\nprint(result)\n# ရလဒ်: မင်္ဂလာပါ ကျော်ကျော်၊ ကြိုင်တင်ပါ။\n\n# Default parameter နဲ့ function\ndef calculate_price(price, discount=0):\n    '''ပမာဏကို တွက်ချက်ပေးတဲ့ function'''\n    final_price = price - (price * discount / 100)\n    return final_price\n\nprint(calculate_price(1000, 10))  # ရလဒ်: 900.0\n```\n\nfunction ဆိုသည်မှာ ချက်ချင်းလုပ်နေတဲ့ ကုဒ်ကို တစ်ခုခုအဖြစ် ထုတ်လုပ်ထားပြီး အမြဲတမ်းအသုံးပြုနိုင်ရန် အကောင်းပါ။ def keyword နဲ့ ခေါ်သပ်ပါ။"},
        {"instruction": "JavaScript နဲ့ Python ကို နှိုင်းပြောပါ", "input": "", "output": "JavaScript နဲ့ Python နှိုင်းချက်:\n\n| အကြောင်း | JavaScript | Python |\n|---------|-----------|--------|\n|  Variable ခေါ်သပ်ခြင်း | let, const, var | အသုံးမပြုဘဲ |\n|  Block separator | {} နဲ့ ခန့်မှှတ် | Indentation (အကွက်လိုက်) |\n|  Function ခေါ်သပ်ခြင်း | function keyword | def keyword |\n|  Array | [] | list [] |\n|  Object | {} | dict {} |\n|  null | null | None |\n|  true/false | true, false | True, False |\n|  Console output | console.log() | print() |\n|  String template | `${variable}` | f'{variable}' |\n\nJavaScript သည် browser တွေကို မြှင့်တင်ရန် သုံးပြီး Python သည် data science၊ AI တွေ လုပ်ရန် ပိုအသုံးဝင်သည်။"},
        {"instruction": "HTML ကို အခြေခံအနေဖြင့် ရှောမြောက်ပါ", "input": "", "output": "HTML (HyperText Markup Language) ဆိုတာ:\n\n```html\n<!DOCTYPE html>\n<html lang='my'>\n<head>\n    <meta charset='UTF-8'>\n    <title>မင်္ဂလာ ဗားရှင်း</title>\n</head>\n<body>\n    <h1>မင်္ဂလာပါ</h1>\n    <p>ယခုသည် HTML ဗားရှင်းဖြစ်သည်။</p>\n    \n    <h2>အဓိက tags များ</h2>\n    <ul>\n        <li>&lt;h1&gt; - &lt;h6&gt; : ခေါင်းစဉ်များ</li>\n        <li>&lt;p&gt; : စာသားပိုင်း</li>\n        <li>&lt;a&gt; : လင့်ခ်</li>\n        <li>&lt;img&gt; : ပုံ</li>\n        <li>&lt;div&gt; : အုတ်ပိုင်း (container)</li>\n    </ul>\n</body>\n</html>\n```\n\nHTML သည် web page တွေကို ပရောဂျက်စကားဖြင့် ရေးသားပေးတဲ့ အခြေခံဘာသာလိုက်ဖြစ်သည်။ Browser တွေကို HTML ကို ဖတ်ပြီး မြင့်မားချက်ကို ပြသပေးသည်။"},
        {"instruction": "Git ကို အသုံးပြုပြီး GitHub ကို ရှောမြောက်ပါ", "input": "", "output": "Git နဲ့ GitHub ရှောမြောက်ချက်:\n\n```bash\n# အခြေခံ အသုံးပြုမှု\ngit init                    # သို့မဟုတ် repo စတင်\ngit add .                   # အကြောင်းအားလုံး add\ngit commit -m 'first commit'  # သိမ်းဆည်း\ngit branch main             # main branch ခေါ်ပါ\ngit push -u origin main     # GitHub ပေးပို့\n\n# ရှေ့ဆက်ဆောင်ရွက်မှု\ngit pull origin main        # ပြန်လည်ရယူ\ngit status                  # အခြေအနေကြည့်\ngit log                     # သို့မဟုတ် မှတ်တမ်းကြည့်\n```\n\nGit သည် ကုဒ် ပြင်ပြင်လဲလှယ်မှုများကို မှတ်တမ်းတင်ပေးသော version control system ဖြစ်သည်။ GitHub သည် Git repositories များကို cloud တွေကို သိမ်းဆည်းပေးပါသည်။"},
        {"instruction": "REST API ဆိုတာ ဘာလဲ", "input": "", "output": "REST API (Representational State Transfer Application Programming Interface) ဆိုတာ:\n\nREST API သည် နောက်ပိုင်း system များနဲ့ ဆက်သွယ်ရန် အသုံးပြုသော ပုဂ္ဂလိပ်ဖြစ်သည်။ အဓိက HTTP methods များ:\n\n```python\n# Python နဲ့ API ခိုင်မာခံခြင်း\nimport requests\n\n# GET - ဒေတာရယူခြင်း\nresponse = requests.get('https://api.example.com/users')\nprint(response.json())\n\n# POST - ဒေတာပေးပို့ခြင်း\nnew_user = {'name': 'Aung', 'age': 25}\nresponse = requests.post('https://api.example.com/users', json=new_user)\n\n# PUT - ဒေတာပြင်ခြင်း\nresponse = requests.put('https://api.example.com/users/1', json={'age': 26})\n\n# DELETE - ဒေတာဖျက်ခြင်း\nresponse = requests.delete('https://api.example.com/users/1')\n```\n\nREST API ကို modern web applications များတွေကို ပိုမို အရေးကြီးပါသည်။"},
        {"instruction": "Linux terminal commands အဓိကအများဆုံးတွေ ပေးပါ", "input": "", "output": "Linux Terminal အဓိက အမများဆုံး commands:\n\n```bash\n# ဖွင့်လေ့ကျင့်ချက် (File & Directory)\nls          # ဖွဲ့စဉ်ပြရန်\ncd          # ခိုင်းနှီးမြှင့်ချက်\nmkdir       # ဖွင့်ချက်အသစ်ဖန်ခြင်း\ntouch       # file အသစ်ဖန်ခြင်း\ncp          # ကိုင်ဖတ်ခြင်း\nmv          # ရွှေ့ခြင်း/နားလည်ခြင်း\nrm          # ဖျက်ခြင်း\n\n# ဒေတာကြည့်ချက်\ncat         # file အကွင်းပြ\nhead/tail   # ဦးချခ်/နောက်ဆုံးပြ\ngrep        # စာလုံးရှာခြင်း\n\n# အုတ်ခန့်မှှတ်ခြင်း\nchmod       # ဖြစ်ခြင်းခွင့်ပြော\nsudo        # admin အခွင့်နဲ့ လုပ်ခြင်း\n\n# နှုန်းကိုင်\napt install # software တင်ခြင်း (Debian/Ubuntu)\nsystemctl   # service မြှင့်တင်ခြင်း\n```\n\nဤ commands များကို သင်္ချာ သုံးပြီး Linux စစ်စစ်ချိန် လုပ်နိုင်သည်။"},
        {"instruction": "Python နဲ့ database ချိတ်ဆက်ပြီး အသုံးပြုပါ", "input": "", "output": "Python နဲ့ SQLite database ချိတ်ဆက်ပုံ:\n\n```python\nimport sqlite3\n\n# Database ခန့်မှှတ်ခြင်း\nconn = sqlite3.connect('myanmar_app.db')\ncursor = conn.cursor()\n\n# Table ဖန်ခြင်း\ncursor.execute('''\n    CREATE TABLE IF NOT EXISTS users (\n        id INTEGER PRIMARY KEY,\n        name TEXT NOT NULL,\n        email TEXT UNIQUE\n    )\n''')\n\n# ဒေတာထည့်ခြင်း\ncursor.execute('INSERT INTO users (name, email) VALUES (?, ?)',\n               ('ကျော်ကျော်', 'aung@email.com'))\nconn.commit()\n\n# ဒေတာဖတ်ခြင်း\ncursor.execute('SELECT * FROM users')\nusers = cursor.fetchall()\nfor user in users:\n    print(user)\n\nconn.close()\n```\n\nSQLite သည် Python နဲ့ ပူးပေါင်းတိုက်ရိုက် ပေါ်လျှင် install မလုပ်ဘဲ သုံးနိုင်သော အပြည့်အစုံ database ဖြစ်သည်။ PostgreSQL၊ MySQL တို့ကိုလည်း psycopg2၊ mysql-connector နဲ့ ချိတ်ဆက်နိုင်သည်။"},
        {"instruction": "Error handling ကို Python မှာ ရေးပေးပါ", "input": "", "output": "Python Error Handling:\n\n```python\n# try-except အခြေခံ\ndef divide(a, b):\n    try:\n        result = a / b\n        return result\n    except ZeroDivisionError:\n        return 'သာ: သုံးနဲ့ မပြောင်းနိုင်ပါ'\n    except TypeError:\n        return 'သာ: နံပတ်တွေ မမှန်ပါ'\n    finally:\n        print('သတိပေးချက်: ခန့်မှှတ်ပြီးပြီ')\n\nprint(divide(10, 3))   # 3.333...\nprint(divide(10, 0))   # သာ: သုံးနဲ့ မပြောင်းနိုင်ပါ\n\n# Custom Exception\nclass MyanmarInputError(Exception):\n    '''မြန်မာစာ အမှားမှတ်ပါ'''\n    pass\n\ndef validate_name(name):\n    if not name or len(name) < 2:\n        raise MyanmarInputError('အမည် ၂ လုံးထက် ရှည်ရမည်')\n    return True\n\n# try-except-else\ndef read_file(filepath):\n    try:\n        f = open(filepath, 'r')\n    except FileNotFoundError:\n        print(f'{filepath} မတွေ့ပါ')\n    else:\n        content = f.read()\n        f.close()\n        return content\n```\n\nError handling သည် program ကို တိကျစွာ လုပ်ဆောင်နေစဉ် ဖြစ်ပေါ်လာတဲ့ အမှားတွေကို စိတ်ဖြာပေးပြီး ပြဿနာတွေကို အပြုအမူ လုပ်နိုင်ရန် အရေးကြီးသည်။"},
    ]
    instructions.extend(coding)

    # === Category 3: General Knowledge ===
    general = [
        {"instruction": "မြန်မာနိုင်ငံ၏ နေရာချိန်ကို ရှောမြောက်ပါ", "input": "", "output": "မြန်မာနိုင်ငံ၏ နေရာချိန်:\n\nမြန်မာနိုင်ငံသည် GMT+6:30 ကို အသုံးပြုသည်။ မြန်မာစံနှုန်းနေရာချိန် (MST) ဟု ခေါ်သည်။ ထိုင်းနိုင်ငံနေရာချိန် (ICT) ထက် တစ်နာရီတိုင်း (၃၀ မိနစ်) ခန့်ကာလ နောက်ကျသည်။ အိမ်နိုင်ငံခေါင်းစဉ်ရေးသူတွေ အတွက် အရေးကြီးသော အချက်ဖြစ်သည်။ မြန်မာနိုင်ငံတွေ နေရာချိန်ကို ကျွန်ုပ်တို့ နှစ်သက်ရာ မရှိသောအပြင် အမေရိကန်နိုင်ငံ မြှင့်တင်နေရာချိန်ပြောင်းရွှေချက်ကို လက်မှတ်သတ်မှတ်ထားခြင်းမဟုတ်ပါ။"},
        {"instruction": "MyanOS ဆိုတာ ဘာလဲ", "input": "", "output": "MyanOS သည် မြန်မာအရေးသား Developer တွေ ဖန်တီးထားတဲ့ Web-based Operating System ဖြစ်သည်။ ဗားရှင်း (Browser) ပေါ်တွေကို လုပ်ဆောင်နိုင်ပြီး အောက်ပါ အခြေခံဖွင့်လုံးများပါ ရှိသည်:\n\n- Desktop Environment (ဘောလုံးချိန်)\n- File Manager (ဖိနပ် အုတ်ခန့်မှှတ်ချက်)\n- Terminal (အမများဆုံး)\n- Code Editor (ကုဒ် ရေးစရာ)\n- MyanAI Agent (မြန်မာ AI ထုတ်ငန်း)\n- Myanmar Keyboard (မြန်မာ စာသားပို့)\n- Browser (ဗားရှင်း)\n- Settings (ချိန်းသိမ်းချက်)\n\nMyanOS v4.2.0 သည် မြန်မာစာကို အဓိကထားပြီး AI ခွဲခြမ်းစိတ်ဖြာ တွေကို ပါဝင်ထားသည်။"},
        {"instruction": "AI ဆိုတာ ဘာလဲ ရှောမြောက်ပါ", "input": "", "output": "AI (Artificial Intelligence - ယုံကြည်မွန်ခြင်း သီအိုရီ) ဆိုတာ:\n\nAI သည် မိမိ ကိုယ်ပိုင် အာရုံစူးစိတ်ဖြာမှုကို ပိုမို လေ့ကျင့်ပေးပြီး မိမိအလိုလို ဆက်လက်မြှင့်တင်နိုင်အောင် လုပ်ဆောင်နိုင်တဲ့ စကားလုံး စနစ်ဖြစ်သည်။ အဓိက အချက်အလုံးများ:\n\n၁။ Machine Learning (ML) - ဒေတာများမှ သင်္ချာ သုံးပြီး လေ့ကျင့်ခြင်း\n\n၂။ Deep Learning - နီးပိုင်ရှင်းနှင့်အသင့်အဖွဲဝင်သော မြှင့်တင်မှု (Neural Networks)\n\n၃။ Natural Language Processing (NLP) - မိန်းစာလုံးကို နားလည်ခြင်း\n\n၄။ Computer Vision - ပုံသွန်အားကို နားလည်ခြင်း\n\n၅Generative AI - အသစ် ဒေတာများ ထုတ်လုပ်ခြင်း (ကျော်, ပုံ, စာလုံး)\n\nဖိုးရှင်းဆန်ဖိုး: ChatGPT, Ollama, Claude တို့သည် AI ၏ ဥပမာများ ဖြစ်သည်။"},
        {"instruction": "မြန်မာနိုင်ငံ မှာ ကျေးဇူးတိုးပွဲ အချိန်များ ဘာဘာ ရှိသလဲ", "input": "", "output": "မြန်မာနိုင်ငံ ကျေးဇူးတိုးပွဲ အချိန်များ:\n\n၁။ ဇန်နဝါရီလ (၁) ရက် - နိုင်ငံရေး သို့မဟုတ် ပြည်နယ်ရေး ပွဲရှင်းအပွဲ\n\n၂။ ဇန်နဝါရီလ (၁၂) ရက် - မြန်မာနိုင်ငံ နေ့ (သို့မဟုတ် သကြားနေ့) - မြန်မာနိုင်ငံ လွတ်လပ်ရေး နေ့ (၁၉၄၈ ခုနှစ်)\n\n၃။ ဇန်နဝါရီလ (၁၃) ရက် - ပြက္ခဒိန် ပွဲရှင်းနေ့ (သို့မဟုတ် ကွန်ရက်မှာကျင့်သုံး)\n\n၄။ ဒီဇင်ဘာလ (၅) ရက် - မကွေးငွေ ကျေးဇူးတိုးပွဲ အဖွဲ့ချုပ်နေ့\n\n၅။ ဖေဖော်ဝါရီလ (၁၇) ရက် - ကျော်လုံး နေ့ (ကုန်စုံ အမျိုးသားနေ့)\n\n၆။ မေလ (၁) ရက် - ခေါင်းစဉ်လှိုင်းနေ့\n\n၇။ ဇွန်လ (၁၉) ရက် - အရေးကြီးသော အချိန် (သို့မဟုတ် ဒီဇင်ဘာလ)\n\nဤအချိန်များကို မြန်မာနိုင်ငံ ပညာရေး အဖွဲ့ချုပ်က သတ်မှတ်ပေးထားသည်။"},
    ]
    instructions.extend(general)

    # === Category 4: MyanOS Specific ===
    myanos_specific = [
        {"instruction": "MyanOS Terminal မှာ အမများဆုံး commands များကို ပေးပါ", "input": "", "output": "MyanOS Terminal အဓိက commands:\n\n```bash\n# ဖွင့်လေ့ကျင့်ချက်\nhelp                   # အကြည့်ဆုံး ကျွန်ုပ်ပါ လုပ်ဆောင်နိုင်သော အရာများ\nls                     # ဖွဲ့စဉ်ပြရန်\ncd [directory]          # ခိုင်းနှီးမြှင့်ချက်\nmkdir [name]            # ဖွင့်ချက်အသစ်ဖန်ခြင်း\npwd                    # လက်ရှိ ခိုင်းနှီးကို ပြရန်\n\n# MyanOS Package Manager\nsudo apt install [pkg]  # package တင်ခြင်း\nsudo apt update         # package list ပြင်မြှင့်\nsudo apt remove [pkg]   # package ဖျက်ခြင်း\n.myan install [pkg]     # MyanOS package တင်ခြင်း\n\n# AI Commands\nai chat [message]       # MyanAI နဲ့ စကားပြောခြင်း\nai status               # AI အခြေအနေကြည့်\n\n# System\nwhoami                 # လက်ရှိ အသုံးပြုသူ\ndate                   # ရက်စံနေရာချိန်\nclear                  # screen မျက်နှာ သွားခြင်း\n```\n\nMyanOS Terminal သည် Linux Bash shell ကို အခြေခံထားပြီး မြန်မာနိုင်ငံ အသုံးပြုသူများအတွက် လေးကျင့်လေးကျင့် ပြင်ဆင်ထားသည်။"},
        {"instruction": "MyanOS မှာ Code Keys app ကို ဘယ်လို အသုံးပြုမလဲ", "input": "", "output": "MyanOS Code Keys App အသုံးပြုပုံ:\n\nCode Keys သည် မြန်မာ Developer တွေအတွက် ပရောဂျက် စာသားပို့ (Keyboard) ဖြစ်သည်။ အောက်ပါ tab များ ရှိသည်:\n\n၁။ Logic Tab - ကိုယ်ပိုင်း မြန်မာ မှတ်ပုဒ် စာလုံးများ:\n   - ကိုယ် (if), နောက်ပြန် (else), လမ်းညွှန် (elif)\n   - ဖြစ်ပါ (is), မဟုတ်ပါ (not), နဲ့ (and), သို့မဟုတ် (or)\n\n၂။ Operators Tab - အရောင်းသွင်းချက် စာလုံးများ:\n   - ပေါင်း (add), နုတ် (sub), အမြဲ (mul), စစ် (div)\n   - တိုက် (equal), မတိုက် (not_equal)\n\n၃။ Symbols Tab - သွေးစာလုံးများ:\n   - ( ) [ ] { } < > / \\ \" ' # @ $ % ^ & *\n\n၄။ Custom Tab - ကိုယ်ပိုင်း Snippet များ:\n   - အသုံးပြုသူကိုယ်တိုင် ခွဲခြမ်းစိတ်ဖြာ ထည့်နိုင်သည်\n\nAuto-expansion: ကိုယ်ပိုင်း စာလုံးကို ရေးလိုက်ရင် ပြီးပြည့်အုတ်ခန့်မှှတ်ချက်ကို အလိုလို ပေးသည်။"},
        {"instruction": "MyanOS AI Training Center ကို ဘယ်လို အသုံးပြုမလဲ", "input": "", "output": "MyanOS AI Training Center အသုံးပြုပုံ:\n\nAI Training Center သည် MyanOS တွေကို Ollama models များကို မြန်မာစာဖြင့် လေ့ကျင့်ပေးနိုင်သော စနစ်ဖြစ်သည်။ အဆင့်များ:\n\nအဆင့် ၁: Dataset ရွေးချယ်ခြင်း\n- မြန်မာစာ ကုဒံ တင် ဒေတာစုများကို ရွေးချယ်ပါ\n- HuggingFace မှ dataset တင်ရန် နိုင်သည်\n- ကိုယ်ပိုင်း ဒေတာထည့်သွင်းနိုင်သည်\n\nအဆင့် ၂: Model ရွေးချယ်ခြင်း\n- Qwen 2.5 3B (အသင့် - ပမာဏသား)\n- Llama 3.1 8B (ပိုကောင်းမွန်သော)\n- Burmese-Coder-4B (ကုဒ် ရေးရန် အဓိက)\n\nအဆင့် ၃: Fine-tuning စတင်ခြင်း\n- Google Colab free GPU ကို အသုံးပြုပြီး လေ့ကျင့်ခြင်း\n- QLoRA အသုံးပြုပြီး VRAM ကုလားနည်းခြင်း\n- ၃၀ မိနစ် - ၁ နာရီ အတွင်း ပြီးမြောက်မည်\n\nအဆင့် ၄: Ollama ထဲ ထည့်သွင်းခြင်း\n- GGUF ပြောင်းလဲ၍ Ollama ဖို့ import\n- `ollama create myanmar-model -f Modelfile`\n\nဤစနစ်သည် မြန်မာနိုင်ငံ Developer တွေအတွက် အသက်ရှူသော AI ကို လေ့ကျင့်ပေးသည်။"},
    ]
    instructions.extend(myanos_specific)

    # === Category 5: Conversation / Chat ===
    conversation = [
        {"instruction": "ကျေးဇူးပါ", "input": "", "output": "ကျေးဇူးတိုင်းပါ၊ ကြိုတင်ပါ။ ဘာကြောင့် မင်္ဂလာလဲ။ ကျေးဇူးပါ ခေါ်တဲ့ အချက်များကို မေးနိုင်ပါသည်။ ကျွန်ုပ်တို့ မြန်မာစာ ကျွမ်းကျင်သော AI assistant ဖြစ်ပါသည်။"},
        {"instruction": "နေ့ခင်းကျေးဇူးပါ", "input": "", "output": "နေ့ခင်းကျေးဇူးတိုင်းပါ။ နေ့ခင်း ကောင်းပါသလား။ ရှင်းရှင်းပြောရရင် ဘာများ ဝန်ဆောင်ပေးနိုင်ပါသလဲ။ ကျွန်ုပ်တို့ မြန်မာစာ နဲ့ ကိုယ်ပိုင်း နေရာမှာ အကောင်းစွာ အကြံပြုထားပါသည်။ ခက်ခဲရကြောင်း နှစ်သက်ပါသည်။"},
        {"instruction": "ဘာများလုပ်ပေးနိုင်မလဲ", "input": "", "output": "ကျွန်ုပ်တို့ အောက်ပါ အရာများကို လုပ်ပေးနိုင်ပါသည်:\n\n၁။ မြန်မာစာ ကျွမ်းကျင်စွာ အကြောင်း ဖြေရှင်းပေးခြင်း\n\n၂။ ကုဒ် ရေးခြင်း အကြံပြုပေးခြင်း (Python, JavaScript, HTML/CSS)\n\n၃။ ဒေတာ ရှာဖွေခြင်း နှင့် ပြဿနာ ဖြေဆိုခြင်း\n\n၄။ မြန်မာစာ သုံးပြီး ရေးသားခြင်း (နေ့စဉ် သုံးစွဲ စာတွေ)\n\n၅။ MyanOS ခွဲခြမ်းစိတ်ဖြာ ပေးခြင်း\n\n၆။ ကျွန်ုပ်တို့ အကြံပြုထားသော တိုးတက်မှု အကြောင်း ဖြေရှင်းပေးခြင်း\n\nဘာများ ဝန်ဆောင်စေပေးချင်ပါလား။"},
        {"instruction": "မင်္ဂလာနဲ့ နေ့စဉ် စကားပြောရမလား", "input": "", "output": "ရှိပါသည်။ ကျွန်ုပ်တို့ နေ့စဉ် မင်္ဂလာနဲ့ စကားပြောနိုင်ပါသည်။ ကျေးဇူးတိုင်း ခေါ်တဲ့ မြန်မာစာ နဲ့ အကြောင်းအရာ များကို မေးနိုင်ပါသည်။ ကျွန်ုပ်တို့ မြန်မာနိုင်ငံ အိမ်နိုင်ငံရေး ဒေတာ၊ စာတွေ့၊ ကုဒံ ရေးခြင်း၊ နေရာချိန်ကို သိရှိခြင်း စသော အရာများကို အကြံပြု ပေးနိုင်ပါသည်။ ခက်ခဲပါက မေးပါ။"},
        {"instruction": "ဘာသာစကား များ ပြောနိုင်မလဲ", "input": "", "output": "ကျွန်ုပ်တို့ အဓိကအားဖြင့် မြန်မာစာ ပြောနိုင်ပါသည်။ အပြည့်အစုံ မြန်မာစာကျွမ်းကျင်မှု ရှိပါသည်။ ဒါပဲ ကျွန်ုပ်တို့ကို မြန်မာ OS နဲ့ ခွဲခြမ်းစိတ်ဖြာ ထုတ်ငန်းများတွေ လုပ်နိုင်ရန် အကောင်းဆုံး ဖြစ်သည်။ အင်္ဂလိပ်စာလည်း နည်းနည်း ပြောနိုင်ပါသည်။ ဒါပဲ MyanOS MyanAi Agent ဖြစ်ပါသည်။"},
    ]
    instructions.extend(conversation)

    # === Category 6: Technical Explanation in Myanmar ===
    tech_explain = [
        {"instruction": "Docker ဆိုတာ ဘာလဲ", "input": "", "output": "Docker ဆိုတာ:\n\nDocker သည် ကုဒ် (software) များကို container များတွေကို ထုတ်လုပ်ပေးပြီး အမြဲတမ်းတွေကို ပိုမို တိုက်ရိုက် အသုံးပြုနိုင်အောင် လုပ်ပေးသော စကားလုံးဖြစ်သည်။\n\nအခြေခံအကြောင်း:\n- Container: ကုဒံ တစ်ခုခုကို ထိန်းသိမ်းပေးသော လောကကြီး (ပိုင်နက် ဖွဲ့)\n- Image: container ပြင်ဆင်ရန် ပံ့ပိုး ဒေတာ (template)\n- Dockerfile: image ဖန်ခြင်း ရည်ရွယ်ချက်များကို ရေးသားထားသောကုဒ်\n\nအားနည်းချက်များ:\n- ကုဒံ တစ်ခုခုကို ပိုမို တိုက်ရိုက် အသုံးပြုနိုင်သည်\n- OS မှန်ကန်မှုများကို သကြားခံနိုင်သည်\n- ပိုမို လွယ်ကူစွာ deploy လုပ်နိုင်သည်\n- Cloud ပေါ်တွေကို လွယ်ကူစွာ တင်နိုင်သည်"},
        {"instruction": "API ဆိုတာ ဘာလဲ ရှောမြောက်ပါ", "input": "", "output": "API (Application Programming Interface) ဆိုတာ:\n\nAPI သည် နောက်ပိုင်း system နှင့် ပူးပေါင်းလုပ်ဆောင်ရန် အသုံးပြုသော မှုတ်ပုဒ် စနစ်ဖြစ်သည်။ တစ်နည်းလိုက် ပြောရင် software နှစ်ခုခုကို စကားပြောနိုင်အောင် လုပ်ပေးတဲ့ ဘောလုံးကို ဖြစ်သည်။\n\nအမျိုးအစား:\n- REST API: HTTP protocol ကို အသုံးပြုသော အများဆုံး ဖြစ်သည်\n- GraphQL: အချက်အလုံးကို သင်္ချာ တွက်ချက်နိုင်သည်\n- WebSocket: စစ်စစ်စွာ ဆက်သွယ်နိုင်သော ပူးပေါင်း (real-time)\n\nဥပမာ:\n- မြန်မာနိုင်ငံ အခြေခံရေးဝတ်စုံ API\n- OpenWeatherMap API (ဆံချိန် သိရှိရန်)\n- Ollama API (AI model များ ခိုင်မာခံရန်)\n\nAPI မရှိရင် modern web applications များ လုပ်လုပ်နိုင်မည်မဟုတ်ပါ။"},
        {"instruction": "GPU နဲ့ CPU ကို နှိုင်းပြောပါ", "input": "", "output": "GPU နဲ့ CPU နှိုင်းချက်:\n\nCPU (Central Processing Unit):\n- နောက်ဆုံး ခွဲခြမ်းစိတ်ဖြာ ဒေတာများကို တိုက်ရိုက် လုပ်ဆောင်ခြင်း (single-threaded tasks)\n- လမ်းညွှန်မှုတွေ လုပ်တတ်သော (branching logic)\n- ဘောလုံးလေးလေး တွေကို တိုက်ရိုက် လုပ်တတ်သော\n- ဥပမာ: အချိန်ခန့်မှှတ်ခြင်း၊ ဆက်သွယ်ခြင်း၊ လမ်းညွှန်ခြင်း\n\nGPU (Graphics Processing Unit):\n- အလိုလို တစ်ပြိုင်နက်တိုင် တိုက်ရိုက် လုပ်ဆောင်ခြင်း (parallel processing)\n- လုံးဝ ဒေတာများကို တစ်ခါတည်း တိုက်ရိုက် ခန့်မှှတ်ခြင်း (matrix operations)\n- AI training တွေကို အဓိက အသုံးပြုသည်\n- ဥပမာ: Deep learning၊ ရှင်းလင်း ဖန်ခြင်း၊ data science\n\nMyanOS AI Training Center တွေ GPU ကို အသုံးပြုပြီး model များကို လေ့ကျင့်ပေးသည်။"},
        {"instruction": "Git နဲ့ GitHub ကို မကြာသေး ရှောမြောက်ပါ", "input": "", "output": "Git နဲ့ GitHub သည်:\n\nGit သည် ကုဒ် ပြင်ပြင်လဲလှယ်မှုများကို မှတ်တမ်းတင်ပေးတဲ့ version control system ဖြစ်သည်။\n\nGitHub သည် Git repositories များကို cloud တွေကို သိမ်းဆည်းပေးပါသည်။ တစ်နိုင်ငံလုံး developer တွေ ပူးပေါင်းပူးကျင် လုပ်နိုင်အောင် လုပ်ပေးသည်။\n\nအဓိက အကြောင်းများ:\n- Repository (repo): ကုဒံ သိမ်းဆည်းသော နေရာ\n- Commit: ပြင်ပြင်လဲလှယ်မှု ကစားပေးခြင်း\n- Branch: မိမိ ကိုယ်ပိုင်း လုပ်ဆောင်မှု အတွက် ခွဲခြားခြင်း\n- Pull Request: ပြင်ပြင်လဲလှယ်မှု ကို ထည့်သွင်းခိုင်းခြင်း\n- Merge: ပြင်ပြင်လဲလှယ်မှု ကို ပေါင်းစပ်ခြင်း\n\nMyanOS project သည် GitHub တွေကို သိမ်းဆည်းထားသည်: https://github.com/meonnmi-ops/Myanos"},
    ]
    instructions.extend(tech_explain)

    # Save
    with open(output_path, "w", encoding="utf-8") as f:
        for item in instructions:
            f.write(json.dumps(item, ensure_ascii=False) + "\n")

    print(f"\n[+] Created master instruction dataset: {output_path}")
    print(f"    Total instructions: {len(instructions)}")
    return len(instructions)


def main():
    print("=" * 60)
    print("  Myanmar AI Training - Dataset Collector")
    print("  MyanOS v4.2.0 - MyanAI Agent Training Pipeline")
    print("=" * 60)

    check_dependencies()

    # Step 1: Create master instruction dataset
    print("\n" + "=" * 40)
    print("  Step 1: Creating Master Instruction Dataset")
    print("=" * 40)
    create_myanmar_instruction_dataset()

    # Step 2: Download HuggingFace instruction datasets
    print("\n" + "=" * 40)
    print("  Step 2: Downloading HuggingFace Instruction Datasets")
    print("=" * 40)

    hf_instruction_datasets = [
        ("chuuhtetnaing/myanmar-instruction-tuning-dataset", "instruction", "input", "output"),
        ("jojo-ai-mst/Burmese-Microbiology-1K", "instruction", "input", "output"),
        ("jojo-ai-mst/Roleplay-Burmese", "instruction", "input", "output"),
    ]

    total = 0
    for repo, inst_f, inp_f, out_f in hf_instruction_datasets:
        try:
            count = download_instruction_dataset(repo, inst_f, inp_f, out_f)
            total += count
        except Exception as e:
            print(f"  [!] Skipping {repo}: {e}")

    # Step 3: Download corpus datasets
    print("\n" + "=" * 40)
    print("  Step 3: Downloading Text Corpora")
    print("=" * 40)

    hf_corpus_datasets = [
        ("freococo/myanmar-written-corpus", None, "train", None, "text"),
        ("freococo/myanmar_spoken_corpus", None, "train", None, "text"),
    ]

    corpus_total = 0
    for repo, subset, split, _, text_f in hf_corpus_datasets:
        try:
            count = download_hf_dataset(repo, subset, split, text_field=text_f)
            corpus_total += count
        except Exception as e:
            print(f"  [!] Skipping {repo}: {e}")

    # Step 4: Summary
    print("\n" + "=" * 60)
    print("  Dataset Collection Complete!")
    print("=" * 60)
    print(f"  Instruction datasets: {INSTRUCTION_DIR}")
    print(f"  Corpus datasets: {CORPUS_DIR}")
    print(f"  Total instruction pairs from HF: {total}")
    print(f"  Total corpus samples from HF: {corpus_total}")
    print(f"\n  Next step: Run 2_finetune_colab.py (Google Colab)")
    print(f"  Or: Run 3_finetune_cpu.py (CPU-only, HF Space)")
    print("=" * 60)


if __name__ == "__main__":
    main()
