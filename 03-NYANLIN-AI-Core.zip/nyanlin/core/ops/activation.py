# -*- coding: utf-8 -*-
# nyanlin/core/ops/activation.mmc - Vectorized activation functions

math_mod = None

try:
    import math as math_mod
except:
    pass


def silu(x):
    """SiLU (Swish) activation: x * sigmoid(x). Works on 1D lists."""
    result = []
    for i in range(len(x)):
        sig = 1.0 /(1.0 + math_mod.exp(- x[i]))
        result = result +[x[i] * sig]
    return result


def gelu(x):
    """GELU activation using erf approximation. Works on 1D lists."""
    result = []
    for i in range(len(x)):
        v = x[i]
        cdf = 0.5 *(1.0 + math_mod.erf(v / 1.4142135623730951))
        result = result +[v * cdf]
    return result


def relu(x):
    """ReLU activation: အမြင့်ဆုံး(0, x). Works on 1D lists."""
    result = []
    for i in range(len(x)):
        if x[i] > 0.0:
            result = result +[x[i]]
        else:
            result = result +[0.0]
    return result


def sigmoid(x):
    """Sigmoid activation: 1 / (1 + exp(-x)). Works on 1D lists."""
    result = []
    for i in range(len(x)):
        result = result +[1.0 /(1.0 + math_mod.exp(- x[i]))]
    return result


def tanh_act(x):
    """Hyperbolic tangent activation. Works on 1D lists."""
    result = []
    for i in range(len(x)):
        result = result +[math_mod.tanh(x[i])]
    return result


def gelu_tanh(x):
    """GELU activation using tanh approximation. Works on 1D lists."""
    result = []
    for i in range(len(x)):
        v = x[i]
        inner = 0.7978845608 *(v + 0.044715 * v * v * v)
        t = math_mod.tanh(inner)
        result = result +[0.5 * v *(1.0 + t)]
    return result
