# -*- coding: utf-8 -*-
# nyanlin/core/ops/math_ops.mmc - Softmax, LayerNorm, RMSNorm, RoPE, SiLU, GELU

math_mod = None

try:
    import math as math_mod
except:
    pass


def softmax(logits):
    """Compute softmax over a 1D list of logits. Returns probabilities."""
    if len(logits) == 0:
        return[]
    max_val = logits[0]
    for i in range(len(logits)):
        if logits[i] > max_val:
            max_val = logits[i]
    exp_vals = []
    for i in range(len(logits)):
        exp_vals = exp_vals +[math_mod.exp(logits[i] - max_val)]
    sum_exp = 0.0
    for i in range(len(exp_vals)):
        sum_exp = sum_exp + exp_vals[i]
    result = []
    for i in range(len(exp_vals)):
        result = result +[exp_vals[i] / sum_exp]
    return result


def layer_norm(x, weight, bias, eps):
    """Layer normalization over a 1D vector x."""
    n = len(x)
    mean = 0.0
    for i in range(n):
        mean = mean + x[i]
    mean = mean / n
    var = 0.0
    for i in range(n):
        diff = x[i] - mean
        var = var + diff * diff
    var = var / n
    result = []
    for i in range(n):
        val = (x[i] - mean) / math_mod.sqrt(var + eps)
        val = val * weight[i]
        if bias != None:
            val = val + bias[i]
        result = result +[val]
    return result


def rms_norm(x, weight, eps):
    """Root Mean Square normalization over a 1D vector x."""
    n = len(x)
    ss = 0.0
    for i in range(n):
        ss = ss + x[i] * x[i]
    ms = ss / n
    result = []
    for i in range(n):
        val = x[i] / math_mod.sqrt(ms + eps)
        val = val * weight[i]
        result = result +[val]
    return result


def precompute_freqs_cis(head_dim, max_seq_len, theta):
    """Precompute cosine ညီမျှလျှင် sine frequencies အတွက် RoPE.

    Returns(freqs_cos, freqs_sin) each of shape(max_seq_len, head_dim // 2).
    Stored as list(of lists.)
    """
    freqs = []
    for i in range(head_dim // 2):
        freq = 1.0 /(theta **(2.0 * i / head_dim))
        freqs = freqs +[freq]
    t_vals = []
    for t in range(max_seq_len):
        t_vals = t_vals +[t]
    freqs_cos = []
    freqs_sin = []
    for t in range(max_seq_len):
        cos_row = []
        sin_row = []
        for i in range(head_dim // 2):
            angle = t_vals[t] * freqs[i]
            cos_row = cos_row +[math_mod.cos(angle)]
            sin_row = sin_row +[math_mod.sin(angle)]
        freqs_cos = freqs_cos +[cos_row]
        freqs_sin = freqs_sin +[sin_row]
    return freqs_cos, freqs_sin


def apply_rotary_emb(x, freqs_cos, freqs_sin, offset):
    """Apply Rotary Position Embedding to a 1D vector x.

    x has length head_dim.offset is the position in the sequence.
    freqs_cos[offset] and freqs_sin[offset] each have length head_dim // 2.
    """
    half = len(x) // 2
    x_r = []
    x_i = []
    for i in range(half):
        x_r = x_r +[x[i]]
    for i in range(half):
        x_i = x_i +[x[half + i]]
    cos_vals = freqs_cos[offset]
    sin_vals = freqs_sin[offset]
    out_r = []
    out_i = []
    for i in range(half):
        out_r = out_r +[x_r[i] * cos_vals[i] - x_i[i] * sin_vals[i]]
        out_i = out_i +[x_r[i] * sin_vals[i] + x_i[i] * cos_vals[i]]
    result = []
    for i in range(half):
        result = result +[out_r[i]]
    for i in range(half):
        result = result +[out_i[i]]
    return result


def silu(x):
    """SiLU (Swish) activation: x * sigmoid(x). Vectorized အတွက် 1D list."""
    result = []
    for i in range(len(x)):
        sig = 1.0 /(1.0 + math_mod.exp(- x[i]))
        result = result +[x[i] * sig]
    return result


def gelu(x):
    """GELU activation. Vectorized အတွက် 1D list."""
    result = []
    for i in range(len(x)):
        v = x[i]
        # GELU approximation: 0.5 * x * (1 + tanh(sqrt(2/pi) * (x + 0.044715 * x^3)))
        cdf = 0.5 *(1.0 + math_mod.erf(v / 1.4142135623730951))
        result = result +[v * cdf]
    return result


def vec_add(a, b):
    if len(a) != len(b):
        raise ValueError("vec_add length mismatch")
    result = []
    for i in range(len(a)):
        result = result +[a[i] + b[i]]
    return result


def vec_scale(a, s):
    result = []
    for i in range(len(a)):
        result = result +[a[i] * s]
    return result
