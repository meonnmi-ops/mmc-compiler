# -*- coding: utf-8 -*-
# nyanlin/core/model_loader.mmc - Model configuration and weight loading

from core.gguf_parser import GGUFReader


class ModelConfig:
    """Configuration အတွက် a LLaMA-style transformer model."""

    def __init__(self):
        self.dim = 4096
        self.n_layers = 32
        self.n_heads = 32
        self.n_kv_heads = 32
        self.vocab_size = 32000
        self.max_seq_len = 2048
        self.hidden_dim = 11008
        self.norm_eps = 0.00001
        self.rope_theta = 10000.0
        self.head_dim = 128
        self.vocab_size_exp = 0
        self.arch = None

    def __repr__(self):
        return "ModelConfig(dim={}, n_layers={}, n_heads={}, n_kv_heads={}, vocab_size={})".format(
            self.dim, self.n_layers, self.n_heads, self.n_kv_heads, self.vocab_size)


class ModelLoader:
    """Loads mo configuration ညီမျှလျှင် weights မှ a GGUF file."""

    def __init__(self, filepath):
        self.filepath = filepath
        self.reader = None
        self.config = ModelConfig()
        self.weights = {}
        self._loaded = False

    def load(self):
        self.reader = GGUFReader(self.filepath)
        self.reader.parse()
        self._load_config()
        self._loaded = True
        print("Model loaded: {}".format(self.config))

    def _load_config(self):
        meta = self.reader.get_metadata()
        c = self.config
        # Read architecture parameters from metadata
        val = self.reader.get_metadata_value("general.architecture", None)
        if val != None:
            arch = val
            print("Architecture: {}".format(arch))
            c.arch = arch
        val = self.reader.get_metadata_value("{}.embedding_length".format(arch), None)
        if val != None:
            c.dim = val
        val = self.reader.get_metadata_value("{}.block_count".format(arch), None)
        if val != None:
            c.n_layers = val
        val = self.reader.get_metadata_value("{}.attention.head_count".format(arch), None)
        if val != None:
            c.n_heads = val
        val = self.reader.get_metadata_value("{}.attention.head_count_kv".format(arch), None)
        if val != None:
            c.n_kv_heads = val
        else:
            c.n_kv_heads = c.n_heads
        val = self.reader.get_metadata_value("{}.context_length".format(arch), None)
        if val != None:
            c.max_seq_len = val
        val = self.reader.get_metadata_value("{}.feed_forward_length".format(arch), None)
        if val is None:
            val = self.reader.get_metadata_value("{}.intermediate_size".format(arch), None)
        if val != None:
            c.hidden_dim = val
        val = self.reader.get_metadata_value("{}.attention.layer_norm_rms_epsilon".format(arch), None)
        if val != None:
            c.norm_eps = val
        val = self.reader.get_metadata_value("{}.rope.freq_base".format(arch), None)
        if val != None:
            c.rope_theta = val
        val = self.reader.get_metadata_value("{}.tokenizer.ggml.vocab_size".format(arch), None)
        if val != None:
            c.vocab_size = val
        c.head_dim = c.dim // c.n_heads
        if c.head_dim == 0:
            c.head_dim = 128
        # Check for vocab size as exponent
        val = self.reader.get_metadata_value("tokenizer.ggml.vocab_size", None)
        if val != None:
            c.vocab_size_exp = val
        print(
            c.dim, c.n_layers, c.n_heads, c.n_kv_heads, c.vocab_size)

    def load_weight(self, name):
        if not self._loaded:
            raise RuntimeError("Model not loaded")
        flat, dims = self.reader.read_tensor_as_f32(name)
        return flat, dims

    def get_weight_names(self):
        if not self._loaded:
            raise RuntimeError("Model not loaded")
        return self.reader.get_tensor_names()
