# -*- coding: utf-8 -*-
# nyanlin/core/gguf_parser.mmc - GGUF binary file parser

from core.tensor import BytesHelper

GGUF_MAGIC = 0x46475547

GGUF_TYPE_UINT8 = 0
GGUF_TYPE_INT8 = 1
GGUF_TYPE_UINT16 = 2
GGUF_TYPE_INT16 = 3
GGUF_TYPE_UINT32 = 4
GGUF_TYPE_INT32 = 5
GGUF_TYPE_FLOAT32 = 6
GGUF_TYPE_BOOL = 7
GGUF_TYPE_STRING = 8
GGUF_TYPE_ARRAY = 9
GGUF_TYPE_UINT64 = 10
GGUF_TYPE_INT64 = 11
GGUF_TYPE_FLOAT64 = 12

GGUF_TENSOR_F32 = 0
GGUF_TENSOR_F16 = 1
GGUF_TENSOR_Q4_0 = 2
GGUF_TENSOR_Q4_1 = 3
GGUF_TENSOR_Q5_0 = 6
GGUF_TENSOR_Q5_1 = 7
GGUF_TENSOR_Q8_0 = 8
GGUF_TENSOR_Q8_1 = 9
GGUF_TENSOR_Q2_K = 10
GGUF_TENSOR_Q3_K = 11
GGUF_TENSOR_Q4_K = 12
GGUF_TENSOR_Q5_K = 13
GGUF_TENSOR_Q6_K = 14
GGUF_TENSOR_Q8_K = 15
GGUF_TENSOR_BF16 = 30

TENSOR_TYPE_SIZES = {}
TENSOR_TYPE_SIZES[GGUF_TENSOR_F32] = 4
TENSOR_TYPE_SIZES[GGUF_TENSOR_F16] = 2
TENSOR_TYPE_SIZES[GGUF_TENSOR_Q4_0] = 18
TENSOR_TYPE_SIZES[GGUF_TENSOR_Q4_1] = 20
TENSOR_TYPE_SIZES[GGUF_TENSOR_Q5_0] = 22
TENSOR_TYPE_SIZES[GGUF_TENSOR_Q5_1] = 24
TENSOR_TYPE_SIZES[GGUF_TENSOR_Q8_0] = 34
TENSOR_TYPE_SIZES[GGUF_TENSOR_Q8_1] = 36
TENSOR_TYPE_SIZES[GGUF_TENSOR_BF16] = 2


class GGUFReader:
    """Parser အတွက် GGUF mo files."""

    def __init__(self, filepath):
        self.filepath = filepath
        self.data = None
        self.magic = 0
        self.version = 0
        self.tensor_count = 0
        self.metadata_kv_count = 0
        self.metadata = {}
        self.tensor_infos = []
        self.alignment = 32
        self.data_offset = 0
        self._parsed = False

    def parse(self):
        self._read_file()
        self._parse_header()
        self._parse_metadata()
        self._parse_tensor_infos()
        self._compute_data_offoffset()
        self._parsed = True
        print("GGUF file parsed successfully.")

    def _read_file(self):
        with open(self.filepath, 'rb') as f:
            self.data = f.read()

    def _parse_header(self):
        offset = 0
        self.magic, offset = BytesHelper.read_uint32(None, self.data, offset)
        if self.magic != GGUF_MAGIC:
            raise ValueError("Invalid GGUF magic: 0x{:08X}".format(self.magic))
        self.version, offset = BytesHelper.read_uint32(None, self.data, offset)
        print("GGUF version: {}".format(self.version))
        self.tensor_count, offset = BytesHelper.read_uint64(None, self.data, offset)
        print("Tensor count: {}".format(self.tensor_count))
        self.metadata_kv_count, offset = BytesHelper.read_uint64(None, self.data, offset)
        print("Metadata KV count: {}".format(self.metadata_kv_count))
        self._header_end = offset

    def _parse_metadata(self):
        offset = self._header_end
        for _ in range(self.metadata_kv_count):
            key, offset = BytesHelper.read_string(None, self.data, offset)
            value_type, offset = BytesHelper.read_uint32(None, self.data, offset)
            value, offset = self._read_value(value_type, offset)
            self.metadata[key] = value
        self._metadata_end = offset

    def _read_value(self, value_type, offset):
        if value_type == GGUF_TYPE_UINT8:
            val, offset = BytesHelper.read_uint8(None, self.data, offset)
            return val, offset
        else:
            if value_type == GGUF_TYPE_INT8:
                val, offset = BytesHelper.read_int8(None, self.data, offset)
                return val, offset
            else:
                if value_type == GGUF_TYPE_UINT16:
                    val, offset = BytesHelper.read_uint16(None, self.data, offset)
                    return val, offset
                else:
                    if value_type == GGUF_TYPE_INT16:
                        val, offset = BytesHelper.read_int16(None, self.data, offset)
                        return val, offset
                    else:
                        if value_type == GGUF_TYPE_UINT32:
                            val, offset = BytesHelper.read_uint32(None, self.data, offset)
                            return val, offset
                        else:
                            if value_type == GGUF_TYPE_INT32:
                                val, offset = BytesHelper.read_int32(None, self.data, offset)
                                return val, offset
                            else:
                                if value_type == GGUF_TYPE_FLOAT32:
                                    val, offset = BytesHelper.read_float32(None, self.data, offset)
                                    return val, offset
                                else:
                                    if value_type == GGUF_TYPE_BOOL:
                                        val, offset = BytesHelper.read_bool(None, self.data, offset)
                                        return val, offset
                                    else:
                                        if value_type == GGUF_TYPE_STRING:
                                            val, offset = BytesHelper.read_string(None, self.data, offset)
                                            return val, offset
                                        else:
                                            if value_type == GGUF_TYPE_UINT64:
                                                val, offset = BytesHelper.read_uint64(None, self.data, offset)
                                                return val, offset
                                            else:
                                                if value_type == GGUF_TYPE_INT64:
                                                    val, offset = BytesHelper.read_int64(None, self.data, offset)
                                                    return val, offset
                                                else:
                                                    if value_type == GGUF_TYPE_FLOAT64:
                                                        val, offset = BytesHelper.read_float64(None, self.data, offset)
                                                        return val, offset
                                                    else:
                                                        if value_type == GGUF_TYPE_ARRAY:
                                                            val, offset = self._read_array(offset)
                                                            return val, offset
                                                        else:
                                                            print("Warning: unknown metadata type: {}".format(value_type))
                                                            return None, offset

    def _read_array(self, offset):
        elem_type, offset = BytesHelper.read_uint32(None, self.data, offset)
        arr_len, offset = BytesHelper.read_uint64(None, self.data, offset)
        arr = []
        for _ in range(arr_len):
            if elem_type == GGUF_TYPE_UINT8:
                val, offset = BytesHelper.read_uint8(None, self.data, offset)
            else:
                if elem_type == GGUF_TYPE_INT8:
                    val, offset = BytesHelper.read_int8(None, self.data, offset)
                else:
                    if elem_type == GGUF_TYPE_UINT16:
                        val, offset = BytesHelper.read_uint16(None, self.data, offset)
                    else:
                        if elem_type == GGUF_TYPE_INT16:
                            val, offset = BytesHelper.read_int16(None, self.data, offset)
                        else:
                            if elem_type == GGUF_TYPE_UINT32:
                                val, offset = BytesHelper.read_uint32(None, self.data, offset)
                            else:
                                if elem_type == GGUF_TYPE_INT32:
                                    val, offset = BytesHelper.read_int32(None, self.data, offset)
                                else:
                                    if elem_type == GGUF_TYPE_FLOAT32:
                                        val, offset = BytesHelper.read_float32(None, self.data, offset)
                                    else:
                                        if elem_type == GGUF_TYPE_UINT64:
                                            val, offset = BytesHelper.read_uint64(None, self.data, offset)
                                        else:
                                            if elem_type == GGUF_TYPE_INT64:
                                                val, offset = BytesHelper.read_int64(None, self.data, offset)
                                            else:
                                                if elem_type == GGUF_TYPE_FLOAT64:
                                                    val, offset = BytesHelper.read_float64(None, self.data, offset)
                                                else:
                                                    if elem_type == GGUF_TYPE_STRING:
                                                        val, offset = BytesHelper.read_string(None, self.data, offset)
                                                    else:
                                                        val = 0
                                                        offset = offset + 4
            arr = arr +[val]
        return arr, offset

    def _parse_tensor_infos(self):
        offset = self._metadata_end
        self.tensor_infos = []
        for _ in range(self.tensor_count):
            info = {}
            name, offset = BytesHelper.read_string(None, self.data, offset)
            info["name"] = name
            n_dims, offset = BytesHelper.read_uint32(None, self.data, offset)
            info["n_dims"] = n_dims
            dims = []
            for _ in range(n_dims):
                dim_val, offset = BytesHelper.read_uint64(None, self.data, offset)
                dims = dims +[dim_val]
            info["dims"] = dims
            tensor_type, offset = BytesHelper.read_uint32(None, self.data, offset)
            info["type"] = tensor_type
            tensor_offset, offset = BytesHelper.read_uint64(None, self.data, offset)
            info["offset"] = tensor_offset
            self.tensor_infos = self.tensor_infos +[info]
        self._tensor_infos_end = offset

    def _compute_data_offoffset(self):
        raw_offset = self._tensor_infos_end
        if raw_offset % self.alignment != 0:
            raw_offset = raw_offset +(self.alignment -(raw_offset % self.alignment))
        self.data_offset = raw_offset

    def get_metadata(self):
        if not self._parsed:
            raise RuntimeError("GGUF file has not been parsed.")
        return self.metadata

    def get_metadata_value(self, key, default = None):
        if not self._parsed:
            raise RuntimeError("GGUF file has not been parsed.")
        for k in self.metadata:
            if k == key:
                return self.metadata[k]
        return default

    def get_tensor_info(self, name):
        for info in self.tensor_infos:
            if info["name"] == name:
                return info
        return None

    def get_tensor_names(self):
        names = []
        for info in self.tensor_infos:
            names = names +[info["name"]]
        return names

    def read_tensor_data(self, name):
        if not self._parsed:
            raise RuntimeError("GGUF file has not been parsed.")
        info = self.get_tensor_info(name)
        if info == None:
            raise ValueError("Tensor not found: {}".format(name))
        start = self.data_offset + info["offset"]
        n_elements = 1
        for dim_val in info["dims"]:
            n_elements = n_elements * dim_val
        tensor_type = info["type"]
        bytes_per = 4
        for k in TENSOR_TYPE_SIZES:
            if k == tensor_type:
                bytes_per = TENSOR_TYPE_SIZES[k]
                break
        byte_size = bytes_per * n_elements
        end = start + byte_size
        if end > len(self.data):
            end = len(self.data)
        return self.data[start: end], tensor_type, info["dims"]

    def read_tensor_as_f32(self, name):
        raw_bytes, tensor_type, dims = self.read_tensor_data(name)
        if tensor_type == GGUF_TENSOR_F32:
            flat = []
            n_elements = 1
            for d in dims:
                n_elements = n_elements * d
            for i in range(n_elements):
                val, _ = BytesHelper.read_float32(None, raw_bytes, i * 4)
                flat = flat +[val]
            return flat, dims
        else:
            if tensor_type == GGUF_TENSOR_F16:
                flat = []
                n_elements = 1
                for d in dims:
                    n_elements = n_elements * d
                for i in range(n_elements):
                    val, _ = BytesHelper.read_float16(None, raw_bytes, i * 2)
                    flat = flat +[val]
                return flat, dims
            else:
                if tensor_type == GGUF_TENSOR_BF16:
                    flat = []
                    n_elements = 1
                    for d in dims:
                        n_elements = n_elements * d
                    for i in range(n_elements):
                        val, _ = BytesHelper.read_bfloat16(None, raw_bytes, i * 2)
                        flat = flat +[val]
                    return flat, dims
                else:
                    raise NotImplementedError("Unsupported tensor type: {}".format(tensor_type))
