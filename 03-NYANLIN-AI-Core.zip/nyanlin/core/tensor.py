# -*- coding: utf-8 -*-
# nyanlin/core/tensor.mmc - Tensor class, IEEE 754 decoder, byte helpers

struct_mod = None
math_mod = None

try:
    import struct as struct_mod
    import math as math_mod
except:
    pass


class BytesHelper:
    """Static methods အတွက် reading binary data မှ GGUF files."""

    @staticmethod
    def read_uint8(cls, data, offset):
        return data[offset], offset + 1

    @staticmethod
    def read_int8(cls, data, offset):
        val = data[offset]
        if val >= 128:
            val = val - 256
        return val, offset + 1

    @staticmethod
    def read_uint16(cls, data, offset):
        val = struct_mod.unpack('<H', data[offset: offset + 2])[0]
        return val, offset + 2

    @staticmethod
    def read_int16(cls, data, offset):
        val = struct_mod.unpack('<h', data[offset: offset + 2])[0]
        return val, offset + 2

    @staticmethod
    def read_uint32(cls, data, offset):
        val = struct_mod.unpack('<I', data[offset: offset + 4])[0]
        return val, offset + 4

    @staticmethod
    def read_int32(cls, data, offset):
        val = struct_mod.unpack('<i', data[offset: offset + 4])[0]
        return val, offset + 4

    @staticmethod
    def read_uint64(cls, data, offset):
        val = struct_mod.unpack('<Q', data[offset: offset + 8])[0]
        return val, offset + 8

    @staticmethod
    def read_int64(cls, data, offset):
        val = struct_mod.unpack('<q', data[offset: offset + 8])[0]
        return val, offset + 8

    @staticmethod
    def read_float32(cls, data, offset):
        val = struct_mod.unpack('<f', data[offset: offset + 4])[0]
        return val, offset + 4

    @staticmethod
    def read_float64(cls, data, offset):
        val = struct_mod.unpack('<d', data[offset: offset + 8])[0]
        return val, offset + 8

    @staticmethod
    def read_float16(cls, data, offset):
        raw = struct_mod.unpack('<H', data[offset: offset + 2])[0]
        result = BytesHelper._decode_float16(raw)
        return result, offset + 2

    @staticmethod
    def _decode_float16(cls, raw):
        sign = (raw >> 15) & 1
        exponent = (raw >> 10) & 0x1F
        mantissa = raw & 0x3FF
        if exponent == 0:
            if mantissa == 0:
                if sign == 1:
                    return - 0.0
                else:
                    return 0.0
            else:
                sign_mult = - 1.0
                if sign == 0:
                    sign_mult = 1.0
                return sign_mult *(mantissa / 1024.0) * 0.00006103515625
        else:
            if exponent == 31:
                if mantissa == 0:
                    if sign == 1:
                        return - math_mod.inf
                    else:
                        return math_mod.inf
                else:
                    return math_mod.nan
            else:
                sign_mult = - 1.0
                if sign == 0:
                    sign_mult = 1.0
                exp_val = exponent - 15
                return sign_mult *(2.0 ** exp_val) *(1.0 + mantissa / 1024.0)

    @staticmethod
    def read_bfloat16(cls, data, offset):
        raw = struct_mod.unpack('<H', data[offset: offset + 2])[0]
        f32_bits = raw << 16
        result = struct_mod.unpack('<f', struct_mod.pack('<I', f32_bits))[0]
        return result, offset + 2

    @staticmethod
    def read_string(cls, data, offset):
        length, offset = BytesHelper.read_uint64(cls, data, offset)
        string_bytes = data[offset: offset + length]
        string_val = string_bytes.decode('utf-8', errors = 'replace')
        return string_val, offset + length

    @staticmethod
    def read_bytes(cls, data, offset, length):
        result = data[offset: offset + length]
        return result, offset + length

    @staticmethod
    def read_bool(cls, data, offset):
        val = data[offset]
        return val == 1, offset + 1


class Tensor:
    """2D tensor (matrix) အတွက် neural network computations."""

    def __init__(self, data):
        if len(data) == 0:
            self._data = []
            self._rows = 0
            self._cols = 0
            return
        else:
            self._rows = len(data)
            self._cols = len(data[0])
            self._data = []
            for i in range(self._rows):
                row = []
                for j in range(self._cols):
                    row = row +[0.0]
                self._data = self._data +[row]
            for i in range(self._rows):
                for j in range(self._cols):
                    self._data[i][j] = float(data[i][j])

    @property
    def rows(self):
        return self._rows

    @property
    def cols(self):
        return self._cols

    @property
    def shape(self):
        return (self._rows, self._cols)

    @property
    def T(self):
        return self.transpose()

    def transpose(self):
        if self._rows == 0 or self._cols == 0:
            return Tensor([])
        new_data = []
        for j in range(self._cols):
            new_row = []
            for i in range(self._rows):
                new_row = new_row +[self._data[i][j]]
            new_data = new_data +[new_row]
        return Tensor(new_data)

    def matmul(self, other):
        if self._cols != other._rows:
            raise ValueError("matmul dimension mismatch")
        result_data = []
        for i in range(self._rows):
            result_row = []
            for j in range(other._cols):
                s = 0.0
                for k in range(self._cols):
                    s = s + self._data[i][k] * other._data[k][j]
                result_row = result_row +[s]
            result_data = result_data +[result_row]
        return Tensor(result_data)

    def add(self, other):
        if hasattr(other, '_data'):
            new_data = []
            for i in range(self._rows):
                new_row = []
                for j in range(self._cols):
                    new_row = new_row +[self._data[i][j] + other._data[i][j]]
                new_data = new_data +[new_row]
            return Tensor(new_data)
        else:
            scalar = float(other)
            new_data = []
            for i in range(self._rows):
                new_row = []
                for j in range(self._cols):
                    new_row = new_row +[self._data[i][j] + scalar]
                new_data = new_data +[new_row]
            return Tensor(new_data)

    def sub(self, other):
        if hasattr(other, '_data'):
            new_data = []
            for i in range(self._rows):
                new_row = []
                for j in range(self._cols):
                    new_row = new_row +[self._data[i][j] - other._data[i][j]]
                new_data = new_data +[new_row]
            return Tensor(new_data)
        else:
            scalar = float(other)
            new_data = []
            for i in range(self._rows):
                new_row = []
                for j in range(self._cols):
                    new_row = new_row +[self._data[i][j] - scalar]
                new_data = new_data +[new_row]
            return Tensor(new_data)

    def mul(self, other):
        if hasattr(other, '_data'):
            new_data = []
            for i in range(self._rows):
                new_row = []
                for j in range(self._cols):
                    new_row = new_row +[self._data[i][j] * other._data[i][j]]
                new_data = new_data +[new_row]
            return Tensor(new_data)
        else:
            scalar = float(other)
            new_data = []
            for i in range(self._rows):
                new_row = []
                for j in range(self._cols):
                    new_row = new_row +[self._data[i][j] * scalar]
                new_data = new_data +[new_row]
            return Tensor(new_data)

    def scale(self, scalar):
        scalar = float(scalar)
        new_data = []
        for i in range(self._rows):
            new_row = []
            for j in range(self._cols):
                new_row = new_row +[self._data[i][j] * scalar]
            new_data = new_data +[new_row]
        return Tensor(new_data)

    def div(self, scalar):
        scalar = float(scalar)
        new_data = []
        for i in range(self._rows):
            new_row = []
            for j in range(self._cols):
                new_row = new_row +[self._data[i][j] / scalar]
            new_data = new_data +[new_row]
        return Tensor(new_data)

    def get_row(self, i):
        if i < 0 or i >= self._rows:
            raise IndexError("row index out of range")
        result = []
        for j in range(self._cols):
            result = result +[self._data[i][j]]
        return result

    def set_row(self, i, row):
        if i < 0 or i >= self._rows:
            raise IndexError("row index out of range")
        if len(row) != self._cols:
            raise ValueError("row length mismatch")
        for j in range(self._cols):
            self._data[i][j] = float(row[j])

    def get_col(self, j):
        if j < 0 or j >= self._cols:
            raise IndexError("column index out of range")
        result = []
        for i in range(self._rows):
            result = result +[self._data[i][j]]
        return result

    def slice_rows(self, start, end):
        if start < 0:
            start = 0
        if end > self._rows:
            end = self._rows
        if start >= end:
            return Tensor([])
        new_data = []
        for i in range(start, end):
            row_copy = []
            for j in range(self._cols):
                row_copy = row_copy +[self._data[i][j]]
            new_data = new_data +[row_copy]
        return Tensor(new_data)

    def get(self, i, j):
        return self._data[i][j]

    def set(self, i, j, value):
        self._data[i][j] = float(value)

    def to_စာရင်း(self):
        result = []
        for i in range(self._rows):
            row_copy = []
            for j in range(self._cols):
                row_copy = row_copy +[self._data[i][j]]
            result = result +[row_copy]
        return result

    def flatten(self):
        result = []
        for i in range(self._rows):
            for j in range(self._cols):
                result = result +[self._data[i][j]]
        return result

    def copy(self):
        return Tensor(self.to_စာရင်း())

    def __repr__(self):
        return "Tensor(shape=({}, {}))".format(self._rows, self._cols)

    @staticmethod
    def zeros(cls, rows, cols):
        data = []
        for i in range(rows):
            row = []
            for j in range(cols):
                row = row +[0.0]
            data = data +[row]
        return Tensor(data)

    @staticmethod
    def ones(cls, rows, cols):
        data = []
        for i in range(rows):
            row = []
            for j in range(cols):
                row = row +[1.0]
            data = data +[row]
        return Tensor(data)

    @staticmethod
    def from_flat(cls, flat, rows, cols):
        if len(flat) != rows * cols:
            raise ValueError("from_flat: size mismatch")
        data = []
        idx = 0
        for i in range(rows):
            row = []
            for j in range(cols):
                row = row +[float(flat[idx])]
                idx = idx + 1
            data = data +[row]
        return Tensor(data)

    @staticmethod
    def from_row(cls, row_list):
        data = []
        inner = []
        for val in row_list:
            inner = inner +[float(val)]
        data = data +[inner]
        return Tensor(data)

    @staticmethod
    def from_col(cls, col_list):
        data = []
        for val in col_list:
            data = data +[[float(val)]]
        return Tensor(data)


def vec_add(a, b):
    if len(a) != len(b):
        raise ValueError("vec_add length mismatch")
    result = []
    for i in range(len(a)):
        result = result +[a[i] + b[i]]
    return result

def vec_sub(a, b):
    if len(a) != len(b):
        raise ValueError("vec_sub length mismatch")
    result = []
    for i in range(len(a)):
        result = result +[a[i] - b[i]]
    return result

def vec_mul(a, b):
    if len(a) != len(b):
        raise ValueError("vec_mul length mismatch")
    result = []
    for i in range(len(a)):
        result = result +[a[i] * b[i]]
    return result

def vec_scale(a, scalar):
    result = []
    for i in range(len(a)):
        result = result +[a[i] * scalar]
    return result

def vec_dot(a, b):
    if len(a) != len(b):
        raise ValueError("vec_dot length mismatch")
    s = 0.0
    for i in range(len(a)):
        s = s + a[i] * b[i]
    return s
