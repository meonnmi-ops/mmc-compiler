# -*- coding: utf-8 -*-
# nyanlin/core/tokenizer.mmc - BPE tokenizer for GGUF models

class BPETokenizer:
    """BPE tokenizer compatible နုတ်ထုတ် GGUF mo files."""

    def __init__(self, reader):
        self.reader = reader
        self.vocab = []
        self.vocab_scores = []
        self.merges = []
        self.merge_rank = {}
        self.bos_token_id = 1
        self.eos_token_id = 2
        self.pad_token_id = 0
        self._loaded = False
        self._load_tokenizer_data()

    def _load_tokenizer_data(self):
        meta = self.reader.get_metadata()
        tokens_raw = self.reader.get_metadata_value("tokenizer.ggml.tokens", None)
        if tokens_raw == None:
            print("Warning: no tokenizer.ggml.tokens found")
            self.vocab = []
        else:
            self.vocab = tokens_raw
        scores_raw = self.reader.get_metadata_value("tokenizer.ggml.scores", None)
        if scores_raw == None:
            self.vocab_scores = [0.0] * len(self.vocab)
        else:
            self.vocab_scores = scores_raw
        merges_raw = self.reader.get_metadata_value("tokenizer.ggml.merges", None)
        if merges_raw == None:
            self.merges = []
        else:
            self.merges = merges_raw
        self.merge_rank = {}
        for rank_idx in range(len(self.merges)):
            merge_str = self.merges[rank_idx]
            parts = merge_str.split(" ", 1)
            if len(parts) == 2:
                key = (parts[0], parts[1])
                self.merge_rank[key] = rank_idx
        bos = self.reader.get_metadata_value("tokenizer.ggml.bos_token_id", None)
        if bos != None:
            self.bos_token_id = bos
        eos = self.reader.get_metadata_value("tokenizer.ggml.eos_token_id", None)
        if eos != None:
            self.eos_token_id = eos
        self._vocab_to_id = {}
        for _vid in range(len(self.vocab)):
            self._vocab_to_id[self.vocab[_vid]] = _vid
        self._loaded = True
        print("Tokenizer loaded: {} tokens, {} merges".format(len(self.vocab), len(self.merges)))

    def encode(self, text):
        if not self._loaded:
            raise RuntimeError("Tokenizer not loaded")
        if len(text) == 0:
            return[self.bos_token_id]
        tokens = []
        for ch in text:
            tokens = tokens +[ch]
        while len(tokens) >= 2:
            best_rank = len(self.merges) + 1
            best_idx = - 1
            for i in range(len(tokens) - 1):
                pair = (tokens[i], tokens[i + 1])
                rank = len(self.merges) + 1
                for k in self.merge_rank:
                    if k == pair:
                        rank = self.merge_rank[k]
                        break
                if rank < best_rank:
                    best_rank = rank
                    best_idx = i
            if best_idx == - 1:
                break
            merged = tokens[best_idx] + tokens[best_idx + 1]
            new_tokens = []
            for i in range(len(tokens)):
                if i == best_idx:
                    new_tokens = new_tokens +[merged]
                else:
                    if i == best_idx + 1:
                        pass
                    else:
                        new_tokens = new_tokens +[tokens[i]]
            tokens = new_tokens
        token_ids = [self.bos_token_id]
        for tok_str in tokens:
            tok_id = self._bpe_to_id(tok_str)
            if tok_id >= 0:
                token_ids = token_ids +[tok_id]
            else:
                byte_list = tok_str.encode('utf-8')
                for byte_val in byte_list:
                    token_ids = token_ids +[byte_val + 3]
        return token_ids

    def _bpe_to_id(self, token_str):
        if token_str in self._vocab_to_id:
            return self._vocab_to_id[token_str]
        return - 1

    def decode(self, token_ids):
        if not self._loaded:
            raise RuntimeError("Tokenizer not loaded")
        pieces = []
        for tid in token_ids:
            if tid == self.bos_token_id:
                pass
            else:
                if tid == self.eos_token_id:
                    pass
                else:
                    if tid == self.pad_token_id:
                        pass
                    else:
                        if tid < 0:
                            pass
                        else:
                            if tid >= len(self.vocab):
                                pass
                            else:
                                pieces = pieces +[self.vocab[tid]]
        result = ""
        for piece in pieces:
            result = result + piece
        result = self._clean_byte_fallback(result)
        return result

    def _clean_byte_fallback(self, text):
        result = text
        changed = True
        while changed:
            changed = False
            start = 0
            new_result = ""
            while start < len(result):
                pos = result.find("<0x", start)
                if pos == - 1:
                    new_result = new_result + result[start:]
                    break
                new_result = new_result + result[start: pos]
                end_bracket = result.find(">", pos)
                if end_bracket == - 1 or end_bracket > pos + 5:
                    new_result = new_result + result[pos]
                    start = pos + 1
                    continue
                hex_str = result[pos + 3: end_bracket]
                try:
                    byte_val = int(hex_str, 16)
                    new_result = new_result + chr(byte_val)
                    changed = True
                    start = end_bracket + 1
                except:
                    new_result = new_result + result[pos]
                    start = pos + 1
            result = new_result
        return result

    def vocab_size(self):
        return len(self.vocab)
