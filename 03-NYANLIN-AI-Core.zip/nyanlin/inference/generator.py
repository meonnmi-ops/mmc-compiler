# -*- coding: utf-8 -*-
# nyanlin/inference/generator.mmc - Autoregressive text generation
# Fixed: Qwen2 tensor name support, quantized tensor handling

from core.tensor import Tensor
from core.ops.math_ops import rms_norm, precompute_freqs_cis, vec_add


class TextGenerator:
    """Autoregressive text generator for transformer models."""

    def __init__(self, model_loader, tokenizer, sampler):
        self.loader = model_loader
        self.tokenizer = tokenizer
        self.sampler = sampler
        self.config = model_loader.config
        self.layers = []
        self.output_norm_weight = None
        self.output_weight = None
        self.embed_weight = None
        self.freqs_cos = None
        self.freqs_sin = None
        self.kv_cache = None
        self._built = False
        self._name_map = None

    def _build_name_map(self):
        """Build architecture-specific tensor name mapping."""
        arch = getattr(self.config, 'arch', None) or ''
        if arch in ('qwen2', 'qwen', 'qwen2.5', 'qwen2_5'):
            return {
                'embed': 'model.embed_tokens.weight',
                'output_norm': 'model.norm.weight',
                'output': 'model.output.weight',
                'attn_q': 'model.layers.{}.self_attn.q_proj.weight',
                'attn_k': 'model.layers.{}.self_attn.k_proj.weight',
                'attn_v': 'model.layers.{}.self_attn.v_proj.weight',
                'attn_o': 'model.layers.{}.self_attn.o_proj.weight',
                'ffn_gate': 'model.layers.{}.mlp.gate_proj.weight',
                'ffn_up': 'model.layers.{}.mlp.up_proj.weight',
                'ffn_down': 'model.layers.{}.mlp.down_proj.weight',
                'attn_norm': 'model.layers.{}.input_layernorm.weight',
                'ffn_norm': 'model.layers.{}.post_attention_layernorm.weight',
            }
        elif arch in ('llama', 'mistral', 'phi2', 'phi3'):
            return {
                'embed': 'token_embd.weight',
                'output_norm': 'output_norm.weight',
                'output': 'output.weight',
                'attn_q': 'blk.{}.attn_q.weight',
                'attn_k': 'blk.{}.attn_k.weight',
                'attn_v': 'blk.{}.attn_v.weight',
                'attn_o': 'blk.{}.attn_output.weight',
                'ffn_gate': 'blk.{}.ffn_gate.weight',
                'ffn_up': 'blk.{}.ffn_up.weight',
                'ffn_down': 'blk.{}.ffn_down.weight',
                'attn_norm': 'blk.{}.attn_norm.weight',
                'ffn_norm': 'blk.{}.ffn_norm.weight',
            }
        else:
            # Auto-detect from tensor names
            all_names = self.loader.get_weight_names()
            if len(all_names) > 0 and all_names[0].startswith('model.'):
                return {
                    'embed': 'model.embed_tokens.weight',
                    'output_norm': 'model.norm.weight',
                    'output': 'model.output.weight',
                    'attn_q': 'model.layers.{}.self_attn.q_proj.weight',
                    'attn_k': 'model.layers.{}.self_attn.k_proj.weight',
                    'attn_v': 'model.layers.{}.self_attn.v_proj.weight',
                    'attn_o': 'model.layers.{}.self_attn.o_proj.weight',
                    'ffn_gate': 'model.layers.{}.mlp.gate_proj.weight',
                    'ffn_up': 'model.layers.{}.mlp.up_proj.weight',
                    'ffn_down': 'model.layers.{}.mlp.down_proj.weight',
                    'attn_norm': 'model.layers.{}.input_layernorm.weight',
                    'ffn_norm': 'model.layers.{}.post_attention_layernorm.weight',
                }
            else:
                return {
                    'embed': 'token_embd.weight',
                    'output_norm': 'output_norm.weight',
                    'output': 'model.output.weight',
                    'attn_q': 'blk.{}.attn_q.weight',
                    'attn_k': 'blk.{}.attn_k.weight',
                    'attn_v': 'blk.{}.attn_v.weight',
                    'attn_o': 'blk.{}.attn_output.weight',
                    'ffn_gate': 'blk.{}.ffn_gate.weight',
                    'ffn_up': 'blk.{}.ffn_up.weight',
                    'ffn_down': 'blk.{}.ffn_down.weight',
                    'attn_norm': 'blk.{}.attn_norm.weight',
                    'ffn_norm': 'blk.{}.ffn_norm.weight',
                }

    def build(self):
        """Build transformer layers and load weights."""
        from layers.attention import KVCache
        from layers.transformer import TransformerBlock

        c = self.config
        self._name_map = self._build_name_map()
        arch = getattr(c, 'arch', 'unknown')
        print("Tensor name map: {} architecture".format(arch))

        self.layers = []
        for i in range(c.n_layers):
            layer = TransformerBlock(
                c.dim, c.n_heads, c.n_kv_heads,
                c.hidden_dim, c.norm_eps, c.head_dim
            )
            self.layers = self.layers + [layer]

        # Load weights for each layer
        self._load_all_weights()

        # Precompute RoPE frequencies
        print("Precomputing RoPE frequencies...")
        self.freqs_cos, self.freqs_sin = precompute_freqs_cis(
            c.head_dim, c.max_seq_len, c.rope_theta
        )
        for i in range(c.n_layers):
            self.layers[i].set_rope(self.freqs_cos, self.freqs_sin)

        # Load output norm and output weight
        print("Loading output head...")
        try:
            flat, dims = self.loader.load_weight(self._name_map['output_norm'])
            self.output_norm_weight = flat
            print("  Output norm: OK")
        except Exception as e:
            print("  Warning: Could not load output norm: {}".format(e))
            self.output_norm_weight = [1.0] * c.dim

        try:
            flat, dims = self.loader.load_weight(self._name_map['output'])
            self.output_weight = flat
            print("  Output weight: OK ({:.1f}M params)".format(len(flat) / 1e6))
        except Exception as e:
            print("  Warning: Could not load output weight: {}".format(e))
            self.output_weight = None

        # Initialize KV cache
        self.kv_cache = KVCache(c.n_layers, c.n_kv_heads, c.head_dim, c.max_seq_len)
        self._built = True
        print("Generator built with {} layers.".format(c.n_layers))

    def _load_all_weights(self):
        """Load weights for all transformer layers."""
        c = self.config
        nm = self._name_map
        print("Loading weights for {} layers...".format(c.n_layers))
        for i in range(c.n_layers):
            suffix = "{}".format(i)
            try:
                wq_flat, _ = self.loader.load_weight(nm['attn_q'].format(suffix))
                wk_flat, _ = self.loader.load_weight(nm['attn_k'].format(suffix))
                wv_flat, _ = self.loader.load_weight(nm['attn_v'].format(suffix))
                wo_flat, _ = self.loader.load_weight(nm['attn_o'].format(suffix))
                attn_norm, _ = self.loader.load_weight(nm['attn_norm'].format(suffix))
                w_gate, _ = self.loader.load_weight(nm['ffn_gate'].format(suffix))
                w_up, _ = self.loader.load_weight(nm['ffn_up'].format(suffix))
                w_down, _ = self.loader.load_weight(nm['ffn_down'].format(suffix))
                ffn_norm, _ = self.loader.load_weight(nm['ffn_norm'].format(suffix))

                self.layers[i].set_weights(
                    attn_norm, ffn_norm,
                    {"wq": wq_flat, "wk": wk_flat, "wv": wv_flat, "wo": wo_flat},
                    {"w_gate": w_gate, "w_up": w_up, "w_down": w_down}
                )
                if (i + 1) % 4 == 0 or i == c.n_layers - 1:
                    print("  Layer {}/{} loaded".format(i + 1, c.n_layers))
            except Exception as e:
                print("  ERROR loading layer {}: {}".format(i, e))
                raise

    def generate(self, prompt, max_tokens=256, temperature=None, greedy=False):
        """Generate text from a prompt."""
        if not self._built:
            raise RuntimeError("Generator not built. Call build() first.")
        self.kv_cache.clear()

        # Encode prompt
        token_ids = self.tokenizer.encode(prompt)
        print("Prompt tokens: {}".format(len(token_ids)))
        generated = []
        for tid in token_ids:
            generated = generated + [tid]

        # Process prompt tokens (prefill)
        print("Prefilling...")
        for t_idx in range(len(token_ids) - 1):
            pos = t_idx
            self._forward_token(token_ids[t_idx], pos)
            if (t_idx + 1) % 5 == 0 or t_idx == len(token_ids) - 2:
                print("  Prefilled {}/{}".format(t_idx + 1, len(token_ids) - 1))

        # Generate new tokens
        print("Generating {} tokens...".format(max_tokens))
        last_token = token_ids[len(token_ids) - 1]
        pos = len(token_ids) - 1
        for gen_idx in range(max_tokens):
            logits = self._forward_token(last_token, pos)
            if greedy:
                next_token = self.sampler.argmax(logits)
            else:
                next_token = self.sampler.sample(logits, generated)

            if next_token == self.tokenizer.eos_token_id:
                print("  EOS token reached at position {}.".format(gen_idx))
                break

            generated = generated + [next_token]
            last_token = next_token
            pos = pos + 1

            if (gen_idx + 1) % 5 == 0:
                print("  Generated {}/{} tokens...".format(gen_idx + 1, max_tokens))

        output_text = self.tokenizer.decode(generated)
        return output_text

    def _forward_token(self, token_id, pos):
        """Forward a single token through all layers."""
        c = self.config
        dim = c.dim
        vocab_size = c.vocab_size

        # Token embedding
        if self.embed_weight is None:
            flat, _ = self.loader.load_weight(self._name_map['embed'])
            self.embed_weight = flat
            print("  Embedding loaded: {:.1f}M params".format(len(flat) / 1e6))

        x = []
        for i in range(dim):
            x = x + [self.embed_weight[token_id * dim + i]]

        # Forward through layers
        for i in range(c.n_layers):
            x = self.layers[i].forward(x, pos, self.kv_cache, i)

        # Final norm
        x = rms_norm(x, self.output_norm_weight, c.norm_eps)

        # Output projection
        if self.output_weight is None:
            return [0.0] * vocab_size

        logits = []
        for v in range(vocab_size):
            s = 0.0
            for d in range(dim):
                s = s + self.output_weight[v * dim + d] * x[d]
            logits = logits + [s]
        return logits
