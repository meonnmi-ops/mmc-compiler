# -*- coding: utf-8 -*-
# nyanlin/inference/sampler.mmc - Token sampling strategies

math_mod = None
random_mod = None

try:
    import math as math_mod
except:
    pass

try:
    import random as random_mod
except:
    pass


class Sampler:
    """Token sampler နုတ်ထုတ် various strategies.

    Supports: temperature, top - k, top - p(nucleus),
    repetition penalty, and argmax(greedy) decoding.
    """

    def __init__(self, temperature = 1.0, top_k = 40, top_p = 0.95, rep_penalty = 1.1):
        self.temperature = temperature
        self.top_k = top_k
        self.top_p = top_p
        self.rep_penalty = rep_penalty

    def set_temperature(self, temp):
        self.temperature = temp

    def set_top_k(self, k):
        self.top_k = k

    def set_top_p(self, p):
        self.top_p = p

    def set_rep_penalty(self, penalty):
        self.rep_penalty = penalty

    def apply_temperature(self, logits):
        """Scale logits by temperature."""
        if self.temperature == 0.0:
            return logits
        result = []
        for i in range(len(logits)):
            result = result +[logits[i] / self.temperature]
        return result

    def apply_top_k(self, logits, k):
        """Keep only top-k highest logits, set rest to negative infinity."""
        if k <= 0 or k >= len(logits):
            return logits
        indexed = []
        for i in range(len(logits)):
            indexed = indexed +[(logits[i], i)]
        # Sort by logit value descending
        for i in range(len(indexed)):
            for j in range(i + 1, len(indexed)):
                if indexed[j][0] > indexed[i][0]:
                    tmp = indexed[i]
                    indexed[i] = indexed[j]
                    indexed[j] = tmp
        # Find the k-th threshold
        threshold = indexed[k][0]
        result = []
        for i in range(len(logits)):
            if logits[i] < threshold:
                result = result +[- math_mod.inf]
            else:
                result = result +[logits[i]]
        return result

    def apply_top_p(self, logits, p):
        """Nucleus sampling: keep smallest set of tokens နုတ်ထုတ် cumulative prob >= p."""
        indexed = []
        for i in range(len(logits)):
            indexed = indexed +[(logits[i], i)]
        # Sort descending
        for i in range(len(indexed)):
            for j in range(i + 1, len(indexed)):
                if indexed[j][0] > indexed[i][0]:
                    tmp = indexed[i]
                    indexed[i] = indexed[j]
                    indexed[j] = tmp
        # Compute softmax of sorted logits
        max_val = indexed[0][0]
        exp_vals = []
        for i in range(len(indexed)):
            exp_vals = exp_vals +[math_mod.exp(indexed[i][0] - max_val)]
        sum_exp = 0.0
        for i in range(len(exp_vals)):
            sum_exp = sum_exp + exp_vals[i]
        probs = []
        for i in range(len(exp_vals)):
            probs = probs +[exp_vals[i] / sum_exp]
        # Find cutoff
        cumsum = 0.0
        cutoff_idx = len(probs)
        for i in range(len(probs)):
            cumsum = cumsum + probs[i]
            if cumsum >= p:
                cutoff_idx = i + 1
                break
        # Build mask
        keep = {}
        for i in range(cutoff_idx):
            keep[indexed[i][1]] = True
        result = []
        for i in range(len(logits)):
            if i in keep:
                result = result +[logits[i]]
            else:
                result = result +[- math_mod.inf]
        return result

    def apply_rep_penalty(self, logits, generated_ids, penalty):
        """Apply repetition penalty to already-generated token logits."""
        if penalty == 1.0:
            return logits
        result = []
        for i in range(len(logits)):
            val = logits[i]
            found = False
            for gid in generated_ids:
                if gid == i:
                    found = True
                    break
            if found:
                if val > 0.0:
                    val = val / penalty
                else:
                    val = val * penalty
            result = result +[val]
        return result

    def sample(self, logits, generated_ids = None):
        """Sample a token ID မှ logits.

        Applies(in order): repetition penalty, temperature, top - k, top - p,
        then samples from the resulting distribution.
        """
        logits = self.apply_rep_penalty(logits, generated_ids or[], self.rep_penalty)
        logits = self.apply_temperature(logits)
        logits = self.apply_top_k(logits, self.top_k)
        logits = self.apply_top_p(logits, self.top_p)
        return self._sample_from_logits(logits)

    def _sample_from_logits(self, logits):
        """Sample မှ logits using softmax probabilities."""
        # Softmax
        max_val = logits[0]
        for i in range(len(logits)):
            if logits[i] > max_val:
                max_val = logits[i]
        exp_vals = []
        for i in range(len(logits)):
            if logits[i] == - math_mod.inf:
                exp_vals = exp_vals +[0.0]
            else:
                exp_vals = exp_vals +[math_mod.exp(logits[i] - max_val)]
        sum_exp = 0.0
        for i in range(len(exp_vals)):
            sum_exp = sum_exp + exp_vals[i]
        probs = []
        for i in range(len(exp_vals)):
            probs = probs +[exp_vals[i] / sum_exp]
        # Random sample
        r = random_mod.random()
        cumsum = 0.0
        for i in range(len(probs)):
            cumsum = cumsum + probs[i]
            if cumsum >= r:
                return i
        return len(probs) - 1

    def argအမြင့်ဆုံး(self, logits):
        """Greedy decoding: ပြန်ပေး the index of the maximum logit."""
        best_idx = 0
        best_val = logits[0]
        for i in range(1, len(logits)):
            if logits[i] > best_val:
                best_val = logits[i]
                best_idx = i
        return best_idx
