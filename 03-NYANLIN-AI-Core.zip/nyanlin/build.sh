#!/bin/bash
# nyanlin/build.sh
# ========================================
# Build script for NYANLIN AI Engine
# ========================================
# Steps:
#   1. Transpile all .mmc files to .py
#   2. Run tests to verify
#   3. Package as ARM64 binary (optional)
# ========================================

set -e

echo "========================================="
echo "  NYANLIN Build Script v1.0"
echo "  Pure MMC AI Inference Engine"
echo "========================================="
echo ""

# Configuration
MMC_TRANSPILER="python3 mmc_transpiler.py"
MMC_DIR="."
OUTPUT_DIR="build"
PYTHON="python3"

# Step 1: Check for MMC transpiler
echo "[1/4] Checking for MMC transpiler..."

if [ -f "mmc_transpiler.py" ]; then
    MMC_TRANSPILER="python3 mmc_transpiler.py"
    echo "  Found: mmc_transpiler.py"
elif command -v mmc &> /dev/null; then
    MMC_TRANSPILER="mmc"
    echo "  Found: mmc command"
else
    echo "  Warning: No MMC transpiler found."
    echo "  Using direct Python execution mode."
    MMC_TRANSPILER=""
fi

# Step 2: Create build directory
echo "[2/4] Creating build directory..."
mkdir -p $OUTPUT_DIR/core/ops
mkdir -p $OUTPUT_DIR/layers
mkdir -p $OUTPUT_DIR/inference
mkdir -p $OUTPUT_DIR/tests

# Step 3: Transpile MMC files to Python
echo "[3/4] Transpiling MMC -> Python..."

transpile_file() {
    src="$1"
    dst="$2"
    if [ -n "$MMC_TRANSPILER" ]; then
        $MMC_TRANSPILER transpile < "$src" > "$dst"
        echo "  Transpiled: $src -> $dst"
    else
        cp "$src" "$dst"
        echo "  Copied: $src -> $dst"
    fi
}

# Core files
transpile_file "$MMC_DIR/core/tensor.mmc" "$OUTPUT_DIR/core/tensor.py"
transpile_file "$MMC_DIR/core/gguf_parser.mmc" "$OUTPUT_DIR/core/gguf_parser.py"
transpile_file "$MMC_DIR/core/tokenizer.mmc" "$OUTPUT_DIR/core/tokenizer.py"
transpile_file "$MMC_DIR/core/model_loader.mmc" "$OUTPUT_DIR/core/model_loader.py"

# Ops files
transpile_file "$MMC_DIR/core/ops/math_ops.mmc" "$OUTPUT_DIR/core/ops/math_ops.py"
transpile_file "$MMC_DIR/core/ops/activation.mmc" "$OUTPUT_DIR/core/ops/activation.py"

# Layer files
transpile_file "$MMC_DIR/layers/attention.mmc" "$OUTPUT_DIR/layers/attention.py"
transpile_file "$MMC_DIR/layers/feedforward.mmc" "$OUTPUT_DIR/layers/feedforward.py"
transpile_file "$MMC_DIR/layers/transformer.mmc" "$OUTPUT_DIR/layers/transformer.py"

# Inference files
transpile_file "$MMC_DIR/inference/sampler.mmc" "$OUTPUT_DIR/inference/sampler.py"
transpile_file "$MMC_DIR/inference/generator.mmc" "$OUTPUT_DIR/inference/generator.py"

# Main entry point
transpile_file "$MMC_DIR/main.mmc" "$OUTPUT_DIR/main.py"

# Step 4: Run tests
echo "[4/4] Running tests..."
echo ""

cd $OUTPUT_DIR

echo "--- Tensor Tests ---"
$PYTHON tests/test_tensor.py 2>/dev/null || echo "  (test_tensor not yet available)"
echo ""

echo "--- Parser Tests ---"
$PYTHON tests/test_parser.py 2>/dev/null || echo "  (test_parser not yet available)"
echo ""

cd ..

# Optional: Build ARM64 binary with Nuitka
echo ""
echo "========================================="
echo "  Build complete!"
echo "========================================="
echo ""
echo "Output: $OUTPUT_DIR/"
echo ""
echo "To run:"
echo "  cd $OUTPUT_DIR && python3 main.py <model.gguf> \"prompt\""
echo ""
echo "To compile ARM64 binary (requires Nuitka):"
echo "  pip install nuitka"
echo "  cd $OUTPUT_DIR && python3 -m nuitka --onefile --arch=arm64 main.py"
echo ""
echo "To create zip:"
echo "  cd .. && zip -r nyanlin-mmc-ai-v1.0.zip nyanlin/"
echo ""
echo "========================================="
