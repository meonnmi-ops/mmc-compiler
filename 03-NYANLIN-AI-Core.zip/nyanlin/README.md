# NYANLIN - Pure MMC AI Inference Engine v1.0
# ========================================
# A self-contained AI inference library written entirely in MMC v9.0.
# Parses GGUF model files and generates text token-by-token.
#
# Architecture: Llama-style Transformer
#   - Token Embedding
#   - N x Transformer Blocks (RMSNorm + GQA Attention + SwiGLU FFN)
#   - Output Projection
#   - BPE Tokenizer
#
# Features:
#   - IEEE 754 float32/float16 decoding (pure math, no struct)
#   - GGUF v2/v3 binary parser (all quantization types)
#   - Grouped-Query Attention (GQA) with KV cache
#   - Rotary Position Embeddings (RoPE)
#   - Top-k, Top-p, Temperature sampling
#   - Repetition penalty
#   - Full error handling with Myanmar messages
#
# Zero external C/C++ dependencies.
# ========================================

## Directory Structure

```
nyanlin/
├── core/
│   ├── tensor.mmc          # Tensor class + IEEE 754 decoder + byte helpers
│   ├── tensor.py           # (transpiled Python - ready to run)
│   ├── gguf_parser.mmc      # GGUF binary format parser
│   ├── gguf_parser.py      # (transpiled Python)
│   ├── tokenizer.mmc       # BPE tokenizer (encode/decode)
│   ├── tokenizer.py         # (transpiled Python)
│   ├── model_loader.mmc     # Model weight loader
│   ├── model_loader.py     # (transpiled Python)
│   └── ops/
│       ├── math_ops.mmc     # Softmax, Norm, RoPE, vector ops
│       ├── math_ops.py     # (transpiled Python)
│       ├── activation.mmc  # SiLU, GELU, ReLU, Sigmoid
│       └── activation.py   # (transpiled Python)
├── layers/
│   ├── attention.mmc       # Multi-head attention with GQA
│   ├── attention.py       # (transpiled Python)
│   ├── feedforward.mmc      # SwiGLU feed-forward network
│   ├── feedforward.py      # (transpiled Python)
│   └── transformer.mmc      # Transformer block (norm + attn + ffn)
│       └── transformer.py   # (transpiled Python)
├── inference/
│   ├── sampler.mmc         # Token sampling (top-k, top-p, temperature)
│   ├── sampler.py         # (transpiled Python)
│   └── generator.mmc       # Autoregressive text generation loop
│       └── generator.py     # (transpiled Python)
├── tests/
│   ├── test_tensor.py      # Tensor + float decode tests
│   └── test_parser.py      # GGUF parser tests
├── main.mmc               # CLI entry point
├── main.py                 # (transpiled Python)
└── build.sh                # Build script
```

## Quick Start

```bash
# 1. Transpile all MMC files to Python
cd nyanlin
python3 /path/to/mmc_transpiler.py build .

# 2. Run with a GGUF model
python3 main.py model.gguf "Hello, how are you?"
```

## Dependencies

- Python 3.8+
- MMC v9.0 Transpiler (for .mmc -> .py transpilation)
- No external C/C++ libraries required

## License

Open Source - MyanOS AI Team
