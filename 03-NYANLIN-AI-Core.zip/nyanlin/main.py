# -*- coding: utf-8 -*-
# nyanlin/main.mmc - CLI entry point for NYANLIN AI Inference Engine
# Usage: python main.py <model.gguf> "prompt" [options]

import sys
import time


def main():
    print("=========================================")
    print("  NYANLIN AI Engine v1.0")
    print("  Pure MMC Transformer Inference")
    print("=========================================")
    print("")

    # Parse arguments
    args = sys.argv
    if len(args) < 3:
        print("Usage: python main.py <model.gguf> \"prompt\"")
        print("")
        print("Arguments:")
        print("  model.gguf  Path to GGUF model file")
        print("  prompt      Input text prompt")
        print("")
        print("Options ( အဖြစ် --key value):")
        print("  --max_tokens   Max tokens to generate (default: 256)")
        print("  --temperature  Sampling temperature (default: 0.8)")
        print("  --top_k        Top-k filtering (default: 40)")
        print("  --top_p        Nucleus sampling threshold (default: 0.95)")
        print("  --greedy       Use greedy decoding instead of sampling")
        sys.exit(1)

    model_path = args[1]
    prompt = args[2]

    # Parse optional arguments
    max_tokens = 256
    temperature = 0.8
    top_k = 40
    top_p = 0.95
    greedy = False

    i = 3
    while i < len(args):
        if args[i] == "--max_tokens":
            i = i + 1
            if i < len(args):
                max_tokens = int(args[i])
        else:
            if args[i] == "--temperature":
                i = i + 1
                if i < len(args):
                    temperature = float(args[i])
            else:
                if args[i] == "--top_k":
                    i = i + 1
                    if i < len(args):
                        top_k = int(args[i])
                else:
                    if args[i] == "--top_p":
                        i = i + 1
                        if i < len(args):
                            top_p = float(args[i])
                    else:
                        if args[i] == "--greedy":
                            greedy = True
                        else:
                            print("Warning: unknown argument: {}".format(args[i]))
        i = i + 1

    print("Model path: {}".format(model_path))
    print("Prompt: {}".format(prompt))
    print("Max tokens: {}".format(max_tokens))
    print("Temperature: {}".format(temperature))
    print("Top-k: {}".format(top_k))
    print("Top-p: {}".format(top_p))
    print("Greedy: {}".format(greedy))
    print("")

    # Load model
    print("[1/4] Loading model...")
    from core.model_loader import ModelLoader
    loader = ModelLoader(model_path)
    try:
        loader.load()
    except:
        print("Error: Failed to load model from: {}".format(model_path))
        sys.exit(1)

    # Load tokenizer
    print("[2/4] Loading tokenizer...")
    from core.tokenizer import BPETokenizer
    tokenizer = BPETokenizer(loader.reader)

    # Create sampler
    print("[3/4] Configuring sampler...")
    from inference.sampler import Sampler
    sampler = Sampler(temperature = temperature, top_k = top_k, top_p = top_p)

    # Build generator
    print("[4/4] Building generator...")
    from inference.generator import TextGenerator
    generator = TextGenerator(loader, tokenizer, sampler)
    try:
        generator.build()
    except:
        print("Warning: Could not build full generator. Attempting simplified mode.")
        sys.exit(1)

    # Generate
    print("")
    print("Generating...")
    print("-" * 50)
    start_time = time.time()

    output = generator.generate(prompt, max_tokens = max_tokens, greedy = greedy)

    elapsed = time.time() - start_time
    print("-" * 50)
    print("")
    print("Output:")
    print(output)
    print("")
    print("Generation time: {:.2f}s".format(elapsed))


main()
