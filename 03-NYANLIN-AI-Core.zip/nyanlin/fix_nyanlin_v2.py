#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
fix_nyanlin_v2.py - Complete bug fix for NYANLIN v1 AI Engine
Run from the nyanlin directory:
    cd ~/storage/downloads/MMC-Everything/nyanlin
    python3 fix_nyanlin_v2.py
"""

import os
import sys
import struct

BASE = os.path.dirname(os.path.abspath(__file__))
print("=" * 50)
print("  NYANLIN v1 - Complete Bug Fix")
print("=" * 50)
print("Base dir:", BASE)
print("")

fixed_count = 0
total_files = 8

# ============================================================
# FIX 1: gguf_parser.py
# - Remove undefined GGUF_TENSOR_F64 reference
# - Add auto-parse in __init__
# - Add Q5_K_M dequantization support
# ============================================================
print("[1/8] Fixing core/gguf_parser.py...")
fpath = os.path.join(BASE, "core", "gguf_parser.py")
with open(fpath, 'r', encoding='utf-8') as f:
    content = f.read()

# Remove the broken line that references undefined GGUF_TENSOR_F64
content = content.replace("TENSOR_TYPE_SIZES[GGUF_TENSOR_F64] = 8\n", "")

# Add auto-parse to __init__
old_init = """    def __init__(self, filepath):
        self.filepath = filepath
        self.data = None
        self.magic = 0
        self.version = 0
        self.tensor_count = 0
        self.metadata_kv_count = 0
        self.metadata = {}
        self.tensor_infos = []
        self.alignment = 32
        self.data_offset = 0
        self._parsed = False"""

new_init = """    def __init__(self, filepath):
        self.filepath = filepath
        self.data = None
        self.magic = 0
        self.version = 0
        self.tensor_count = 0
        self.metadata_kv_count = 0
        self.metadata = {}
        self.tensor_infos = []
        self.alignment = 32
        self.data_offset = 0
        self._parsed = False
        # Auto-parse on creation
        self.parse()"""

content = content.replace(old_init, new_init)

# Add Q5_K_M dequantization method before the closing of the class
dequant_method = '''

    def _dequantize_q5_K_M(self, raw_bytes, n_elements):
        """Dequantize Q5_K_M blocks to float32 flat list."""
        import struct
        BLOCK_SIZE = 256
        BLOCK_BYTES = 148
        n_blocks = n_elements // BLOCK_SIZE
        if n_blocks * BLOCK_SIZE != n_elements:
            n_blocks = n_elements // BLOCK_SIZE + 1
        result = []
        for b in range(n_blocks):
            off = b * BLOCK_BYTES
            if off + BLOCK_BYTES > len(raw_bytes):
                break
            # Block header
            d = struct.unpack('<e', raw_bytes[off:off+2])[0]
            dmin = struct.unpack('<e', raw_bytes[off+2:off+4])[0]
            scales = raw_bytes[off+4:off+16]
            qh = raw_bytes[off+16:off+20]
            qs = raw_bytes[off+20:off+148]

            def get_scale_min(j, sc):
                if j < 4:
                    return sc[j] & 63, sc[j + 4] & 63
                else:
                    d_ = (sc[j + 4] & 0xF) | ((sc[j - 4] >> 6) << 4)
                    m_ = (sc[j + 4] >> 4) | ((sc[j - 0] >> 6) << 4)
                    return d_, m_

            q_pos = 0
            is_ = 0
            for j in range(4):  # 4 sub-blocks of 64
                sc1, mn1 = get_scale_min(is_, scales)
                sc2, mn2 = get_scale_min(is_ + 1, scales)
                d1 = d * sc1
                m1 = dmin * mn1
                d2 = d * sc2
                m2 = dmin * mn2
                # First 16 values (lower nibble)
                for l in range(16):
                    v = (qs[q_pos + l] & 0xF) - 16
                    result.append(d1 * v - m1)
                # Next 16 values (upper nibble)
                for l in range(16):
                    v = (qs[q_pos + l] >> 4) - 16
                    result.append(d2 * v - m2)
                q_pos += 16
                # Next 16 values with qh
                for l in range(16):
                    ql = (qs[q_pos + l] & 0xF)
                    qh_bit = (qh[l >> 3] >> (l & 7)) & 1
                    v = (ql | (qh_bit << 4)) - 16
                    result.append(d1 * v - m1)
                # Next 16 values with qh
                for l in range(16):
                    ql = (qs[q_pos + l] >> 4)
                    qh_bit = (qh[(l + 16) >> 3] >> ((l + 16) & 7)) & 1
                    v = (ql | (qh_bit << 4)) - 16
                    result.append(d2 * v - m2)
                q_pos += 16
                is_ += 2
        return result[:n_elements]

    def _dequantize_q4_0(self, raw_bytes, n_elements):
        """Dequantize Q4_0 blocks to float32 flat list."""
        BLOCK_SIZE = 32
        BLOCK_BYTES = 18
        n_blocks = (n_elements + BLOCK_SIZE - 1) // BLOCK_SIZE
        result = []
        for b in range(n_blocks):
            off = b * BLOCK_BYTES
            if off + BLOCK_BYTES > len(raw_bytes):
                break
            d = struct.unpack('<e', raw_bytes[off:off+2])[0]
            qs = raw_bytes[off+2:off+18]
            for l in range(BLOCK_SIZE):
                if l % 2 == 0:
                    qb = (qs[l // 2] & 0xF) - 8
                else:
                    qb = (qs[l // 2] >> 4) - 8
                result.append(d * qb)
        return result[:n_elements]

    def _dequantize_q8_0(self, raw_bytes, n_elements):
        """Dequantize Q8_0 blocks to float32 flat list."""
        BLOCK_SIZE = 32
        BLOCK_BYTES = 34
        n_blocks = (n_elements + BLOCK_SIZE - 1) // BLOCK_SIZE
        result = []
        for b in range(n_blocks):
            off = b * BLOCK_BYTES
            if off + BLOCK_BYTES > len(raw_bytes):
                break
            d = struct.unpack('<e', raw_bytes[off:off+2])[0]
            qs = raw_bytes[off+2:off+34]
            for l in range(BLOCK_SIZE):
                qb = struct.unpack('<b', bytes([qs[l]]))[0]
                result.append(d * qb)
        return result[:n_elements]

    def read_tensor_as_f32(self, name):
        raw_bytes, tensor_type, dims = self.read_tensor_data(name)
        n_elements = 1
        for d in dims:
            n_elements = n_elements * d

        if tensor_type == 0:  # F32
            flat = list(struct.unpack('<{}f'.format(n_elements), raw_bytes[:n_elements * 4]))
            return flat, dims
        elif tensor_type == 1:  # F16
            flat = list(struct.unpack('<{}e'.format(n_elements), raw_bytes[:n_elements * 2]))
            return flat, dims
        elif tensor_type == 30:  # BF16
            flat = []
            for i in range(n_elements):
                f16_bits = struct.unpack('<H', raw_bytes[i*2:i*2+2])[0]
                f32_bits = f16_bits << 16
                val = struct.unpack('<f', struct.pack('<I', f32_bits))[0]
                flat.append(val)
            return flat, dims
        elif tensor_type == 12:  # Q5_K (Q5_K_M)
            print("    Dequantizing Q5_K_M: {} ({} elements)...".format(name, n_elements))
            flat = self._dequantize_q5_K_M(raw_bytes, n_elements)
            return flat, dims
        elif tensor_type == 2:  # Q4_0
            print("    Dequantizing Q4_0: {} ({} elements)...".format(name, n_elements))
            flat = self._dequantize_q4_0(raw_bytes, n_elements)
            return flat, dims
        elif tensor_type == 8:  # Q8_0
            print("    Dequantizing Q8_0: {} ({} elements)...".format(name, n_elements))
            flat = self._dequantize_q8_0(raw_bytes, n_elements)
            return flat, dims
        else:
            raise NotImplementedError(
                "Unsupported tensor type {} for tensor '{}'. "
                "Please use an F16 or F32 GGUF model.".format(tensor_type, name))
'''

# Replace old read_tensor_as_f32 method and everything after it
old_read = """    def read_tensor_as_f32(self, name):
        raw_bytes, tensor_type, dims = self.read_tensor_data(name)"""
content = content.replace(old_read, dequant_method.strip() + "\n\n    def read_tensor_as_f32(self, name):\n        raw_bytes, tensor_type, dims = self.read_tensor_data(name)")

# Remove the old body of read_tensor_as_f32 that starts with "if tensor_type == GGUF_TENSOR_F32:"
# We need to remove everything from the old F32 check to the end of the method
# Let's find and remove the old implementation
old_impl = '''        if tensor_type == GGUF_TENSOR_F32:
            flat = []
            n_elements = 1
            for d in dims:
                n_elements = n_elements * d
            for i in range(n_elements):
                val, _ = BytesHelper.read_float32(None, raw_bytes, i * 4)
                flat = flat +[val]
            return flat, dims
        else:
            if tensor_type == GGUF_TENSOR_F16:
                flat = []
                n_elements = 1
                for d in dims:
                    n_elements = n_elements * d
                for i in range(n_elements):
                    val, _ = BytesHelper.read_float16(None, raw_bytes, i * 2)
                    flat = flat +[val]
                return flat, dims
            else:
                if tensor_type == GGUF_TENSOR_BF16:
                    flat = []
                    n_elements = 1
                    for d in dims:
                        n_elements = n_elements * d
                    for i in range(n_elements):
                        val, _ = BytesHelper.read_bfloat16(None, raw_bytes, i * 2)
                        flat = flat +[val]
                    return flat, dims
                else:
                    raise NotImplementedError("Unsupported tensor type: {}".format(tensor_type))'''

# Check if old impl exists
if old_impl in content:
    # Remove the duplicate new method header we just added and replace with complete version
    # Actually, let me just replace the old impl with a pass
    content = content.replace(old_impl, "        # Dequantization handled above")

with open(fpath, 'w', encoding='utf-8') as f:
    f.write(content)
fixed_count += 1
print("  Fixed: GGUF_TENSOR_F64 removed, auto-parse added, Q5_K_M dequant added")
print("")

# ============================================================
# FIX 2: model_loader.py
# - Fix "Mo" -> "Model"
# - Add self.arch to ModelConfig
# - Handle qwen2 intermediate_size key
# ============================================================
print("[2/8] Fixing core/model_loader.py...")
fpath = os.path.join(BASE, "core", "model_loader.py")
with open(fpath, 'r', encoding='utf-8') as f:
    content = f.read()

# Add arch field to ModelConfig
content = content.replace(
    "        self.vocab_size_exp = 0",
    "        self.vocab_size_exp = 0\n        self.arch = None"
)

# Fix "Mo loaded" -> "Model loaded"
content = content.replace('print("Mo loaded: {}'.format(self.config))',
                          'print("Model loaded: {}".format(self.config))')

# Fix "mo configuration" comment
content = content.replace('Loads mo configuration',
                          'Loads model configuration')

# Fix "weights" -> "weights" line
content = content.replace('complexion weights',
                          'configuration and weights')
content = content.replace('complexion weight',
                          'configuration weight')

# Save architecture
content = content.replace(
    '            print("Architecture: {}".format(arch))',
    '            print("Architecture: {}".format(arch))\n            c.arch = arch'
)

# Handle intermediate_size for Qwen2
content = content.replace(
    '        val = self.reader.get_metadata_value("{}.feed_forward_length".format(arch), None)',
    '        val = self.reader.get_metadata_value("{}.feed_forward_length".format(arch), None)\n        if val is None:\n            val = self.reader.get_metadata_value("{}.intermediate_size".format(arch), None)'
)

with open(fpath, 'w', encoding='utf-8') as f:
    f.write(content)
fixed_count += 1
print("  Fixed: arch field added, 'Mo' -> 'Model', intermediate_size support")
print("")

# ============================================================
# FIX 3: tokenizer.py
# - Fix O(n^2) list concat with [0.0] * N
# - Add vocab_to_id dict for O(1) lookup
# ============================================================
print("[3/8] Fixing core/tokenizer.py...")
fpath = os.path.join(BASE, "core", "tokenizer.py")
with open(fpath, 'r', encoding='utf-8') as f:
    content = f.read()

# Fix O(n^2) list building
content = content.replace(
    """            self.vocab_scores = []
            for _ in range(len(self.vocab)):
                self.vocab_scores = self.vocab_scores +[0.0]""",
    "            self.vocab_scores = [0.0] * len(self.vocab)"
)

# Add vocab_to_id dict after self._loaded = True
content = content.replace(
    '        self._loaded = True\n        print("Tokenizer loaded:',
    '        self._vocab_to_id = {}\n        for _vid in range(len(self.vocab)):\n            self._vocab_to_id[self.vocab[_vid]] = _vid\n        self._loaded = True\n        print("Tokenizer loaded:'
)

# Fix _bpe_to_id to use dict
content = content.replace(
    """    def _bpe_to_id(self, token_str):
        for i in range(len(self.vocab)):
            if self.vocab[i] == token_str:
                return i
        return - 1""",
    """    def _bpe_to_id(self, token_str):
        if token_str in self._vocab_to_id:
            return self._vocab_to_id[token_str]
        return - 1"""
)

with open(fpath, 'w', encoding='utf-8') as f:
    f.write(content)
fixed_count += 1
print("  Fixed: O(n^2) list concat, vocab_to_id dict for O(1) lookup")
print("")

# ============================================================
# FIX 4: attention.py
# - softအမြင့်ဆုံး -> softmax
# - seq_အရှည် -> seq_len
# ============================================================
print("[4/8] Fixing layers/attention.py...")
fpath = os.path.join(BASE, "layers", "attention.py")
with open(fpath, 'r', encoding='utf-8') as f:
    content = f.read()

content = content.replace("softအမြင့်ဆုံး", "softmax")
content = content.replace("seq_အရှည်", "seq_len")

with open(fpath, 'w', encoding='utf-8') as f:
    f.write(content)
fixed_count += 1
print("  Fixed: soft\u1021\u1000\u103b\u1014\u1037\u1039\u101d\u1015\u103a\u1021\u103b\u1015\u103a -> softmax, seq_\u1000\u102d\u1019\u103e\u101c\u103a -> seq_len")
print("")

# ============================================================
# FIX 5: sampler.py
# - argအမြင့်ဆုံး -> argmax
# ============================================================
print("[5/8] Fixing inference/sampler.py...")
fpath = os.path.join(BASE, "inference", "sampler.py")
with open(fpath, 'r', encoding='utf-8') as f:
    content = f.read()

content = content.replace("argအမြင့်ဆုံး", "argmax")

with open(fpath, 'w', encoding='utf-8') as f:
    f.write(content)
fixed_count += 1
print("  Fixed: arg\u1021\u1000\u103b\u1014\u1037\u1039\u101d\u1015\u103a\u1021\u103b\u1015\u103a -> argmax")
print("")

# ============================================================
# FIX 6: tensor.py
# - to_စာရင်း -> to_list
# ============================================================
print("[6/8] Fixing core/tensor.py...")
fpath = os.path.join(BASE, "core", "tensor.py")
with open(fpath, 'r', encoding='utf-8') as f:
    content = f.read()

content = content.replace("to_စာရင်း", "to_list")
content = content.replace("return Tensor(self.to_list())", "return Tensor(self.to_list())")

with open(fpath, 'w', encoding='utf-8') as f:
    f.write(content)
fixed_count += 1
print("  Fixed: to_\u1040\u1044\u1019\u1015\u103c\u103a\u103b\u103a -> to_list")
print("")

# ============================================================
# FIX 7: main.py
# - Fix all "Mo" remnants
# ============================================================
print("[7/8] Fixing main.py...")
fpath = os.path.join(BASE, "main.py")
with open(fpath, 'r', encoding='utf-8') as f:
    content = f.read()

content = content.replace('print("Mo path: {}'.format(model_path))',
                          'print("Model path: {}".format(model_path))')
content = content.replace('print("Error: Failed to load mo from: {}'.format(model_path))',
                          'print("Error: Failed to load model from: {}".format(model_path))')
content = content.replace("  model.gguf  Path to GGUF mo file",
                          "  model.gguf  Path to GGUF model file")

with open(fpath, 'w', encoding='utf-8') as f:
    f.write(content)
fixed_count += 1
print("  Fixed: Mo -> Model in all user-facing strings")
print("")

# ============================================================
# FIX 8: generator.py - COMPLETE REWRITE
# - Architecture-aware tensor name mapping
# - Support for quantized tensors
# ============================================================
print("[8/8] Rewriting inference/generator.py...")
fpath = os.path.join(BASE, "inference", "generator.py")

generator_content = '''# -*- coding: utf-8 -*-
# nyanlin/inference/generator.mmc - Autoregressive text generation
# Fixed: Qwen2 tensor name support, quantized tensor handling

from core.tensor import Tensor
from core.ops.math_ops import rms_norm, precompute_freqs_cis, vec_add


class TextGenerator:
    """Autoregressive text generator for transformer models."""

    def __init__(self, model_loader, tokenizer, sampler):
        self.loader = model_loader
        self.tokenizer = tokenizer
        self.sampler = sampler
        self.config = model_loader.config
        self.layers = []
        self.output_norm_weight = None
        self.output_weight = None
        self.embed_weight = None
        self.freqs_cos = None
        self.freqs_sin = None
        self.kv_cache = None
        self._built = False
        self._name_map = None

    def _build_name_map(self):
        """Build architecture-specific tensor name mapping."""
        arch = getattr(self.config, 'arch', None) or ''
        if arch in ('qwen2', 'qwen', 'qwen2.5', 'qwen2_5'):
            return {
                'embed': 'model.embed_tokens.weight',
                'output_norm': 'model.norm.weight',
                'output': 'model.output.weight',
                'attn_q': 'model.layers.{}.self_attn.q_proj.weight',
                'attn_k': 'model.layers.{}.self_attn.k_proj.weight',
                'attn_v': 'model.layers.{}.self_attn.v_proj.weight',
                'attn_o': 'model.layers.{}.self_attn.o_proj.weight',
                'ffn_gate': 'model.layers.{}.mlp.gate_proj.weight',
                'ffn_up': 'model.layers.{}.mlp.up_proj.weight',
                'ffn_down': 'model.layers.{}.mlp.down_proj.weight',
                'attn_norm': 'model.layers.{}.input_layernorm.weight',
                'ffn_norm': 'model.layers.{}.post_attention_layernorm.weight',
            }
        elif arch in ('llama', 'mistral', 'phi2', 'phi3'):
            return {
                'embed': 'token_embd.weight',
                'output_norm': 'output_norm.weight',
                'output': 'output.weight',
                'attn_q': 'blk.{}.attn_q.weight',
                'attn_k': 'blk.{}.attn_k.weight',
                'attn_v': 'blk.{}.attn_v.weight',
                'attn_o': 'blk.{}.attn_output.weight',
                'ffn_gate': 'blk.{}.ffn_gate.weight',
                'ffn_up': 'blk.{}.ffn_up.weight',
                'ffn_down': 'blk.{}.ffn_down.weight',
                'attn_norm': 'blk.{}.attn_norm.weight',
                'ffn_norm': 'blk.{}.ffn_norm.weight',
            }
        else:
            # Try to auto-detect from tensor names
            all_names = self.loader.get_weight_names()
            if len(all_names) > 0 and all_names[0].startswith('model.'):
                return {
                    'embed': 'model.embed_tokens.weight',
                    'output_norm': 'model.norm.weight',
                    'output': 'model.output.weight',
                    'attn_q': 'model.layers.{}.self_attn.q_proj.weight',
                    'attn_k': 'model.layers.{}.self_attn.k_proj.weight',
                    'attn_v': 'model.layers.{}.self_attn.v_proj.weight',
                    'attn_o': 'model.layers.{}.self_attn.o_proj.weight',
                    'ffn_gate': 'model.layers.{}.mlp.gate_proj.weight',
                    'ffn_up': 'model.layers.{}.mlp.up_proj.weight',
                    'ffn_down': 'model.layers.{}.mlp.down_proj.weight',
                    'attn_norm': 'model.layers.{}.input_layernorm.weight',
                    'ffn_norm': 'model.layers.{}.post_attention_layernorm.weight',
                }
            else:
                return {
                    'embed': 'token_embd.weight',
                    'output_norm': 'output_norm.weight',
                    'output': 'model.output.weight',
                    'attn_q': 'blk.{}.attn_q.weight',
                    'attn_k': 'blk.{}.attn_k.weight',
                    'attn_v': 'blk.{}.attn_v.weight',
                    'attn_o': 'blk.{}.attn_output.weight',
                    'ffn_gate': 'blk.{}.ffn_gate.weight',
                    'ffn_up': 'blk.{}.ffn_up.weight',
                    'ffn_down': 'blk.{}.ffn_down.weight',
                    'attn_norm': 'blk.{}.attn_norm.weight',
                    'ffn_norm': 'blk.{}.ffn_norm.weight',
                }

    def build(self):
        """Build transformer layers and load weights."""
        from layers.attention import KVCache
        from layers.transformer import TransformerBlock

        c = self.config
        self._name_map = self._build_name_map()
        arch = getattr(c, 'arch', 'unknown')
        print("Tensor name map: {} architecture".format(arch))

        self.layers = []
        for i in range(c.n_layers):
            layer = TransformerBlock(
                c.dim, c.n_heads, c.n_kv_heads,
                c.hidden_dim, c.norm_eps, c.head_dim
            )
            self.layers = self.layers + [layer]

        # Load weights for each layer
        self._load_all_weights()

        # Precompute RoPE frequencies
        print("Precomputing RoPE frequencies...")
        self.freqs_cos, self.freqs_sin = precompute_freqs_cis(
            c.head_dim, c.max_seq_len, c.rope_theta
        )
        for i in range(c.n_layers):
            self.layers[i].set_rope(self.freqs_cos, self.freqs_sin)

        # Load output norm and output weight
        print("Loading output head...")
        try:
            flat, dims = self.loader.load_weight(self._name_map['output_norm'])
            self.output_norm_weight = flat
            print("  Output norm: OK")
        except Exception as e:
            print("  Warning: Could not load output norm: {}".format(e))
            self.output_norm_weight = [1.0] * c.dim

        try:
            flat, dims = self.loader.load_weight(self._name_map['output'])
            self.output_weight = flat
            print("  Output weight: OK ({:.1f}M params)".format(len(flat) / 1e6))
        except Exception as e:
            print("  Warning: Could not load output weight: {}".format(e))
            self.output_weight = None

        # Initialize KV cache
        self.kv_cache = KVCache(c.n_layers, c.n_kv_heads, c.head_dim, c.max_seq_len)
        self._built = True
        print("Generator built with {} layers.".format(c.n_layers))

    def _load_all_weights(self):
        """Load weights for all transformer layers."""
        c = self.config
        nm = self._name_map
        print("Loading weights for {} layers...".format(c.n_layers))
        for i in range(c.n_layers):
            suffix = "{}".format(i)
            try:
                wq_flat, _ = self.loader.load_weight(nm['attn_q'].format(suffix))
                wk_flat, _ = self.loader.load_weight(nm['attn_k'].format(suffix))
                wv_flat, _ = self.loader.load_weight(nm['attn_v'].format(suffix))
                wo_flat, _ = self.loader.load_weight(nm['attn_o'].format(suffix))
                attn_norm, _ = self.loader.load_weight(nm['attn_norm'].format(suffix))
                w_gate, _ = self.loader.load_weight(nm['ffn_gate'].format(suffix))
                w_up, _ = self.loader.load_weight(nm['ffn_up'].format(suffix))
                w_down, _ = self.loader.load_weight(nm['ffn_down'].format(suffix))
                ffn_norm, _ = self.loader.load_weight(nm['ffn_norm'].format(suffix))

                self.layers[i].set_weights(
                    attn_norm, ffn_norm,
                    {"wq": wq_flat, "wk": wk_flat, "wv": wv_flat, "wo": wo_flat},
                    {"w_gate": w_gate, "w_up": w_up, "w_down": w_down}
                )
                if (i + 1) % 4 == 0 or i == c.n_layers - 1:
                    print("  Layer {}/{} loaded".format(i + 1, c.n_layers))
            except Exception as e:
                print("  ERROR loading layer {}: {}".format(i, e))
                raise

    def generate(self, prompt, max_tokens=256, temperature=None, greedy=False):
        """Generate text from a prompt."""
        if not self._built:
            raise RuntimeError("Generator not built. Call build() first.")
        self.kv_cache.clear()

        # Encode prompt
        token_ids = self.tokenizer.encode(prompt)
        print("Prompt tokens: {}".format(len(token_ids)))
        generated = []
        for tid in token_ids:
            generated = generated + [tid]

        # Process prompt tokens (prefill)
        print("Prefilling...")
        for t_idx in range(len(token_ids) - 1):
            pos = t_idx
            self._forward_token(token_ids[t_idx], pos)
            if (t_idx + 1) % 5 == 0 or t_idx == len(token_ids) - 2:
                print("  Prefilled {}/{}".format(t_idx + 1, len(token_ids) - 1))

        # Generate new tokens
        print("Generating {} tokens...".format(max_tokens))
        last_token = token_ids[len(token_ids) - 1]
        pos = len(token_ids) - 1
        for gen_idx in range(max_tokens):
            logits = self._forward_token(last_token, pos)
            if greedy:
                next_token = self.sampler.argmax(logits)
            else:
                next_token = self.sampler.sample(logits, generated)

            if next_token == self.tokenizer.eos_token_id:
                print("  EOS token reached at position {}.".format(gen_idx))
                break

            generated = generated + [next_token]
            last_token = next_token
            pos = pos + 1

            if (gen_idx + 1) % 5 == 0:
                print("  Generated {}/{} tokens...".format(gen_idx + 1, max_tokens))

        output_text = self.tokenizer.decode(generated)
        return output_text

    def _forward_token(self, token_id, pos):
        """Forward a single token through all layers."""
        c = self.config
        dim = c.dim
        vocab_size = c.vocab_size

        # Token embedding
        if self.embed_weight is None:
            flat, _ = self.loader.load_weight(self._name_map['embed'])
            self.embed_weight = flat
            print("  Embedding loaded: {:.1f}M params".format(len(flat) / 1e6))

        x = []
        for i in range(dim):
            x = x + [self.embed_weight[token_id * dim + i]]

        # Forward through layers
        for i in range(c.n_layers):
            x = self.layers[i].forward(x, pos, self.kv_cache, i)

        # Final norm
        x = rms_norm(x, self.output_norm_weight, c.norm_eps)

        # Output projection
        if self.output_weight is None:
            return [0.0] * vocab_size

        logits = []
        for v in range(vocab_size):
            s = 0.0
            for d in range(dim):
                s = s + self.output_weight[v * dim + d] * x[d]
            logits = logits + [s]
        return logits
'''

with open(fpath, 'w', encoding='utf-8') as f:
    f.write(generator_content)
fixed_count += 1
print("  Rewritten: Qwen2 tensor names, auto-detect, quantized support")
print("")

# ============================================================
# DONE
# ============================================================
print("=" * 50)
print("  All {} files fixed!".format(fixed_count))
print("=" * 50)
print("")
print("Fixed bugs:")
print("  1. GGUF_TENSOR_F64 undefined -> removed")
print("  2. Auto-parse on GGUFReader creation")
print("  3. Q5_K_M, Q4_0, Q8_0 dequantization added")
print("  4. Model arch detection + intermediate_size support")
print("  5. Tokenizer O(n^2) -> O(n) performance fix")
print("  6. Vocab lookup O(n) -> O(1) with dict")
print("  7. Myanmar function names fixed (softmax, argmax, seq_len)")
print("  8. Qwen2 tensor name mapping added")
print("  9. All 'Mo' -> 'Model' text fixed")
print("  10. to_list() method name fixed")
print("")
print("Run: python3 main.py /storage/emulated/0/Download/tiny.gguf 'Hello'")
