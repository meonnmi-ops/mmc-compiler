# -*- coding: utf-8 -*-
# nyanlin/layers/attention.mmc - MultiHeadAttention with GQA, RoPE, KV cache

from core.tensor import Tensor, vec_dot
from core.ops.math_ops import softmax, apply_rotary_emb


class KVCache:
    """Key-Value cache အတွက် autoregressive attention."""

    def __init__(self, n_layers, n_kv_heads, head_dim, max_seq_len):
        self.n_layers = n_layers
        self.n_kv_heads = n_kv_heads
        self.head_dim = head_dim
        self.max_seq_len = max_seq_len
        # Cache stored as dict: layer_idx -> {"k": list of lists, "v": list of lists}
        # Each list is (n_kv_heads * head_dim) long, one per cached position
        self.cache = {}

    def get(self, layer_idx):
        if layer_idx not in self.cache:
            self.cache[layer_idx] = {"k": [], "v": []}
        return self.cache[layer_idx]

    def append(self, layer_idx, key_vec, val_vec):
        entry = self.get(layer_idx)
        entry["k"] = entry["k"] +[key_vec]
        entry["v"] = entry["v"] +[val_vec]

    def get_k(self, layer_idx, head_idx, head_dim):
        entry = self.get(layer_idx)
        result = []
        for pos in range(len(entry["k"])):
            start = head_idx * head_dim
            row = []
            for i in range(head_dim):
                row = row +[entry["k"][pos][start + i]]
            result = result +[row]
        return result

    def get_v(self, layer_idx, head_idx, head_dim):
        entry = self.get(layer_idx)
        result = []
        for pos in range(len(entry["v"])):
            start = head_idx * head_dim
            row = []
            for i in range(head_dim):
                row = row +[entry["v"][pos][start + i]]
            result = result +[row]
        return result

    def seq_အရှည်(self, layer_idx):
        entry = self.get(layer_idx)
        return len(entry["k"])

    def clear(self):
        self.cache = {}


class MultiHeadAttention:
    """Multi-Head Attention နုတ်ထုတ် Grouped Query Attention (GQA) support.

    Supports:
    - Standard MHA(n_heads == n_kv_heads)
    - GQA(n_kv_heads < n_heads, queries share KV heads)
    - RoPE(Rotary Position Embeddings)
    - KV cache for autoregressive in generation
    """

    def __init__(self, dim, n_heads, n_kv_heads, head_dim):
        self.dim = dim
        self.n_heads = n_heads
        self.n_kv_heads = n_kv_heads
        self.head_dim = head_dim
        self.n_rep = n_heads // n_kv_heads
        # Weight matrices (will be set by model loader)
        self.wq = None
        self.wk = None
        self.wv = None
        self.wo = None
        # Precomputed RoPE frequencies
        self.freqs_cos = None
        self.freqs_sin = None

    def set_weights(self, wq, wk, wv, wo):
        """Set attention weight tensors (flat lists နုတ်ထုတ် their dims)."""
        self.wq_flat = wq
        self.wk_flat = wk
        self.wv_flat = wv
        self.wo_flat = wo

    def set_rope(self, freqs_cos, freqs_sin):
        """Set precomputed RoPE frequencies."""
        self.freqs_cos = freqs_cos
        self.freqs_sin = freqs_sin

    def forward(self, x, pos, kv_cache, layer_idx):
        """Forward ကျန်ရမ်း အတွက် multi-head attention.

        Args:
            x: Input vector of length dim.
            pos: Current position in sequence.
            kv_cache: KVCache instance.
            layer_idx: Current layer index.

        Returns:
            Output vector of length dim.
        """
        n_heads = self.n_heads
        n_kv_heads = self.n_kv_heads
        head_dim = self.head_dim
        dim = self.dim

        # Compute Q, K, V by multiplying x with weight matrices
        q = self._mat_vec(self.wq_flat, x, dim, dim)
        k = self._mat_vec(self.wk_flat, x, dim, n_kv_heads * head_dim)
        v = self._mat_vec(self.wv_flat, x, dim, n_kv_heads * head_dim)

        # Apply RoPE to Q and K
        q = self._apply_rope_to_all_heads(q, n_heads, head_dim, pos)
        k = self._apply_rope_to_all_heads(k, n_kv_heads, head_dim, pos)

        # Append K, V to cache
        kv_cache.append(layer_idx, k, v)

        # Compute attention for each head
        kv_len = kv_cache.seq_အရှည်(layer_idx)
        output = []
        for i in range(dim):
            output = output +[0.0]

        for h in range(n_heads):
            kv_h = h // self.n_rep
            # Get cached K and V for this KV head
            k_head = self._get_cached_head(kv_cache, layer_idx, kv_h, head_dim)
            v_head = self._get_cached_head_v(kv_cache, layer_idx, kv_h, head_dim)
            # Get Q for this head
            q_head = self._get_head_slice(q, h, head_dim)
            # Compute attention scores
            scores = []
            for s in range(kv_len):
                score = vec_dot(q_head, k_head[s])
                scores = scores +[score]
            # Scale by 1/sqrt(head_dim)
            scale = 1.0 /(head_dim ** 0.5)
            scaled_scores = []
            for s in range(len(scores)):
                scaled_scores = scaled_scores +[scores[s] * scale]
            # Softmax
            probs = softmax(scaled_scores)
            # Weighted sum of V
            attn_out = []
            for d in range(head_dim):
                val = 0.0
                for s in range(kv_len):
                    val = val + probs[s] * v_head[s][d]
                attn_out = attn_out +[val]
            # Store in output
            for d in range(head_dim):
                output[h * head_dim + d] = attn_out[d]

        # Output projection
        final = self._mat_vec(self.wo_flat, output, dim, dim)
        return final

    def _mat_vec(self, w_flat, x, in_dim, out_dim):
        """Multiply a flat weight matrix (out_dim x in_dim) နုတ်ထုတ် vector x."""
        result = []
        for i in range(out_dim):
            s = 0.0
            for j in range(in_dim):
                s = s + w_flat[i * in_dim + j] * x[j]
            result = result +[s]
        return result

    def _get_head_slice(self, vec, head_idx, head_dim):
        """Extract a single head's values မှ a concatenated vector."""
        start = head_idx * head_dim
        result = []
        for i in range(head_dim):
            result = result +[vec[start + i]]
        return result

    def _apply_rope_to_all_heads(self, vec, n_heads, head_dim, pos):
        """Apply RoPE to each head in a concatenated vector."""
        result = []
        for h in range(n_heads):
            head = self._get_head_slice(vec, h, head_dim)
            if self.freqs_cos != None and self.freqs_sin != None:
                head = apply_rotary_emb(head, self.freqs_cos, self.freqs_sin, pos)
            for v in head:
                result = result +[v]
        return result

    def _get_cached_head(self, kv_cache, layer_idx, kv_h, head_dim):
        """Get all cached K vectors အတွက် a given KV head."""
        entry = kv_cache.get(layer_idx)
        result = []
        for p in range(len(entry["k"])):
            start = kv_h * head_dim
            row = []
            for d in range(head_dim):
                row = row +[entry["k"][p][start + d]]
            result = result +[row]
        return result

    def _get_cached_head_v(self, kv_cache, layer_idx, kv_h, head_dim):
        """Get all cached V vectors အတွက် a given KV head."""
        entry = kv_cache.get(layer_idx)
        result = []
        for p in range(len(entry["v"])):
            start = kv_h * head_dim
            row = []
            for d in range(head_dim):
                row = row +[entry["v"][p][start + d]]
            result = result +[row]
        return result
