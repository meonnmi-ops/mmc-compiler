# -*- coding: utf-8 -*-
# nyanlin/layers/transformer.mmc - TransformerBlock (pre-norm LLaMA style)

from core.ops.math_ops import rms_norm, vec_add
from layers.attention import MultiHeadAttention
from layers.feedforward import FeedForward


class TransformerBlock:
    """Single transformer block နုတ်ထုတ် pre-norm architecture (LLaMA-style).

    Architecture:
        x = x + Attention(RMSNorm(x))
        x = x + FFN(RMSNorm(x))
    """

    def __init__(self, dim, n_heads, n_kv_heads, hidden_dim, norm_eps, head_dim):
        self.dim = dim
        self.attention = MultiHeadAttention(dim, n_heads, n_kv_heads, head_dim)
        self.ffn = FeedForward(dim, hidden_dim)
        self.norm_eps = norm_eps
        # Normalization weights (flat lists, set by model loader)
        self.attn_norm_weight = None
        self.ffn_norm_weight = None

    def set_weights(self, attn_norm, ffn_norm, attn_weights, ffn_weights):
        """Set all weights အတွက် this transformer block.

        Args:
            attn_norm: RMSNorm weight for attention in (length dim).
            ffn_norm: RMSNorm weight for FFN in (length dim).
            attn_weights: dict with keys wq, wk, wv, wo(flat lists).
            ffn_weights: dict with keys w_gate, w_up, w_down(flat lists).
        """
        self.attn_norm_weight = attn_norm
        self.ffn_norm_weight = ffn_norm
        self.attention.set_weights(
            attn_weights["wq"], attn_weights["wk"],
            attn_weights["wv"], attn_weights["wo"]
        )
        self.ffn.set_weights(
            ffn_weights["w_gate"], ffn_weights["w_up"],
            ffn_weights["w_down"]
        )

    def set_rope(self, freqs_cos, freqs_sin):
        """Set precomputed RoPE frequencies."""
        self.attention.set_rope(freqs_cos, freqs_sin)

    def forward(self, x, pos, kv_cache, layer_idx):
        """Forward ကျန်ရမ်း through the transformer block.

        Args:
            x: Input vector of length dim.
            pos: Current position in sequence.
            kv_cache: KVCache instance.
            layer_idx: Layer index for KV in cache.

        Returns:
            Output vector of length dim.
        """
        # Pre-norm attention
        normed = rms_norm(x, self.attn_norm_weight, self.norm_eps)
        attn_out = self.attention.forward(normed, pos, kv_cache, layer_idx)
        x = vec_add(x, attn_out)

        # Pre-norm FFN
        normed2 = rms_norm(x, self.ffn_norm_weight, self.norm_eps)
        ffn_out = self.ffn.forward(normed2)
        x = vec_add(x, ffn_out)

        return x
