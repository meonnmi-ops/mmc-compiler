# -*- coding: utf-8 -*-
# nyanlin/layers/feedforward.mmc - SwiGLU FeedForward network

from core.ops.math_ops import silu, vec_dot


class FeedForward:
    """SwiGLU Feed-Forward network.

    Architecture:
        output = W_out @(SiLU(W_gate @x) *(W_up @x))

    This is the FFN variant used in LLaMA and many modern LLMs.
    """

    def __init__(self, dim, hidden_dim):
        self.dim = dim
        self.hidden_dim = hidden_dim
        # Weight matrices (flat lists, set by model loader)
        self.w_gate_flat = None
        self.w_up_flat = None
        self.w_down_flat = None

    def set_weights(self, w_gate, w_up, w_down):
        """Set FFN weight tensors (flat lists)."""
        self.w_gate_flat = w_gate
        self.w_up_flat = w_up
        self.w_down_flat = w_down

    def forward(self, x):
        """Forward ကျန်ရမ်း through the SwiGLU FFN.

        Args:
            x: Input vector of length dim.

        Returns:
            Output vector of length dim.
        """
        dim = self.dim
        hidden_dim = self.hidden_dim

        # W_gate @ x -> hidden_dim
        gate = self._mat_vec(self.w_gate_flat, x, dim, hidden_dim)
        # W_up @ x -> hidden_dim
        up = self._mat_vec(self.w_up_flat, x, dim, hidden_dim)
        # SiLU(gate) * up
        gate_act = silu(gate)
        hidden = []
        for i in range(hidden_dim):
            hidden = hidden +[gate_act[i] * up[i]]
        # W_down @ hidden -> dim
        output = self._mat_vec(self.w_down_flat, hidden, hidden_dim, dim)
        return output

    def _mat_vec(self, w_flat, x, in_dim, out_dim):
        """Multiply a flat weight matrix နုတ်ထုတ် a vector."""
        result = []
        for i in range(out_dim):
            s = 0.0
            for j in range(in_dim):
                s = s + w_flat[i * in_dim + j] * x[j]
            result = result +[s]
        return result
