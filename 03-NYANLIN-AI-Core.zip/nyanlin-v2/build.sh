#!/bin/bash
# build.sh - NYANLIN v2.0 Build Script
# Usage: bash build.sh
#
# ဤ script သည် NYANLIN v2.0 ကို MMC transpiler ဖြင့်
# ARM64 binary အဖြစ် compile လုပ်ပြီး ဖိုင်ထုတ်ယူခြင်း ဖြစ်သည်။

set -e

echo "========================================="
echo "  NYANLIN v2.0 Build Script"
echo "========================================="
echo ""

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
BUILD_DIR="${SCRIPT_DIR}/build"
OUTPUT="nyanlin"

# Step 1: Check MMC transpiler
echo "[1/4] Checking MMC transpiler..."
if command -v mmc &> /dev/null; then
    echo "  MMC transpiler found: $(mmc --version 2>/dev/null || echo 'installed')"
else
    echo "  MMC transpiler not found."
    echo "  Using Python fallback (transpile to .py)..."
    MMC_CMD="python3"
else
    MMC_CMD="mmc"
fi

# Step 2: Create build directory
echo "[2/4] Creating build directory..."
mkdir -p "${BUILD_DIR}"

# Step 3: Copy source files
echo "[3/4] Copying source files..."
cp -r "${SCRIPT_DIR}/core" "${BUILD_DIR}/"
cp -r "${SCRIPT_DIR}/layers" "${BUILD_DIR}/"
cp -r "${SCRIPT_DIR}/inference" "${BUILD_DIR}/"
cp "${SCRIPT_DIR}/main.mmc" "${BUILD_DIR}/"
cp "${SCRIPT_DIR}/web/mmc_ai_server.py" "${BUILD_DIR}/"
echo "  Files copied successfully."

# Step 4: Compile
echo "[4/4] Compiling..."
if [ "$MMC_CMD" = "mmc" ]; then
    echo "  Compiling main.mmc with MMC transpiler..."
    $MMC_CMD -o "${BUILD_DIR}/${OUTPUT}" "${BUILD_DIR}/main.mmc" 2>&1 || {
        echo "  MMC compile failed. Creating Python fallback..."
        cp "${BUILD_DIR}/main.mmc" "${BUILD_DIR}/main.py"
        echo "  Created main.py (Python fallback)"
    }
else
    echo "  No MMC transpiler. Creating Python wrapper..."
    # Create a simple runner script
    cat > "${BUILD_DIR}/run_nyanlin.sh" << 'RUNEOF'
#!/bin/bash
# NYANLIN v2.0 Runner
# Transpiles MMC to Python and runs
python3 main.py "$@"
RUNEOF
    chmod +x "${BUILD_DIR}/run_nyanlin.sh"
    echo "  Created run_nyanlin.sh"
fi

echo ""
echo "========================================="
echo "  Build Complete!"
echo "========================================="
echo ""
echo "Output directory: ${BUILD_DIR}"
echo ""
echo "Usage:"
echo "  cd ${BUILD_DIR}"
echo "  python3 main.mmc <model.gguf> \"prompt\""
echo ""
echo "Web IDE:"
echo "  python3 mmc_ai_server.py <model.gguf> --port 8080"
echo "  Open http://localhost:8080"
echo ""

# Count files
FILE_COUNT=$(find "${BUILD_DIR}" -name "*.mmc" -o -name "*.py" -o -name "*.sh" | wc -l)
echo "Total source files: ${FILE_COUNT}"
