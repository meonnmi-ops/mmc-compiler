#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# mmc_ai_server.py - NYANLIN v2.0 Web IDE + API Server
# Usage: python mmc_ai_server.py [--port 8080] [--host 0.0.0.0]
#
# Features:
#   - Web IDE နဲ့ NYANLIN model ကို browser မှာ သုံးနိုင်သည်
#   - REST API endpoint အဖြစ် NYANLIN binary ကို ခေါ်ဆိုခြင်း
#   - Model info, generate, tokenize API များ ပါဝင်သည်

import http.server
import json
import sys
import os
import socket
import struct
import math
import time
import threading
import urllib.parse
from pathlib import Path

# ============================================================
# Server Configuration
# ============================================================
DEFAULT_PORT = 8080
DEFAULT_HOST = "0.0.0.0"
SERVER_VERSION = "NYANLIN v2.0 Web Server"

# ============================================================
# Core AI Engine (Embedded Python implementation)
# This provides the API functionality without requiring
# the MMC transpiler - it directly implements the same logic
# ============================================================

class GGUFReader:
    """Minimal GGUF reader for Web API."""

    def __init__(self, filepath):
        self.filepath = filepath
        self.data = None
        self.magic = 0
        self.version = 0
        self.tensor_count = 0
        self.metadata = {}
        self.tensor_infos = []
        self._parsed = False
        self.data_offset = 0
        self.alignment = 32

    def parse(self):
        with open(self.filepath, 'rb') as f:
            self.data = f.read()
        self._parse_header()
        self._parse_metadata()
        self._parse_tensor_infos()
        self._compute_data_offset()
        self._parsed = True

    def _read_string(self, offset):
        length = struct.unpack('<Q', self.data[offset:offset+8])[0]
        offset += 8
        s = self.data[offset:offset+length].decode('utf-8', errors='replace')
        return s, offset + length

    def _parse_header(self):
        offset = 0
        self.magic = struct.unpack('<I', self.data[offset:offset+4])[0]
        offset += 4
        if self.magic != 0x46475547:
            raise ValueError(f"Invalid GGUF magic: 0x{self.magic:08X}")
        self.version = struct.unpack('<I', self.data[offset:offset+4])[0]
        offset += 4
        self.tensor_count = struct.unpack('<Q', self.data[offset:offset+8])[0]
        offset += 8
        metadata_kv_count = struct.unpack('<Q', self.data[offset:offset+8])[0]
        offset += 8
        self._header_end = offset
        self._metadata_kv_count = metadata_kv_count

    def _parse_metadata(self):
        offset = self._header_end
        for _ in range(self._metadata_kv_count):
            key, offset = self._read_string(offset)
            vtype = struct.unpack('<I', self.data[offset:offset+4])[0]
            offset += 4
            if vtype == 8:  # STRING
                val, offset = self._read_string(offset)
            elif vtype == 9:  # ARRAY
                etype = struct.unpack('<I', self.data[offset:offset+4])[0]
                offset += 4
                alen = struct.unpack('<Q', self.data[offset:offset+8])[0]
                offset += 8
                arr = []
                for _ in range(alen):
                    if etype == 8:
                        val, offset = self._read_string(offset)
                    elif etype == 4:
                        val = struct.unpack('<I', self.data[offset:offset+4])[0]
                        offset += 4
                    elif etype == 5:
                        val = struct.unpack('<i', self.data[offset:offset+4])[0]
                        offset += 4
                    elif etype == 6:
                        val = struct.unpack('<f', self.data[offset:offset+4])[0]
                        offset += 4
                    elif etype == 7:
                        val = self.data[offset] == 1
                        offset += 1
                    else:
                        val = 0
                        offset += 4
                    arr.append(val)
                val = arr
            elif vtype == 4:
                val = struct.unpack('<I', self.data[offset:offset+4])[0]
                offset += 4
            elif vtype == 5:
                val = struct.unpack('<i', self.data[offset:offset+4])[0]
                offset += 4
            elif vtype == 6:
                val = struct.unpack('<f', self.data[offset:offset+4])[0]
                offset += 4
            elif vtype == 7:
                val = self.data[offset] == 1
                offset += 1
            else:
                val = 0
                offset += 4
            self.metadata[key] = val
        self._metadata_end = offset

    def _parse_tensor_infos(self):
        offset = self._metadata_end
        for _ in range(self.tensor_count):
            name, offset = self._read_string(offset)
            n_dims = struct.unpack('<I', self.data[offset:offset+4])[0]
            offset += 4
            dims = []
            for _ in range(n_dims):
                d = struct.unpack('<Q', self.data[offset:offset+8])[0]
                offset += 8
                dims.append(d)
            ttype = struct.unpack('<I', self.data[offset:offset+4])[0]
            offset += 4
            toffset = struct.unpack('<Q', self.data[offset:offset+8])[0]
            offset += 8
            self.tensor_infos.append({
                "name": name, "n_dims": n_dims,
                "dims": dims, "type": ttype, "offset": toffset
            })
        self._tensor_infos_end = offset

    def _compute_data_offset(self):
        raw = self._tensor_infos_end
        if raw % self.alignment != 0:
            raw += self.alignment - (raw % self.alignment)
        self.data_offset = raw

    def get_model_info(self):
        """Get model info as dict."""
        tensor_types = {
            0: "F32", 1: "F16", 2: "Q4_0", 3: "Q4_1",
            6: "Q5_0", 7: "Q5_1", 8: "Q8_0", 10: "Q2_K",
            11: "Q3_K", 12: "Q4_K", 13: "Q5_K", 14: "Q6_K",
            15: "Q8_K", 30: "BF16"
        }
        info = {
            "version": self.version,
            "tensor_count": self.tensor_count,
            "metadata_keys": list(self.metadata.keys()),
            "file_size": len(self.data),
            "file_path": self.filepath
        }
        # Architecture
        arch = self.metadata.get("general.architecture", "unknown")
        info["architecture"] = arch
        info["context_length"] = self.metadata.get(f"{arch}.context_length", 0)
        info["embedding_length"] = self.metadata.get(f"{arch}.embedding_length", 0)
        info["block_count"] = self.metadata.get(f"{arch}.block_count", 0)
        info["head_count"] = self.metadata.get(f"{arch}.attention.head_count", 0)
        info["head_count_kv"] = self.metadata.get(f"{arch}.attention.head_count_kv", 0)
        info["vocab_size"] = self.metadata.get(f"{arch}.tokenizer.ggml.vocab_size", 0)

        # Tensor type summary
        type_counts = {}
        for ti in self.tensor_infos:
            tname = tensor_types.get(ti["type"], f"UNKNOWN({ti['type']})")
            type_counts[tname] = type_counts.get(tname, 0) + 1
        info["tensor_types"] = type_counts

        return info

    def get_tensor_names(self):
        return [ti["name"] for ti in self.tensor_infos]


class TextSimulator:
    """Simulates text generation for demo (without actual model weights)."""

    def __init__(self):
        self.loaded = False
        self.model_info = {}

    def load_model(self, reader):
        self.loaded = True
        self.model_info = reader.get_model_info()
        self.reader = reader

    def generate_demo(self, prompt, max_tokens=50):
        """Demo generation - returns mock output since we may not have actual weights."""
        return f"[NYANLIN v2.0 Demo] Prompt: '{prompt}' -> Model architecture: {self.model_info.get('architecture', 'N/A')}, Layers: {self.model_info.get('block_count', 'N/A')}, Vocab: {self.model_info.get('vocab_size', 'N/A')}"


# ============================================================
# Global State
# ============================================================
current_reader = None
simulator = TextSimulator()


# ============================================================
# HTML Web IDE Page
# ============================================================
HTML_PAGE = """<!DOCTYPE html>
<html lang="my">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>NYANLIN v2.0 Web IDE</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: 'Noto Sans Myanmar', -apple-system, BlinkMacSystemFont, sans-serif; background: #0f172a; color: #e2e8f0; min-height: 100vh; }

  .header { background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%); border-bottom: 1px solid rgba(212,175,55,0.2); padding: 16px 24px; display: flex; align-items: center; justify-content: space-between; }
  .header h1 { font-size: 20px; color: #f0e6d0; letter-spacing: 2px; }
  .header h1 span { color: rgba(212,175,55,0.7); font-size: 12px; margin-left: 10px; }
  .header .status { font-size: 11px; color: #64748b; }
  .header .status .dot { display: inline-block; width: 6px; height: 6px; border-radius: 50%; background: #22c55e; margin-right: 4px; }
  .header .status .dot.off { background: #ef4444; }

  .container { display: grid; grid-template-columns: 300px 1fr; min-height: calc(100vh - 56px); }

  .sidebar { background: #1e293b; border-right: 1px solid rgba(255,255,255,0.05); padding: 16px; overflow-y: auto; }
  .sidebar h2 { font-size: 11px; letter-spacing: 3px; color: rgba(212,175,55,0.6); text-transform: uppercase; margin-bottom: 12px; }
  .sidebar .btn { display: block; width: 100%; padding: 10px 14px; margin-bottom: 6px; background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); color: #cbd5e1; border-radius: 6px; cursor: pointer; font-size: 13px; text-align: left; transition: all 0.2s; }
  .sidebar .btn:hover { background: rgba(212,175,55,0.1); border-color: rgba(212,175,55,0.3); color: #f0e6d0; }
  .sidebar .btn.active { background: rgba(212,175,55,0.15); border-color: rgba(212,175,55,0.4); color: #f5e6b8; }
  .sidebar .model-info { margin-top: 20px; padding: 12px; background: rgba(0,0,0,0.2); border-radius: 6px; font-size: 11px; color: #94a3b8; line-height: 1.8; }
  .sidebar .model-info .label { color: rgba(212,175,55,0.5); font-size: 10px; letter-spacing: 1px; }
  .sidebar .model-info .value { color: #e2e8f0; font-size: 13px; font-weight: 600; }

  .main { padding: 24px; overflow-y: auto; }

  .panel { display: none; }
  .panel.active { display: block; }

  .panel h2 { font-size: 16px; color: #f0e6d0; margin-bottom: 16px; letter-spacing: 1px; }

  textarea { width: 100%; min-height: 100px; background: #0f172a; border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; padding: 14px; color: #e2e8f0; font-size: 14px; font-family: inherit; resize: vertical; outline: none; }
  textarea:focus { border-color: rgba(212,175,55,0.4); }

  .generate-btn { padding: 10px 28px; background: linear-gradient(135deg, rgba(212,175,55,0.2), rgba(212,175,55,0.1)); border: 1px solid rgba(212,175,55,0.4); color: #f5e6b8; border-radius: 6px; cursor: pointer; font-size: 14px; font-weight: 600; letter-spacing: 1px; transition: all 0.2s; margin-top: 12px; }
  .generate-btn:hover { background: linear-gradient(135deg, rgba(212,175,55,0.3), rgba(212,175,55,0.15)); }

  .output { margin-top: 20px; padding: 16px; background: rgba(0,0,0,0.3); border: 1px solid rgba(255,255,255,0.05); border-radius: 8px; min-height: 80px; font-size: 14px; line-height: 1.8; color: #94a3b8; white-space: pre-wrap; }

  .params { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-top: 16px; }
  .param-group label { display: block; font-size: 11px; color: rgba(212,175,55,0.5); letter-spacing: 1px; margin-bottom: 4px; }
  .param-group input { width: 100%; padding: 8px 10px; background: #0f172a; border: 1px solid rgba(255,255,255,0.1); border-radius: 4px; color: #e2e8f0; font-size: 13px; outline: none; }
  .param-group input:focus { border-color: rgba(212,175,55,0.4); }

  .api-section { margin-top: 20px; padding: 16px; background: rgba(0,0,0,0.2); border-radius: 8px; }
  .api-section h3 { font-size: 13px; color: rgba(212,175,55,0.6); margin-bottom: 10px; letter-spacing: 1px; }
  .api-section code { display: block; padding: 10px 12px; background: rgba(0,0,0,0.3); border-radius: 4px; font-family: monospace; font-size: 12px; color: #94a3b8; margin-bottom: 6px; word-break: break-all; white-space: pre-wrap; }

  .tensor-list { list-style: none; }
  .tensor-list li { padding: 6px 10px; border-bottom: 1px solid rgba(255,255,255,0.03); font-size: 12px; color: #94a3b8; display: flex; justify-content: space-between; }
  .tensor-list li .type { color: rgba(212,175,55,0.5); font-size: 11px; }
  .loading { text-align: center; padding: 20px; color: #64748b; }
</style>
</head>
<body>

<div class="header">
  <h1>NYANLIN <span>v2.0 Web IDE</span></h1>
  <div class="status"><span class="dot" id="statusDot"></span><span id="statusText">Disconnected</span></div>
</div>

<div class="container">
  <div class="sidebar">
    <h2>Navigate</h2>
    <button class="btn active" onclick="showPanel('generate')">Generate</button>
    <button class="btn" onclick="showPanel('tensors')">Tensors</button>
    <button class="btn" onclick="showPanel('api')">API Docs</button>
    <button class="btn" onclick="showPanel('about')">About</button>

    <div class="model-info" id="modelInfo">
      <div class="label">MODEL STATUS</div>
      <div class="value" id="modelStatus">No model loaded</div>
    </div>
  </div>

  <div class="main">
    <div class="panel active" id="panel-generate">
      <h2>Text Generation</h2>
      <textarea id="promptInput" placeholder="Enter your prompt here...&#10;&#10;e.g. &#x1005;&#x1014;&#x1033;&#x1038;&#x1019;&#x101E;&#x1014;&#x1037;&#x103A;&#x1015;&#x1031;&#x101C;&#x1004;&#x1037;&#x103A;"></textarea>
      <div class="params">
        <div class="param-group">
          <label>Max Tokens</label>
          <input type="number" id="maxTokens" value="128">
        </div>
        <div class="param-group">
          <label>Temperature</label>
          <input type="number" id="temperature" value="0.8" step="0.1">
        </div>
        <div class="param-group">
          <label>Top-K</label>
          <input type="number" id="topK" value="40">
        </div>
        <div class="param-group">
          <label>Top-P</label>
          <input type="number" id="topP" value="0.95" step="0.05">
        </div>
      </div>
      <button class="generate-btn" onclick="generate()">Generate</button>
      <div class="output" id="outputArea">Output will appear here...</div>
    </div>

    <div class="panel" id="panel-tensors">
      <h2>Tensor List</h2>
      <div id="tensorListContent"><p style="color:#64748b;">Load a model first</p></div>
    </div>

    <div class="panel" id="panel-api">
      <h2>API Documentation</h2>
      <div class="api-section">
        <h3>GET /api/info</h3>
        <code>curl http://localhost:8080/api/info</code>
        <p style="font-size:12px;color:#64748b;margin-top:4px;">Returns model info (architecture, layers, vocab size, tensor types)</p>
      </div>
      <div class="api-section">
        <h3>GET /api/tensors</h3>
        <code>curl http://localhost:8080/api/tensors</code>
        <p style="font-size:12px;color:#64748b;margin-top:4px;">Returns list of all tensor names and types</p>
      </div>
      <div class="api-section">
        <h3>POST /api/generate</h3>
        <code>curl -X POST http://localhost:8080/api/generate -H "Content-Type: application/json" -d '{"prompt":"Hello","max_tokens":50}'</code>
        <p style="font-size:12px;color:#64748b;margin-top:4px;">Generate text from a prompt</p>
      </div>
    </div>

    <div class="panel" id="panel-about">
      <h2>About NYANLIN v2.0</h2>
      <div style="color:#94a3b8;line-height:2;font-size:14px;">
        <p><strong style="color:#f0e6d0;">NYANLIN v2.0</strong> - Pure MMC AI Inference Engine</p>
        <p>&#x1000;&#x101C;&#x103D;&#x1019;&#x1014;&#x103C;&#x1014;&#x103A;&#x1019;&#x103D;&#x103C;&#x1014;&#x103A; &#x101C;&#x102D;&#x102F;&#x1015;&#x102D;&#x1010;&#x103A;&#x1038;&#x1019;&#x102C;&#x101C;&#x103A;&#x101D;&#x1004;&#x1039;&#x1037;&#x101C;&#x1019;&#x103E;&#x101C;&#x1030;&#x101C;&#x1038;&#x1019;&#x103E;&#x101C;&#x1038; AI Engine</p>
        <br>
        <p>v2.0 Features:</p>
        <ul style="padding-left:20px;margin-top:8px;">
          <li>Performance: List comprehension optimizations</li>
          <li>Quantization: Q4_K_M, Q8_0 dequantization</li>
          <li>Sampling: &#x1000;&#x103C;&#x1019;&#x102C;&#x1010;&#x1038;&#x1019;&#x103A;&#x102F;, top_k, top_p</li>
          <li>Web IDE: Browser-based interface</li>
          <li>API: REST endpoints for integration</li>
        </ul>
        <br>
        <p style="color:#64748b;">Powered by MMC v9.0 + Z-AI (GLM-5-Turbo)</p>
      </div>
    </div>
  </div>
</div>

<script>
function showPanel(name) {
  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.sidebar .btn').forEach(b => b.classList.remove('active'));
  document.getElementById('panel-' + name).classList.add('active');
  event.target.classList.add('active');
  if (name === 'tensors') loadTensors();
}

async function generate() {
  const output = document.getElementById('outputArea');
  const prompt = document.getElementById('promptInput').value;
  if (!prompt.trim()) { output.textContent = 'Please enter a prompt.'; return; }
  output.textContent = 'Generating...';
  try {
    const resp = await fetch('/api/generate', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        prompt: prompt,
        max_tokens: parseInt(document.getElementById('maxTokens').value) || 128,
        temperature: parseFloat(document.getElementById('temperature').value) || 0.8
      })
    });
    const data = await resp.json();
    output.textContent = data.output || data.error || 'No output';
  } catch(e) {
    output.textContent = 'Error: ' + e.message;
  }
}

async function loadTensors() {
  const container = document.getElementById('tensorListContent');
  try {
    const resp = await fetch('/api/tensors');
    const data = await resp.json();
    if (data.error) { container.innerHTML = '<p style="color:#ef4444;">' + data.error + '</p>'; return; }
    let html = '<ul class="tensor-list">';
    data.tensors.forEach(t => {
      html += '<li><span>' + t.name + '</span><span class="type">' + t.type + ' [' + t.dims.join('x') + ']</span></li>';
    });
    html += '</ul>';
    container.innerHTML = html;
  } catch(e) {
    container.innerHTML = '<p style="color:#ef4444;">Error loading tensors</p>';
  }
}

// Check server status on load
fetch('/api/info').then(r => r.json()).then(data => {
  if (data.model_loaded) {
    document.getElementById('statusDot').classList.remove('off');
    document.getElementById('statusText').textContent = 'Model loaded';
    document.getElementById('modelStatus').textContent = data.info.architecture || 'Unknown';
  }
}).catch(() => {});
</script>
</body>
</html>"""


# ============================================================
# HTTP Request Handler
# ============================================================
class NYANLINHandler(http.server.BaseHTTPRequestHandler):
    """HTTP handler for NYANLIN Web IDE and API."""

    def log_message(self, format, *args):
        pass  # Suppress default logging

    def _send_json(self, data, status=200):
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(json.dumps(data, ensure_ascii=False).encode('utf-8'))

    def _send_html(self, html, status=200):
        self.send_response(status)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.end_headers()
        self.wfile.write(html.encode('utf-8'))

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        if path == '/' or path == '/index.html':
            self._send_html(HTML_PAGE)

        elif path == '/api/info':
            if current_reader and current_reader._parsed:
                info = current_reader.get_model_info()
                self._send_json({"model_loaded": True, "info": info})
            else:
                self._send_json({"model_loaded": False, "info": {}, "error": "No model loaded. Start server with: python mmc_ai_server.py model.gguf"})

        elif path == '/api/tensors':
            if current_reader and current_reader._parsed:
                tensor_types = {0:"F32",1:"F16",2:"Q4_0",3:"Q4_1",6:"Q5_0",7:"Q5_1",8:"Q8_0",10:"Q2_K",11:"Q3_K",12:"Q4_K",13:"Q5_K",14:"Q6_K",15:"Q8_K",30:"BF16"}
                tensors = []
                for ti in current_reader.tensor_infos:
                    tensors.append({
                        "name": ti["name"],
                        "type": tensor_types.get(ti["type"], f"UNK({ti['type']})"),
                        "dims": ti["dims"],
                        "n_dims": ti["n_dims"]
                    })
                self._send_json({"tensors": tensors, "count": len(tensors)})
            else:
                self._send_json({"error": "No model loaded", "tensors": []})

        else:
            self._send_html(HTML_PAGE, 404)

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        if path == '/api/generate':
            content_length = int(self.headers.get('Content-Length', 0))
            body = self.rfile.read(content_length)
            try:
                data = json.loads(body)
            except json.JSONDecodeError:
                self._send_json({"error": "Invalid JSON", "output": ""})
                return

            prompt = data.get('prompt', '')
            max_tokens = data.get('max_tokens', 128)
            temperature = data.get('temperature', 0.8)

            if not prompt:
                self._send_json({"error": "Empty prompt", "output": ""})
                return

            if simulator.loaded:
                start = time.time()
                output = simulator.generate_demo(prompt, max_tokens)
                elapsed = time.time() - start
                self._send_json({
                    "output": output,
                    "prompt": prompt,
                    "max_tokens": max_tokens,
                    "temperature": temperature,
                    "time_seconds": round(elapsed, 3)
                })
            else:
                self._send_json({"error": "No model loaded", "output": ""})

        elif path == '/api/load':
            content_length = int(self.headers.get('Content-Length', 0))
            body = self.rfile.read(content_length)
            try:
                data = json.loads(body)
            except json.JSONDecodeError:
                self._send_json({"error": "Invalid JSON", "success": False})
                return

            model_path = data.get('model_path', '')
            if not model_path or not os.path.exists(model_path):
                self._send_json({"error": f"Model not found: {model_path}", "success": False})
                return

            try:
                global current_reader
                current_reader = GGUFReader(model_path)
                current_reader.parse()
                simulator.load_model(current_reader)
                info = current_reader.get_model_info()
                self._send_json({"success": True, "info": info})
            except Exception as e:
                self._send_json({"error": str(e), "success": False})

        else:
            self._send_json({"error": "Unknown endpoint", "output": ""})


# ============================================================
# Main Entry Point
# ============================================================
def main():
    global current_reader

    port = DEFAULT_PORT
    host = DEFAULT_HOST
    model_path = None

    # Parse command line arguments
    i = 1
    while i < len(sys.argv):
        if sys.argv[i] == '--port':
            i += 1
            if i < len(sys.argv):
                port = int(sys.argv[i])
        elif sys.argv[i] == '--host':
            i += 1
            if i < len(sys.argv):
                host = sys.argv[i]
        elif not sys.argv[i].startswith('--'):
            model_path = sys.argv[i]
        i += 1

    # Load model if path provided
    if model_path:
        if not os.path.exists(model_path):
            print(f"Error: Model file not found: {model_path}")
            sys.exit(1)
        print(f"Loading model: {model_path}")
        try:
            current_reader = GGUFReader(model_path)
            current_reader.parse()
            simulator.load_model(current_reader)
            info = current_reader.get_model_info()
            print(f"  Architecture: {info.get('architecture', 'N/A')}")
            print(f"  Layers: {info.get('block_count', 'N/A')}")
            print(f"  Vocab: {info.get('vocab_size', 'N/A')}")
            print(f"  Tensors: {info.get('tensor_count', 'N/A')}")
            print(f"  File size: {info.get('file_size', 0) / (1024*1024):.1f} MB")
        except Exception as e:
            print(f"Error loading model: {e}")
            sys.exit(1)

    # Start server
    server = http.server.HTTPServer((host, port), NYANLINHandler)
    print(f"\n{'='*50}")
    print(f"  NYANLIN v2.0 Web IDE + API Server")
    print(f"  URL: http://{host}:{port}")
    print(f"  Model: {'Loaded' if model_path else 'None (API only mode)'}")
    print(f"{'='*50}\n")
    print("Endpoints:")
    print(f"  GET  /          - Web IDE")
    print(f"  GET  /api/info  - Model info")
    print(f"  GET  /api/tensors - Tensor list")
    print(f"  POST /api/generate - Text generation")
    print(f"  POST /api/load - Load model dynamically")
    print(f"\nPress Ctrl+C to stop\n")

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nServer stopped.")
        server.server_close()


if __name__ == '__main__':
    main()
