#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MMC Transpiler v8.0
Myanmar Code (MMC) -> Python 3

Complete language with:
  v4: Variables, Types, Control Flow, Loops, Functions, OOP,
      Dict/Map, Error Handling, File I/O, Import, String/List/Dict methods
  v5: Module System (export), Package Manager bridge, Enhanced Stdlib
  v6: Type Hints, Decorators, Generators (yield), Lambda, Comprehensions
  v7: Full async/await, Testing Framework, with statement
  v8: Source Maps, Debug markers, LLVM bridge, Pass/Global/Nonlocal/Del

Author: MyanOS AI Team
Version: 8.0.0
"""

import re
import sys
import io
import json
import traceback

# ============================================================
# Keyword Categories
# ============================================================

# Statements -> Python keywords
STMT_KEYWORDS = {
    # v4 - Control Flow
    'အကယ်၍': 'if',
    'မဟုတ်ပါက': 'else',
    'မဟုတ်လျှင်': 'elif',
    # v4 - Loops
    'အတွက်': 'for',
    'လုပ်နေစဉ်': 'while',
    'ရပ်': 'break',
    'ဆက်လုပ်': 'continue',
    # v4 - Functions & Classes
    'အဓိပ္ပာယ်': 'def',
    'လုပ်ဆောင်ချက်': 'def',
    'ပြန်ပေး': 'return',
    'အတန်း': 'class',
    # v4 - Import
    'တင်သွင်း': 'import',
    'မှ': 'from',
    'ကူးယူပါ': 'import',
    # v4 - Error Handling
    'ကြိုးစား': 'try',
    'ဖမ်းမိ': 'except',
    'နောက်ဆုံး': 'finally',
    'ချမြှောက်': 'raise',
    # v4 - Async
    'မတူညီ': 'async',
    'မျှော်': 'await',
    # v4 - Logic
    'ညီမျှလျှင်': 'and',
    'သို့မဟုတ်': 'or',
    'မဟုတ်': 'not',
    'ဖြစ်ပြီး': 'while',
    'အဖြစ်': 'as',
    # v5 - Module
    'ပေးပါ': '__all__',
    # v6 - Generators
    'ပေး': 'yield',
    'ပြန်လုပ်ပေး': 'yield from',
    # v6 - Lambda
    'များလိုက်': 'lambda',
    # v7 - With
    'နုတ်ထုတ်': 'with',
    # v7 - Assert
    'စာသေးခံ': 'assert',
    # v8 - Pass / Global / Nonlocal / Del
    'ကျန်ရမ်း': 'pass',
    'ကြွင်းလဲ': 'global',
    'ဒေသခံ': 'nonlocal',
    'ဖျက်ပါ': 'del',
}

# Function calls -> Python builtins (wrap with parens)
FUNC_KEYWORDS = {
    'ပုံနှိပ်': 'print',
    'မေးမြန်း': 'input',
    'အရှည်': 'len',
    'ဇယား': 'type',
    'ကျပန်း': 'str',
    'အချိန်': 'int',
    'လော့ဂရစ်သမ်': 'float',
    'တန်ဂျင့်': 'bool',
    'စာရင်း': 'list',
    'အရာဝတ္ထု': 'dict',
    'အဘိဓာန်': 'set',
    'ဆိုင်': 'tuple',
    'ပတ်လမ်း': 'range',
    'သင်္ချာ': 'abs',
    'အမြင့်ဆုံး': 'max',
    'အနိမ့်ဆုံး': 'min',
    'ပေါင်းလုံး': 'sum',
    'ရွေးချယ်': 'sorted',
    'ပြဿနာ': 'map',
    'ကုလသိုက်': 'filter',
    'ဟိုပ်': 'hex',
    'ဒုန်းလံ': 'bin',
    'ခဲမစ်တီ': 'hash',
    'အID': 'id',
    'ရောကိုင်': 'enumerate',
    'ဇကာ': 'zip',
    'မြှင့်တင်': 'round',
    'ဖန်တီး': 'chr',
    'စကားလုံး': 'ord',
    'ဖွင့်': 'open',
    'ထည့်သွင်း_ဖိုင်': 'import_module',
    # v6 - Type constructors
    'ပုံ_စုံ': 'frozenset',
    'ဘိုးလံ': 'bytes',
    'ဘိုးလံ_ပုံ': 'bytearray',
    # v7 - Async
    'ဖွင့်_သတိမှတ်': 'asyncio.get_event_loop',
    'အလိုလို': 'asyncio.gather',
    # v8 - Debug
    'ကျေးဇူးပြု': 'breakpoint',
    'ပုံ_မှတ်တမ်း': 'repr',
    'ရှင်းပြ': 'vars',
    'အလေ့အကျင်': 'dir',
    # v8 - Meta
    'အမျိုးအစား': 'isinstance',
    'အတိအကျ': 'issubclass',
    'လုပ်ဆောင်ချက်_ပေး': 'callable',
    'သုံးစွဲ': 'hasattr',
    'ဖွင့်ဆိုင်': 'getattr',
    'သတွေ့': 'setattr',
    'ဖျက်ဆိုင်': 'delattr',
}

# Type names for hints (no parens wrapping)
TYPE_NAMES = {
    'စာသား': 'str',
    'အချိန်': 'int',
    'လော့ဂရစ်သမ်': 'float',
    'တန်ဂျင့်': 'bool',
    'စာရင်း': 'list',
    'အရာဝတ္ထု': 'dict',
    'အဘိဓာန်': 'set',
    'ဆိုင်': 'tuple',
    'မပါ': 'None',
    'အရာရည်': 'Any',
    'ခေါ်ဆိုချက်': 'Callable',
    'ဖျက်ရှင်း': 'Optional',
    'ပုံ_စုံ_အတန်း': 'FrozenSet',
    'ဘိုးလံ_အတန်း': 'Bytes',
    'ဖွင့်ထုတ်': 'Iterator',
    'ဖွင့်ထုတ်_အုပ်စု': 'Iterable',
}

# Decorator keywords
DECORATOR_KEYWORDS = {
    'လက်မှတ်_ပေး': '',
    'ခွဲခြမ်းစိတ်': 'property',
    'ခန့်မှန်း': 'staticmethod',
    'ပုံ_အတန်း': 'classmethod',
    'ထိုင်သင့်': '',
    'ပရော်ပါ': '',
    'တင်သပ်ပါ': '',
    'မှတ်သား_ပေး': '',
    'ကျွန်ုပ်တည်ငြိမ်': 'dataclass',
    'အခြေခံ': 'abstractmethod',
    'တိကျ': '',
    'စကားသား': '',
}

# Value keywords
VALUE_KEYWORDS = {
    'မှန်': 'True',
    'မှား': 'False',
    'မပါ': 'None',
    'ဒီ': 'self',
    'အထက်': 'super()',
    'ဒါ': 'cls',
}

# Variable type hints (skip - Python doesn't need var/let/const)
SKIP_KEYWORDS = {'ကိန်း', 'အတည်', 'နေရာ'}

# Method names (after dot: object.method())
METHOD_KEYWORDS = {
    # String methods
    'စာလုံးကြီး': 'upper',
    'စာလုံးသေး': 'lower',
    'စမြည့်': 'capitalize',
    'ဆုံးမြည့်': 'title',
    'စာဆက်': 'join',
    'စာခွဲ': 'split',
    'ဖြတ်': 'strip',
    'အစားထိုး': 'replace',
    'ရှာဖွေ': 'find',
    'အမှန်နေ': 'isalpha',
    'ဂဏန်းဖြစ်': 'isdigit',
    'စာသားဖြစ်': 'isalnum',
    'အသားဖြစ်': 'isupper',
    'သေးဖြစ်': 'islower',
    'ပိုင်ဆိုင်': 'startswith',
    'ပြီးဆုံးဖြစ်': 'endswith',
    'အရှည်_စာရင်း': 'splitlines',
    'ကျေးဇူးပါ': 'center',
    'ဘယ်ကဲ့': 'ljust',
    'ညာကဲ့': 'rjust',
    'ဖော်ပြ': 'format',
    'ကိုယ်ပိုင်': 'encode',
    'ဖွင့်ထုတ်': 'decode',
    'ရှာမှတ်': 'index',
    'တိကျ_စာ': 'count',
    'ပြုပြင်': 'expandtabs',
    'ပုံ_ပြောင်း': 'copy',
    'ဖြစ်စဉ်': 'partition',
    'နောက်ဆုံး_ဖြစ်စဉ်': 'rpartition',
    'ရောကိုင်ပြု': 'maketrans',

    # List methods
    'ထည့်သွင်း': 'insert',
    'စီ': 'sort',
    'ရှင်းလင်း': 'clear',
    'ပြန်လဲ': 'reverse',
    'အမြင့်ပြဦး': 'index',
    'ရှိမရှိ': 'count',
    'အရှည်_ထည့်': 'extend',
    'ပုံ_ပြောင်း': 'copy',
    'ရှင်း': 'pop',
    'နောက်ဆုံး_ထည့်': 'append',
    'တိကျ_ဖြစ်မရှိ': 'remove',

    # Dict methods
    'ဝင်_အကွက်': 'keys',
    'ပြ_အကွက်': 'values',
    'အုပ်စု': 'items',
    'ဖော်ပြ_ရှိမရှိ': 'get',
    'ချက်_ဖော်ပြ': 'popitem',
    'ပြန်လဲ_ပုံ': 'update',
    'မှတ်သား': 'setdefault',
    'ဖယ်ရှား': 'discard',

    # Set methods
    'ပေါင်းပါ': 'union',
    'တူနေ_အပေါ်': 'intersection',
    'မတူနေ': 'difference',
    'ပါဝင်': 'add',

    # File methods
    'ဖိုင်ဖတ်': 'read',
    'ဖိုင်ရေး': 'write',
    'ဖိုင်ဖျက်': 'close',
    'ဖိုင်စုံ': 'readlines',
    'ဖိုင်လမ်း': 'readline',
    'ဖိုင်_ပြောင်း': 'flush',
    'ဖိုင်_ရေးပါ': 'writelines',

    # Iterator methods
    'နောက်_တိုင်း': '__next__',
    'အရေရှိ': '__iter__',

    # General
    'ပုံ_အတွေ့': '__repr__',
    'ပုံ_စာသား': '__str__',
    'တိကျ': '__eq__',
    'ပိုမို': '__lt__',
    'ပိုမို_ကြီး': '__gt__',
    'ပိုမို_သေး': '__le__',
    'ပိုမို_ကြီး_သေး': '__ge__',
    'ပေါင်း': '__add__',
    'နုတ်': '__sub__',
    'အထိ': '__mul__',
    'ပြောင်း': '__truediv__',
}

# All keywords combined for quick lookup
ALL_KEYWORDS = {}
ALL_KEYWORDS.update(STMT_KEYWORDS)
ALL_KEYWORDS.update(FUNC_KEYWORDS)
ALL_KEYWORDS.update(VALUE_KEYWORDS)
ALL_KEYWORDS.update(METHOD_KEYWORDS)
ALL_KEYWORDS.update(DECORATOR_KEYWORDS)
ALL_KEYWORDS.update(TYPE_NAMES)
for k in SKIP_KEYWORDS:
    ALL_KEYWORDS[k] = ''

# Myanmar digits
MYANMAR_DIGITS = {
    '၀': '0', '၁': '1', '၂': '2', '၃': '3', '၄': '4',
    '၅': '5', '၆': '6', '၇': '7', '၈': '8', '၉': '9',
}


# ============================================================
# Source Map Generator
# ============================================================

class SourceMap:
    """Track MMC line -> Python line mapping for debugging."""

    def __init__(self):
        self.mappings = []  # [(mmc_line, py_line, mmc_col)]

    def add(self, mmc_line, py_line, mmc_col=0):
        self.mappings.append((mmc_line, py_line, mmc_col))

    def to_dict(self):
        return {
            'version': 8,
            'mappings': self.mappings
        }

    def to_json(self):
        return json.dumps(self.to_dict(), indent=2)


# ============================================================
# Tokenizer
# ============================================================

class Token:
    """MMC token."""
    __slots__ = ('type', 'value', 'line', 'col')

    def __init__(self, type_, value, line=0, col=0):
        self.type = type_
        self.value = value
        self.line = line
        self.col = col

    def __repr__(self):
        return f"Token({self.type}, {self.value!r})"


def tokenize(source):
    """Tokenize MMC source code into a list of Token objects."""
    tokens = []
    i = 0
    line = 1
    col = 1

    while i < len(source):
        ch = source[i]

        # Newline
        if ch == '\n':
            tokens.append(Token('NEWLINE', '\n', line, col))
            line += 1
            col = 1
            i += 1
            continue

        # Whitespace
        if ch in ' \t\r':
            i += 1
            col += 1
            continue

        # Comment
        if ch == '#':
            j = i
            while j < len(source) and source[j] != '\n':
                j += 1
            tokens.append(Token('COMMENT', source[i:j], line, col))
            col += j - i
            i = j
            continue

        # f-strings (f"..." or f'...') — only if f is immediately before quote
        # Make sure 'f' is not part of a longer identifier
        if (ch == 'f' and i + 1 < len(source) and source[i + 1] in ('"', "'")
                and (i == 0 or not (source[i-1].isalnum() or source[i-1] == '_'
                                     or ord(source[i-1]) > 0x1000))):
            j = i + 2
            quote = source[i + 1]
            while j < len(source) and source[j] != quote:
                if source[j] == '\\':
                    j += 2
                    continue
                j += 1
            j = min(j + 1, len(source))
            tokens.append(Token('FSTRING', source[i:j], line, col))
            col += j - i
            i = j
            continue

        # String literals
        if ch in ('"', "'"):
            j = i + 1
            while j < len(source) and source[j] != ch:
                if source[j] == '\\':
                    j += 1
                j += 1
            j = min(j + 1, len(source))
            tokens.append(Token('STRING', source[i:j], line, col))
            col += j - i
            i = j
            continue

        # Triple-quoted strings (""" or ''')
        if source[i:i+3] in ('"""', "'''"):
            quote = source[i:i+3]
            j = i + 3
            while j < len(source) - 2:
                if source[j:j+3] == quote:
                    j += 3
                    break
                if source[j] == '\n':
                    line += 1
                    col = 1
                j += 1
            else:
                j = len(source)
            tokens.append(Token('STRING', source[i:j], line, col))
            col += j - i
            i = j
            continue

        # Numbers (including Myanmar digits)
        if ch.isdigit() or ch in MYANMAR_DIGITS:
            j = i
            while j < len(source) and (source[j].isdigit() or source[j] in MYANMAR_DIGITS or source[j] == '.'):
                j += 1
            num = source[i:j]
            for my, ar in MYANMAR_DIGITS.items():
                num = num.replace(my, ar)
            tokens.append(Token('NUMBER', num, line, col))
            col += j - i
            i = j
            continue

        # Multi-char operators
        two = source[i:i+2] if i + 1 < len(source) else ''
        three = source[i:i+3] if i + 2 < len(source) else ''

        if three in ('**=', '//=', '>>=', '<<=', '@='):
            tokens.append(Token('OP', three, line, col))
            i += 3
            col += 3
            continue

        if two in ('==', '!=', '>=', '<=', '+=', '-=', '*=', '/=', '%=',
                    '**', '//', '->', '<<', '>>', '&&', '||', ':=', '??'):
            tokens.append(Token('OP', two, line, col))
            i += 2
            col += 2
            continue

        # Single-char operators and punctuation
        if ch in '=!<>+-*/%()[]{}:,.;@\\~^&|?':
            tokens.append(Token('OP', ch, line, col))
            i += 1
            col += 1
            continue

        # Identifiers / Myanmar words
        if ch.isalpha() or ch == '_' or ord(ch) > 0x1000:
            j = i
            while j < len(source) and (
                source[j].isalnum() or source[j] == '_' or
                ord(source[j]) > 0x1000 or source[j] in MYANMAR_DIGITS
            ):
                j += 1
            word = source[i:j]
            for my, ar in MYANMAR_DIGITS.items():
                word = word.replace(my, ar)
            tokens.append(Token('WORD', word, line, col))
            col += j - i
            i = j
            continue

        # Unknown
        tokens.append(Token('UNKNOWN', ch, line, col))
        i += 1
        col += 1

    return tokens


# ============================================================
# Translator: MMC Source -> Python Source
# ============================================================

def translate_to_python(tokens):
    """Translate MMC token list to Python source code."""
    lines = []
    current_tokens = []

    for tok in tokens:
        if tok.type == 'NEWLINE':
            if current_tokens:
                line_str = _tokens_to_str(current_tokens)
                lines.append(line_str)
            else:
                lines.append('')
            current_tokens = []
        elif tok.type == 'COMMENT':
            if not current_tokens:
                lines.append(tok.value)
        else:
            current_tokens.append(tok)

    if current_tokens:
        line_str = _tokens_to_str(current_tokens)
        lines.append(line_str)

    return '\n'.join(lines)


def _tokens_to_str(tokens):
    """Convert a list of tokens to a translated Python string."""
    if not tokens:
        return ''
    py_parts = _translate_tokens(tokens)
    return _smart_join(py_parts)


def _translate_tokens(tokens):
    """Translate a list of tokens to Python parts."""
    parts = []
    i = 0
    after_dot = False
    after_at = False  # Track if previous token was @
    after_colon_type = False  # Track if in type hint context

    while i < len(tokens):
        tok = tokens[i]

        if tok.type == 'COMMENT':
            i += 1
            continue

        # String literals - pass through
        if tok.type == 'STRING':
            parts.append(tok.value)
            i += 1
            after_dot = False
            after_at = False
            after_colon_type = False
            continue

        # f-strings - pass through
        if tok.type == 'FSTRING':
            parts.append(tok.value)
            i += 1
            after_dot = False
            after_at = False
            after_colon_type = False
            continue

        # Numbers
        if tok.type == 'NUMBER':
            parts.append(tok.value)
            i += 1
            after_dot = False
            after_at = False
            after_colon_type = False
            continue

        # Operators
        if tok.type == 'OP':
            parts.append(tok.value)
            after_dot = (tok.value == '.')
            after_at = (tok.value == '@')
            after_colon_type = (tok.value == ':')
            i += 1
            continue

        # Words (identifiers/keywords)
        if tok.type == 'WORD':
            word = tok.value

            # Skip keywords (var/let/const)
            if word in SKIP_KEYWORDS:
                i += 1
                after_dot = False
                after_at = False
                continue

            # Value keywords
            if word in VALUE_KEYWORDS:
                parts.append(VALUE_KEYWORDS[word])
                i += 1
                after_dot = False
                after_at = False
                after_colon_type = False
                continue

            # Decorator context: after @, translate decorator keyword
            if after_at and word in DECORATOR_KEYWORDS:
                py_dec = DECORATOR_KEYWORDS[word]
                if py_dec:
                    parts.append(py_dec)
                else:
                    parts.append(word)  # Custom decorator name
                i += 1
                after_at = False
                after_dot = False
                continue

            # After @ but not a known decorator - pass through (custom decorator)
            if after_at:
                parts.append(word)
                i += 1
                after_at = False
                after_dot = False
                continue

            # After dot - check for method name
            if after_dot and word in METHOD_KEYWORDS:
                parts.append(METHOD_KEYWORDS[word])
                i += 1
                after_dot = False
                after_colon_type = False
                continue

            # Type names (after colon context - for type hints)
            if after_colon_type and word in TYPE_NAMES:
                parts.append(TYPE_NAMES[word])
                i += 1
                after_colon_type = False
                after_dot = False
                continue

            # Function call keywords
            if word in FUNC_KEYWORDS:
                py_name = FUNC_KEYWORDS[word]
                i += 1
                # Check if next token is ( - user provided parens
                if i < len(tokens) and tokens[i].value == '(':
                    parts.append(py_name)
                    parts.append('(')
                    i += 1
                    # Collect everything until matching )
                    depth = 1
                    inner_parts = []
                    while i < len(tokens) and depth > 0:
                        t = tokens[i]
                        if t.value == '(':
                            depth += 1
                        elif t.value == ')':
                            depth -= 1
                            if depth == 0:
                                inner_py = _smart_join(_translate_tokens(inner_parts))
                                parts.append(inner_py)
                                parts.append(')')
                                i += 1
                                break
                        inner_parts.append(t)
                        i += 1
                else:
                    # No parens - check for simple statement keywords that shouldn't wrap
                    if py_name in ('breakpoint', '__next__', '__iter__'):
                        parts.append(py_name)
                    elif py_name.startswith('asyncio.'):
                        parts.append(py_name)
                    elif py_name == 'super()':
                        parts.append(py_name)
                    else:
                        # Collect remaining tokens as args
                        args = []
                        while i < len(tokens):
                            args.append(tokens[i])
                            i += 1
                        if args:
                            args_py = _smart_join(_translate_tokens(args))
                            parts.append(f"{py_name}({args_py})")
                        else:
                            parts.append(f"{py_name}()")
                after_dot = False
                after_at = False
                after_colon_type = False
                continue

            # Statement keywords
            if word in STMT_KEYWORDS:
                py_kw = STMT_KEYWORDS[word]

                # Special: __all__ (export)
                if py_kw == '__all__':
                    parts.append('__all__')
                    i += 1
                    after_dot = False
                    after_at = False
                    continue

                # Special handling for 'for' - insert 'in' if not already present
                if py_kw == 'for':
                    parts.append('for')
                    i += 1
                    # Collect all comma-separated variables (tuple unpacking support)
                    if i < len(tokens):
                        parts.append(_translate_single_token(tokens[i]))
                        i += 1
                        # Check for comma-separated vars (for i, v in enumerate(...))
                        while i < len(tokens) and tokens[i].value == ',':
                            parts.append(',')
                            i += 1
                            if i < len(tokens) and tokens[i].type == 'WORD':
                                parts.append(_translate_single_token(tokens[i]))
                                i += 1
                    # Check if next token is already 'in' ( Myanmar: အတွက် maps to 'for', no 'in' keyword)
                    # User might write: for i range(3) -> need to insert 'in'
                    # User might write: for i in range(3) -> 'in' already present as WORD
                    if i < len(tokens) and tokens[i].type == 'WORD' and _translate_single_token(tokens[i]) == 'in':
                        # User already wrote 'in', just consume it
                        i += 1
                    else:
                        # No 'in' found, insert it
                        parts.append('in')
                    after_dot = False
                    after_at = False
                    after_colon_type = False
                    continue

                # Special handling for 'lambda'
                # lambda(x: body) -> lambda x: body (strip parens for Python compat)
                if py_kw == 'lambda':
                    parts.append('lambda')
                    i += 1
                    # Skip opening ( if present
                    if i < len(tokens) and tokens[i].value == '(':
                        i += 1
                        # Collect inner tokens until matching )
                        depth = 1
                        inner_parts = []
                        while i < len(tokens) and depth > 0:
                            t = tokens[i]
                            if t.value == '(':
                                depth += 1
                                inner_parts.append(t)
                            elif t.value == ')':
                                depth -= 1
                                if depth == 0:
                                    i += 1
                                    break
                                inner_parts.append(t)
                            else:
                                inner_parts.append(t)
                            i += 1
                        # Translate inner parts
                        for ip in inner_parts:
                            parts.append(_translate_single_token(ip))
                    after_dot = False
                    after_at = False
                    after_colon_type = False
                    continue

                # Special handling for 'assert'
                if py_kw == 'assert':
                    parts.append('assert')
                    i += 1
                    after_dot = False
                    after_at = False
                    after_colon_type = False
                    continue

                # Special handling for 'yield from'
                if py_kw == 'yield from':
                    parts.append('yield from')
                    i += 1
                    after_dot = False
                    after_at = False
                    continue

                # Special handling for 'del'
                if py_kw == 'del':
                    parts.append('del')
                    i += 1
                    after_dot = False
                    after_at = False
                    continue

                # Special handling for 'with'
                if py_kw == 'with':
                    parts.append('with')
                    i += 1
                    after_dot = False
                    after_at = False
                    after_colon_type = False
                    continue

                parts.append(py_kw)
                i += 1
                after_dot = False
                after_at = False
                after_colon_type = False
                continue

            # Regular identifier - pass through
            parts.append(word)
            i += 1
            after_dot = False
            after_at = False
            after_colon_type = False
            continue

        # Fallback
        parts.append(str(tok.value))
        i += 1
        after_dot = False
        after_at = False
        after_colon_type = False

    return parts


def _translate_single_token(tok):
    """Translate a single token."""
    if tok.type == 'WORD':
        if tok.value in SKIP_KEYWORDS:
            return ''
        if tok.value in VALUE_KEYWORDS:
            return VALUE_KEYWORDS[tok.value]
        if tok.value in STMT_KEYWORDS:
            return STMT_KEYWORDS[tok.value]
        if tok.value in FUNC_KEYWORDS:
            return FUNC_KEYWORDS[tok.value]
        if tok.value in METHOD_KEYWORDS:
            return METHOD_KEYWORDS[tok.value]
        if tok.value in TYPE_NAMES:
            return TYPE_NAMES[tok.value]
    return tok.value


def _smart_join(parts):
    """Join Python parts with smart spacing.

    Uses a two-pass approach:
    1. Mark which '(' should have space before (decorator calls, lambda)
    2. Apply spacing rules

    Rules:
    - No space around '.'
    - No space inside (), [], {}  
    - No space before , : ;
    - No space after @
    - 'for X in' — no space before 'in'
    - Function calls: no space before (
    - Keywords before (: space before (
    """
    if not parts:
        return ''

    parts = [p for p in parts if p]
    if len(parts) <= 1:
        return ''.join(parts)

    # First, identify tokens that are function names (should NOT have space before their paren)
    # vs keywords that need space before their paren
    result = [parts[0]]

    i = 1
    while i < len(parts):
        prev = result[-1]
        curr = parts[i]

        # --- Rule: No space around dot ---
        if prev == '.' or curr == '.':
            result.append(curr)
            i += 1
            continue

        # --- Rule: No space after @ (decorator) ---
        if prev == '@':
            result.append(curr)
            i += 1
            continue

        # --- Rule: No space inside () [] {} ---
        if prev in ('(', '[', '{'):
            result.append(curr)
            i += 1
            continue

        # --- Rule: No space before ) ] } ---
        if curr in (')', ']', '}'):
            result.append(curr)
            i += 1
            continue

        # --- Rule: No space before , : ; ---
        if curr in (',', ';', ':'):
            result.append(curr)
            i += 1
            continue

        # --- Rule: [ ( { after = (assignment) = space ---
        # Use a special marker to avoid breaking bracket detection
        if curr in ('[', '(', '{') and prev == '=':
            result.append(' ')  # Just the space
            result.append(curr)  # Then the bracket as separate element
            i += 1
            continue

        # --- Rule: ( after number/operator = no space ---
        if curr == '(' and (prev[-1:].isdigit() or prev[-1:] in '+-*/%<>!&|^~?)\'"'):
            result.append(curr)
            i += 1
            continue

        # --- Rule: [ after number/operator/string = no space (subscript) ---
        if curr == '[' and (prev[-1:].isdigit() or prev[-1:] in '+-*/%<>!&|^~?)\'"'):
            result.append(curr)
            i += 1
            continue

        # --- Rule: [ after word = no space (subscript: d["x"], a[0]) ---
        # But NOT after = (handled above)
        if curr == '[' and (prev[-1:].isalpha() or prev[-1:] == '_') and prev != '=':
            result.append(curr)
            i += 1
            continue

        # --- Rule: [ after ) ] } = no space (chained subscript) ---
        if curr in ('(', '[') and prev[-1:] in (')', ']', '}'):
            result.append(curr)
            i += 1
            continue

        # --- Rule: Space after ) ] } before next token ---
        if prev[-1:] in (')', ']', '}'):
            if curr[0:1] not in (',', ';', ':', ')', ']', '}'):
                result.append(' ')
            result.append(curr)
            i += 1
            continue

        # --- Rule: Space after string literal before next token ---
        if prev[0:1] in ('"', "'"):
            result.append(' ')
            result.append(curr)
            i += 1
            continue

        # --- Rule: ( after word/identifier ---
        # Keywords that NEED space before (: def, if, elif, while, for, with,
        #   assert, class, except, finally, return, raise, yield, lambda, not,
        #   and, or, in, is, as, async, await, del, global, nonlocal, import, from
        # Function names that need NO space: print, len, range, str, int, etc.
        if curr == '(':
            prev_clean = prev.lstrip()
            SPACE_BEFORE_PAREN = {
                'def', 'class', 'if', 'elif', 'else', 'while', 'for', 'with',
                'assert', 'return', 'raise', 'yield', 'yield from', 'lambda',
                'not', 'and', 'or', 'in', 'is', 'as', 'async', 'await',
                'del', 'global', 'nonlocal', 'pass', 'import', 'from',
                'except', 'finally', 'try', 'super()',
            }
            if prev_clean in SPACE_BEFORE_PAREN:
                result.append(' ')
                result.append(curr)
            elif prev_clean == 'print':
                # print( is a function call — no space, BUT we need to check
                # if this is the auto-wrapped print from the translator
                # Since the translator wraps print(x) for MMC, no space needed
                result.append(curr)
            else:
                # Other words: check if it looks like a function call
                # (alphanumeric identifier) — no space
                # vs keyword — space
                if prev_clean[0:1].isalpha() or prev_clean[0:1] == '_':
                    # Could be function name or keyword
                    # Python convention: function calls have no space
                    result.append(curr)
                else:
                    result.append(curr)
            i += 1
            continue

        # --- No more special operator rules — fall through to default (space) ---

        # --- Rule: = is assignment — needs space before next token ---
        if prev == '=':
            result.append(' ')
            result.append(curr)
            i += 1
            continue

        # --- Rule: Two-char assignment operators (+=, -=, etc.) need space ---
        if prev in ('+=', '-=', '*=', '/=', '%=', '**=', '//=', '>>=', '<<=', '@='):
            result.append(' ')
            result.append(curr)
            i += 1
            continue

        # --- Rule: Two-char comparison/logic operators: space after ---
        if prev in ('==', '!=', '>=', '<=', '**', '//', '->', '<<', '>>', '&&', '||',
                     ':=', '??'):
            result.append(' ')
            result.append(curr)
            i += 1
            continue

        # --- Default: space ---
        result.append(' ')
        result.append(curr)
        i += 1

    return ''.join(result)


# ============================================================
# Main Transpiler API
# ============================================================

def mmc_to_python(source, generate_map=False):
    """MMC source -> Python source (main API).

    Args:
        source: MMC source code string
        generate_map: If True, also return a SourceMap

    Returns:
        If generate_map is False: Python source string
        If generate_map is True: (Python source, SourceMap)
    """
    source_map = SourceMap() if generate_map else None

    lines = source.split('\n')
    py_lines = []

    for line_num, line in enumerate(lines, 1):
        stripped = line.strip()

        # Empty line
        if not stripped:
            py_lines.append('')
            if source_map:
                source_map.add(line_num, len(py_lines))
            continue

        # Comment-only line
        if stripped.startswith('#'):
            py_lines.append(line)
            if source_map:
                source_map.add(line_num, len(py_lines))
            continue

        # Get indentation from original line
        leading = len(line) - len(line.lstrip())
        indent = '    ' * (leading // 4)

        # Tokenize and translate
        tokens = tokenize(stripped)
        py_parts = _translate_tokens(tokens)
        py_code = _smart_join(py_parts)

        py_lines.append(indent + py_code)
        if source_map:
            source_map.add(line_num, len(py_lines), 0)

    py_source = '\n'.join(py_lines)

    if generate_map:
        return py_source, source_map
    return py_source


def run_mmc(source, timeout=10):
    """Execute MMC code. Returns (stdout, stderr, exit_code, python_code)."""
    py_code = mmc_to_python(source)

    old_out = sys.stdout
    old_err = sys.stderr
    sys.stdout = out_buf = io.StringIO()
    sys.stderr = err_buf = io.StringIO()

    exit_code = 0
    try:
        ns = {'__builtins__': __builtins__, '__name__': '__mmc__'}
        exec(py_code, ns)
    except SystemExit as e:
        exit_code = e.code or 0
    except Exception as e:
        exit_code = 1
        err_buf.write(f"{type(e).__name__}: {e}\n")

    sys.stdout = old_out
    sys.stderr = old_err
    return out_buf.getvalue(), err_buf.getvalue(), exit_code, py_code


def compile_mmc(source, output_file=None):
    """Compile MMC to Python and optionally write to file."""
    py_code, source_map = mmc_to_python(source, generate_map=True)
    header = f"# Generated by MMC Transpiler v8.0\n# Source Map: {len(source_map.mappings)} lines mapped\n\n"
    py_code = header + py_code

    if output_file:
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(py_code)
        map_file = output_file + '.map'
        with open(map_file, 'w', encoding='utf-8') as f:
            f.write(source_map.to_json())
        return py_code, map_file
    return py_code, source_map.to_json()


# ============================================================
# CLI
# ============================================================

def main():
    if len(sys.argv) < 2:
        print("""
MMC Transpiler v8.0 - Myanmar Code Programming Language

Usage:
  python mmc_transpiler.py run <file.mmc>        Run MMC code
  python mmc_transpiler.py compile <file.mmc>    Show Python output
  python mmc_transpiler.py transpile              Read from stdin
  python mmc_transpiler.py build <file.mmc>       Compile to .py with source map
  python mmc_transpiler.py version                Show version info

Keywords: 150+ Myanmar keywords mapped to Python
Features: Dict, Error Handling, File I/O, OOP, Import,
          Type Hints, Decorators, Generators, Lambda, Comprehensions,
          Async/Await, Testing, Debug, Source Maps
""")
        sys.exit(0)

    cmd = sys.argv[1]

    if cmd == 'run':
        if len(sys.argv) < 3:
            print("Error: Specify .mmc file")
            sys.exit(1)
        with open(sys.argv[2], 'r', encoding='utf-8') as f:
            source = f.read()
        stdout, stderr, code, _ = run_mmc(source)
        if stdout:
            print(stdout, end='')
        if stderr:
            print(stderr, end='', file=sys.stderr)
        sys.exit(code)

    elif cmd == 'compile':
        if len(sys.argv) < 3:
            print("Error: Specify .mmc file")
            sys.exit(1)
        with open(sys.argv[2], 'r', encoding='utf-8') as f:
            source = f.read()
        py = mmc_to_python(source)
        print("--- MMC -> Python ---")
        print(py)
        print("--- End ---")

    elif cmd == 'build':
        if len(sys.argv) < 3:
            print("Error: Specify .mmc file")
            sys.exit(1)
        with open(sys.argv[2], 'r', encoding='utf-8') as f:
            source = f.read()
        out = sys.argv[2].replace('.mmc', '.py')
        py, map_json = compile_mmc(source, out)
        print(f"Compiled: {out}")
        print(f"Source map: {out}.map")

    elif cmd == 'transpile':
        source = sys.stdin.read()
        py = mmc_to_python(source)
        print(py)

    elif cmd == 'version':
        print("MMC Transpiler v8.0")
        print("Myanmar Code Programming Language")
        print(f"Keywords: {len(ALL_KEYWORDS)}")
        print(f"Statements: {len(STMT_KEYWORDS)}")
        print(f"Functions: {len(FUNC_KEYWORDS)}")
        print(f"Methods: {len(METHOD_KEYWORDS)}")
        print(f"Decorators: {len(DECORATOR_KEYWORDS)}")
        print(f"Types: {len(TYPE_NAMES)}")

    else:
        print(f"Unknown command: {cmd}")
        sys.exit(1)


if __name__ == '__main__':
    main()
