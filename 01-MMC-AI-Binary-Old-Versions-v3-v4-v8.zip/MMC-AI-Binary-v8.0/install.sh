#!/usr/bin/env bash
# ============================================================
# MMC AI v8.0 - Complete Install Script
# Myanmar Code Programming Language
# Works on: Termux (Android), Linux, macOS
# ============================================================

echo "========================================="
echo "  MMC AI v8.0 - Myanmar Code Installer"
echo "========================================="
echo ""

# Create project directory
mkdir -p ~/mmc-ai && cd ~/mmc-ai || exit 1

# ---- Step 1: Python ----
echo "[1/5] Checking Python..."
if ! command -v python3 &> /dev/null; then
    echo "  Installing Python..."
    if [ -n "$TERMUX_VERSION" ]; then
        pkg update -y && pkg install python -y
    elif command -v apt &> /dev/null; then
        sudo apt update -y && sudo apt install python3 python3-pip -y
    elif command -v brew &> /dev/null; then
        brew install python3
    else
        echo "  ERROR: Cannot install Python automatically."
        echo "  Please install Python 3.8+ manually."
        exit 1
    fi
fi
echo "  Python: $(python3 --version)"

# ---- Step 2: Ollama ----
echo "[2/5] Checking Ollama..."
if ! command -v ollama &> /dev/null; then
    echo "  Installing Ollama..."
    if [ -n "$TERMUX_VERSION" ]; then
        # Termux - install from source or pkg
        pkg install tur-repo -y 2>/dev/null || true
        pkg install ollama -y 2>/dev/null || {
            echo "  Ollama not available in Termux repos."
            echo "  AI features will work with external Ollama server."
        }
    else
        curl -fsSL https://ollama.com/install.sh | sh
    fi
fi

# Start Ollama if not running
echo "  Checking Ollama server..."
if ! curl -s http://localhost:11434/api/tags > /dev/null 2>&1; then
    echo "  Starting Ollama..."
    ollama serve > /dev/null 2>&1 &
    sleep 3
fi

# ---- Step 3: AI Model ----
echo "[3/5] Setting up MMC AI model..."
if command -v ollama &> /dev/null; then
    ollama pull qwen2.5:1.5b 2>/dev/null || true
    ollama create mmc-ai -f - <<'MODELEOF'
FROM qwen2.5:1.5b
PARAMETER temperature 0.6
PARAMETER num_ctx 4096
SYSTEM """You are MMC AI v8.0 - Myanmar Code Programming Language Assistant.

MMC v8.0 Features:
  v4: Variables, Types, Control Flow, Loops, Functions, OOP,
      Dict/Map, Error Handling, File I/O, Import, Methods
  v5: Package Manager, Standard Library, Module System
  v6: Type Hints, Decorators, Generators, Lambda, Comprehensions
  v7: Async/Await, Testing Framework, With Statement
  v8: Source Maps, Debug, Pass/Global/Del

Keywords (150+ Myanmar -> Python):
  Variables: ကိန်း(var), အတည်(const), နေရာ(let)
  Control: အကယ်၍(if), မဟုတ်ပါက(else), မဟုတ်လျှင်(elif)
  Loops: အတွက်(for), လုပ်နေစဉ်(while), ရပ်(break), ဆက်လုပ်(continue)
  Functions: အဓိပ္ပာယ်(def), ပြန်ပေး(return)
  Classes: အတန်း(class), ဒီ(self)
  I/O: ပုံနှိပ်(print), မေးမြန်း(input), ဖွင့်(open)
  Import: တင်သွင်း(import), မှ(from), ပေးပါ(export)
  Error: ကြိုးစား(try), ဖမ်းမိ(except), နောက်ဆုံး(finally)
  Logic: ညီမျှလျှင်(and), သို့မဟုတ်(or), မဟုတ်(not)
  Boolean: မှန်(True), မှား(False), မပါ(None)
  Built-in: အရှည်(len), ပတ်လမ်း(range), ကျပန်း(str), အချိန်(int)
  v6: ပေး(yield), များလိုက်(lambda), များလိုက်(lambda)
  v6: လက်မှတ်_ပေး(decorator), ခွဲခြမ်းစိတ်(property)
  v7: စာသေးခံ(assert), နုတ်ထုတ်(with)
  v8: ကျန်ရမ်း(pass), ကြွင်းလဲ(global), ဒေသခံ(nonlocal), ဖျက်ပါ(del)

Rules:
- Respond in Myanmar language
- Use ```mmc for code blocks
- Write correct MMC code
- Show Python equivalent when translating"""
MODELEOF
    echo "  MMC AI model created!"
else
    echo "  Ollama not available - AI features need external server"
fi

# ---- Step 4: Copy Files ----
echo "[4/5] Installing MMC files..."
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

cp "$SCRIPT_DIR/mmc_transpiler.py" ~/mmc-ai/ 2>/dev/null || true
cp "$SCRIPT_DIR/mmc_ai_server.py" ~/mmc-ai/ 2>/dev/null || true
cp "$SCRIPT_DIR/mmc_pkg.py" ~/mmc-ai/ 2>/dev/null || true
cp "$SCRIPT_DIR/mmc_test.py" ~/mmc-ai/ 2>/dev/null || true
cp "$SCRIPT_DIR/mmc_debug.py" ~/mmc-ai/ 2>/dev/null || true

# Copy stdlib
mkdir -p ~/mmc-ai/stdlib
cp "$SCRIPT_DIR/stdlib/"*.py ~/mmc-ai/stdlib/ 2>/dev/null || true

# Copy examples
mkdir -p ~/mmc-ai/examples
cp "$SCRIPT_DIR/examples/"*.mmc ~/mmc-ai/examples/ 2>/dev/null || true

# Copy tests
mkdir -p ~/mmc-ai/tests
cp "$SCRIPT_DIR/tests/"*.py ~/mmc-ai/tests/ 2>/dev/null || true

echo "  Files installed to ~/mmc-ai/"

# ---- Step 5: Verify ----
echo "[5/5] Verifying installation..."
cd ~/mmc-ai

if [ -f mmc_transpiler.py ]; then
    KEYWORDS=$(python3 mmc_transpiler.py version 2>/dev/null | grep "Keywords" | awk '{print $2}')
    echo "  Transpiler: OK ($KEYWORDS keywords)"
else
    echo "  Transpiler: MISSING"
fi

if [ -f mmc_ai_server.py ]; then
    echo "  Web IDE: OK"
else
    echo "  Web IDE: MISSING"
fi

if [ -f mmc_pkg.py ]; then
    echo "  Package Manager: OK"
else
    echo "  Package Manager: MISSING"
fi

if [ -f mmc_test.py ]; then
    echo "  Test Framework: OK"
else
    echo "  Test Framework: MISSING"
fi

if [ -f mmc_debug.py ]; then
    echo "  Debugger: OK"
else
    echo "  Debugger: MISSING"
fi

# ---- Done ----
echo ""
echo "========================================="
echo "  Installation Complete!"
echo "========================================="
echo ""
echo "  Commands:"
echo "    cd ~/mmc-ai"
echo "    python3 mmc_ai_server.py    # Start Web IDE"
echo "    python3 mmc_transpiler.py run examples/hello.mmc"
echo "    python3 mmc_test.py tests/test_v8.py"
echo "    python3 mmc_pkg.py list"
echo "    python3 mmc_debug.py examples/fibonacci.mmc"
echo ""
echo "  Open in browser:"
echo "    http://localhost:8080"
echo ""
echo "  MMC AI v8.0 - Myanmar Code Programming Language"
echo "========================================="
