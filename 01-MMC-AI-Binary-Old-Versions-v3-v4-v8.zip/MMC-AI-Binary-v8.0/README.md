MMC AI v8.0 - Myanmar Code Programming Language
=====================================================

Myanmar Code (MMC) - မြန်မာဘာသာဖြင့်ရေးသားသော ဘာသာစကား

Version: 8.0.0
Author: MyanOS AI Team
License: MIT

## Quick Start

### Install (Copy Paste - Termux/PC)

```bash
# 1. Extract the zip
unzip MMC-AI-Binary-v8.0.zip
cd MMC-AI-Binary-v8.0

# 2. Run installer
bash install.sh

# 3. Start Web IDE
cd ~/mmc-ai
python3 mmc_ai_server.py

# 4. Open browser
# http://localhost:8080
```

### Run MMC Code

```bash
python3 mmc_transpiler.py run examples/hello.mmc
python3 mmc_transpiler.py compile examples/calculator.mmc
python3 mmc_transpiler.py build examples/fibonacci.mmc
```

### Test

```bash
python3 mmc_test.py tests/test_v8.py
python3 mmc_transpiler.py version
```

### Debug

```bash
python3 mmc_debug.py examples/fibonacci.mmc
python3 mmc_debug.py --break 5 examples/loops.mmc
```

### Package Manager

```bash
python3 mmc_pkg.py init
python3 mmc_pkg.py create mypackage
python3 mmc_pkg.py list
python3 mmc_pkg.py install somepackage
```

## Files

| File | Description |
|------|-------------|
| mmc_transpiler.py | Core MMC -> Python transpiler (v8.0) |
| mmc_ai_server.py | Web IDE + AI Assistant (port 8080) |
| mmc_pkg.py | Package Manager |
| mmc_test.py | Testing Framework |
| mmc_debug.py | Interactive Debugger |
| install.sh | Copy-paste installer |
| stdlib/ | Standard Library (Math, OS, DateTime, Random, JSON, Net) |
| examples/ | 18 example MMC programs |
| tests/ | Test suite |

## Version Roadmap

### v4.0 - Foundation (Implemented)
- Variables (ကိန်း/အတည်/နေရာ)
- Types (အချိန်/လော့ဂရစ်သမ်/စာသား/တန်ဂျင့်)
- Control Flow (အကယ်၍/မဟုတ်ပါက/မဟုတ်လျှင်)
- Loops (အတွက်/လုပ်နေစဉ်/ရပ်/ဆက်လုပ်)
- Functions (အဓိပ္ပာယ်/ပြန်ပေး)
- OOP (အတန်း/ဒီ/အထက်, inheritance)
- Dictionary/Map (အရာဝတ္ထု)
- Error Handling (ကြိုးစား/ဖမ်းမိ/နောက်ဆုံး)
- File I/O (ဖွင့်/ဖိုင်ဖတ်/ဖိုင်ရေး)
- Import System (တင်သွင်း/မှ)
- 80+ String/List/Dict Methods
- Myanmar Digits (၀-၉)

### v5.0 - Package Manager & Stdlib (Implemented)
- Package Manager (install, create, publish, search)
- Standard Library: Math, OS/Path, DateTime, Random, JSON, HTTP
- Module System (export/import)
- 150+ keywords

### v6.0 - Type System & Advanced (Implemented)
- Type Hints (name: စာသား = "hello")
- Decorators (@လက်မှတ်_ပေး, @ခွဲခြမ်းစိတ်, @ခန့်မှန်း)
- Generators (ပေး = yield, ပြန်လုပ်ပေး = yield from)
- Lambda (များလိုက် = lambda)
- Comprehensions ([x အတွက် x ပတ်လမ်း(10)])

### v7.0 - Concurrency & Testing (Implemented)
- Full Async/Await (မတူညီ/မျှော်)
- With Statement (နုတ်ထုတ် = with)
- Testing Framework (စာသေးခံ, သတိမှတ်ပါ, တင်သပ်ပါ, တွက်ချက်ပါ)
- Test Discovery and Runner

### v8.0 - Production (Implemented)
- Source Maps (MMC line -> Python line mapping)
- Interactive Debugger (breakpoints, stepping, variable inspection)
- Pass/Global/Nonlocal/Del (ကျန်ရမ်း/ကြွင်းလဲ/ဒေသခံ/ဖျက်ပါ)
- Repr/Type/Isinstance (ပုံ_မှတ်တမ်း/ဇယား/အမျိုးအစား)
- LLVM Bridge (mmc.cpp on GitHub)
- Compile to .py with source maps

## MMC Keywords (150+)

### Core
| Myanmar | Python | Category |
|---------|--------|----------|
| ကိန်း | var (skip) | Variable |
| အတည် | const (skip) | Constant |
| နေရာ | let (skip) | Let |
| အကယ်၍ | if | Control |
| မဟုတ်ပါက | else | Control |
| မဟုတ်လျှင် | elif | Control |
| အတွက် | for | Loop |
| လုပ်နေစဉ် | while | Loop |
| ရပ် | break | Loop |
| ဆက်လုပ် | continue | Loop |
| အဓိပ္ပာယ် | def | Function |
| ပြန်ပေး | return | Function |
| အတန်း | class | OOP |
| ဒီ | self | OOP |
| အထက် | super() | OOP |

### I/O & Import
| Myanmar | Python |
|---------|--------|
| ပုံနှိပ် | print |
| မေးမြန်း | input |
| ဖွင့် | open |
| တင်သွင်း | import |
| မှ | from |
| ပေးပါ | __all__ |

### Error Handling
| Myanmar | Python |
|---------|--------|
| ကြိုးစား | try |
| ဖမ်းမိ | except |
| နောက်ဆုံး | finally |
| ချမြှောက် | raise |

### Boolean & Logic
| Myanmar | Python |
|---------|--------|
| မှန် | True |
| မှား | False |
| မပါ | None |
| ညီမျှလျှင် | and |
| သို့မဟုတ် | or |
| မဟုတ် | not |

### Built-in Functions (40+)
ပုံနှိပ်(print), အရှည်(len), ပတ်လမ်း(range), ကျပန်း(str),
အချိန်(int), လော့ဂရစ်သမ်(float), တန်ဂျင့်(bool), စာရင်း(list),
အရာဝတ္ထု(dict), ဆိုင်(tuple), ရွေးချယ်(sorted), ပေါင်းလုံး(sum),
အမြင့်ဆုံး(max), အနိမ့်ဆုံး(min), သင်္ချာ(abs), မြှင့်တင်(round),
ရောကိုင်(enumerate), ဇကာ(zip), ဇယား(type), အမျိုးအစား(isinstance)...

### v6 Keywords
| Myanmar | Python |
|---------|--------|
| ပေး | yield |
| ပြန်လုပ်ပေး | yield from |
| များလိုက် | lambda |
| လက်မှတ်_ပေး | @decorate |
| ခွဲခြမ်းစိတ် | @property |
| ခန့်မှန်း | @staticmethod |
| ပုံ_အတန်း | @classmethod |
| ကျွန်ုပ်တည်ငြိမ် | @dataclass |
| အခြေခံ | @abstractmethod |

### v7 Keywords
| Myanmar | Python |
|---------|--------|
| မတူညီ | async |
| မျှော် | await |
| စာသေးခံ | assert |
| နုတ်ထုတ် | with |
| သတိမှတ်ပါ | describe |
| တင်သပ်ပါ | it |
| တွက်ချက်ပါ | expect |

### v8 Keywords
| Myanmar | Python |
|---------|--------|
| ကျန်ရမ်း | pass |
| ကြွင်းလဲ | global |
| ဒေသခံ | nonlocal |
| ဖျက်ပါ | del |
| ကျေးဇူးပြု | breakpoint |
| ပုံ_မှတ်တမ်း | repr |

## Standard Library Modules

### စွမ်းအင် (Math)
  ပြီးချင်း(sqrt), ရပ်အထိ(abs), ပမာဏ(ceil), ကုန်(floor),
  အားလုံး(pow), လွန်ချက်(log), အကြောင်း(sin), ကြည့်(cos),
  သကြား(tan), ကွက်လပ်(factorial), စစ်_ဆက်(gcd)

### လမ်းညွှန် (OS/Path)
  လမ်းညွှန်(join), ဖိုင်_ဖတ်(read_file), ဖိုင်ရေး(write_file),
  စာရင်း(listdir), ရှိမရှိ(exists), လမ်း_လေ့လာ(walk)

### အချိန်_ကိရိယာ (DateTime)
  လက်ရှိ(now), ပြောင်း(format), ရက်_အမည်(day_name),
  လ_အမည်(month_name), မြန်မာ_နှစ်(myanmar_year)

### အသစ်ပြောင်း (Random)
  အသစ်(random), အသစ်_ပေါင်း(randint), ရွေးချယ်(choice),
  ပြောင်း(shuffle)

### သတင်းစာ (JSON)
  ဖော်ပြ(dumps), ဖွင့်(loads), ဖော်ပြ_ဖိုင်(dump), ဖွင့်_ဖိုင်(load)

### ကွန်ပျူတာ (HTTP)
  ဖွင့်(get), ထိုင်(post), ပြောင်း(put), ဖျက်ပါ(delete), ခေါ်(fetch)

## GitHub Repository

LLVM-based native compiler: https://github.com/meonnmi-ops/mmc-compiler

## License

MIT License - Free to use, modify, and distribute.
Myanmar Code - Programming in Myanmar Language.
