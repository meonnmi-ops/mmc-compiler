#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MMC AI Server v4.0 - Myanmar Code Web IDE + AI Assistant
Author: MyanOS AI Team
"""

import json
import os
import sys
import threading
import urllib.request
import urllib.error
from http.server import HTTPServer, BaseHTTPRequestHandler

# Ensure transpiler is importable
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from mmc_transpiler import mmc_to_python, run_mmc

PORT = int(os.environ.get('MMC_PORT', 8080))
HOST = os.environ.get('MMC_HOST', '0.0.0.0')

# ============================================================
# MMC AI System Prompt
# ============================================================
MMC_SYSTEM_PROMPT = """You are MMC AI v4.0 - Myanmar Code Programming Language Assistant.

MMC Keywords (Myanmar -> Python):
- Variables: ကိန်း (var), အတည် (const), နေရာ (let)
- Control: အကယ်၍ (if), မဟုတ်ပါက (else), မဟုတ်လျှင် (elif)
- Loops: အတွက် (for), လုပ်နေစဉ် (while), ရပ် (break), ဆက်လုပ် (continue)
- Functions: အဓိပ္ပာယ် (def), ပြန်ပေး (return)
- Classes: အတန်း (class), ဒီ (self)
- I/O: ပုံနှိပ် (print), မေးမြန်း (input)
- Import: တင်သွင်း (import), မှ (from)
- Boolean: မှန် (True), မှား (False), မပါ (None)
- Error: ကြိုးစား (try), ဖမ်းမိ (except), နောက်ဆုံး (finally)
- Logic: ညီမျှလျှင် (and), သို့မဟုတ် (or), မဟုတ် (not)
- Built-in: အရှည် (len), ပတ်လမ်း (range), ကျပန်း (str), အချိန် (int), ဇယား (type), စာရင်း (list), အရာဝတ္ထု (dict), အဘိဓာန် (set), ဆိုင် (tuple), ပေါင်းလုံး (sum), အမြင့်ဆုံး (max), အနိမ့်ဆုံး (min), ရွေးချယ် (sorted), သင်္ချာ (abs)
- String methods: .စာလုံးကြီး (upper), .စာလုံးသေး (lower), .စမြည့် (capitalize), .ဆုံးမြည့် (title), .စာဆက် (join), .စာခွဲ (split), .ဖြတ် (strip), .အစားထိုး (replace)
- List methods: .နောက်ဆုံး_ထည့် (append), .ရှင် (pop), .စီ (sort), .ပြန်လဲ (reverse), .ထည့်သွင်း (insert)
- Dict methods: .ဝင်_အကွက် (keys), .ပြ_အကွက် (values), .အုပ်စု (items)
- File I/O: ဖွင့် (open), .ဖိုင်ဖတ် (read), .ဖိုင်ရေး (write), .ဖိုင်ဖျက် (close)
- Numbers: \u1040-\u1049 = 0-9
- Operators: + - * / ** // % = == != > < >= <= += -=

Rules:
- Respond in Myanmar language
- Use ```mmc for MMC code blocks
- Write correct MMC code
- Show Python equivalent when translating"""

# ============================================================
# HTML IDE
# ============================================================
HTML_PAGE = r"""<!DOCTYPE html>
<html lang="my">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>MMC AI v4.0 - Myanmar Code IDE</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{
  --bg:#0d1117;--surface:#161b22;--border:#30363d;
  --text:#c9d1d9;--text-dim:#8b949e;--accent:#58a6ff;
  --green:#3fb950;--red:#f85149;--yellow:#d29922;
  --purple:#bc8cff;--font-mono:'Cascadia Code','Fira Code','JetBrains Mono',Consolas,monospace;
}
body{font-family:var(--font-mono);background:var(--bg);color:var(--text);height:100vh;display:flex;flex-direction:column;overflow:hidden}
header{background:var(--surface);border-bottom:1px solid var(--border);padding:8px 16px;display:flex;align-items:center;gap:8px;flex-shrink:0;flex-wrap:wrap}
.logo{font-size:18px;font-weight:700;color:var(--accent);white-space:nowrap}
.logo span{color:var(--green)}
.toolbar{display:flex;gap:6px;align-items:center;flex-wrap:wrap;flex:1}
.btn{background:var(--border);color:var(--text);border:1px solid #444;border-radius:6px;padding:6px 14px;cursor:pointer;font-family:var(--font-mono);font-size:13px;transition:all .15s;white-space:nowrap}
.btn:hover{background:#444;border-color:#666}
.btn-run{background:#238636;border-color:#2ea043;color:#fff}
.btn-run:hover{background:#2ea043}
.btn-ai{background:#8957e5;border-color:#a371f7;color:#fff}
.btn-ai:hover{background:#a371f7}
.btn-danger{background:#da3633;border-color:#f85149;color:#fff}
.btn-danger:hover{background:#f85149}
select.sel{background:var(--surface);color:var(--text);border:1px solid var(--border);border-radius:6px;padding:6px 10px;font-family:var(--font-mono);font-size:13px;cursor:pointer}
.main{display:flex;flex:1;overflow:hidden}
.panel{display:flex;flex-direction:column;min-width:0}
.editor-panel{flex:1;border-right:1px solid var(--border);display:flex;flex-direction:column}
.output-panel{flex:1;display:flex;flex-direction:column}
.panel-header{background:var(--surface);border-bottom:1px solid var(--border);padding:6px 12px;display:flex;align-items:center;gap:8px;font-size:13px;flex-shrink:0}
.panel-header .title{color:var(--text-dim);font-weight:600;text-transform:uppercase;letter-spacing:.5px}
.tabs{display:flex;gap:0}
.tab{background:transparent;color:var(--text-dim);border:none;border-bottom:2px solid transparent;padding:6px 14px;cursor:pointer;font-family:var(--font-mono);font-size:13px;transition:all .15s}
.tab.active{color:var(--accent);border-bottom-color:var(--accent)}
.tab:hover{color:var(--text)}
textarea.editor{flex:1;background:var(--bg);color:var(--text);border:none;padding:16px;font-family:var(--font-mono);font-size:14px;line-height:1.6;resize:none;outline:none;tab-size:4}
.output-area{flex:1;background:var(--bg);padding:16px;overflow:auto;font-size:14px;line-height:1.6;white-space:pre-wrap;word-break:break-all}
.ai-bar{background:var(--surface);border-top:1px solid var(--border);padding:10px 12px;display:flex;gap:8px;flex-shrink:0}
.ai-bar input{flex:1;background:var(--bg);color:var(--text);border:1px solid var(--border);border-radius:6px;padding:8px 12px;font-family:var(--font-mono);font-size:14px;outline:none}
.ai-bar input:focus{border-color:var(--purple)}
footer{background:var(--surface);border-top:1px solid var(--border);padding:4px 16px;font-size:12px;color:var(--text-dim);display:flex;justify-content:space-between;align-items:center;flex-shrink:0}
.status-dot{display:inline-block;width:8px;height:8px;border-radius:50%;margin-right:6px}
.status-dot.on{background:var(--green)}
.status-dot.off{background:var(--red)}
.resize-handle{width:4px;cursor:col-resize;background:transparent;flex-shrink:0}
.resize-handle:hover{background:var(--accent)}
.example-popup{display:none;position:absolute;top:40px;left:0;background:var(--surface);border:1px solid var(--border);border-radius:8px;padding:6px 0;z-index:100;box-shadow:0 8px 24px rgba(0,0,0,.4);max-height:300px;overflow-y:auto}
.example-popup.show{display:block}
.example-popup a{display:block;padding:8px 16px;color:var(--text);text-decoration:none;font-size:13px;cursor:pointer;white-space:nowrap}
.example-popup a:hover{background:var(--border);color:var(--accent)}
.spinner{display:inline-block;width:14px;height:14px;border:2px solid var(--border);border-top-color:var(--accent);border-radius:50%;animation:spin .6s linear infinite;vertical-align:middle}
@keyframes spin{to{transform:rotate(360deg)}}
@media(max-width:768px){
  .main{flex-direction:column}
  .editor-panel{border-right:none;border-bottom:1px solid var(--border);height:50%}
  .output-panel{height:50%}
  .resize-handle{width:100%;height:4px;cursor:row-resize}
  .logo{font-size:14px}
  .btn{padding:5px 10px;font-size:12px}
  .toolbar{gap:4px}
}
.file-input-hidden{display:none}
</style>
</head>
<body>
<header>
  <div class="logo">MMC <span>AI</span> v4.0</div>
  <div class="toolbar">
    <button class="btn btn-run" onclick="runCode()" title="Run MMC Code (Ctrl+Enter)">▶ Run</button>
    <button class="btn" onclick="showPython()" title="Show Python Output">🐍 Python</button>
    <button class="btn" onclick="clearOutput()">🗑 Clear</button>
    <div style="position:relative">
      <button class="btn" onclick="toggleExamples()">📁 Examples</button>
      <div class="example-popup" id="examplePopup">
        <a onclick="loadExample('hello')">Hello World</a>
        <a onclick="loadExample('calculator')">Calculator</a>
        <a onclick="loadExample('loops')">For/While Loops</a>
        <a onclick="loadExample('fibonacci')">Fibonacci</a>
        <a onclick="loadExample('class_example')">Class Example</a>
        <a onclick="loadExample('error_handling')">Error Handling</a>
        <a onclick="loadExample('string_methods')">String Methods</a>
        <a onclick="loadExample('dict_operations')">Dict Operations</a>
      </div>
    </div>
    <button class="btn" onclick="openFile()">📂 Open</button>
    <button class="btn" onclick="saveFile()">💾 Save</button>
    <input type="file" id="fileInput" class="file-input-hidden" accept=".mmc" onchange="handleFile(event)">
    <select class="sel" id="themeSelect" onchange="changeFontSize(this.value)" title="Font Size">
      <option value="13">13px</option>
      <option value="14" selected>14px</option>
      <option value="16">16px</option>
      <option value="18">18px</option>
      <option value="20">20px</option>
    </select>
  </div>
</header>

<div class="main">
  <div class="panel editor-panel" id="editorPanel">
    <div class="panel-header">
      <span class="title">📝 Editor</span>
      <span id="fileName" style="color:var(--text-dim);font-size:12px">untitled.mmc</span>
    </div>
    <textarea class="editor" id="editor" spellcheck="false" placeholder="# Write your MMC code here...
# ဤနေရာတွင် MMC ကိုရေးပါ
# MMC AI v4.0 - Myanmar Code"></textarea>
  </div>
  <div class="resize-handle" id="resizeHandle"></div>
  <div class="panel output-panel" id="outputPanel">
    <div class="panel-header">
      <div class="tabs">
        <button class="tab active" onclick="switchTab('run',this)">▶ Run</button>
        <button class="tab" onclick="switchTab('python',this)">🐍 Python</button>
        <button class="tab" onclick="switchTab('ai',this)">🤖 AI</button>
      </div>
      <span id="runStatus" style="margin-left:auto;font-size:12px;color:var(--text-dim)"></span>
    </div>
    <div class="output-area" id="output">Welcome to MMC AI v4.0 IDE!
Write Myanmar code and press Run or Ctrl+Enter.

# မင်္ဂလာပါ ကမ္ဘာကြီး
ပုံနှိပ်("Hello World!")

Supported: 80+ keywords, OOP, Dict, Error Handling, File I/O
</div>
    <div class="ai-bar" id="aiBar" style="display:none">
      <input type="text" id="aiInput" placeholder="Ask MMC AI... (Myanmar Code questions)" onkeydown="if(event.key==='Enter')sendAI()">
      <button class="btn btn-ai" onclick="sendAI()" id="aiSendBtn">🤖 Ask</button>
    </div>
  </div>
</div>

<footer>
  <span><span class="status-dot off" id="ollamaDot"></span><span id="ollamaStatus">Checking Ollama...</span></span>
  <span>MMC v4.0 | Myanmar Code Programming Language</span>
</footer>

<script>
// State
let currentFile = 'untitled.mmc';
let aiMessages = [];
const EXAMPLES = {
  hello: '# Hello World Program\n# \u1000\u101b\u102b\u1015\u103a\u103b\u103d \u1000\u101b\u102c\u101e\u103c\u102d\u1033\u1015\n\u1015\u103b\u102c\u101e\u1019\u103d\u1014\u103a\u102f\u1036("\u1000\u101b\u102b\u1015\u103a\u103b\u103d \u1000\u101b\u102c\u101e\u103c\u102d\u1033\u1015!")',
  calculator: '# Calculator - \u1015\u103b\u1018\u101b\u1010\u103a\u1019\u103b\u103a\u1015\u103a\u101e\u1005\u103a\n\u1021\u1015\u1031\u1021\u103a\u103b\u1015\u1015\u103a add(a, b):\n    \u1015\u103b\u1000\u1014\u100a\u103a\u1015\u1031(a + b)\n\n\u1021\u1015\u1031\u1021\u103a\u103b\u1015\u1015\u103a subtract(a, b):\n    \u1015\u103b\u1000\u1014\u100a\u103a\u1015\u1031(a - b)\n\n\u1015\u103b\u102c\u101e\u1019\u103d\u1014\u103a\u102f\u1036("10 + 20 =", add(10, 20))\n\u1015\u103b\u102c\u101e\u1019\u103d\u1014\u103a\u102f\u1036("50 - 15 =", subtract(50, 15))',
  loops: '# Loops - \u1015\u103b\u1000\u103a\u1014\u103c\u1021\u1031\u1037\u1000\u1036\u1019\u103b\u102c\u1038\n\u1021\u1000\u103b\u103a\u1015\u103a i \u1014\u1000\u103a\u1031\u1005\u103a(5):\n    \u1015\u103b\u102c\u101e\u1019\u103d\u1014\u103a\u102f\u1036("For: " + \u1016\u102c\u1014\u100a\u103a\u1036(i))\n\n\u1000\u101b\u1015\u103a count = 0\n\u101c\u102c\u1015\u103a\u1014\u103a\u1015\u103a\u1000\u103b\u1015\u103a count < 3:\n    \u1015\u103b\u102c\u101e\u1019\u103d\u1014\u103a\u102f\u1036("While: " + \u1016\u102c\u1014\u100a\u103a\u1036(count))\n    count = count + 1',
  fibonacci: '# Fibonacci Sequence\n\u1021\u1015\u1031\u1021\u103a\u103b\u1015\u1015\u103a fibonacci(n):\n    \u1021\u1015\u1036\u101b\u103d\u1010\u103a n <= 1:\n        \u1015\u103b\u1000\u1014\u100a\u103a\u1015\u1031(n)\n    \u1015\u103b\u1000\u1014\u100a\u103a\u1015\u1031(fibonacci(n - 1) + fibonacci(n - 2))\n\n\u1021\u1000\u103b\u103a\u1015\u103a i \u1014\u1000\u103a\u1031\u1005\u103a(10):\n    \u1015\u103b\u102c\u101e\u1019\u103d\u1014\u103a\u102f\u1036(\u1016\u102c\u1014\u100a\u103a\u1036(i) + ": " + \u1016\u102c\u1014\u100a\u103a\u1036(fibonacci(i)))',
  class_example: '# OOP - \u1021\u101a\u103a\u1019\u1000\u103b\u1015\u103a\u101b\u103e\u102c\u1038\u1014\u100a\u103a\u1019\u102c\u1015\u103a\n\u1021\u1000\u103b\u1015\u103a Animal:\n    \u1021\u1015\u1031\u1021\u103a\u103b\u1015\u1015\u103a __init__(\u1012\u102e, name, sound):\n        \u1012\u102e.name = name\n        \u1012\u102e.sound = sound\n    \n    \u1021\u1015\u1031\u1021\u103a\u103b\u1015\u1015\u103a speak(\u1012\u102e):\n        \u1015\u103b\u102c\u101e\u1019\u103d\u1014\u103a\u102f\u1036(\u1012\u102e.name + " says " + \u1012\u102e.sound)\n\n\u1021\u1000\u103b\u1015\u103a Dog(Animal):\n    \u1021\u1015\u1031\u1021\u103a\u103b\u1015\u1015\u103a __init__(\u1012\u102e, name):\n        \u1012\u102e super().__init__(name, "Woof!")\n\ndog = Dog("Buddy")\ndog.speak()',
  error_handling: '# Error Handling - \u1021\u1000\u1036\u1019\u102c\u1014\u103a\u1000\u102d\u103d\u102f\u1030\u1015\u103c\u100a\u103a\u1019\u103b\u1015\u103a\n\u1000\u103b\u1019\u103e\u1014\u1001\u103a:\n    \u1000\u101b\u1015\u103a result = 10 / 0\n\u1015\u103c\u1014\u103a\u1000\u103a:\n    \u1015\u103b\u102c\u101e\u1019\u103d\u1014\u103a\u102f\u1036("Cannot divide by zero!")\n\u1014\u102a\u1015\u103a\u1000\u103b\u1015\u103a\u1000\u103c:\n    \u1015\u103b\u102c\u101e\u1019\u103d\u1014\u103a\u102f\u1036("Done.")',
  string_methods: '# String Methods - \u1005\u102c\u1014\u1036\u1019\u103c\u102d\u102f\u1036\u101c\u102c\u1015\u103a\u101d\u102d\u1014\u103a\u1021\u1000\u1036\u1019\u103b\u102c\u1038\n\u1000\u101b\u1015\u103a text = "Hello World"\n\n\u1015\u103b\u102c\u101e\u1019\u103d\u1014\u103a\u102f\u1036(text.\u1005\u102c\u1014\u1000\u103a\u1015\u103a\u101e\u103c\u102d\u1033())\n\u1015\u103b\u102c\u101e\u1019\u103d\u1014\u103a\u102f\u1036(text.\u1005\u102c\u1014\u1000\u103a\u1015\u103a\u1014\u103a\u1037())\n\u1015\u103b\u102c\u101e\u1019\u103d\u1014\u103a\u102f\u1036(text.\u1005\u1000\u103b\u101c\u103b\u103e\u1019\u103a())\n\u1015\u103b\u102c\u101e\u1019\u103d\u1014\u103a\u102f\u1036(text.\u1021\u1005\u102d\u1015\u103a\u1021\u101b\u102d\u103d\u1031("World", "Myanmar"))\n\u1015\u103b\u102c\u101e\u1019\u103d\u1014\u103a\u102f\u1036(text.\u1005\u102c\u101c\u1000\u103a(" "))',
  dict_operations: '# Dictionary - \u1021\u101b\u102c\u101e\u103c\u1005\u103a\u1031\u1001\u103a\u101c\u102c\u1015\u103a\u101d\u102d\u1014\u103a\u1021\u1000\u1036\u1019\u103b\u102c\u1038\n\u1000\u101b\u1015\u103a student = {"name": "Aung", "age": 20, "grade": "A"}\n\n\u1015\u103b\u102c\u101e\u1019\u103d\u1014\u103a\u102f\u1036("Name: " + student["name"])\n\u1015\u103b\u102c\u101e\u1019\u103d\u1014\u103a\u102f\u1036("Keys: " + \u1016\u102c\u1014\u100a\u103a\u1036(student.\u1000\u102d\u103d_\u1021\u1000\u103b\u1015\u103a()))\n\u1015\u103b\u102c\u101e\u1019\u103d\u1014\u103a\u102f\u1036("Values: " + \u1016\u102c\u1014\u100a\u103a\u1036(student.\u1015\u103b\u1000_\u1021\u1000\u103b\u1015\u103a()))\n\n\u1021\u1000\u103b\u103a\u1015\u103a key, value \u1014\u103e\u1014\u103a student.\u1021\u101a\u103a\u1015\u103a\u1018\u103a():\n    \u1015\u103b\u102c\u101e\u1019\u103d\u1014\u103a\u102f\u1036(\u1016\u102c\u1014\u100a\u103a\u1036(key) + " = " + \u1016\u102c\u1014\u100a\u103a\u1036(value))'
};

const editor = document.getElementById('editor');
const output = document.getElementById('output');
const aiBar = document.getElementById('aiBar');
const aiInput = document.getElementById('aiInput');

// Keyboard shortcut
editor.addEventListener('keydown', function(e) {
  if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
    e.preventDefault();
    runCode();
  }
  // Tab support
  if (e.key === 'Tab') {
    e.preventDefault();
    const s = this.selectionStart, end = this.selectionEnd;
    this.value = this.value.substring(0, s) + '    ' + this.value.substring(end);
    this.selectionStart = this.selectionEnd = s + 4;
  }
});

function switchTab(name, btn) {
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  btn.classList.add('active');
  aiBar.style.display = name === 'ai' ? 'flex' : 'none';
}

function toggleExamples() {
  document.getElementById('examplePopup').classList.toggle('show');
}
document.addEventListener('click', function(e) {
  if (!e.target.closest('.toolbar')) {
    document.getElementById('examplePopup').classList.remove('show');
  }
});

function loadExample(name) {
  editor.value = EXAMPLES[name] || '';
  currentFile = name + '.mmc';
  document.getElementById('fileName').textContent = currentFile;
  document.getElementById('examplePopup').classList.remove('show');
}

function openFile() {
  document.getElementById('fileInput').click();
}
function handleFile(e) {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = function(ev) {
    editor.value = ev.target.result;
    currentFile = file.name;
    document.getElementById('fileName').textContent = currentFile;
  };
  reader.readAsText(file);
  e.target.value = '';
}
function saveFile() {
  const blob = new Blob([editor.value], {type: 'text/plain;charset=utf-8'});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = currentFile;
  a.click();
  URL.revokeObjectURL(a.href);
}

function changeFontSize(size) {
  editor.style.fontSize = size + 'px';
  output.style.fontSize = size + 'px';
}

function clearOutput() {
  output.textContent = '';
  document.getElementById('runStatus').textContent = '';
}

async function apiCall(url, data) {
  const resp = await fetch(url, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify(data)
  });
  return resp.json();
}

async function runCode() {
  const code = editor.value;
  if (!code.trim()) return;
  document.getElementById('runStatus').innerHTML = '<span class="spinner"></span> Running...';
  try {
    const res = await apiCall('/api/run', {code});
    switchTab('run', document.querySelectorAll('.tab')[0]);
    let text = '';
    if (res.output) text += res.output;
    if (res.error) text += (text ? '\n' : '') + '\x1b[31m' + res.error;
    output.textContent = text || '(no output)';
    document.getElementById('runStatus').textContent = res.error ? '❌ Error' : '✅ Done';
    document.getElementById('runStatus').style.color = res.error ? 'var(--red)' : 'var(--green)';
  } catch(e) {
    output.textContent = 'Server error: ' + e.message;
    document.getElementById('runStatus').textContent = '❌ Failed';
    document.getElementById('runStatus').style.color = 'var(--red)';
  }
}

async function showPython() {
  const code = editor.value;
  if (!code.trim()) return;
  try {
    const res = await apiCall('/api/python', {code});
    switchTab('python', document.querySelectorAll('.tab')[1]);
    output.textContent = res.python || '(no output)';
  } catch(e) {
    output.textContent = 'Error: ' + e.message;
  }
}

async function sendAI() {
  const msg = aiInput.value.trim();
  if (!msg) return;
  aiInput.value = '';
  output.textContent += '\n🧑 ' + msg + '\n\n';
  aiInput.disabled = true;
  document.getElementById('aiSendBtn').innerHTML = '<span class="spinner"></span>';
  try {
    const res = await apiCall('/api/ai', {message: msg, history: aiMessages});
    const reply = res.reply || '(no response)';
    aiMessages.push({role:'user',content:msg},{role:'assistant',content:reply});
    output.textContent += '🤖 ' + reply + '\n\n';
  } catch(e) {
    output.textContent += '❌ Error: ' + e.message + '\n\n';
  }
  aiInput.disabled = false;
  document.getElementById('aiSendBtn').textContent = '🤖 Ask';
  output.scrollTop = output.scrollHeight;
}

// Check Ollama status
async function checkOllama() {
  try {
    const res = await fetch('/api/ollama-status');
    const data = await res.json();
    const dot = document.getElementById('ollamaDot');
    const txt = document.getElementById('ollamaStatus');
    if (data.running) {
      dot.className = 'status-dot on';
      txt.textContent = 'Ollama: Connected' + (data.models ? ' (' + data.models + ')' : '');
    } else {
      dot.className = 'status-dot off';
      txt.textContent = 'Ollama: Not running';
    }
  } catch(e) {
    document.getElementById('ollamaDot').className = 'status-dot off';
    document.getElementById('ollamaStatus').textContent = 'Ollama: Offline';
  }
}
checkOllama();
setInterval(checkOllama, 15000);

// Resize handle
(function() {
  const handle = document.getElementById('resizeHandle');
  const ep = document.getElementById('editorPanel');
  const op = document.getElementById('outputPanel');
  let dragging = false, startX, startW;
  handle.addEventListener('mousedown', function(e) {
    dragging = true; startX = e.clientX;
    startW = ep.getBoundingClientRect().width;
    document.body.style.cursor = 'col-resize';
    document.body.style.userSelect = 'none';
  });
  document.addEventListener('mousemove', function(e) {
    if (!dragging) return;
    const dx = e.clientX - startX;
    const total = ep.parentElement.getBoundingClientRect().width;
    const newW = Math.max(200, Math.min(total - 200, startW + dx));
    ep.style.flex = 'none';
    ep.style.width = newW + 'px';
    op.style.flex = '1';
  });
  document.addEventListener('mouseup', function() {
    if (dragging) {
      dragging = false;
      document.body.style.cursor = '';
      document.body.style.userSelect = '';
    }
  });
})();
</script>
</body>
</html>"""

# ============================================================
# HTTP Handler
# ============================================================
class MMCHandler(BaseHTTPRequestHandler):
    """MMC AI Server HTTP request handler."""

    def log_message(self, format, *args):
        """Quieter logging."""
        sys.stderr.write(f"[MMC] {args[0]}\n")

    def _send_json(self, data, status=200):
        body = json.dumps(data, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(body)

    def _send_html(self):
        body = HTML_PAGE.encode('utf-8')
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read_body(self):
        length = int(self.headers.get('Content-Length', 0))
        if length == 0:
            return {}
        raw = self.rfile.read(length)
        return json.loads(raw.decode('utf-8'))

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

    def do_GET(self):
        if self.path == '/' or self.path == '/index.html':
            self._send_html()

        elif self.path == '/api/ollama-status':
            running = False
            models = []
            try:
                req = urllib.request.Request(
                    'http://localhost:11434/api/tags',
                    headers={'Content-Type': 'application/json'}
                )
                with urllib.request.urlopen(req, timeout=3) as resp:
                    data = json.loads(resp.read().decode())
                    running = True
                    models = [m.get('name', '') for m in data.get('models', [])]
            except Exception:
                pass
            self._send_json({
                'running': running,
                'models': ', '.join(models[:5]) if models else ''
            })

        else:
            self.send_response(404)
            self.send_header('Content-Type', 'text/plain')
            self.end_headers()
            self.wfile.write(b'404 Not Found')

    def do_POST(self):
        try:
            body = self._read_body()
        except Exception as e:
            self._send_json({'error': f'Invalid JSON: {e}'}, 400)
            return

        if self.path == '/api/run':
            code = body.get('code', '')
            stdout, stderr, exit_code, py_code = run_mmc(code)
            self._send_json({
                'output': stdout,
                'error': stderr,
                'python': py_code,
                'exit_code': exit_code
            })

        elif self.path == '/api/python':
            code = body.get('code', '')
            try:
                py_code = mmc_to_python(code)
                self._send_json({'python': py_code})
            except Exception as e:
                self._send_json({'python': '', 'error': str(e)})

        elif self.path == '/api/ai':
            message = body.get('message', '')
            history = body.get('history', [])

            # Build messages for Ollama
            messages = [{'role': 'system', 'content': MMC_SYSTEM_PROMPT}]
            for h in history[-10:]:  # Keep last 10 messages for context
                messages.append({'role': h['role'], 'content': h['content']})
            messages.append({'role': 'user', 'content': message})

            try:
                req_data = json.dumps({
                    'model': 'mmc-ai',
                    'messages': messages,
                    'stream': False
                }).encode('utf-8')

                req = urllib.request.Request(
                    'http://localhost:11434/api/chat',
                    data=req_data,
                    headers={'Content-Type': 'application/json'}
                )

                with urllib.request.urlopen(req, timeout=60) as resp:
                    result = json.loads(resp.read().decode())
                    reply = result.get('message', {}).get('content', 'No response')
                    self._send_json({'reply': reply})

            except urllib.error.URLError:
                self._send_json({
                    'reply': 'Ollama server not running. Please start Ollama first:\n  ollama serve\nThen create model:\n  ollama create mmc-ai -f Modelfile\nOr run install.sh'
                })
            except urllib.error.HTTPError as e:
                err_body = e.read().decode() if e.fp else ''
                self._send_json({
                    'reply': f'Ollama error ({e.code}): {err_body}\n\nMake sure mmc-ai model exists:\n  ollama create mmc-ai -f Modelfile'
                })
            except Exception as e:
                self._send_json({'reply': f'Error: {str(e)}'})

        else:
            self.send_response(404)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps({'error': 'Not found'}).encode())


# ============================================================
# Main
# ============================================================
def main():
    print(f"""
╔══════════════════════════════════════════════════╗
║          MMC AI v4.0 - Myanmar Code IDE          ║
║                                                  ║
║  Server:  http://{HOST}:{PORT}                    ║
║  Transpiler: mmc_transpiler.py                    ║
║  AI Model:  Ollama (mmc-ai)                      ║
║                                                  ║
║  Press Ctrl+C to stop                             ║
╚══════════════════════════════════════════════════╝
""")
    server = HTTPServer((HOST, PORT), MMCHandler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nMMC AI Server stopped.")
        server.server_close()


if __name__ == '__main__':
    main()
