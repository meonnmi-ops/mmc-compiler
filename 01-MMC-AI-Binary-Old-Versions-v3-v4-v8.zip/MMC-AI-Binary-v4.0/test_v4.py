#!/usr/bin/env python3
import sys
sys.path.insert(0, '/home/z/my-project/download/MMC-AI-Binary-v4.0')
from mmc_transpiler import mmc_to_python, run_mmc

p = 0; f = 0
def t(n, c, eo=None):
    global p, f
    py = mmc_to_python(c)
    o, e, rc, _ = run_mmc(c)
    ok = (eo is None or eo in o)
    if ok: p += 1
    else: f += 1
    s = 'PASS' if ok else 'FAIL'
    print(f'  [{s}] {n}')
    if not ok:
        print(f'    Py: {repr(py[:200])}')
        print(f'    Out: {repr(o[:100])}| Err: {repr(e[:100])}')

print('=== MMC v4.0 Tests ===')
t('Hello', 'ပုံနှိပ်("Hello")', 'Hello')
t('Var', 'ကိန်း x = 10\nပုံနှိပ်(x)', '10')
t('If/Else', 'ကိန်း x = 5\nအကယ်၍ x > 10:\n    ပုံနှိပ်("big")\nမဟုတ်ပါက:\n    ပုံနှိပ်("small")', 'small')
t('Elif', 'ကိန်း x = 5\nအကယ်၍ x > 10:\n    ပုံနှိပ်("a")\nမဟုတ်လျှင် x > 3:\n    ပုံနှိပ်("b")\nမဟုတ်ပါက:\n    ပုံနှိပ်("c")', 'b')
t('For', 'အတွက် i ပတ်လမ်း(3):\n    ပုံနှိပ်(i)', '0\n1\n2')
t('While', 'ကိန်း i = 0\nလုပ်နေစဉ် i < 3:\n    ပုံနှိပ်(i)\n    i = i + 1', '0\n1\n2')
t('Break', 'အတွက် i ပတ်လမ်း(10):\n    အကယ်၍ i == 3:\n        ရပ်\n    ပုံနှိပ်(i)', '0\n1\n2')
t('Continue', 'အတွက် i ပတ်လမ်း(5):\n    အကယ်၍ i == 2:\n        ဆက်လုပ်\n    ပုံနှိပ်(i)', '0\n1\n3\n4')
t('Func', 'အဓိပ္ပာယ် hello():\n    ပုံနှိပ်("Hi")\nhello()', 'Hi')
t('Func args', 'အဓိပ္ပာယ် add(a, b):\n    ပြန်ပေး(a + b)\nပုံနှိပ်(add(3, 5))', '8')
t('Recursion', 'အဓိပ္ပာယ် f(n):\n    အကယ်၍ n <= 1:\n        ပြန်ပေး 1\n    ပြန်ပေး n * f(n - 1)\nပုံနှိပ်(f(5))', '120')
t('Class', 'အတန်း Dog:\n    အဓိပ္ပာယ် __init__(ဒီ, name):\n        ဒီ.name = name\n    အဓိပ္ပာယ် bark(ဒီ):\n        ပုံနှိပ်(ဒီ.name + " Woof")\nd = Dog("Rex")\nd.bark()', 'Rex Woof')
t('Inherit', 'အတန်း Animal:\n    အဓိပ္ပာယ် speak(ဒီ):\n        ပြန်ပေး "..."\nအတန်း Cat(Animal):\n    အဓိပ္ပာယ် speak(ဒီ):\n        ပြန်ပေး "Meow"\nc = Cat()\nပုံနှိပ်(c.speak())', 'Meow')
t('Dict', 'ကိန်း d = {"a": 1}\nပုံနှိပ်(d["a"])', '1')
t('upper', 'ကိန်း s = "hello"\nပုံနှိပ်(s.စာလုံးကြီး())', 'HELLO')
t('append', 'ကိန်း a = [1]\na.နောက်ဆုံး_ထည့်(2)\nပုံနှိပ်(a)', '[1, 2]')
t('sort', 'ကိန်း a = [3, 1, 2]\na.စီ()\nပုံနှိပ်(a)', '[1, 2, 3]')
t('try/except', 'ကြိုးစား:\n    x = 1 / 0\nဖမ်းမိ:\n    ပုံနှိပ်("error")', 'error')
t('Fibonacci', 'အဓိပ္ပာယ် fib(n):\n    အကယ်၍ n <= 1:\n        ပြန်ပေး n\n    ပြန်ပေး fib(n-1) + fib(n-2)\nပုံနှိပ်(fib(10))', '55')
t('replace', 'ကိန်း s = "abc"\nပုံနှိပ်(s.အစားထိုး("b", "X"))', 'aXc')
t('split', 'ကိန်း s = "a,b,c"\nပုံနှိပ်(s.စာခွဲ(","))', None)
t('sum/max/min', 'ပုံနှိပ်(ပေါင်းလုံး([1,2,3]))\nပုံနှိပ်(အမြင့်ဆုံး([1,5,3]))\nပုံနှိပ်(အနိမ့်ဆုံး([1,5,3]))', '6\n3\n1')
t('abs/round', 'ပုံနှိပ်(သင်္ချာ(-7))\nပုံနှိပ်(မြှင့်တင်(3.14, 2))', '7\n3.14')
t('sorted', 'ပုံနှိပ်(ရွေးချယ်([3,1,2]))', '[1, 2, 3]')
t('dict keys/values', 'ကိန်း d = {"x": 10}\nပုံနှိပ်(d.ဝင်_အကွက်())\nပုံနှိပ်(d.ပြ_အကွက်())', None)
t('list reverse', 'ကိန်း a = [1,2]\na.ပြန်လဲ()\nပုံနှိပ်(a)', '[2, 1]')
print(f'\n=== Results: {p} passed, {f} failed ===')
