#!/usr/bin/env bash
echo "MMC AI v4.0 - Installing..."
mkdir -p ~/mmc-ai && cd ~/mmc-ai

# Install Python if needed
if ! command -v python3 &> /dev/null; then
    if [ -n "$TERMUX_VERSION" ]; then
        pkg update -y && pkg install python -y
    else
        sudo apt update -y && sudo apt install python3 -y
    fi
fi

# Install/Start Ollama
if ! command -v ollama &> /dev/null; then
    curl -fsSL https://ollama.com/install.sh | sh
fi
if ! curl -s http://localhost:11434/api/tags > /dev/null 2>&1; then
    ollama serve > /dev/null 2>&1 &
    sleep 3
fi

# Pull model & create MMC AI
ollama pull qwen2.5:1.5b 2>/dev/null
ollama create mmc-ai -f - <<'EOF'
FROM qwen2.5:1.5b
PARAMETER temperature 0.6
PARAMETER num_ctx 4096
SYSTEM """You are MMC AI v4.0. Myanmar Code Programming Language Assistant. Respond in Myanmar. Use mmc code blocks."""
EOF

echo ""
echo "Setup Complete!"
echo "Run: cd ~/mmc-ai && python mmc_ai_server.py"
echo "Open: http://localhost:8080"
