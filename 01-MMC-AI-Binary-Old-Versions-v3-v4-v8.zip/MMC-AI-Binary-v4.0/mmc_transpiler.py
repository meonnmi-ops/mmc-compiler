#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MMC Transpiler v4.0
Myanmar Code (MMC) -> Python 3

Complete rewrite with:
- Smart token spacing (dot notation, method calls)
- Dictionary/Map support
- Error Handling (try/except/finally)
- File I/O
- Import system
- OOP (classes, inheritance, methods)
- String/List/Dict methods
- Standard library bridge
- Myanmar digits (၀-၉)
- Comprehensive keyword mapping

Author: MyanOS AI Team
Version: 4.0.0
"""

import re
import sys
import io
import traceback

# ============================================================
# Keyword Categories
# ============================================================

# Statements - translate to Python keywords
STMT_KEYWORDS = {
    'အကယ်၍': 'if',
    'မဟုတ်ပါက': 'else',
    'မဟုတ်လျှင်': 'elif',
    'အတွက်': 'for',
    'လုပ်နေစဉ်': 'while',
    'ရပ်': 'break',
    'ဆက်လုပ်': 'continue',
    'အဓိပ္ပာယ်': 'def',
    'လုပ်ဆောင်ချက်': 'def',
    'ပြန်ပေး': 'return',
    'အတန်း': 'class',
    'တင်သွင်း': 'import',
    'မှ': 'from',
    'ကူးယူပါ': 'import',
    'ကြိုးစား': 'try',
    'ဖမ်းမိ': 'except',
    'နောက်ဆုံး': 'finally',
    'ချမြှောက်': 'raise',
    'မတူညီ': 'async',
    'မျှော်': 'await',
    'ညီမျှလျှင်': 'and',
    'သို့မဟုတ်': 'or',
    'မဟုတ်': 'not',
    'ဖြစ်ပြီး': 'while',
    'အဖြစ်': 'as',
}

# Function calls - translate and wrap with parentheses
FUNC_KEYWORDS = {
    'ပုံနှိပ်': 'print',
    'မေးမြန်း': 'input',
    'အရှည်': 'len',
    'ဇယား': 'type',
    'ကျပန်း': 'str',
    'အချိန်': 'int',
    'လော့ဂရစ်သမ်': 'float',
    'တန်ဂျင့်': 'bool',
    'စာရင်း': 'list',
    'အရာဝတ္ထု': 'dict',
    'အဘိဓာန်': 'set',
    'ဆိုင်': 'tuple',
    'ပတ်လမ်း': 'range',
    'သင်္ချာ': 'abs',
    'အမြင့်ဆုံး': 'max',
    'အနိမ့်ဆုံး': 'min',
    'ပေါင်းလုံး': 'sum',
    'ရွေးချယ်': 'sorted',
    'ပြဿနာ': 'map',
    'ကုလသိုက်': 'filter',
    'ဟိုပ်': 'hex',
    'ဒုန်းလံ': 'bin',
    'ခဲမစ်တီ': 'hash',
    'အID': 'id',
    'ရောကိုင်': 'enumerate',
    'ဇကာ': 'zip',
    'မြှင့်တင်': 'round',
    'ဖန်တီး': 'chr',
    'စကားလုံး': 'ord',
    'ဖွင့်': 'open',
    'ထည့်သွင်း_ဖိုင်': 'import_module',
}

# Value keywords
VALUE_KEYWORDS = {
    'မှန်': 'True',
    'မှား': 'False',
    'မပါ': 'None',
    'ဒီ': 'self',
    'အထက်': 'super()',
}

# Variable type hints (skip - Python doesn't need var/let/const)
SKIP_KEYWORDS = {'ကိန်း', 'အတည်', 'နေရာ'}

# Method names (used after dot: object.method())
METHOD_KEYWORDS = {
    # String methods
    'စာလုံးကြီး': 'upper',
    'စာလုံးသေး': 'lower',
    'စမြည့်': 'capitalize',
    'ဆုံးမြည့်': 'title',
    'စာဆက်': 'join',
    'စာခွဲ': 'split',
    'ဖြတ်': 'strip',
    'အစားထိုး': 'replace',
    'ရှာဖွေ': 'find',
    'အမှန်နေ': 'isalpha',
    'ဂဏန်းဖြစ်': 'isdigit',
    'စာသားဖြစ်': 'isalnum',
    'အသားဖြစ်': 'isupper',
    'သေးဖြစ်': 'islower',
    'ပိုင်ဆိုင်': 'startswith',
    'ပြီးဆုံးဖြစ်': 'endswith',
    'အရှည်_စာရင်း': 'splitlines',
    'ကျေးဇူးပါ': 'center',
    'ဘယ်ကဲ့': 'ljust',
    'ညာကဲ့': 'rjust',
    'ဖော်ပြ': 'format',
    'ကိုယ်ပိုင်': 'encode',
    'ဖွင့်ထုတ်': 'decode',

    # List methods
    'ထည့်သွင်း': 'insert',
    'စီ': 'sort',
    'ရှင်းလင်း': 'clear',
    'ပြန်လဲ': 'reverse',
    'အမြင့်ပြဦး': 'index',
    'ရှိမရှိ': 'count',
    'အရှည်_ထည့်': 'extend',
    'ပုံ_ပြောင်း': 'copy',
    'ရှင်း': 'pop',
    'နောက်ဆုံး_ထည့်': 'append',

    # Dict methods
    'ဝင်_အကွက်': 'keys',
    'ပြ_အကွက်': 'values',
    'အုပ်စု': 'items',
    'ဖော်ပြ_ရှိမရှိ': 'get',
    'ချက်_ဖော်ပြ': 'popitem',
    'ပြန်လဲ_ပုံ': 'update',
    'မှတ်သား': 'setdefault',

    # Set methods
    'ပေါင်းပါ': 'union',
    'တူနေ_အပေါ်': 'intersection',
    'မတူနေ': 'difference',
    'ပါဝင်': 'add',
    'ဖယ်ရှား': 'discard',
    'ရှိမရှိ_ပါ': 'issubset',

    # File methods
    'ဖိုင်ဖတ်': 'read',
    'ဖိုင်ရေး': 'write',
    'ဖိုင်ဖျက်': 'close',
    'ဖိုင်စုံ': 'readlines',
    'ဖိုင်လမ်း': 'readline',
    'ဖိုင်_ပြောင်း': 'flush',
}

# All keywords combined for quick lookup
ALL_KEYWORDS = {}
ALL_KEYWORDS.update(STMT_KEYWORDS)
ALL_KEYWORDS.update(FUNC_KEYWORDS)
ALL_KEYWORDS.update(VALUE_KEYWORDS)
ALL_KEYWORDS.update(METHOD_KEYWORDS)
for k in SKIP_KEYWORDS:
    ALL_KEYWORDS[k] = ''

# Myanmar digits
MYANMAR_DIGITS = {
    '၀': '0', '၁': '1', '၂': '2', '၃': '3', '၄': '4',
    '၅': '5', '၆': '6', '၇': '7', '၈': '8', '၉': '9',
}


# ============================================================
# Tokenizer
# ============================================================

class Token:
    """MMC token."""
    __slots__ = ('type', 'value', 'line', 'col')

    def __init__(self, type_, value, line=0, col=0):
        self.type = type_
        self.value = value
        self.line = line
        self.col = col

    def __repr__(self):
        return f"Token({self.type}, {self.value!r})"


def tokenize(source):
    """Tokenize MMC source code into a list of Token objects."""
    tokens = []
    i = 0
    line = 1
    col = 1

    while i < len(source):
        ch = source[i]

        # Newline
        if ch == '\n':
            tokens.append(Token('NEWLINE', '\n', line, col))
            line += 1
            col = 1
            i += 1
            continue

        # Whitespace
        if ch in ' \t\r':
            i += 1
            col += 1
            continue

        # Comment
        if ch == '#':
            j = i
            while j < len(source) and source[j] != '\n':
                j += 1
            tokens.append(Token('COMMENT', source[i:j], line, col))
            col += j - i
            i = j
            continue

        # String literals
        if ch in ('"', "'"):
            j = i + 1
            while j < len(source) and source[j] != ch:
                if source[j] == '\\':
                    j += 1
                j += 1
            j = min(j + 1, len(source))
            tokens.append(Token('STRING', source[i:j], line, col))
            col += j - i
            i = j
            continue

        # Triple-quoted strings (""" or ''')
        if source[i:i+3] in ('"""', "'''"):
            quote = source[i:i+3]
            j = i + 3
            while j < len(source) - 2:
                if source[j:j+3] == quote:
                    j += 3
                    break
                if source[j] == '\n':
                    line += 1
                    col = 1
                j += 1
            else:
                j = len(source)
            tokens.append(Token('STRING', source[i:j], line, col))
            col += j - i
            i = j
            continue

        # Numbers (including Myanmar digits)
        if ch.isdigit() or ch in MYANMAR_DIGITS:
            j = i
            while j < len(source) and (source[j].isdigit() or source[j] in MYANMAR_DIGITS or source[j] == '.'):
                j += 1
            num = source[i:j]
            # Convert Myanmar digits
            for my, ar in MYANMAR_DIGITS.items():
                num = num.replace(my, ar)
            tokens.append(Token('NUMBER', num, line, col))
            col += j - i
            i = j
            continue

        # Multi-char operators
        two = source[i:i+2] if i + 1 < len(source) else ''
        three = source[i:i+3] if i + 2 < len(source) else ''

        if three in ('**=', '//=', 'not'):
            tokens.append(Token('OP', three, line, col))
            i += 3
            col += 3
            continue

        if two in ('==', '!=', '>=', '<=', '+=', '-=', '*=', '/=', '%=',
                    '**', '//', '->', '<<', '>>', '&&', '||'):
            tokens.append(Token('OP', two, line, col))
            i += 2
            col += 2
            continue

        # Single-char operators and punctuation
        if ch in '=!<>+-*/%()[]{}:,.;@\\~^&|?':
            tokens.append(Token('OP', ch, line, col))
            i += 1
            col += 1
            continue

        # Identifiers / Myanmar words
        if ch.isalpha() or ch == '_' or ord(ch) > 0x1000:
            j = i
            while j < len(source) and (
                source[j].isalnum() or source[j] == '_' or
                ord(source[j]) > 0x1000 or source[j] in MYANMAR_DIGITS
            ):
                j += 1
            word = source[i:j]
            # Convert Myanmar digits within identifiers
            for my, ar in MYANMAR_DIGITS.items():
                word = word.replace(my, ar)
            tokens.append(Token('WORD', word, line, col))
            col += j - i
            i = j
            continue

        # Unknown
        tokens.append(Token('UNKNOWN', ch, line, col))
        i += 1
        col += 1

    return tokens


# ============================================================
# Translator: MMC Source -> Python Source (Line-by-Line)
# ============================================================

def translate_to_python(tokens):
    """Translate MMC token list to Python source code."""
    lines = []
    current_tokens = []

    for tok in tokens:
        if tok.type == 'NEWLINE':
            if current_tokens:
                line_str = _tokens_to_str(current_tokens)
                lines.append(line_str)
            else:
                lines.append('')
            current_tokens = []
        elif tok.type == 'COMMENT':
            if not current_tokens:
                lines.append(tok.value)
            # else: inline comment handled in _tokens_to_str
        else:
            current_tokens.append(tok)

    if current_tokens:
        line_str = _tokens_to_str(current_tokens)
        lines.append(line_str)

    return '\n'.join(lines)


def _tokens_to_str(tokens):
    """Convert a list of tokens to a translated Python string."""
    if not tokens:
        return ''

    py_parts = _translate_tokens(tokens)
    return _smart_join(py_parts)


def _translate_tokens(tokens):
    """Translate a list of tokens to Python parts."""
    parts = []
    i = 0
    after_dot = False  # Track if previous token was a dot

    while i < len(tokens):
        tok = tokens[i]

        # Skip COMMENT tokens (handled elsewhere)
        if tok.type == 'COMMENT':
            i += 1
            continue

        # String literals - pass through
        if tok.type == 'STRING':
            parts.append(tok.value)
            i += 1
            after_dot = False
            continue

        # Numbers
        if tok.type == 'NUMBER':
            parts.append(tok.value)
            i += 1
            after_dot = False
            continue

        # Operators
        if tok.type == 'OP':
            parts.append(tok.value)
            after_dot = (tok.value == '.')
            i += 1
            continue

        # Words (identifiers/keywords)
        if tok.type == 'WORD':
            word = tok.value

            # Skip keywords (var/let/const)
            if word in SKIP_KEYWORDS:
                i += 1
                continue

            # Value keywords
            if word in VALUE_KEYWORDS:
                parts.append(VALUE_KEYWORDS[word])
                i += 1
                after_dot = False
                continue

            # After dot - check for method name
            if after_dot and word in METHOD_KEYWORDS:
                parts.append(METHOD_KEYWORDS[word])
                i += 1
                after_dot = False
                continue

            # Function call keywords
            if word in FUNC_KEYWORDS:
                py_name = FUNC_KEYWORDS[word]
                i += 1
                # Check if next token is ( - user provided parens
                if i < len(tokens) and tokens[i].value == '(':
                    parts.append(py_name)
                    parts.append('(')
                    i += 1
                    # Collect everything until matching )
                    depth = 1
                    inner_parts = []
                    while i < len(tokens) and depth > 0:
                        t = tokens[i]
                        if t.value == '(':
                            depth += 1
                        elif t.value == ')':
                            depth -= 1
                            if depth == 0:
                                inner_py = _smart_join(_translate_tokens(inner_parts))
                                parts.append(inner_py)
                                parts.append(')')
                                i += 1
                                break
                        inner_parts.append(t)
                        i += 1
                else:
                    # No parens - collect remaining tokens as args
                    args = []
                    while i < len(tokens):
                        args.append(tokens[i])
                        i += 1
                    if args:
                        args_py = _smart_join(_translate_tokens(args))
                        parts.append(f"{py_name}({args_py})")
                    else:
                        parts.append(f"{py_name}()")
                after_dot = False
                continue

            # Statement keywords
            if word in STMT_KEYWORDS:
                py_kw = STMT_KEYWORDS[word]

                # Special handling for 'for' - insert 'in'
                if py_kw == 'for':
                    parts.append('for')
                    i += 1
                    # variable name
                    if i < len(tokens):
                        parts.append(_translate_single_token(tokens[i]))
                        i += 1
                    parts.append('in')
                    after_dot = False
                    continue

                parts.append(py_kw)
                i += 1
                after_dot = False
                continue

            # Regular identifier - pass through
            parts.append(word)
            i += 1
            after_dot = False
            continue

        # Fallback
        parts.append(str(tok.value))
        i += 1
        after_dot = False

    return parts


def _translate_single_token(tok):
    """Translate a single token."""
    if tok.type == 'WORD' and tok.value in ALL_KEYWORDS:
        if tok.value in SKIP_KEYWORDS:
            return ''
        if tok.value in VALUE_KEYWORDS:
            return VALUE_KEYWORDS[tok.value]
        if tok.value in STMT_KEYWORDS:
            return STMT_KEYWORDS[tok.value]
        if tok.value in FUNC_KEYWORDS:
            return FUNC_KEYWORDS[tok.value]
        if tok.value in METHOD_KEYWORDS:
            return METHOD_KEYWORDS[tok.value]
    return tok.value


def _smart_join(parts):
    """Join Python parts with smart spacing."""
    if not parts:
        return ''

    parts = [p for p in parts if p]
    result = [parts[0]]

    for i in range(1, len(parts)):
        prev = result[-1]
        curr = parts[i]

        # No space around dot
        if prev == '.' or curr == '.':
            result.append(curr)
            continue

        # No space before/after parens and brackets
        if curr in ('(', '[') or prev in ('(', '['):
            result.append(curr)
            continue

        # No space before ) ]
        if curr in (')', ']'):
            result.append(curr)
            continue

        # No space after ) ] before next token
        if prev in (')', ']'):
            result.append(' ' + curr)
            continue

        # No space before/after , : ;
        if curr in (',', ';', ':'):
            result.append(curr)
            continue

        # No space after operator before number
        if prev in ('+', '-', '*', '/', '%', '=', '!', '<', '>', '&', '|', '^'):
            result.append(curr)
            continue

        # Default: space
        result.append(' ' + curr)

    return ''.join(result)


# ============================================================
# Indentation Handler
# ============================================================

def handle_indentation(source):
    """Process MMC source indentation and convert to consistent Python.

    MMC uses Python-style indentation (4 spaces = 1 level).
    """
    lines = source.split('\n')
    processed = []

    for line in lines:
        # Count leading spaces
        stripped = line.lstrip(' ')
        leading_spaces = len(line) - len(stripped)
        # Normalize to 4-space indent
        indent_level = leading_spaces // 4
        processed.append('    ' * indent_level + stripped)

    return '\n'.join(processed)


# ============================================================
# Main Transpiler API
# ============================================================

def mmc_to_python(source):
    """MMC source -> Python source (main API)."""
    # Process line by line - preserve input indentation
    lines = source.split('\n')
    py_lines = []

    for line in lines:
        stripped = line.strip()

        # Empty line
        if not stripped:
            py_lines.append('')
            continue

        # Comment-only line
        if stripped.startswith('#'):
            py_lines.append(line)
            continue

        # Get indentation from original line
        leading = len(line) - len(line.lstrip())
        indent = '    ' * (leading // 4)

        # Tokenize and translate the content (without leading spaces)
        tokens = tokenize(stripped)
        py_parts = _translate_tokens(tokens)
        py_code = _smart_join(py_parts)

        py_lines.append(indent + py_code)

    return '\n'.join(py_lines)


def run_mmc(source, timeout=10):
    """Execute MMC code. Returns (stdout, stderr, exit_code, python_code)."""
    py_code = mmc_to_python(source)

    old_out = sys.stdout
    old_err = sys.stderr
    sys.stdout = out_buf = io.StringIO()
    sys.stderr = err_buf = io.StringIO()

    exit_code = 0
    try:
        ns = {'__builtins__': __builtins__, '__name__': '__mmc__'}
        exec(py_code, ns)
    except SystemExit as e:
        exit_code = e.code or 0
    except Exception as e:
        exit_code = 1
        err_buf.write(f"{type(e).__name__}: {e}\n")

    sys.stdout = old_out
    sys.stderr = old_err
    return out_buf.getvalue(), err_buf.getvalue(), exit_code, py_code


# ============================================================
# CLI
# ============================================================

def main():
    if len(sys.argv) < 2:
        print("MMC Transpiler v4.0")
        print("Myanmar Code Programming Language")
        print("")
        print("Usage:")
        print("  python mmc_transpiler.py run <file.mmc>      Run MMC code")
        print("  python mmc_transpiler.py compile <file.mmc>  Show Python output")
        print("  python mmc_transpiler.py transpile            Read from stdin")
        print("")
        print("Keywords: 80+ Myanmar keywords mapped to Python")
        print("Features: Dict, Error Handling, File I/O, OOP, Imports")
        sys.exit(0)

    cmd = sys.argv[1]

    if cmd == 'run':
        if len(sys.argv) < 3:
            print("Error: Specify .mmc file")
            sys.exit(1)
        with open(sys.argv[2], 'r', encoding='utf-8') as f:
            source = f.read()
        stdout, stderr, code, _ = run_mmc(source)
        if stdout:
            print(stdout, end='')
        if stderr:
            print(stderr, end='', file=sys.stderr)
        sys.exit(code)

    elif cmd == 'compile':
        if len(sys.argv) < 3:
            print("Error: Specify .mmc file")
            sys.exit(1)
        with open(sys.argv[2], 'r', encoding='utf-8') as f:
            source = f.read()
        py = mmc_to_python(source)
        print("--- MMC -> Python ---")
        print(py)
        print("--- End ---")

    elif cmd == 'transpile':
        source = sys.stdin.read()
        py = mmc_to_python(source)
        print(py)

    else:
        print(f"Unknown command: {cmd}")
        sys.exit(1)


if __name__ == '__main__':
    main()
