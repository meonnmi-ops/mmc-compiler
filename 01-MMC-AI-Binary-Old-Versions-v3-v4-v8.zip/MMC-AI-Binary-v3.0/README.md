# ================================================================
# MMC AI Binary v3.0
# Myanmar Code Programming Language
# ================================================================

MMC AI v3.0 - မြန်မာဘာသာ ပါဝင်မှုရှိသော AI ပ取代 ကိုယ်ပိုင် Programming Language ဖြစ်ပါသည်။
သင် ကုဒ်မရေးဘဲ AI က ကိုယ်တိုင် MMC ကုဒ် ရေးပေးပါမည်။
ဖုန်း (Termux/PC/Mac) ပေါ်တွင် run လုပ်နိုင်ပါသည်။

## အတွက် ဘယ်လို Install လုပ်မလဲ

### Termux (Android)
```bash
# 1. install.sh ကို copy လုပ်ပြီး Termux မှာ paste လုပ်ပါ
# 2. Enter နှိပ်ပါ

# နိုင်ငံရေးကြီးကိုင်တာဖြင့်
bash install.sh
```

### PC / Mac
```bash
# 1. install.sh ကို copy လုပ်ပြီး terminal မှာ paste လုပ်ပါ
# 2. Enter နှိပ်ပါ

bash install.sh
```

## စတင်ပါ

### MMC AI IDE ဖွင့်ခြင်း (Web Browser)
```bash
cd ~/mmc-ai
python mmc_ai_server.py
```
Browser မှာ `http://localhost:8080` ဖွင့်ပါ။

### AI Chat (CLI)
```bash
ollama run mmc-ai
```

## MMC Keywords (မြန်မာစကားလုံးများ)

| MMC Keyword | Python | အဓိပ္ပာယ် |
|------------|--------|-----------|
| ကိန်း | var | ကိန်းသတ်မှတ်ခြင်း |
| အတည် | const | မပြောင်းလဲသော |
| နေရာ | let | ခေါင်းဆိုင်သတ်မှတ်ခြင်း |
| အကယ်၍ | if | စစ်ဆေးခြင်း |
| မဟုတ်ပါက | else | အခြားနေရာ |
| အတွက် | for | ဖြတ်သန်းခြင်း |
| လုပ်နေစဉ် | while | လုပ်နေစဉ်ဖြတ်သန်းခြင်း |
| အဓိပ္ပာယ် | def | လုပ်ဆောင်ချက် |
| ပြန်ပေး | return | ပြန်ပေးခြင်း |
| ပုံနှိပ် | print | ဖော်ပြခြင်း |
| မေးမြန်း | input | ဖော်ကျင်သွင်းခြင်း |
| အတန်း | class | အတန်းသတ်မှတ်ခြင်း |
| ဒီ | self | ကိုယ်ကိုယ် |
| မှန် | True | မှန်သည် |
| မှား | False | မှားသည် |
| ညီမျှလျှင် | and | နှုတ်ဆက် |
| သို့မဟုတ် | or | သို့မဟုတ် |
| တင်သွင်း | import | ထည့်သွင်းခြင်း |
| ကြိုးစား | try | စမ်းလုပ်ခြင်း |
| ဖမ်းမိ | except | မှားသွားလျှင် |
| ရပ် | break | ရပ်ခြင်း |
| ဆက်လုပ် | continue | ဆက်လုပ်ခြင်း |

## ကွက်တိုင်းများ

- mmc_ai_server.py - Web IDE Server (Python, no dependencies needed)
- mmc_transpiler.py - MMC to Python Transpiler
- install.sh - Auto install script (Termux + PC + Mac)
- README.md - This file

## Files
```
MMC-AI-Binary-v3.0/
  mmc_ai_server.py    - Web IDE + AI + Transpiler (main)
  mmc_transpiler.py   - MMC -> Python transpiler
  install.sh          - Copy-paste install for Termux/PC
  README.md           - This file
  examples/
    hello.mmc         - Hello World
    calculator.mmc    - Calculator
    fibonacci.mmc     - Fibonacci
    class_example.mmc - Class example
```

## System Requirements
- Python 3.6+ (Termux: `pkg install python`)
- Ollama (optional - for AI features)
- Modern web browser (for IDE)

Created by MyanOS AI Team
