#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MMC AI Server v3.0
Myanmar Code (MMC) AI Programming Environment

- Web IDE (browser-based code editor)
- MMC Transpiler (MMC -> Python -> Execute)
- Ollama AI Integration (MMC code generation, debugging)
- Works on Termux (Android), PC, Mac

Start:
  python mmc_ai_server.py
  Open browser: http://localhost:8080
"""

import os
import sys
import json
import subprocess
import threading
import time
import traceback
from http.server import HTTPServer, SimpleHTTPRequestHandler

# ============================================================
# MMC Transpiler (embedded - no external dependencies)
# ============================================================

KEYWORDS = {
    'ကိန်း': '', 'အတည်': '', 'နေရာ': '',
    'အကယ်၍': 'if', 'မဟုတ်ပါက': 'else', 'မဟုတ်လျှင်': 'elif',
    'အတွက်': 'for', 'လုပ်နေစဉ်': 'while', 'ရပ်': 'break', 'ဆက်လုပ်': 'continue',
    'အဓိပ္ပာယ်': 'def', 'လုပ်ဆောင်ချက်': 'def', 'ပြန်ပေး': 'return',
    'အတန်း': 'class', 'ဒီ': 'self', 'အထက်': 'super()',
    'ပုံနှိပ်': 'print', 'မေးမြန်း': 'input',
    'တင်သွင်း': 'import', 'မှ': 'from', 'ကူးယူပါ': 'import',
    'ကြိုးစား': 'try', 'ဖမ်းမိ': 'except', 'နောက်ဆုံး': 'finally', 'ချမြှောက်': 'raise',
    'မှန်': 'True', 'မှား': 'False', 'မပါ': 'None',
    'ညီမျှလျှင်': 'and', 'သို့မဟုတ်': 'or', 'မဟုတ်': 'not',
    'တူလျှင်': '==', 'မတူလျှင်': '!=',
    'ပိုကြီး': '>', 'ပိုငယ်': '<',
    'ကြီးလျှင်သို့မဟုတ်': '>=', 'ငယ်လျှင်သို့မဟုတ်': '<=',
    'မတူညီ': 'async', 'မျှော်': 'await',
    'အရှည်': 'len', 'ပတ်လမ်း': 'range', 'ကျပန်း': 'str',
    'အချိန်': 'int', 'လော့ဂရစ်သမ်': 'float',
    'အရာဝတ္ထု': 'dict', 'အဘိဓာန်': 'set',
    'ဆိုင်': 'tuple', 'တန်ဂျင့်': 'bool', 'ဇယား': 'type',
    'စာရင်း': 'list', 'သင်္ချာ': 'abs',
    'အမြင့်ဆုံး': 'max', 'အနိမ့်ဆုံး': 'min', 'ပေါင်းလုံး': 'sum',
    'ရွေးချယ်': 'sorted',
    'ဖွင့်': 'open',
}

MYANMAR_DIGITS = {
    '၀': '0', '၁': '1', '၂': '2', '၃': '3', '၄': '4',
    '၅': '5', '၆': '6', '၇': '7', '၈': '8', '၉': '9',
}


def mmc_to_python(source):
    """MMC source code -> Python source code (line-by-line translation)."""
    lines = source.split('\n')
    py_lines = []
    indent_level = 0

    for line in lines:
        stripped = line.strip()

        if not stripped:
            py_lines.append('')
            continue

        if stripped.startswith('#'):
            py_lines.append(line)
            continue

        # Detect indent level from leading spaces
        current_indent = len(line) - len(line.lstrip())
        est_level = current_indent // 4

        # Dedent
        while indent_level > est_level:
            indent_level -= 1

        translated_line = _translate_line(stripped)

        # Statements that increase indent on next line
        indent_increasers = [
            'အကယ်၍', 'မဟုတ်ပါက', 'မဟုတ်လျှင်',
            'အတွက်', 'လုပ်နေစဉ်',
            'အဓိပ္ပာယ်', 'လုပ်ဆောင်ချက်',
            'အတန်း', 'ကြိုးစား',
        ]
        needs_indent = any(stripped.startswith(kw) for kw in indent_increasers)

        indent_str = '    ' * indent_level
        py_lines.append(indent_str + translated_line)

        if needs_indent:
            indent_level += 1

    return '\n'.join(py_lines)


# Functions that need parenthesized call: print(...), input(...), len(...), etc.
CALL_KEYWORDS = {
    'ပုံနှိပ်', 'မေးမြန်း',  # print, input
    'အရှည်', 'ဇယား', 'ကျပန်း',  # len, type, str
    'အချိန်', 'လော့ဂရစ်သမ်',  # int, float
    'တန်ဂျင့်', 'စာရင်း',  # bool, list
    'အရာဝတ္ထု', 'အဘိဓာန်', 'ဆိုင်',  # dict, set, tuple
    'ပတ်လမ်း', 'သင်္ချာ',  # range, abs
    'အမြင့်ဆုံး', 'အနိမ့်ဆုံး', 'ပေါင်းလုံး', 'ရွေးချယ်',  # max, min, sum, sorted
    'ပြဿနာ', 'ကုလသိုက်',  # map, filter
}

# Built-in functions that are called with parens but don't need 'in'
BUILTIN_FUNCS = CALL_KEYWORDS


def _translate_line(line):
    """Translate a single MMC line to Python."""
    if line.startswith('#'):
        return line

    # Replace Myanmar digits
    for my, ar in MYANMAR_DIGITS.items():
        line = line.replace(my, ar)

    tokens = _tokenize(line)
    result = []
    i = 0

    while i < len(tokens):
        token = tokens[i]

        # String literals
        if token.startswith('"') or token.startswith("'"):
            result.append(token)
            i += 1
            continue

        # Keywords that are function calls (need parens)
        if token in CALL_KEYWORDS:
            py_val = KEYWORDS[token]
            # Gather arguments until end of statement or closing paren
            args = []
            i += 1
            if i < len(tokens) and tokens[i] == '(':
                # Already has parens - just pass through
                result.append(py_val + '(')
                i += 1
                depth = 1
                while i < len(tokens) and depth > 0:
                    if tokens[i] == '(':
                        depth += 1
                    elif tokens[i] == ')':
                        depth -= 1
                        if depth == 0:
                            result.append(')')
                            i += 1
                            break
                    # Recursively translate inner tokens
                    result.append(_translate_token(tokens[i]))
                    i += 1
            else:
                # Collect everything until end as arguments
                while i < len(tokens):
                    args.append(_translate_token(tokens[i]))
                    i += 1
                if args:
                    result.append(py_val + '(' + ' '.join(args) + ')')
                else:
                    result.append(py_val + '()')
            continue

        # Known keyword (not a function call)
        if token in KEYWORDS:
            py_val = KEYWORDS[token]
            if py_val == '':
                # var/let/const - skip
                if i + 1 < len(tokens) and tokens[i + 1] == '=':
                    i += 1
                    continue
                i += 1
                continue

            # for loop: insert 'in' after variable
            if py_val == 'for':
                result.append('for')
                i += 1
                # variable name
                if i < len(tokens):
                    result.append(_translate_token(tokens[i]))
                    i += 1
                # insert 'in'
                result.append('in')
                continue

            result.append(py_val)
            i += 1
            continue

        # Operators
        if token == '=':
            if i + 1 < len(tokens) and tokens[i + 1] == '=':
                result.append('==')
                i += 2
            else:
                result.append('=')
                i += 1
            continue
        if token == '!':
            if i + 1 < len(tokens) and tokens[i + 1] == '=':
                result.append('!=')
                i += 2
            else:
                result.append('not ')
                i += 1
            continue
        if token == '<':
            if i + 1 < len(tokens) and tokens[i + 1] == '=':
                result.append('<=')
                i += 2
            else:
                result.append('<')
                i += 1
            continue
        if token == '>':
            if i + 1 < len(tokens) and tokens[i + 1] == '=':
                result.append('>=')
                i += 2
            else:
                result.append('>')
                i += 1
            continue
        if token == '+' and i + 1 < len(tokens) and tokens[i + 1] == '=':
            result.append('+=')
            i += 2
            continue
        if token == '-' and i + 1 < len(tokens) and tokens[i + 1] == '=':
            result.append('-=')
            i += 2
            continue
        if token == '*' and i + 1 < len(tokens) and tokens[i + 1] == '*':
            result.append('**')
            i += 2
            continue
        if token == '/' and i + 1 < len(tokens) and tokens[i + 1] == '/':
            result.append('//')
            i += 2
            continue

        # Number
        if token[0].isdigit() or (token[0] == '.' and len(token) > 1 and token[1].isdigit()):
            result.append(token)
            i += 1
            continue

        # Everything else (identifiers, etc)
        result.append(_translate_token(token))
        i += 1

    return ' '.join(result)


def _translate_token(token):
    """Translate a single token."""
    if token in KEYWORDS:
        return KEYWORDS[token]
    return token


def _tokenize(line):
    """Simple tokenizer for a single line."""
    # Remove inline comments
    comment_idx = line.find('#')
    if comment_idx >= 0:
        # But not inside strings
        in_string = False
        quote_char = None
        for j, ch in enumerate(line):
            if ch in '"\'':
                if not in_string:
                    in_string = True
                    quote_char = ch
                elif ch == quote_char:
                    in_string = False
            elif not in_string and ch == '#':
                comment_idx = j
                break
        else:
            comment_idx = -1
        if comment_idx >= 0:
            line = line[:comment_idx]

    tokens = []
    i = 0
    while i < len(line):
        ch = line[i]

        # Skip whitespace
        if ch in ' \t':
            i += 1
            continue

        # String literal
        if ch in '"\'':
            j = i + 1
            while j < len(line) and line[j] != ch:
                if line[j] == '\\':
                    j += 1
                j += 1
            tokens.append(line[i:min(j + 1, len(line))])
            i = min(j + 1, len(line))
            continue

        # Multi-char operators
        if i + 1 < len(line):
            two = line[i:i + 2]
            if two in ('==', '!=', '>=', '<=', '+=', '-=', '**', '//'):
                tokens.append(two)
                i += 2
                continue

        # Single-char operators
        if ch in '=!<>+-*/%()[]{}:,.':
            tokens.append(ch)
            i += 1
            continue

        # Word (Myanmar text or identifier)
        if ch.isalpha() or ch == '_' or ord(ch) > 0x1000:
            j = i
            while j < len(line) and (line[j].isalnum() or line[j] == '_' or ord(line[j]) > 0x1000):
                j += 1
            tokens.append(line[i:j])
            i = j
            continue

        # Number
        if ch.isdigit() or ch in MYANMAR_DIGITS:
            j = i
            while j < len(line) and (line[j].isdigit() or line[j] in MYANMAR_DIGITS or line[j] == '.'):
                j += 1
            tokens.append(line[i:j])
            i = j
            continue

        # Unknown
        tokens.append(ch)
        i += 1

    return tokens


def run_mmc_code(source, timeout=10):
    """Execute MMC code and return (stdout, stderr, exit_code, python_code)."""
    py_code = mmc_to_python(source)

    import io
    old_out = sys.stdout
    old_err = sys.stderr
    sys.stdout = out_buf = io.StringIO()
    sys.stderr = err_buf = io.StringIO()

    exit_code = 0
    try:
        ns = {'__builtins__': __builtins__, '__name__': '__mmc__'}
        exec(py_code, ns)
    except SystemExit as e:
        exit_code = e.code or 0
    except Exception as e:
        exit_code = 1
        err_buf.write(f"{type(e).__name__}: {e}\n")

    sys.stdout = old_out
    sys.stderr = old_err
    return out_buf.getvalue(), err_buf.getvalue(), exit_code, py_code


# ============================================================
# Ollama AI Integration
# ============================================================

def call_ollama(prompt, model="mmc-ai", system=None, timeout=30):
    """Call Ollama API for AI code generation."""
    messages = []
    if system:
        messages.append({"role": "system", "content": system})

    messages.append({"role": "user", "content": prompt})

    payload = json.dumps({
        "model": model,
        "messages": messages,
        "stream": False,
        "options": {
            "temperature": 0.6,
            "num_ctx": 4096,
        }
    }).encode()

    try:
        import urllib.request
        req = urllib.request.Request(
            "http://localhost:11434/api/chat",
            data=payload,
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read())
            return data.get("message", {}).get("content", "")
    except Exception as e:
        return f"AI Error: {e}"


MMC_SYSTEM_PROMPT = """You are MMC AI (Myanmar Code AI Assistant) v3.0.

MMC (Myanmar Code) Programming Language Keywords:
- Variables: ကိန်း (var), အတည် (const), နေရာ (let)
- Control: အကယ်၍ (if), မဟုတ်ပါက (else), မဟုတ်လျှင် (elif)
- Loops: အတွက် (for), လုပ်နေစဉ် (while), ရပ် (break), ဆက်လုပ် (continue)
- Functions: အဓိပ္ပာယ် (def), လုပ်ဆောင်ချက် (function), ပြန်ပေး (return)
- Classes: အတန်း (class), ဒီ (self), အထက် (super)
- I/O: ပုံနှိပ် (print), မေးမြန်း (input)
- Import: တင်သွင်း (import), မှ (from)
- Boolean: မှန် (True), မှား (False), မပါ (None)
- Logic: ညီမျှလျှင် (and), သို့မဟုတ် (or), မဟုတ် (not)
- Error: ကြိုးစား (try), ဖမ်းမိ (except), နောက်ဆုံး (finally)
- Numbers: ၀-၉ = 0-9
- Operators: + - * / ** // % = == != > < >= <= += -=

Respond in Myanmar language. Use ```mmc code blocks for MMC code.
When user asks for code, write MMC code that actually works."""


# ============================================================
# Web Server + IDE
# ============================================================

HTML_IDE = r"""<!DOCTYPE html>
<html lang="my">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>MMC AI IDE v3.0 - Myanmar Code Programming Language</title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }

:root {
  --bg-dark: #1a1a2e;
  --bg-panel: #16213e;
  --bg-editor: #0f0f23;
  --accent: #e94560;
  --accent2: #0f3460;
  --text: #e0e0e0;
  --text-dim: #888;
  --green: #4ecca3;
  --yellow: #f1c40f;
  --border: #2a2a4a;
  --radius: 8px;
}

body {
  background: var(--bg-dark);
  color: var(--text);
  font-family: 'Courier New', monospace;
  height: 100vh;
  display: flex;
  flex-direction: column;
}

/* Header */
.header {
  background: var(--bg-panel);
  border-bottom: 2px solid var(--accent);
  padding: 10px 20px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-shrink: 0;
}

.logo {
  font-size: 20px;
  font-weight: bold;
  color: var(--accent);
}

.logo span { color: var(--green); }

.header-info {
  font-size: 12px;
  color: var(--text-dim);
}

/* Toolbar */
.toolbar {
  background: var(--bg-panel);
  border-bottom: 1px solid var(--border);
  padding: 6px 15px;
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
  flex-shrink: 0;
}

.btn {
  background: var(--accent2);
  color: white;
  border: 1px solid var(--border);
  padding: 6px 14px;
  border-radius: var(--radius);
  cursor: pointer;
  font-size: 13px;
  font-family: inherit;
  transition: all 0.2s;
}

.btn:hover { background: var(--accent); }
.btn-run { background: #27ae60; }
.btn-run:hover { background: #2ecc71; }
.btn-ai { background: #8e44ad; }
.btn-ai:hover { background: #9b59b6; }

select.btn {
  background: var(--accent2);
  color: white;
}

/* Main Area */
.main {
  flex: 1;
  display: flex;
  overflow: hidden;
}

/* Panels */
.panel {
  flex: 1;
  display: flex;
  flex-direction: column;
  min-width: 0;
}

.panel-left { border-right: 2px solid var(--border); }

.panel-header {
  background: var(--bg-panel);
  padding: 6px 12px;
  font-size: 12px;
  color: var(--text-dim);
  border-bottom: 1px solid var(--border);
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-shrink: 0;
}

.panel-header span { color: var(--accent); font-weight: bold; }

/* Editor */
#editor {
  flex: 1;
  background: var(--bg-editor);
  color: #c0c0c0;
  border: none;
  padding: 12px;
  font-family: 'Courier New', 'Noto Sans Myanmar', monospace;
  font-size: 14px;
  resize: none;
  outline: none;
  tab-size: 4;
  line-height: 1.6;
  width: 100%;
}

#editor::selection {
  background: var(--accent);
  color: white;
}

/* Output */
.output-tabs {
  display: flex;
  background: var(--bg-panel);
  border-bottom: 1px solid var(--border);
  flex-shrink: 0;
}

.output-tab {
  padding: 5px 12px;
  cursor: pointer;
  font-size: 12px;
  color: var(--text-dim);
  border-bottom: 2px solid transparent;
}

.output-tab.active {
  color: var(--accent);
  border-bottom-color: var(--accent);
}

.output-content {
  flex: 1;
  overflow: auto;
  padding: 12px;
  font-size: 13px;
  line-height: 1.5;
}

#output-run {
  background: var(--bg-editor);
  white-space: pre-wrap;
  word-break: break-all;
}

#output-run .success { color: var(--green); }
#output-run .error { color: #e74c3c; }
#output-run .info { color: var(--text-dim); }

#output-py {
  background: var(--bg-editor);
  white-space: pre-wrap;
  word-break: break-all;
  display: none;
}

#output-ai {
  background: var(--bg-editor);
  white-space: pre-wrap;
  word-break: break-all;
  display: none;
  font-family: 'Noto Sans Myanmar', 'Courier New', monospace;
}

/* AI Input */
.ai-bar {
  background: var(--bg-panel);
  border-top: 1px solid var(--border);
  padding: 8px 12px;
  display: flex;
  gap: 8px;
  flex-shrink: 0;
}

#ai-input {
  flex: 1;
  background: var(--bg-editor);
  border: 1px solid var(--border);
  color: var(--text);
  padding: 8px 12px;
  border-radius: var(--radius);
  font-family: 'Noto Sans Myanmar', 'Courier New', monospace;
  font-size: 13px;
  outline: none;
}

#ai-input:focus { border-color: var(--accent); }

#ai-input::placeholder { color: #555; }

/* Status Bar */
.statusbar {
  background: var(--bg-panel);
  border-top: 1px solid var(--border);
  padding: 4px 15px;
  font-size: 11px;
  color: var(--text-dim);
  display: flex;
  justify-content: space-between;
  flex-shrink: 0;
}

.status-dot {
  display: inline-block;
  width: 8px;
  height: 8px;
  border-radius: 50%;
  margin-right: 5px;
  vertical-align: middle;
}

.dot-green { background: var(--green); }
.dot-red { background: #e74c3c; }
.dot-yellow { background: var(--yellow); }

/* Examples dropdown */
.examples-dropdown {
  position: absolute;
  top: 100%;
  left: 0;
  background: var(--bg-panel);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  max-height: 300px;
  overflow-y: auto;
  z-index: 100;
  display: none;
}

.examples-dropdown.show { display: block; }

.example-item {
  padding: 8px 15px;
  cursor: pointer;
  font-size: 12px;
  border-bottom: 1px solid var(--border);
  color: var(--text);
}

.example-item:hover { background: var(--accent2); }

/* Responsive */
@media (max-width: 768px) {
  .main { flex-direction: column; }
  .panel-left { border-right: none; border-bottom: 2px solid var(--border); }
  .panel { min-height: 200px; }
  .header { padding: 8px 12px; }
  .toolbar { padding: 4px 8px; }
}
</style>
</head>
<body>

<div class="header">
  <div class="logo">MMC <span>AI IDE</span> v3.0</div>
  <div class="header-info" id="server-info">Connecting...</div>
</div>

<div class="toolbar">
  <button class="btn btn-run" onclick="runCode()">&#9654; Run</button>
  <button class="btn" onclick="showPython()">&#128196; Python</button>
  <button class="btn" onclick="clearOutput()">&#128465; Clear</button>
  <div style="position:relative; display:inline-block;">
    <button class="btn" onclick="toggleExamples()">&#128218; Examples</button>
    <div class="examples-dropdown" id="examples-list"></div>
  </div>
  <button class="btn" onclick="loadFile()">&#128193; Open .mmc</button>
  <button class="btn" onclick="saveFile()">&#128190; Save .mmc</button>
  <input type="file" id="file-input" accept=".mmc" style="display:none" onchange="handleFile(event)">
</div>

<div class="main">
  <div class="panel panel-left">
    <div class="panel-header">
      <span>&#128187; MMC Editor</span>
      <span id="line-count">Line: 1</span>
    </div>
    <textarea id="editor" spellcheck="false" placeholder="MMC &#x1000;&#x1014;&#x1019;&#x102C;&#x1015;&#x102D;&#x102F; &#x101B;&#x102D;&#x102F;&#x1038;&#x1001;&#x1036;&#x1031;&#x1000;&#x103A; &#x1021;&#x101E;&#x102C;&#x1038;&#x1000;&#x101B;&#x102D;&#x102F;&#x102F;&#x1015;&#x102B;&#x1004;&#x1039;&#x101C;&#x102F;&#x1016;&#x102C;&#x101D;&#x1014;&#x1039;&#x102B;&#x101E;&#x102C;..."># MMC Hello World
&#x1000;&#x1014;&#x101F;&#x102C;&#x101B;&#x1010;&#x1039; &#x1001;&#x101C;&#x102F;&#x1015;&#x1039;&#x1000;&#x103C;&#x108F;&#x1000;&#x1014;&#x1039; &#x1015;&#x102D;&#x102F;&#x1038;&#x1005;&#x1036;&#x1010;&#x102D;&#x102F;&#x1021;&#x101B;&#x103E;&#x102D;&#x1019;&#x103A;&#x1038;&#x1019;&#x1004;&#x1039;&#x100B;&#x1039;
&#x1019;&#x1014;&#x103A;&#x1019;&#x102C;&#x101C;&#x103B;&#x102F;&#x1016;&#x103A; "&#x1000;&#x1014;&#x101F;&#x102C;&#x101B;&#x1010;&#x1039; &#x1015;&#x102D;&#x102F;&#x1038;&#x1005;&#x1036;&#x1010;&#x102D;&#x102F;&#x1021;&#x101B;&#x103E;&#x102D;&#x1019;&#x103A;&#x1038;&#x1019;&#x1004;&#x1039;&#x100B;&#x1039;!"

# &#x1015;&#x101C;&#x1004;&#x1039; &#x1005;&#x102C;&#x1018;&#x101A;&#x1039;&#x1014;&#x103E;&#x102C;&#x101D;&#x1014;&#x1039;
&#x101A;&#x1031;&#x102C;&#x1001;&#x102F;&#x102F;&#x1016;&#x103A;&#x101E;&#x102C;&#x1038;&#x1011;&#x103A;&#x1010;&#x103C;&#x1038;&#x1019;&#x102C;&#x101C;&#x103B;&#x102F;&#x1016;&#x103A;&#x101A;&#x103A;&#x1019;&#x100A;&#x1039;&#x1001;&#x1004;&#x1039;&#x101E;&#x103C;&#x1014;&#x1039; &#x1010;&#x1038;&#x102C;&#x1021;&#x102C;&#x1038;&#x1001;&#x1036;&#x101E;&#x102D;&#x102F;&#x1038;&#x1019;&#x101A;&#x1039;&#x1000;&#x101C;&#x103B;&#x102D;&#x1039;&#x1010;&#x1038;&#x101C;&#x1039;&#x101E;&#x1030;&#x1001;&#x1036;&#x100A;&#x1039;&#x1004;&#x1039;&#x1021;&#x1001;&#x103B;&#x103A;&#x1019;&#x103A;&#x1038;&#x1019;&#x103A;&#x1038;&#x101C;&#x1039;&#x101B;&#x1021;&#x102C;&#x1019;&#x100A;&#x1039;&#x1015;&#x102B;&#x1019;&#x101A;&#x1039;&#x101C;&#x1005;&#x103A;&#x101B;&#x103E;&#x1031;&#x1014;&#x1039;&#x1006;&#x1004;&#x1039;&#x1015;&#x103c;&#x1019;&#x102c;&#x101c;&#x102f;&#x1015;&#x1039;&#x1000;&#x101c;&#x103e;&#x1037;&#x1031;&#x1005;&#x102f;&#x102f;&#x1015;&#x1039;&#x101c;&#x103d;&#x102d;&#x1019;&#x101a;&#x1039;&#x1019;&#x101a;&#x1039;&#x1001;&#x103b;&#x1038;&#x101b;&#x103e;&#x1031;&#x1014;&#x1039;&#x1016;&#x1030;&#x102c;&#x101b;&#x101e;&#x1000;&#x1039;&#x101b;&#x103e;&#x1031;&#x1014;&#x1039;&#x1015;&#x103c;&#x1019;&#x102c;&#x1004;&#x1039;&#x1019;&#x101a;&#x1039;&#x1001;&#x103b;&#x1038;&#x101b;&#x103e;&#x1031;&#x1014;&#x1039;&#x1019;&#x101a;&#x1039;&#x1001;&#x103b;&#x1038;&#x101b;&#x103e;&#x1031;&#x1014;&#x1039;&#x1019;&#x101a;&#x1039;&#x1001;&#x103b;&#x1038;&#x101b;&#x103e;&#x1031;&#x1014;&#x1039;&#x1019;&#x101a;&#x1039;&#x1001;&#x103b;&#x1038;&#x101b;&#x103e;&#x1031;&#x1014;&#x1039;&#x1019;&#x101a;&#x1039;&#x1001;&#x103b;&#x1038;&#x101b;&#x103e;&#x1031;&#x1014;&#x1039;&#x1019;&#x101a;&#x1039;&#x1001;&#x103b;&#x1038;&#x101b;&#x103e;&#x1031;&#x1014;&#x1039;
&#x101E;&#x103C;&#x1014;&#x1039;&#x101B;&#x103e;&#x102D;&#x1019;&#x103A;&#x1038;&#x1019;&#x1004;&#x1039;&#x100B;&#x1039;&#x1001;&#x102F;&#x1036;&#x1000;&#x1014;&#x1039;&#x101E;&#x102C;&#x1019;&#x103A;&#x1038;&#x1018;&#x103D;&#x102C;&#x1018;&#x103D;&#x102C;&#x1019;&#x101C;&#x103B;&#x102F;&#x1016;&#x103A;&#x1015;&#x102B;&#x100B;&#x1039;&#x101E;&#x103c;&#x1021;&#x1001;&#x103b;&#x103a;&#x1019;&#x103a;&#x1038;&#x1019;&#x103a;&#x1038;&#x101c;&#x1039;&#x101c;&#x1005;&#x103a;&#x101c;&#x1030;&#x1010;&#x102d;&#x102f;&#x1021;&#x102c;&#x1038;&#x1001;&#x1036;&#x101e;&#x102d;&#x102f;&#x1038;&#x1001;&#x1036;&#x1016;&#x1030;&#x1001;&#x1036;&#x1015;&#x102b;&#x101e;&#x102c;&#x101d;&#x1014;&#x1039;&#x1001;&#x103b;&#x103a;&#x1019;&#x103a;&#x1038;&#x1019;&#x103a;&#x1038;&#x101c;&#x1039;&#x101c;&#x1030;&#x102c;&#x1018;&#x103a;&#x1014;&#x1039;&#x1010;&#x102d;&#x102f;&#x1001;&#x1036;&#x1015;&#x102b;&#x101c;&#x103b;&#x102f;&#x1016;&#x103a;&#x1000;&#x101c;&#x1039;&#x101b;&#x103e;&#x1031;&#x1014;&#x1039;&#x1021;&#x102c;&#x1038;&#x1000;&#x1015;&#x101b;&#x101e;&#x1030;&#x1001;&#x1036;&#x100a;&#x1039;&#x1004;&#x1039;&#x1000;&#x101c;&#x103e;&#x1019;&#x102c;&#x101c;&#x103b;&#x102f;&#x1016;&#x103a;&#x1001;&#x103b;&#x103a;&#x1019;&#x103a;&#x1038;&#x1019;&#x103a;&#x1038;&#x101c;&#x1039;&#x1015;&#x102b;</textarea>
  </div>

  <div class="panel">
    <div class="panel-header">
      <span>&#128196; Output</span>
      <span id="run-status"></span>
    </div>
    <div class="output-tabs">
      <div class="output-tab active" onclick="switchTab('run')">&#9654; Run</div>
      <div class="output-tab" onclick="switchTab('py')">&#128013; Python</div>
      <div class="output-tab" onclick="switchTab('ai')">&#129302; AI</div>
    </div>
    <div class="output-content" id="output-run"></div>
    <div class="output-content" id="output-py"></div>
    <div class="output-content" id="output-ai"></div>
    <div class="ai-bar">
      <input id="ai-input" placeholder="MMC &#x1000;&#x1014;&#x1039;&#x1019;&#x102c;&#x1015;&#x103c; &#x1019;&#x1031;&#x1019;&#x103c;&#x1038;&#x1015;&#x102b;&#x1000;&#x103C;&#x1039;... (AI &#x1011;&#x1036;&#x1038;&#x1019;&#x103E;&#x101C;&#x103A;&#x1038;&#x101E;&#x103D;&#x102C;&#x1015;&#x103C; &#x1021;&#x101E;&#x102F;&#x1036;&#x1038;&#x1005;&#x103A;&#x101B;&#x103E;&#x1031;&#x1014;&#x1039;)" onkeypress="if(event.key==='Enter')askAI()">
      <button class="btn btn-ai" onclick="askAI()">&#129302; Ask AI</button>
    </div>
  </div>
</div>

<div class="statusbar">
  <span>
    <span class="status-dot dot-green" id="ollama-dot"></span>
    <span id="ollama-status">Checking Ollama...</span>
  </span>
  <span>MMC AI v3.0 | Myanmar Code Programming Language</span>
</div>

<script>
const editor = document.getElementById('editor');
const examples = {
  'Hello World': `# Hello World\n\u1000\u1014\u101f\u102c\u101b\u1010\u1039 \u1001\u101c\u102f\u1015\u1039\u1000\u103c\u103f\u1000\u1014\u1039 \u1015\u102d\u102f\u1038\u1005\u1036\u1010\u102d\u102f\u1021\u101b\u103e\u102d\u1019\u103a\u1038\u1019\u1004\u1039\u100b\u1039\n\u1019\u1014\u103a\u1019\u102c\u101c\u103b\u102f\u1016\u103a "\u1000\u1014\u101f\u102c\u101b\u1010\u1039 \u1015\u102d\u102f\u1038\u1005\u1036\u1010\u102d\u102f\u1021\u101b\u103e\u102d\u1019\u103a\u1038\u1019\u1004\u1039\u100b\u1039!"`,
  'Calculator': `# \u1015\u103c\u102d\u102f\u1001\u103b\u102c\u1008\u103a\u1038\u1005\u102c\u1018\u101a\u1039\u1014\u103e\u102c\u101d\u1014\u1039\n\u101a\u1031\u102c\u1001\u102f\u1000\u103a \u1001\u102f\u1014\u1039\u1000\u103c\u1010\u103a(\u1010\u1015\u103a, \u1019\u101f\u102f\u1010\u103a):\n    \u1021\u1015\u103c\u102d\u102f = \u1010\u1015\u103a + \u1019\u101f\u102f\u1010\u103a\n    \u1021\u1014\u103e\u102f = \u1010\u1015\u103a - \u1019\u101f\u102f\u1010\u103a\n    \u1021\u1019\u103d\u1014\u1039 = \u1010\u1015\u103a * \u1019\u101f\u102f\u1010\u103a\n    \u1021\u1005\u102c\u1015\u103d = 0\n    \u1021\u1015\u103c\u102d\u102f 3 \u1016\u103c\u102d\u102f\u1038 \u1011\u103c\u1038\u1001\u1036\u101d\u102f \u1010\u1015\u103a = 10, \u1019\u101f\u102f\u1010\u103a = 5\n    \u1019\u1014\u103a\u1019\u102c\u101c\u103b\u102f\u1016\u103a "\u1015\u103c\u102d\u102f\u1001\u103b\u102c = " + str(\u1021\u1015\u103c\u102d\u102f)`,
  'For Loop': `# For Loop \u1014\u103e\u101c\u103b\u102f\u1016\u103a\u1000\u103c\u100a\u1039\u1019\u101a\u1039\n\u1005\u102c\u1018\u101a\u1039 \u1021\u1018\u103d\u1014\u1039\u1001\u1037\u1000\u103a \u1016\u103c\u102d\u102f\u1038:\n    \u1019\u1014\u103a\u1019\u102c\u101c\u103b\u102f\u1016\u103a "\u1018\u103d\u1014\u1039 = " + str(\u1021\u1018\u103d\u1014\u1039)`,
  'Fibonacci': `# Fibonacci \u1005\u102c\u1018\u101a\u1039\u1014\u103e\u102c\u101d\u1014\u1039\n\u101e\u102f = 0\n\u101c = 1\n\u1015\u103c\u102f\u1010\u103c\u100a\u1039 = 10\n\u1019\u1014\u103a\u1019\u102c\u101c\u103b\u102f\u1016\u103a "\u1015\u103c\u102f\u1010\u103c\u100a\u1039 " + str(\u1015\u103c\u102f\u1010\u103c\u100a\u1039) + " \u1001\u102f\u1014\u1039\u1000\u103c\u1010\u103a\u1019\u103e\u101c\u103a\u1038:"\n\u1005\u102c\u1018\u101a\u1039 i \u1001\u102f\u1014\u1039\u1000\u103c\u1010\u103a(\u1015\u103c\u102f\u1010\u103c\u100a\u1039):\n    \u1019\u1014\u103a\u1019\u102c\u101c\u103b\u102f\u1016\u103a str(i+1) + ": " + str(\u101e\u102f)\n    \u1014\u103e\u101c\u103b\u102f\u1016\u103a = \u101e\u102f + \u101c\n    \u101e\u102f = \u101c\n    \u101c = \u1014\u103e\u101c\u103b\u102f\u1016\u103a`,
  'Class Example': `# \u1005\u102c\u1018\u101a\u1039 \u1014\u103e\u101c\u103b\u102f\u1016\u103a - \u101e\u102c\u1038\u1005\u102c\u1018\u101a\u1039\u1014\u103e\u102c\u101d\u1014\u1039\n\u1005\u102c\u1018\u101a\u1039 \u101e\u102c\u1038():\n    \u1021\u1005\u102d\u101a\u103a\u1000\u103c\u1021\u1031\u101c\u102c\u1004\u1039\u1005\u103d\u102c(\u1014\u103e, \u1001\u102f\u1014\u1039\u1000\u103c, \u1015\u103c\u102d\u102f):\n        \u1014\u103e.\u1001\u102f\u1014\u1039\u1000\u103c = \u1001\u102f\u1014\u1039\u1000\u103c\n        \u1014\u103e.\u1015\u103c\u102d\u102f = \u1015\u103c\u102d\u102f\n\n    \u1021\u1005\u102d\u101a\u103a\u1000\u103c\u1023\u102f\u1036\u1038\u1000\u103a():\n        \u1021\u1015\u103c\u102d\u102f = \u1014\u103e.\u1001\u102f\u1014\u1039\u1000\u103c + \u1014\u103e.\u1015\u103c\u102d\u102f\n        \u1021\u1001\u103b\u102f\u1005\u102c\u1018\u101a\u1039\u1014\u103e "\u1015\u103c\u102d\u102f\u1001\u103b\u102c = " + str(\u1021\u1015\u103c\u102d\u102f)\n\n\u1014\u103e = \u101e\u102c\u1038(10, 20)\n\u1014\u103e.\u1023\u102f\u1036\u1038\u1000\u103a()`,
};

// Populate examples
const exList = document.getElementById('examples-list');
Object.keys(examples).forEach(name => {
  const div = document.createElement('div');
  div.className = 'example-item';
  div.textContent = name;
  div.onclick = () => { editor.value = examples[name]; exList.classList.remove('show'); };
  exList.appendChild(div);
});

function toggleExamples() { exList.classList.toggle('show'); }
document.addEventListener('click', e => { if (!e.target.closest('.examples-dropdown') && !e.target.closest('[onclick*="toggleExamples"]')) exList.classList.remove('show'); });

// Tab switching
function switchTab(tab) {
  document.querySelectorAll('.output-tab').forEach(t => t.classList.remove('active'));
  document.getElementById('output-run').style.display = 'none';
  document.getElementById('output-py').style.display = 'none';
  document.getElementById('output-ai').style.display = 'none';
  if (tab === 'run') { document.querySelectorAll('.output-tab')[0].classList.add('active'); document.getElementById('output-run').style.display = ''; }
  if (tab === 'py') { document.querySelectorAll('.output-tab')[1].classList.add('active'); document.getElementById('output-py').style.display = ''; }
  if (tab === 'ai') { document.querySelectorAll('.output-tab')[2].classList.add('active'); document.getElementById('output-ai').style.display = ''; }
}

// Run MMC code
async function runCode() {
  const code = editor.value;
  switchTab('run');
  const out = document.getElementById('output-run');
  const status = document.getElementById('run-status');
  out.innerHTML = '<span class="info">Compiling MMC code...</span>';
  status.textContent = 'Running...';
  try {
    const res = await fetch('/api/run', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({code}) });
    const data = await res.json();
    let html = '';
    if (data.output) html += '<span class="success">' + esc(data.output) + '</span>';
    if (data.error) html += '<span class="error">' + esc(data.error) + '</span>';
    if (data.python) html += '\n<span class="info">--- Generated Python ---\n' + esc(data.python) + '</span>';
    out.innerHTML = html || '<span class="info">No output</span>';
    status.textContent = data.error ? 'Error' : 'Done';
    status.style.color = data.error ? '#e74c3c' : '#4ecca3';
  } catch(e) {
    out.innerHTML = '<span class="error">Connection error: ' + e.message + '</span>';
    status.textContent = 'Error';
  }
}

// Show Python
async function showPython() {
  const code = editor.value;
  switchTab('py');
  const out = document.getElementById('output-py');
  out.textContent = 'Generating Python...';
  try {
    const res = await fetch('/api/python', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({code}) });
    const data = await res.json();
    out.textContent = data.python || 'No output';
  } catch(e) {
    out.textContent = 'Error: ' + e.message;
  }
}

// AI Chat
async function askAI() {
  const input = document.getElementById('ai-input');
  const prompt = input.value.trim();
  if (!prompt) return;
  input.value = '';
  switchTab('ai');
  const out = document.getElementById('output-ai');
  out.innerHTML += '<span style="color:#f1c40f">You: </span>' + esc(prompt) + '\n';
  out.innerHTML += '<span style="color:#888">AI thinking...</span>\n';
  out.scrollTop = out.scrollHeight;
  try {
    const res = await fetch('/api/ai', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({prompt, code: editor.value}) });
    const data = await res.json();
    // Remove "AI thinking..."
    const lines = out.innerHTML.split('\n');
    lines.splice(-2, 1);
    out.innerHTML = lines.join('\n');
    const reply = data.response || data.error || 'No response';
    out.innerHTML += '<span style="color:#9b59b6">MMC AI: </span>' + esc(reply) + '\n\n';
  } catch(e) {
    out.innerHTML += '<span style="color:#e74c3c">Error: </span>' + e.message + '\n\n';
  }
  out.scrollTop = out.scrollHeight;
}

// Clear
function clearOutput() {
  document.getElementById('output-run').innerHTML = '';
  document.getElementById('output-py').textContent = '';
  document.getElementById('output-ai').innerHTML = '';
}

// File ops
function loadFile() { document.getElementById('file-input').click(); }
function handleFile(e) { const f = e.target.files[0]; if(f) { const r = new FileReader(); r.onload = ev => { editor.value = ev.target.result; }; r.readAsText(f); } }
function saveFile() { const b = new Blob([editor.value], {type:'text/plain'}); const a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = 'code.mmc'; a.click(); }

// Line count
editor.addEventListener('input', updateLineCount);
function updateLineCount() { const lines = editor.value.split('\n').length; document.getElementById('line-count').textContent = 'Line: ' + lines; }

// Tab key
editor.addEventListener('keydown', e => { if(e.key === 'Tab') { e.preventDefault(); const s = editor.selectionStart; editor.value = editor.value.substring(0,s) + '    ' + editor.value.substring(editor.selectionEnd); editor.selectionStart = editor.selectionEnd = s + 4; }});

// ESC HTML
function esc(s) { const d = document.createElement('div'); d.textContent = s; return d.innerHTML; }

// Check Ollama
async function checkOllama() {
  try {
    const res = await fetch('/api/ollama-status');
    const data = await res.json();
    const dot = document.getElementById('ollama-dot');
    const status = document.getElementById('ollama-status');
    if (data.running) {
      dot.className = 'status-dot dot-green';
      status.textContent = 'Ollama: ' + (data.model || 'Ready');
    } else {
      dot.className = 'status-dot dot-red';
      status.textContent = 'Ollama: Not running';
    }
    document.getElementById('server-info').textContent = 'MMC AI Server Connected | ' + (data.platform || '');
  } catch(e) {
    document.getElementById('ollama-dot').className = 'status-dot dot-yellow';
    document.getElementById('ollama-status').textContent = 'Connecting...';
  }
}

checkOllama();
setInterval(checkOllama, 10000);
</script>
</body>
</html>"""


class MMCHandler(SimpleHTTPRequestHandler):
    """HTTP request handler for MMC AI IDE."""

    def log_message(self, format, *args):
        pass  # Suppress default logging

    def do_GET(self):
        if self.path == '/' or self.path == '/index.html':
            self._send_html(HTML_IDE)
        elif self.path == '/api/ollama-status':
            self._send_json(self._ollama_status())
        else:
            self.send_error(404)

    def do_POST(self):
        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length)

        try:
            data = json.loads(body) if body else {}
        except json.JSONDecodeError:
            self._send_json({"error": "Invalid JSON"}, 400)
            return

        if self.path == '/api/run':
            self._handle_run(data)
        elif self.path == '/api/python':
            self._handle_python(data)
        elif self.path == '/api/ai':
            self._handle_ai(data)
        else:
            self.send_error(404)

    def _handle_run(self, data):
        code = data.get('code', '')
        if not code:
            self._send_json({"error": "Code is empty"}, 400)
            return

        try:
            stdout, stderr, exit_code, py_code = run_mmc_code(code)
            response = {
                "output": stdout,
                "error": stderr if exit_code != 0 else None,
                "exit_code": exit_code,
                "python": py_code,
            }
            self._send_json(response)
        except Exception as e:
            self._send_json({"error": str(e)}, 500)

    def _handle_python(self, data):
        code = data.get('code', '')
        if not code:
            self._send_json({"error": "Code is empty"}, 400)
            return

        try:
            py_code = mmc_to_python(code)
            self._send_json({"python": py_code})
        except Exception as e:
            self._send_json({"error": str(e)}, 500)

    def _handle_ai(self, data):
        prompt = data.get('prompt', '')
        code = data.get('code', '')

        if not prompt:
            self._send_json({"error": "Prompt is empty"}, 400)
            return

        full_prompt = prompt
        if code:
            full_prompt = f"Current MMC Code:\n```mmc\n{code}\n```\n\nQuestion: {prompt}"

        response = call_ollama(full_prompt, system=MMC_SYSTEM_PROMPT)

        if response.startswith("AI Error:"):
            self._send_json({"error": response}, 500)
        else:
            self._send_json({"response": response})

    def _ollama_status(self):
        try:
            import urllib.request
            req = urllib.request.Request("http://localhost:11434/api/tags")
            with urllib.request.urlopen(req, timeout=3) as resp:
                data = json.loads(resp.read())
                models = [m.get('name', '') for m in data.get('models', [])]
                mmc_model = None
                for m in models:
                    if 'mmc' in m.lower() or 'myanmar' in m.lower():
                        mmc_model = m
                        break
                return {
                    "running": True,
                    "models": models,
                    "model": mmc_model or models[0] if models else None,
                    "platform": "Termux" if os.environ.get('TERMUX_VERSION') else sys.platform,
                }
        except Exception:
            return {"running": False, "platform": sys.platform}

    def _send_html(self, html):
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Content-Length', len(html.encode('utf-8')))
        self.end_headers()
        self.wfile.write(html.encode('utf-8'))

    def _send_json(self, data, status=200):
        body = json.dumps(data, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', len(body))
        self.end_headers()
        self.wfile.write(body)


def main():
    port = int(os.environ.get('MMC_PORT', 8080))
    host = os.environ.get('MMC_HOST', '0.0.0.0')

    print("")
    print("  ============================================")
    print("  MMC AI IDE v3.0")
    print("  Myanmar Code Programming Language")
    print("  ============================================")
    print(f"  URL: http://localhost:{port}")
    print(f"  Host: {host}")
    print(f"  Platform: {'Termux' if os.environ.get('TERMUX_VERSION') else sys.platform}")
    print("")

    # Check Ollama
    try:
        import urllib.request
        req = urllib.request.Request("http://localhost:11434/api/tags")
        with urllib.request.urlopen(req, timeout=3) as resp:
            data = json.loads(resp.read())
            models = [m.get('name', '') for m in data.get('models', [])]
            print(f"  Ollama: Connected ({len(models)} models)")
            for m in models[:5]:
                print(f"    - {m}")
    except Exception:
        print("  Ollama: Not running (AI features disabled)")
        print("  Start Ollama: ollama serve")

    print("")
    print("  Open browser -> http://localhost:" + str(port))
    print("  Press Ctrl+C to stop")
    print("")

    server = HTTPServer((host, port), MMCHandler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n  MMC AI Server stopped.")
        server.server_close()


if __name__ == '__main__':
    main()
