#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MMC Transpiler v3.0
Myanmar Code (MMC) -> Python

Myanmar Code programming language transpiler.
MMC source code is translated to Python and executed.
"""

import re
import sys
import io
import traceback

# ============================================================
# MMC Keywords -> Python Mapping
# ============================================================

KEYWORDS = {
    # Variables
    'ကိန်း': 'var',
    'အတည်': 'const',
    'နေရာ': 'let',

    # Control Flow
    'အကယ်၍': 'if',
    'မဟုတ်ပါက': 'else',
    'မဟုတ်လျှင်': 'elif',

    # Loops
    'အတွက်': 'for',
    'လုပ်နေစဉ်': 'while',
    'ရပ်': 'break',
    'ဆက်လုပ်': 'continue',

    # Functions
    'အဓိပ္ပာယ်': 'def',
    'လုပ်ဆောင်ချက်': 'function',
    'ပြန်ပေး': 'return',

    # Classes
    'အတန်း': 'class',
    'ဒီ': 'self',
    'အထက်': 'super',

    # I/O
    'ပုံနှိပ်': 'print',
    'မေးမြန်း': 'input',

    # Import
    'တင်သွင်း': 'import',
    'မှ': 'from',
    'ကူးယူပါ': 'import',

    # Error Handling
    'ကြိုးစား': 'try',
    'ဖမ်းမိ': 'except',
    'နောက်ဆုံး': 'finally',
    'ချမြှောက်': 'raise',

    # Boolean
    'မှန်': 'True',
    'မှား': 'False',
    'မပါ': 'None',

    # Logic
    'ညီမျှလျှင်': 'and',
    'သို့မဟုတ်': 'or',
    'မဟုတ်': 'not',

    # Comparison
    'တူလျှင်': '==',
    'မတူလျှင်': '!=',
    'ပိုကြီး': '>',
    'ပိုငယ်': '<',
    'ကြီးလျှင်သို့မဟုတ်': '>=',
    'ငယ်လျှင်သို့မဟုတ်': '<=',

    # Async
    'မတူညီ': 'async',
    'မျှော်': 'await',

    # Built-in Functions
    'အရှည်': 'len',
    'ပတ်လမ်း': 'range',
    'ကျပန်း': 'str',
    'အချိန်': 'int',
    'လော့ဂရစ်သမ်': 'float',
    'အရာဝတ္ထု': 'dict',
    'အဘိဓာန်': 'set',
    'ဆိုင်': 'tuple',
    'တန်ဂျင့်': 'bool',
    'ဇယား': 'type',
    'စာရင်း': 'list',
    'သင်္ချာ': 'abs',
    'အမြင့်ဆုံး': 'max',
    'အနိမ့်ဆုံး': 'min',
    'ပေါင်းလုံး': 'sum',
    'ရွေးချယ်': 'sorted',
    'ပြဿနာ': 'map',
    'ကုလသိုက်': 'filter',

    # String Methods (prefix .method())
    'စာလုံးကြီး': '.upper()',
    'စာလုံးသေး': '.lower()',
    'စမြည့်': '.capitalize()',
    'ဆုံးမြည့်': '.title()',
    'စာဆက်': '.join()',
    'စာခွဲ': '.split()',
    'ဖြတ်': '.strip()',
    'အစားထိုး': '.replace()',
    'ရှာဖွေ': '.find()',
    'အမှန်နေ': '.isalpha()',
    'ဂဏန်းဖြစ်': '.isdigit()',

    # List Methods
    'စာရင်းအရှည်': '.append()',
    'စာရင်းအလယ်': '.pop()',
    'ထည့်သွင်း': '.insert()',
    'စီ': '.sort()',
    'ရှင်းလင်း': '.clear()',
    'ပြန်လဲ': '.reverse()',
    'အမြင့်ပြဦး': '.index()',
    'ရှိမရှိ': '.count()',

    # File Operations
    'ဖွင့်': 'open',
    'ဖိုင်ဖတ်': '.read()',
    'ဖိုင်ရေး': '.write()',
    'ဖိုင်ဖျက်': '.close()',
    'ဖိုင်စုံ': '.readlines()',
    'ဖိုင်လမ်း': '.readline()',

    # Math
    'သင်္ချာ_အမြင့်ဆုံး': 'max',
    'သင်္ချာ_အနိမ့်ဆုံး': 'min',
    'သင်္ချာ_ပေါင်းလုံး': 'sum',
}

# Myanmar digits to Arabic digits
MYANMAR_DIGITS = {
    '၀': '0', '၁': '1', '၂': '2', '၃': '3',
    '၄': '4', '၅': '5', '၆': '6', '၇': '7',
    '၈': '8', '၉': '9',
}

# Myanmar punctuation
MYANMAR_PUNCT = {
    '၊': ',',  # Myanmar comma
    '။': '.',  # Myanmar period
    ' semblay': ',',  # visarga - treat as comma
}


class MMCTranspiler:
    """MMC source code to Python transpiler."""

    def __init__(self):
        self.output_lines = []
        self.indent_level = 0
        self.imports = set()

    def translate_digits(self, text):
        """Myanmar digits (၀-၉) -> Arabic digits (0-9)."""
        for myanmar, arabic in MYANMAR_DIGITS.items():
            text = text.replace(myanmar, arabic)
        return text

    def translate_keyword(self, word):
        """MMC keyword -> Python keyword."""
        if word in KEYWORDS:
            return KEYWORDS[word]
        return word

    def tokenize(self, source):
        """MMC source -> token list."""
        tokens = []
        i = 0
        line = 1
        col = 1

        while i < len(source):
            ch = source[i]

            # Newline
            if ch == '\n':
                tokens.append(('NEWLINE', '\n', line, col))
                line += 1
                col = 1
                i += 1
                continue

            # Whitespace
            if ch in ' \t\r':
                i += 1
                col += 1
                continue

            # Comment: # ...
            if ch == '#':
                j = i
                while j < len(source) and source[j] != '\n':
                    j += 1
                comment = source[i:j]
                tokens.append(('COMMENT', comment, line, col))
                col += j - i
                i = j
                continue

            # String literals: "..." or '...'
            if ch in '"\'':
                j = i + 1
                while j < len(source) and source[j] != ch:
                    if source[j] == '\\':
                        j += 1
                    j += 1
                j = min(j + 1, len(source))
                string_val = source[i:j]
                tokens.append(('STRING', string_val, line, col))
                col += j - i
                i = j
                continue

            # Numbers (including Myanmar digits)
            if ch.isdigit() or ch in MYANMAR_DIGITS:
                j = i
                while j < len(source) and (source[j].isdigit() or source[j] in MYANMAR_DIGITS or source[j] == '.'):
                    j += 1
                num_val = source[i:j]
                num_val = self.translate_digits(num_val)
                tokens.append(('NUMBER', num_val, line, col))
                col += j - i
                i = j
                continue

            # Operators
            if ch == '(' :
                tokens.append(('LPAREN', '(', line, col))
                i += 1; col += 1; continue
            if ch == ')':
                tokens.append(('RPAREN', ')', line, col))
                i += 1; col += 1; continue
            if ch == ':':
                tokens.append(('COLON', ':', line, col))
                i += 1; col += 1; continue
            if ch == '+':
                if i + 1 < len(source) and source[i+1] == '=':
                    tokens.append(('PLUSEQ', '+=', line, col))
                    i += 2; col += 2
                else:
                    tokens.append(('PLUS', '+', line, col))
                    i += 1; col += 1
                continue
            if ch == '-':
                if i + 1 < len(source) and source[i+1] == '=':
                    tokens.append(('MINUSEQ', '-=', line, col))
                    i += 2; col += 2
                else:
                    tokens.append(('MINUS', '-', line, col))
                    i += 1; col += 1
                continue
            if ch == '*':
                if i + 1 < len(source) and source[i+1] == '*':
                    tokens.append(('POWER', '**', line, col))
                    i += 2; col += 2
                else:
                    tokens.append(('STAR', '*', line, col))
                    i += 1; col += 1
                continue
            if ch == '/':
                if i + 1 < len(source) and source[i+1] == '/':
                    tokens.append(('DOUBLESLASH', '//', line, col))
                    i += 2; col += 2
                else:
                    tokens.append(('SLASH', '/', line, col))
                    i += 1; col += 1
                continue
            if ch == '%':
                tokens.append(('PERCENT', '%', line, col))
                i += 1; col += 1; continue
            if ch == '=':
                if i + 1 < len(source) and source[i+1] == '=':
                    tokens.append(('EQ', '==', line, col))
                    i += 2; col += 2
                else:
                    tokens.append(('ASSIGN', '=', line, col))
                    i += 1; col += 1
                continue
            if ch == '!':
                if i + 1 < len(source) and source[i+1] == '=':
                    tokens.append(('NEQ', '!=', line, col))
                    i += 2; col += 2
                else:
                    tokens.append(('BANG', '!', line, col))
                    i += 1; col += 1
                continue
            if ch == '>':
                if i + 1 < len(source) and source[i+1] == '=':
                    tokens.append(('GTE', '>=', line, col))
                    i += 2; col += 2
                else:
                    tokens.append(('GT', '>', line, col))
                    i += 1; col += 1
                continue
            if ch == '<':
                if i + 1 < len(source) and source[i+1] == '=':
                    tokens.append(('LTE', '<=', line, col))
                    i += 2; col += 2
                else:
                    tokens.append(('LT', '<', line, col))
                    i += 1; col += 1
                continue
            if ch == '[':
                tokens.append(('LBRACKET', '[', line, col))
                i += 1; col += 1; continue
            if ch == ']':
                tokens.append(('RBRACKET', ']', line, col))
                i += 1; col += 1; continue
            if ch == '{':
                tokens.append(('LBRACE', '{', line, col))
                i += 1; col += 1; continue
            if ch == '}':
                tokens.append(('RBRACE', '}', line, col))
                i += 1; col += 1; continue
            if ch == ',':
                tokens.append(('COMMA', ',', line, col))
                i += 1; col += 1; continue
            if ch == '.':
                tokens.append(('DOT', '.', line, col))
                i += 1; col += 1; continue

            # Identifiers / Myanmar words
            if (ch.isalpha() or ch == '_' or ord(ch) > 0x1000):
                j = i
                while j < len(source) and (
                    source[j].isalnum() or source[j] == '_' or
                    ord(source[j]) > 0x1000 or source[j] in MYANMAR_DIGITS
                ):
                    j += 1
                word = source[i:j]
                tokens.append(('WORD', word, line, col))
                col += j - i
                i = j
                continue

            # Unknown character - skip
            tokens.append(('UNKNOWN', ch, line, col))
            i += 1
            col += 1

        return tokens

    def tokens_to_python(self, tokens):
        """Token list -> Python source code."""
        lines = []
        current_line_tokens = []
        indent_stack = [0]
        paren_depth = 0
        in_function_def = False
        in_class_def = False
        in_import = False
        skip_next_colon = False

        for idx, (ttype, tval, tline, tcol) in enumerate(tokens):
            # Collect tokens per line
            if ttype == 'NEWLINE':
                line_str = self._process_line_tokens(current_line_tokens, indent_stack, in_function_def, in_class_def)
                if line_str is not None:
                    lines.append(line_str)
                current_line_tokens = []
                in_function_def = False
                in_class_def = False
                in_import = False
                continue

            if ttype == 'COMMENT':
                current_line_tokens.append(('COMMENT', tval))
                continue

            current_line_tokens.append((ttype, tval))

        # Process remaining tokens
        if current_line_tokens:
            line_str = self._process_line_tokens(current_line_tokens, indent_stack, in_function_def, in_class_def)
            if line_str is not None:
                lines.append(line_str)

        return '\n'.join(lines)

    def _process_line_tokens(self, tokens, indent_stack, in_function_def, in_class_def):
        """Process one line of tokens and return Python code string."""
        if not tokens:
            return None

        indent = '    ' * indent_stack[-1]

        # Check for comment-only line
        if len(tokens) == 1 and tokens[0][0] == 'COMMENT':
            return '    ' * indent_stack[-1] + tokens[0][1]

        # Check for blank/comment line
        result_parts = []
        i = 0
        is_var_decl = False
        is_def = False
        is_class = False
        is_import = False
        is_dedent = False

        while i < len(tokens):
            ttype, tval = tokens[i]

            # Comments at end of line
            if ttype == 'COMMENT':
                result_parts.append(tval)
                i += 1
                continue

            if ttype == 'WORD':
                translated = self.translate_keyword(tval)

                # Variable declarations: ကိန်း, နေရာ -> just skip (Python doesn't need var/let)
                if tval in ('ကိန်း', 'နေရာ', 'အတည်'):
                    is_var_decl = True
                    # Check if next token is ASSIGN
                    if i + 1 < len(tokens) and tokens[i + 1][0] == 'ASSIGN':
                        # Skip the var/let/const keyword
                        i += 1
                        continue

                # Function definition
                elif tval == 'အဓိပ္ပာယ်':
                    is_def = True
                    result_parts.append('def')
                    i += 1
                    continue

                # Class definition
                elif tval == 'အတန်း':
                    is_class = True
                    result_parts.append('class')
                    i += 1
                    continue

                # Import
                elif tval in ('တင်သွင်း', 'ကူးယူပါ'):
                    is_import = True
                    result_parts.append('import')
                    i += 1
                    continue

                elif tval == 'မှ':
                    is_import = True
                    result_parts.append('from')
                    i += 1
                    continue

                # Boolean
                elif tval == 'မှန်':
                    result_parts.append('True')
                    i += 1
                    continue
                elif tval == 'မှား':
                    result_parts.append('False')
                    i += 1
                    continue
                elif tval == 'မပါ':
                    result_parts.append('None')
                    i += 1
                    continue

                # Self
                elif tval == 'ဒီ':
                    result_parts.append('self')
                    i += 1
                    continue

                # Super
                elif tval == 'အထက်':
                    result_parts.append('super()')
                    i += 1
                    continue

                # Other keywords
                elif translated != tval:
                    result_parts.append(translated)
                    i += 1
                    continue

                else:
                    # Keep as-is (function name, variable name, etc.)
                    result_parts.append(tval)
                    i += 1
                    continue

            elif ttype == 'NUMBER':
                result_parts.append(tval)
                i += 1
                continue

            elif ttype == 'STRING':
                result_parts.append(tval)
                i += 1
                continue

            elif ttype == 'ASSIGN':
                result_parts.append('=')
                i += 1
                continue

            elif ttype == 'EQ':
                result_parts.append('==')
                i += 1
                continue

            elif ttype == 'NEQ':
                result_parts.append('!=')
                i += 1
                continue

            elif ttype == 'PLUS':
                result_parts.append('+')
                i += 1
                continue

            elif ttype == 'MINUS':
                result_parts.append('-')
                i += 1
                continue

            elif ttype == 'STAR':
                result_parts.append('*')
                i += 1
                continue

            elif ttype == 'POWER':
                result_parts.append('**')
                i += 1
                continue

            elif ttype == 'SLASH':
                result_parts.append('/')
                i += 1
                continue

            elif ttype == 'DOUBLESLASH':
                result_parts.append('//')
                i += 1
                continue

            elif ttype == 'PERCENT':
                result_parts.append('%')
                i += 1
                continue

            elif ttype == 'PLUSEQ':
                result_parts.append('+=')
                i += 1
                continue

            elif ttype == 'MINUSEQ':
                result_parts.append('-=')
                i += 1
                continue

            elif ttype == 'GT':
                result_parts.append('>')
                i += 1
                continue

            elif ttype == 'LT':
                result_parts.append('<')
                i += 1
                continue

            elif ttype == 'GTE':
                result_parts.append('>=')
                i += 1
                continue

            elif ttype == 'LTE':
                result_parts.append('<=')
                i += 1
                continue

            elif ttype == 'LPAREN':
                result_parts.append('(')
                i += 1
                continue

            elif ttype == 'RPAREN':
                result_parts.append(')')
                i += 1
                continue

            elif ttype == 'LBRACKET':
                result_parts.append('[')
                i += 1
                continue

            elif ttype == 'RBRACKET':
                result_parts.append(']')
                i += 1
                continue

            elif ttype == 'COLON':
                result_parts.append(':')
                i += 1
                continue

            elif ttype == 'COMMA':
                result_parts.append(',')
                i += 1
                continue

            elif ttype == 'DOT':
                result_parts.append('.')
                i += 1
                continue

            elif ttype == 'BANG':
                result_parts.append('not ')
                i += 1
                continue

            elif ttype == 'LBRACE':
                # Skip { - Python uses indentation
                i += 1
                continue

            elif ttype == 'RBRACE':
                # Skip } - handle dedent
                if len(indent_stack) > 1:
                    indent_stack.pop()
                i += 1
                return None  # Don't output a line for just }

            else:
                result_parts.append(str(tval))
                i += 1
                continue

        line_code = indent + ' '.join(result_parts)

        # Handle indentation changes
        if is_def or is_class:
            indent_stack.append(indent_stack[-1] + 1)

        return line_code

    def transpile(self, source):
        """MMC source -> Python source."""
        tokens = self.tokenize(source)
        python_code = self.tokens_to_python(tokens)
        return python_code

    def run(self, source, timeout=10):
        """
        MMC source -> Execute -> (stdout, stderr, exit_code).
        """
        python_code = self.transpile(source)

        # Capture stdout
        old_stdout = sys.stdout
        old_stderr = sys.stderr
        sys.stdout = captured_stdout = io.StringIO()
        sys.stderr = captured_stderr = io.StringIO()

        exit_code = 0
        try:
            # Use exec to run the generated Python code
            exec_globals = {
                '__builtins__': __builtins__,
                '__name__': '__mmc__',
            }
            exec(python_code, exec_globals)
        except SystemExit as e:
            exit_code = e.code if e.code else 0
        except Exception as e:
            exit_code = 1
            captured_stderr.write(f"{type(e).__name__}: {e}\n")
            captured_stderr.write(traceback.format_exc())
        finally:
            sys.stdout = old_stdout
            sys.stderr = old_stderr

        return captured_stdout.getvalue(), captured_stderr.getvalue(), exit_code, python_code


def main():
    """MMC transpiler CLI."""
    if len(sys.argv) < 2:
        print("MMC Transpiler v3.0")
        print("Myanmar Code Programming Language")
        print("")
        print("Usage:")
        print("  python mmc_transpiler.py run <file.mmc>    Run MMC code")
        print("  python mmc_transpiler.py compile <file.mmc>  Show Python output")
        print("")
        sys.exit(1)

    command = sys.argv[1]

    if command == 'run':
        if len(sys.argv) < 3:
            print("Error: Please specify MMC file path.")
            sys.exit(1)

        filepath = sys.argv[2]
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                source = f.read()
        except FileNotFoundError:
            print(f"Error: File not found - {filepath}")
            sys.exit(1)
        except Exception as e:
            print(f"Error: {e}")
            sys.exit(1)

        transpiler = MMCTranspiler()
        stdout, stderr, exit_code, py_code = transpiler.run(source)

        if stdout:
            print(stdout, end='')
        if stderr:
            print(stderr, end='')
        sys.exit(exit_code)

    elif command == 'compile':
        if len(sys.argv) < 3:
            print("Error: Please specify MMC file path.")
            sys.exit(1)

        filepath = sys.argv[2]
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                source = f.read()
        except FileNotFoundError:
            print(f"Error: File not found - {filepath}")
            sys.exit(1)
        except Exception as e:
            print(f"Error: {e}")
            sys.exit(1)

        transpiler = MMCTranspiler()
        py_code = transpiler.transpile(source)
        print("--- MMC -> Python ---")
        print(py_code)
        print("--- End ---")

    else:
        print(f"Error: Unknown command '{command}'")
        print("Available commands: run, compile")
        sys.exit(1)


if __name__ == '__main__':
    main()
