#!/usr/bin/env bash
# ================================================================
#   MMC AI Binary v3.0 - Termux / PC Install Script
#   Myanmar Code Programming Language AI Environment
#   Copy this entire script and paste into terminal
# ================================================================
# HOW TO USE:
#   1. Copy everything below the "START" line
#   2. Paste into Termux terminal
#   3. Press Enter - everything installs automatically
# ================================================================

echo ""
echo "  ============================================"
echo "  MMC AI Binary v3.0"
echo "  Myanmar Code Programming Language"
echo "  ============================================"
echo ""

# Create project directory
mkdir -p ~/mmc-ai
cd ~/mmc-ai

echo "  [1/4] Installing Python..."
if command -v python3 &> /dev/null; then
    echo "  [OK] Python3 already installed"
else
    if [ -n "$TERMUX_VERSION" ]; then
        pkg update -y && pkg install python -y
    else
        sudo apt update -y && sudo apt install python3 python3-pip -y 2>/dev/null || \
        brew install python3 2>/dev/null
    fi
fi

echo ""
echo "  [2/4] Checking Ollama..."
if command -v ollama &> /dev/null; then
    echo "  [OK] Ollama already installed"
else
    echo "  Installing Ollama..."
    if [ -n "$TERMUX_VERSION" ]; then
        pkg install ollama -y 2>/dev/null || {
            echo "  Trying curl install..."
            curl -fsSL https://ollama.com/install.sh | sh
        }
    else
        curl -fsSL https://ollama.com/install.sh | sh
    fi
fi

echo ""
echo "  [3/4] Starting Ollama..."
if curl -s http://localhost:11434/api/tags > /dev/null 2>&1; then
    echo "  [OK] Ollama is already running"
else
    ollama serve > /dev/null 2>&1 &
    echo "  Waiting for Ollama to start..."
    sleep 3
fi

echo ""
echo "  [4/4] Downloading AI model (Qwen2.5 1.5B)..."
ollama pull qwen2.5:1.5b 2>/dev/null

echo ""
echo "  Creating MMC AI model..."
ollama create mmc-ai -f - <<'MODELEOF'
FROM qwen2.5:1.5b

PARAMETER temperature 0.6
PARAMETER num_ctx 4096
PARAMETER repeat_penalty 1.15
PARAMETER stop "<|im_end|>"
PARAMETER stop "</s>"

SYSTEM """You are MMC AI (Myanmar Code AI Assistant) v3.0.

MMC (Myanmar Code) Programming Language Keywords:
- Variables: ကိန်း (var), အတည် (const), နေရာ (let)
- Control: အကယ်၍ (if), မဟုတ်ပါက (else), မဟုတ်လျှင် (elif)
- Loops: အတွက် (for), လုပ်နေစဉ် (while), ရပ် (break), ဆက်လုပ် (continue)
- Functions: အဓိပ္ပာယ် (def), လုပ်ဆောင်ချက် (function), ပြန်ပေး (return)
- Classes: အတန်း (class), ဒီ (self), အထက် (super)
- I/O: ပုံနှိပ် (print), မေးမြန်း (input)
- Import: တင်သွင်း (import), မှ (from)
- Boolean: မှန် (True), မှား (False), မပါ (None)
- Logic: ညီမျှလျှင် (and), သို့မဟုတ် (or), မဟုတ် (not)
- Error: ကြိုးစား (try), ဖမ်းမိ (except), နောက်ဆုံး (finally)
- Numbers: ၀-၉ = 0-9
- Operators: + - * / ** // % = == != > < >= <= += -=

Rules:
- Respond in Myanmar language
- Use ```mmc for MMC code blocks
- Write correct MMC code that works
- Show Python equivalent when translating
- Be helpful and clear"""
MODELEOF

echo ""
echo "  ============================================"
echo "  Installation Complete!"
echo "  ============================================"
echo ""
echo "  To start MMC AI IDE:"
echo "    cd ~/mmc-ai"
echo "    python mmc_ai_server.py"
echo ""
echo "  Then open browser:"
echo "    http://localhost:8080"
echo ""
echo "  AI chat (no browser needed):"
echo "    ollama run mmc-ai"
echo ""
